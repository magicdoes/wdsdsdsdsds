/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.milkbowl.vault.economy.AbstractEconomy
 *  net.milkbowl.vault.economy.EconomyResponse
 *  net.milkbowl.vault.economy.EconomyResponse$ResponseType
 *  org.bukkit.OfflinePlayer
 */
package com.bx.magicSmp.hooks;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.managers.CurrencyManager;
import com.bx.magicSmp.managers.EconomyManager;
import com.bx.magicSmp.models.EconomyReason;
import com.bx.magicSmp.models.EconomyTransactionResult;
import java.util.List;
import net.milkbowl.vault.economy.AbstractEconomy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;

public class VaultEconomyHook
extends AbstractEconomy {
    private final MagicSmp plugin;

    public VaultEconomyHook(MagicSmp plugin) {
        this.plugin = plugin;
    }

    public boolean isEnabled() {
        return this.plugin.isEnabled();
    }

    public String getName() {
        return this.plugin.getDescription().getName();
    }

    public boolean hasBankSupport() {
        return false;
    }

    public int fractionalDigits() {
        return 2;
    }

    public String format(double amount) {
        return this.plugin.getCurrencyManager().formatMoney(amount);
    }

    public String currencyNamePlural() {
        return this.plugin.getCurrencyManager().plural(CurrencyManager.CurrencyType.MONEY);
    }

    public String currencyNameSingular() {
        return this.plugin.getCurrencyManager().singular(CurrencyManager.CurrencyType.MONEY);
    }

    public boolean hasAccount(String playerName) {
        return this.plugin.getEconomyManager().resolveAccount(playerName) != null;
    }

    public boolean hasAccount(OfflinePlayer player) {
        return this.plugin.getEconomyManager().hasAccount(player);
    }

    public boolean hasAccount(String playerName, String worldName) {
        return this.hasAccount(playerName);
    }

    public boolean hasAccount(OfflinePlayer player, String worldName) {
        return this.hasAccount(player);
    }

    public double getBalance(String playerName) {
        EconomyManager.AccountReference account = this.plugin.getEconomyManager().resolveAccount(playerName);
        return account == null ? 0.0 : this.plugin.getEconomyManager().getBalance(account.uuid());
    }

    public double getBalance(OfflinePlayer player) {
        return this.plugin.getEconomyManager().getBalance(player);
    }

    public double getBalance(String playerName, String world) {
        return this.getBalance(playerName);
    }

    public double getBalance(OfflinePlayer player, String world) {
        return this.getBalance(player);
    }

    public boolean has(String playerName, double amount) {
        EconomyManager.AccountReference account = this.plugin.getEconomyManager().resolveAccount(playerName);
        return account != null && this.plugin.getEconomyManager().has(account.uuid(), amount);
    }

    public boolean has(OfflinePlayer player, double amount) {
        return this.plugin.getEconomyManager().has(player, amount);
    }

    public boolean has(String playerName, String worldName, double amount) {
        return this.has(playerName, amount);
    }

    public boolean has(OfflinePlayer player, String worldName, double amount) {
        return this.has(player, amount);
    }

    public EconomyResponse withdrawPlayer(String playerName, double amount) {
        EconomyManager.AccountReference account = this.plugin.getEconomyManager().resolveAccount(playerName);
        if (account == null) {
            return this.failureResponse(amount, 0.0, "Player account not found.");
        }
        EconomyTransactionResult result = this.plugin.getEconomyManager().withdraw(account, amount, EconomyReason.AUCTION_PURCHASE);
        return this.toResponse(result);
    }

    public EconomyResponse withdrawPlayer(OfflinePlayer player, double amount) {
        return this.toResponse(this.plugin.getEconomyManager().withdraw(player, amount, EconomyReason.AUCTION_PURCHASE));
    }

    public EconomyResponse withdrawPlayer(String playerName, String worldName, double amount) {
        return this.withdrawPlayer(playerName, amount);
    }

    public EconomyResponse withdrawPlayer(OfflinePlayer player, String worldName, double amount) {
        return this.withdrawPlayer(player, amount);
    }

    public EconomyResponse depositPlayer(String playerName, double amount) {
        EconomyManager.AccountReference account = this.plugin.getEconomyManager().resolveAccount(playerName);
        if (account == null) {
            return this.failureResponse(amount, 0.0, "Player account not found.");
        }
        EconomyTransactionResult result = this.plugin.getEconomyManager().deposit(account, amount, EconomyReason.SELL_PAYOUT);
        return this.toResponse(result);
    }

    public EconomyResponse depositPlayer(OfflinePlayer player, double amount) {
        return this.toResponse(this.plugin.getEconomyManager().deposit(player, amount, EconomyReason.SELL_PAYOUT));
    }

    public EconomyResponse depositPlayer(String playerName, String worldName, double amount) {
        return this.depositPlayer(playerName, amount);
    }

    public EconomyResponse depositPlayer(OfflinePlayer player, String worldName, double amount) {
        return this.depositPlayer(player, amount);
    }

    public EconomyResponse createBank(String name, String player) {
        return this.bankUnsupported();
    }

    public EconomyResponse createBank(String name, OfflinePlayer player) {
        return this.bankUnsupported();
    }

    public EconomyResponse deleteBank(String name) {
        return this.bankUnsupported();
    }

    public EconomyResponse bankBalance(String name) {
        return this.bankUnsupported();
    }

    public EconomyResponse bankHas(String name, double amount) {
        return this.bankUnsupported();
    }

    public EconomyResponse bankWithdraw(String name, double amount) {
        return this.bankUnsupported();
    }

    public EconomyResponse bankDeposit(String name, double amount) {
        return this.bankUnsupported();
    }

    public EconomyResponse isBankOwner(String name, String playerName) {
        return this.bankUnsupported();
    }

    public EconomyResponse isBankOwner(String name, OfflinePlayer player) {
        return this.bankUnsupported();
    }

    public EconomyResponse isBankMember(String name, String playerName) {
        return this.bankUnsupported();
    }

    public EconomyResponse isBankMember(String name, OfflinePlayer player) {
        return this.bankUnsupported();
    }

    public List<String> getBanks() {
        return List.of();
    }

    public boolean createPlayerAccount(String playerName) {
        EconomyManager.AccountReference account = this.plugin.getEconomyManager().resolveAccount(playerName);
        return account != null || this.plugin.getEconomyManager().createPlayerAccount(Bukkit.getOfflinePlayer((String)playerName));
    }

    public boolean createPlayerAccount(OfflinePlayer player) {
        return this.plugin.getEconomyManager().createPlayerAccount(player);
    }

    public boolean createPlayerAccount(String playerName, String worldName) {
        return this.createPlayerAccount(playerName);
    }

    public boolean createPlayerAccount(OfflinePlayer player, String worldName) {
        return this.createPlayerAccount(player);
    }

    private EconomyResponse toResponse(EconomyTransactionResult result) {
        if (result.success()) {
            return new EconomyResponse(result.amount(), result.afterBalance(), EconomyResponse.ResponseType.SUCCESS, null);
        }
        return this.failureResponse(result.amount(), result.beforeBalance(), result.failureReason().name());
    }

    private EconomyResponse failureResponse(double amount, double balance, String message) {
        return new EconomyResponse(amount, balance, EconomyResponse.ResponseType.FAILURE, message);
    }

    private EconomyResponse bankUnsupported() {
        return new EconomyResponse(0.0, 0.0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "Bank support is not implemented.");
    }
}

