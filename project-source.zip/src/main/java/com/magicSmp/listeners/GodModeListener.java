/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Sound
 *  org.bukkit.SoundCategory
 *  org.bukkit.enchantments.Enchantment
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.LivingEntity
 *  org.bukkit.entity.Projectile
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.entity.EntityDamageByEntityEvent
 *  org.bukkit.event.entity.EntityDamageEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 *  org.bukkit.inventory.EntityEquipment
 *  org.bukkit.projectiles.ProjectileSource
 *  org.bukkit.util.Vector
 */
package com.bx.magicSmp.listeners;

import com.bx.magicSmp.MagicSmp;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.projectiles.ProjectileSource;
import org.bukkit.util.Vector;

public class GodModeListener
implements Listener {
    private static final double BASE_ENTITY_KNOCKBACK = 0.4;
    private static final double BASE_PROJECTILE_KNOCKBACK = 0.35;
    private static final double EXTRA_KNOCKBACK_PER_LEVEL = 0.2;
    private static final double SPRINT_KNOCKBACK_BONUS = 0.15;
    private static final double VERTICAL_KNOCKBACK = 0.36;
    private static final double MIN_DIRECTION_LENGTH = 1.0E-4;
    private final MagicSmp plugin;

    public GodModeListener(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onDamage(EntityDamageEvent event) {
        Entity entity = event.getEntity();
        if (!(entity instanceof Player)) {
            return;
        }
        Player player = (Player)entity;
        if (!this.plugin.getGodModeManager().isInGodMode(player.getUniqueId())) {
            return;
        }
        if (event.isCancelled()) {
            return;
        }
        double originalDamage = event.getDamage();
        event.setDamage(0.0);
        if (originalDamage > 0.0) {
            this.playDamageFeedback(player, event);
            this.applyKnockback(player, event);
        }
    }

    @EventHandler(priority=EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) {
        this.plugin.getGodModeManager().clear(event.getPlayer().getUniqueId());
    }

    private void playDamageFeedback(Player player, EntityDamageEvent event) {
        player.playHurtAnimation(this.resolveHurtYaw(player, event));
        Sound hurtSound = player.getHurtSound();
        if (hurtSound != null) {
            player.getWorld().playSound(player.getLocation(), hurtSound, SoundCategory.PLAYERS, 1.0f, 1.0f);
        }
    }

    private void applyKnockback(Player player, EntityDamageEvent event) {
        Player attacker;
        if (!(event instanceof EntityDamageByEntityEvent)) {
            return;
        }
        EntityDamageByEntityEvent damageByEntity = (EntityDamageByEntityEvent)event;
        Entity damager = damageByEntity.getDamager();
        Vector direction = this.resolveKnockbackDirection(player, damager);
        if (direction == null) {
            return;
        }
        double horizontalStrength = damager instanceof Projectile ? 0.35 : 0.4;
        horizontalStrength += (double)this.resolveKnockbackLevel(damager) * 0.2;
        if (damager instanceof Player && (attacker = (Player)damager).isSprinting()) {
            horizontalStrength += 0.15;
        }
        Vector velocity = direction.multiply(horizontalStrength);
        velocity.setY(Math.max(player.getVelocity().getY(), 0.36));
        player.setVelocity(velocity);
    }

    private Vector resolveKnockbackDirection(Player player, Entity damager) {
        if (damager instanceof Projectile) {
            Projectile projectile = (Projectile)damager;
            Vector projectileVelocity = projectile.getVelocity();
            Vector projectileDirection = new Vector(projectileVelocity.getX(), 0.0, projectileVelocity.getZ());
            if (projectileDirection.lengthSquared() > 1.0E-4) {
                return projectileDirection.normalize();
            }
            ProjectileSource projectileSource = projectile.getShooter();
            if (projectileSource instanceof Entity) {
                Entity shooter = (Entity)projectileSource;
                return this.directionFrom(player, shooter);
            }
        }
        return this.directionFrom(player, damager);
    }

    private Vector directionFrom(Player player, Entity source) {
        Vector direction = player.getLocation().toVector().subtract(source.getLocation().toVector());
        direction.setY(0.0);
        if (direction.lengthSquared() <= 1.0E-4) {
            direction = player.getLocation().getDirection().setY(0.0).multiply(-1.0);
        }
        return direction.lengthSquared() > 1.0E-4 ? direction.normalize() : null;
    }

    private int resolveKnockbackLevel(Entity damager) {
        Projectile projectile;
        ProjectileSource projectileSource;
        if (damager instanceof Projectile && (projectileSource = (projectile = (Projectile)damager).getShooter()) instanceof LivingEntity) {
            LivingEntity shooter = (LivingEntity)projectileSource;
            return this.getEnchantmentLevel(shooter, Enchantment.PUNCH);
        }
        if (damager instanceof LivingEntity) {
            LivingEntity livingEntity = (LivingEntity)damager;
            return this.getEnchantmentLevel(livingEntity, Enchantment.KNOCKBACK);
        }
        return 0;
    }

    private int getEnchantmentLevel(LivingEntity entity, Enchantment enchantment) {
        EntityEquipment equipment = entity.getEquipment();
        if (equipment == null) {
            return 0;
        }
        ItemStack item = equipment.getItemInMainHand();
        return item == null ? 0 : item.getEnchantmentLevel(enchantment);
    }

    private float resolveHurtYaw(Player player, EntityDamageEvent event) {
        if (!(event instanceof EntityDamageByEntityEvent)) {
            return player.getLocation().getYaw();
        }
        EntityDamageByEntityEvent damageByEntity = (EntityDamageByEntityEvent)event;
        Entity damager = damageByEntity.getDamager();
        double x = damager.getLocation().getX() - player.getLocation().getX();
        double z = damager.getLocation().getZ() - player.getLocation().getZ();
        return (float)Math.toDegrees(Math.atan2(-x, z));
    }
}

