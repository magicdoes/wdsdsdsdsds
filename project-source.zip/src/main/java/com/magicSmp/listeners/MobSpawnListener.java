/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.EntityType
 *  org.bukkit.entity.LivingEntity
 *  org.bukkit.event.entity.CreatureSpawnEvent$SpawnReason
 */
package com.bx.magicSmp.listeners;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.models.PlayerData;
import com.bx.magicSmp.utils.MobSpawnPolicy;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;

public class MobSpawnListener
implements Listener {
    private final MagicSmp plugin;

    public MobSpawnListener(MagicSmp plugin) {
        this.plugin = plugin;
        this.startCleanupTask();
    }

    @EventHandler(ignoreCancelled=true)
    public void onMobSpawn(CreatureSpawnEvent event) {
        LivingEntity livingEntity = event.getEntity();
        if (!(livingEntity instanceof LivingEntity)) {
            return;
        }
        LivingEntity entity = livingEntity;
        if (MobSpawnPolicy.hasCustomName(entity)) {
            return;
        }
        if (event.getEntityType() == EntityType.PHANTOM) {
            if (this.isPreventableSpawnReason(event.getSpawnReason()) && this.shouldCancelPhantomSpawn(entity.getLocation())) {
                event.setCancelled(true);
            }
            return;
        }
        if (!MobSpawnPolicy.isHostileMob(entity)) {
            return;
        }
        if (this.isPreventableSpawnReason(event.getSpawnReason()) && this.shouldCancelMobSpawn(entity.getLocation())) {
            event.setCancelled(true);
            return;
        }
        if (MobSpawnPolicy.isVanillaSpawnerSpawn(event.getSpawnReason())) {
            MobSpawnPolicy.markVanillaSpawnerMob(this.plugin, entity);
        }
    }

    private boolean shouldCancelPhantomSpawn(Location location) {
        Player nearestPlayer = this.getNearestPlayer2D(location, this.plugin.getConfigManager().getConfig().getDouble("SETTINGS.PHANTOM-SPAWN-RADIUS", 40.0));
        if (nearestPlayer == null) {
            return false;
        }
        PlayerData data = this.plugin.getPlayerDataManager().get(nearestPlayer);
        return data != null && !data.isPhantomEnabled();
    }

    private boolean shouldCancelMobSpawn(Location location) {
        Player nearestPlayer = this.getNearestPlayer(location, this.plugin.getConfigManager().getConfig().getDouble("SETTINGS.MOB-SPAWN-RADIUS", 50.0));
        if (nearestPlayer == null) {
            return false;
        }
        PlayerData data = this.plugin.getPlayerDataManager().get(nearestPlayer);
        return data != null && !data.isMobSpawnEnabled();
    }

    private boolean isPreventableSpawnReason(CreatureSpawnEvent.SpawnReason reason) {
        if (reason == null) {
            return false;
        }
        return switch (reason) {
            case CreatureSpawnEvent.SpawnReason.CUSTOM, CreatureSpawnEvent.SpawnReason.SPAWNER_EGG, CreatureSpawnEvent.SpawnReason.BUILD_WITHER, CreatureSpawnEvent.SpawnReason.BREEDING -> false;
            default -> true;
        };
    }

    private Player getNearestPlayer(Location location, double radius) {
        double radiusSquared = radius * radius;
        Player nearestPlayer = null;
        double nearestDistance = radiusSquared;
        for (Player player : location.getWorld().getPlayers()) {
            double distance = player.getLocation().distanceSquared(location);
            if (distance > radiusSquared || distance >= nearestDistance) continue;
            nearestPlayer = player;
            nearestDistance = distance;
        }
        return nearestPlayer;
    }

    private Player getNearestPlayer2D(Location location, double radius) {
        double radiusSquared = radius * radius;
        Player nearestPlayer = null;
        double nearestDistance = radiusSquared;
        for (Player player : location.getWorld().getPlayers()) {
            double dz;
            double dx = player.getLocation().getX() - location.getX();
            double distance2D = dx * dx + (dz = player.getLocation().getZ() - location.getZ()) * dz;
            if (distance2D > radiusSquared || distance2D >= nearestDistance) continue;
            nearestPlayer = player;
            nearestDistance = distance2D;
        }
        return nearestPlayer;
    }

    private void startCleanupTask() {
        this.plugin.getSpigotScheduler().runGlobalTimer(this::cleanupNearbyHostileMobs, 20L, 20L);
    }

    private void cleanupNearbyHostileMobs() {
        double radius = this.plugin.getConfigManager().getConfig().getDouble("SETTINGS.MOB-SPAWN-RADIUS", 50.0);
        double radiusSquared = radius * radius;
        this.plugin.getSpigotScheduler().forEachOnlinePlayer(player -> {
            PlayerData data = this.plugin.getPlayerDataManager().get((Player)player);
            if (data == null || data.isMobSpawnEnabled()) {
                return;
            }
            this.removeNearbyHostiles((Player)player, radius, radiusSquared);
        });
    }

    private void removeNearbyHostiles(Player player, double radius, double radiusSquared) {
        Location playerLocation = player.getLocation();
        for (Entity nearby : player.getNearbyEntities(radius, radius, radius)) {
            LivingEntity entity;
            if (!(nearby instanceof LivingEntity) || !this.isRemovableHostileMob(entity = (LivingEntity)nearby) || entity.getLocation().distanceSquared(playerLocation) > radiusSquared) continue;
            entity.remove();
        }
    }

    private boolean isRemovableHostileMob(LivingEntity entity) {
        return MobSpawnPolicy.shouldRemoveFromPeriodicCleanup(this.plugin, entity);
    }
}

