/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Particle
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.LivingEntity
 *  org.bukkit.event.entity.EntityResurrectEvent
 */
package com.bx.magicSmp.listeners;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.models.PlayerData;
import com.bx.magicSmp.utils.NightVisionUtils;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityResurrectEvent;

public class PlayerSettingEffectsListener
implements Listener {
    private final MagicSmp plugin;

    public PlayerSettingEffectsListener(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @EventHandler(ignoreCancelled=true)
    public void onTotemUse(EntityResurrectEvent event) {
        PlayerData data;
        LivingEntity livingEntity = event.getEntity();
        if (!(livingEntity instanceof Player)) {
            return;
        }
        Player player = (Player)livingEntity;
        if (NightVisionUtils.isEnabled(this.plugin, player)) {
            this.plugin.getSpigotScheduler().runEntityLater((Entity)player, () -> NightVisionUtils.restoreIfEnabled(this.plugin, player), 1L);
        }
        if ((data = this.plugin.getPlayerDataManager().get(player)) != null && !data.isTotemParticlesEnabled()) {
            return;
        }
        this.playTotemBurst(player);
    }

    private void playTotemBurst(Player player) {
        this.spawnTotemWave(player, 0.35, 0.2, 18, 90);
        for (int stage = 1; stage <= 3; ++stage) {
            int currentStage = stage;
            this.plugin.getSpigotScheduler().runEntityLater((Entity)player, () -> {
                if (!player.isOnline()) {
                    return;
                }
                double radius = 0.35 + (double)currentStage * 0.3;
                double heightOffset = 0.2 + (double)currentStage * 0.28;
                int points = 18 + currentStage * 4;
                int burstCount = 90 + currentStage * 20;
                this.spawnTotemWave(player, radius, heightOffset, points, burstCount);
            }, (long)stage * 2L);
        }
    }

    private void spawnTotemWave(Player player, double radius, double heightOffset, int points, int burstCount) {
        World world = player.getWorld();
        Location base = player.getLocation().add(0.0, 1.0 + heightOffset, 0.0);
        world.spawnParticle(Particle.TOTEM_OF_UNDYING, base, burstCount, 0.45 + radius, 0.35, 0.45 + radius, 0.04);
        world.spawnParticle(Particle.GLOW, base, Math.max(20, burstCount / 3), 0.35 + radius, 0.25, 0.35 + radius, 0.01);
        for (int point = 0; point < points; ++point) {
            double angle = Math.PI * 2 * (double)point / (double)points;
            double x = base.getX() + Math.cos(angle) * radius;
            double z = base.getZ() + Math.sin(angle) * radius;
            double y = base.getY() + Math.sin(angle * 2.0) * 0.1;
            world.spawnParticle(Particle.TOTEM_OF_UNDYING, x, y, z, 1, 0.0, 0.0, 0.0, 0.0);
            if (point % 2 != 0) continue;
            world.spawnParticle(Particle.GLOW, x, y, z, 1, 0.0, 0.0, 0.0, 0.0);
        }
    }
}

