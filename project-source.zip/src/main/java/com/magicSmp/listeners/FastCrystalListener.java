/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.EnderCrystal
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.Projectile
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.block.Action
 *  org.bukkit.event.entity.EntityDamageByEntityEvent
 *  org.bukkit.event.player.PlayerInteractEvent
 *  org.bukkit.event.player.PlayerJoinEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 *  org.bukkit.inventory.EquipmentSlot
 *  org.bukkit.projectiles.ProjectileSource
 */
package com.bx.magicSmp.listeners;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.managers.FastCrystalManager;
import org.bukkit.Material;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.projectiles.ProjectileSource;

public class FastCrystalListener
implements Listener {
    private final MagicSmp plugin;

    public FastCrystalListener(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onCrystalUse(PlayerInteractEvent event) {
        FastCrystalManager fastCrystalManager = this.plugin.getFastCrystalManager();
        if (!fastCrystalManager.isEnabled()) {
            return;
        }
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        if (event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        if (event.getClickedBlock() == null) {
            return;
        }
        if (event.getItem() == null || event.getItem().getType() != Material.END_CRYSTAL) {
            return;
        }
        Player player = event.getPlayer();
        if (!fastCrystalManager.isEnabledFor(player)) {
            this.scheduleCooldownApply(player);
            return;
        }
        if (!fastCrystalManager.tryBeginPlace(player, event.getClickedBlock())) {
            return;
        }
        this.scheduleCooldownApply(player);
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onCrystalBreak(EntityDamageByEntityEvent event) {
        FastCrystalManager fastCrystalManager = this.plugin.getFastCrystalManager();
        if (!fastCrystalManager.isEnabled()) {
            return;
        }
        if (!(event.getEntity() instanceof EnderCrystal)) {
            return;
        }
        Player attacker = this.resolveAttacker(event.getDamager());
        if (attacker == null) {
            return;
        }
        if (!fastCrystalManager.isEnabledFor(attacker)) {
            return;
        }
        if (!fastCrystalManager.shouldClearCooldownAfterHit()) {
            return;
        }
        this.plugin.getSpigotScheduler().runEntity((Entity)attacker, () -> fastCrystalManager.clearCrystalCooldown(attacker));
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        this.plugin.getFastCrystalManager().clearState(event.getPlayer().getUniqueId());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        this.plugin.getFastCrystalManager().clearState(event.getPlayer().getUniqueId());
    }

    private void scheduleCooldownApply(Player player) {
        this.plugin.getSpigotScheduler().runEntity((Entity)player, () -> {
            if (player.isOnline()) {
                this.plugin.getFastCrystalManager().applyCrystalCooldown(player);
            }
        });
    }

    private Player resolveAttacker(Entity damager) {
        Projectile projectile;
        ProjectileSource projectileSource;
        if (damager instanceof Player) {
            Player player = (Player)damager;
            return player;
        }
        if (damager instanceof Projectile && (projectileSource = (projectile = (Projectile)damager).getShooter()) instanceof Player) {
            Player player = (Player)projectileSource;
            return player;
        }
        return null;
    }
}

