/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.inventory.AnvilInventory
 */
package com.bx.magicSmp.listeners;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.utils.ColorUtils;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.AnvilInventory;
import org.bukkit.inventory.ItemStack;

public class AnvilModerationListener
implements Listener {
    private final MagicSmp plugin;

    public AnvilModerationListener(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        HumanEntity humanEntity = event.getWhoClicked();
        if (!(humanEntity instanceof Player)) {
            return;
        }
        Player player = (Player)humanEntity;
        if (event.getClickedInventory() == null) {
            return;
        }
        if (!(event.getView().getTopInventory() instanceof AnvilInventory)) {
            return;
        }
        if (event.getRawSlot() != 2) {
            return;
        }
        ItemStack clickedItem = event.getCurrentItem();
        if (clickedItem == null || clickedItem.getType().isAir()) {
            return;
        }
        if (!clickedItem.hasItemMeta() || !clickedItem.getItemMeta().hasDisplayName()) {
            return;
        }
        String displayName = clickedItem.getItemMeta().getDisplayName();
        String matchedWord = this.plugin.getAnvilModerationManager().findInappropriateWord(displayName);
        if (matchedWord != null) {
            if (player.hasPermission("anvilmod.admin")) {
                return;
            }
            event.setCancelled(true);
            player.closeInventory();
            String strippedInput = ColorUtils.strip(displayName);
            this.plugin.getAnvilModerationManager().punish(player, matchedWord, strippedInput);
        }
    }
}

