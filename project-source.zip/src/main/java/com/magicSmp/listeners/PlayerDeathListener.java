/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.EnderPearl
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.Projectile
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.entity.EntityDamageByEntityEvent
 *  org.bukkit.event.entity.EntityDamageEvent
 *  org.bukkit.event.entity.PlayerDeathEvent
 *  org.bukkit.projectiles.ProjectileSource
 */
package com.bx.magicSmp.listeners;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.managers.FeatureManager;
import com.bx.magicSmp.models.PlayerData;
import com.bx.magicSmp.models.TwoChoice;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.NumberUtils;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.EnderPearl;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.projectiles.ProjectileSource;

public class PlayerDeathListener
implements Listener {
    private final MagicSmp plugin;

    public PlayerDeathListener(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onDeath(PlayerDeathEvent event) {
        String cleanDeathMsg;
        Player victim = event.getEntity();
        Player killer = victim.getKiller();
        PlayerData victimData = this.plugin.getPlayerDataManager().get(victim);
        if (victimData != null) {
            if (victimData.isDestroyPearlOnDeath()) {
                for (World world : Bukkit.getWorlds()) {
                    for (EnderPearl pearl : world.getEntitiesByClass(EnderPearl.class)) {
                        if (!victim.equals(pearl.getShooter())) continue;
                        pearl.remove();
                    }
                }
            } else if (this.plugin.getEnderPearlManager() != null) {
                this.plugin.getEnderPearlManager().handlePlayerDeath(victim);
            }
        }
        String deathMsg = this.buildDeathMessage(event, victim, killer);
        if (victimData != null) {
            victimData.addDeath();
            victimData.resetKillStreak();
        }
        String locationStr = String.format("%s (%d, %d, %d)", victim.getWorld().getName(), victim.getLocation().getBlockX(), victim.getLocation().getBlockY(), victim.getLocation().getBlockZ());
        String string = cleanDeathMsg = deathMsg != null ? ColorUtils.strip(deathMsg) : "";
        if (killer != null && !killer.equals(victim)) {
            double amount;
            PlayerData killerData = this.plugin.getPlayerDataManager().get(killer);
            if (killerData != null) {
                killerData.addKill();
                killerData.addKillStreak();
            }
            this.plugin.getPlayerLogsManager().log(victim.getUniqueId(), victim.getName(), "deaths", "PVP_DEATH", "Killed by " + killer.getName() + " at " + locationStr + (String)(cleanDeathMsg.isEmpty() ? "" : " | " + cleanDeathMsg));
            this.plugin.getPlayerLogsManager().log(killer.getUniqueId(), killer.getName(), "deaths", "PVP_KILL", "Killed " + victim.getName() + " at " + locationStr + (String)(cleanDeathMsg.isEmpty() ? "" : " | " + cleanDeathMsg));
            if (this.plugin.getFeatureManager().isEnabled(FeatureManager.Feature.BOUNTY) && this.plugin.getBountyManager().hasBounty(victim.getUniqueId()) && !this.plugin.getBountyManager().isExcludedWorld(victim.getWorld().getName()) && (amount = this.plugin.getBountyManager().claimBounty(killer, victim.getUniqueId())) > 0.0) {
                String msg = this.plugin.getConfigManager().getMessage("BOUNTY.CLAIM-SUCCESS", "{amount}", NumberUtils.format(amount), "{amount_formatted}", this.plugin.getCurrencyManager().formatMoney(amount), "{player}", victim.getName());
                killer.sendMessage(ColorUtils.toComponent(msg));
            }
        } else {
            EntityDamageEvent damageCause = victim.getLastDamageCause();
            String causeName = damageCause != null ? damageCause.getCause().name() : "UNKNOWN";
            this.plugin.getPlayerLogsManager().log(victim.getUniqueId(), victim.getName(), "deaths", "DEATH", "Died from " + causeName + " at " + locationStr + (String)(cleanDeathMsg.isEmpty() ? "" : " | " + cleanDeathMsg));
        }
        if (this.plugin.getConfigManager().getDeathMessages().getBoolean("MESSAGES.ENABLED", true)) {
            event.setDeathMessage(deathMsg);
        } else {
            event.setDeathMessage(null);
        }
        this.plugin.getCombatManager().clearTag(victim.getUniqueId());
        this.plugin.getRtpZoneManager().clearState(victim);
    }

    private boolean shouldReceiveDeathMessage(Player receiver, Player victim) {
        PlayerData receiverData = this.plugin.getPlayerDataManager().get(receiver);
        if (receiverData == null) {
            return true;
        }
        TwoChoice choice = receiverData.getDeathMessagesChoice();
        if (choice == TwoChoice.OFF) {
            return false;
        }
        if (choice == TwoChoice.FRIENDS_FOLLOWED) {
            return this.plugin.getFriendsManager() != null && this.plugin.getFriendsManager().isFollowing(receiver.getUniqueId(), victim.getUniqueId());
        }
        return true;
    }

    private String buildDeathMessage(PlayerDeathEvent event, Player victim, Player killer) {
        if (killer != null && !killer.equals(victim)) {
            return this.buildPlayerKillMessage(victim, killer);
        }
        FileConfiguration cfg = this.plugin.getConfigManager().getDeathMessages();
        String prefix = cfg.getString("MESSAGES.PREFIX", "&c\u2620 ");
        EntityDamageEvent damageCause = event.getEntity().getLastDamageCause();
        String cause = damageCause != null ? damageCause.getCause().name() : "DEFAULT";
        String killerName = this.resolveNonPlayerKillerName(damageCause, victim);
        boolean hasNonPlayerKiller = killerName != null;
        String template = switch (cause) {
            case "BLOCK_EXPLOSION" -> cfg.getString("MESSAGES.BLOCK-EXPLOSION", "{player} was blown up");
            case "CONTACT" -> cfg.getString("MESSAGES.CONTACT", "{player} was pricked");
            case "DROWNING" -> {
                if (hasNonPlayerKiller) {
                    yield cfg.getString("MESSAGES.DROWNING.PVP", "{player} drowned escaping {killer}");
                }
                yield cfg.getString("MESSAGES.DROWNING.NORMAL", "{player} drowned!");
            }
            case "ENTITY_ATTACK" -> cfg.getString("MESSAGES.ENTITY-ATTACK", "{player} was slain by {killer}");
            case "FALL" -> {
                if (hasNonPlayerKiller) {
                    yield cfg.getString("MESSAGES.FALL.PVP", "{player} was doomed to fall by {killer}");
                }
                yield cfg.getString("MESSAGES.FALL.NORMAL", "{player} hit the ground too hard");
            }
            case "FALLING_BLOCK" -> cfg.getString("MESSAGES.FALLING-BLOCK", "{player} was squashed");
            case "FIRE" -> {
                if (hasNonPlayerKiller) {
                    yield cfg.getString("MESSAGES.FIRE.PVP", "{player} walked into fire fighting {killer}");
                }
                yield cfg.getString("MESSAGES.FIRE.NORMAL", "{player} went up in flames");
            }
            case "FIRE_TICK" -> {
                if (hasNonPlayerKiller) {
                    yield cfg.getString("MESSAGES.FIRE-TICK.PVP", "{player} burned while fighting {killer}");
                }
                yield cfg.getString("MESSAGES.FIRE-TICK.NORMAL", "{player} burned to death");
            }
            case "LAVA" -> {
                if (hasNonPlayerKiller) {
                    yield cfg.getString("MESSAGES.LAVA.PVP", "{player} tried to swim in lava escaping {killer}");
                }
                yield cfg.getString("MESSAGES.LAVA.NORMAL", "{player} tried to swim in lava");
            }
            case "LIGHTNING" -> cfg.getString("MESSAGES.LIGHTNING", "{player} got struck by lightning");
            case "POISON" -> cfg.getString("MESSAGES.POISON", "{player} was poisoned");
            case "PROJECTILE" -> {
                if (hasNonPlayerKiller) {
                    yield cfg.getString("MESSAGES.PROJECTILE.PVP", "{player} was shot by {killer}");
                }
                yield cfg.getString("MESSAGES.PROJECTILE.NORMAL", "{player} was shot");
            }
            case "STARVATION" -> cfg.getString("MESSAGES.STARVATION", "{player} starved to death");
            case "SUFFOCATION" -> cfg.getString("MESSAGES.SUFFOCATION", "{player} suffocated in a wall");
            case "SUICIDE" -> cfg.getString("MESSAGES.SUICIDE", "{player} took their own life");
            case "THORNS" -> cfg.getString("MESSAGES.THORNS", "{player} killed themselves trying to kill someone");
            case "VOID" -> {
                if (hasNonPlayerKiller) {
                    yield cfg.getString("MESSAGES.VOID.PVP", "{player} was knocked into the void by {killer}");
                }
                yield cfg.getString("MESSAGES.VOID.NORMAL", "{player} fell out of the world");
            }
            case "WITHER" -> cfg.getString("MESSAGES.WITHER", "{player} withered away");
            case "ENTITY_EXPLOSION" -> {
                if (hasNonPlayerKiller) {
                    yield cfg.getString("MESSAGES.ENTITY-EXPLOSION.PVP", "{player} was blown up by {killer}");
                }
                yield cfg.getString("MESSAGES.ENTITY-EXPLOSION.NORMAL", "{player} was blown up");
            }
            default -> cfg.getString("MESSAGES.DEFAULT", "{player} died");
        };
        String msg = template.replace("{player}", victim.getName()).replace("{killer}", killerName != null ? killerName : "unknown");
        return ColorUtils.colorize(prefix + msg);
    }

    private String resolveNonPlayerKillerName(EntityDamageEvent damageCause, Player victim) {
        if (!(damageCause instanceof EntityDamageByEntityEvent)) {
            return null;
        }
        EntityDamageByEntityEvent entityDamage = (EntityDamageByEntityEvent)damageCause;
        Entity damager = entityDamage.getDamager();
        if (damager instanceof Player) {
            return null;
        }
        if (damager instanceof Projectile) {
            Entity shooter;
            Projectile projectile = (Projectile)damager;
            ProjectileSource projectileSource = projectile.getShooter();
            if (projectileSource instanceof Entity && !((shooter = (Entity)projectileSource) instanceof Player) && !shooter.equals((Object)victim)) {
                return this.safeEntityName(shooter);
            }
            return null;
        }
        if (!damager.equals((Object)victim)) {
            return this.safeEntityName(damager);
        }
        return null;
    }

    private String safeEntityName(Entity entity) {
        if (entity == null) {
            return "unknown";
        }
        String name = entity.getName();
        return name == null || name.isBlank() ? entity.getType().name() : name;
    }

    private String buildPlayerKillMessage(Player victim, Player killer) {
        String victimName = victim == null ? "unknown" : victim.getName();
        String killerName = killer == null ? "unknown" : killer.getName();
        return ColorUtils.colorize("&c\u2620 " + victimName + " \u1d21\u1d00\u0455 \u0455\u029f\u1d00\u026a\u0274 \u0299\u028f " + killerName);
    }
}

