/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.entity.Entity
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.player.PlayerRespawnEvent
 *  org.bukkit.inventory.PlayerInventory
 */
package com.bx.magicSmp.listeners;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.managers.SpawnManager;
import com.bx.magicSmp.models.PlayerData;
import com.bx.magicSmp.utils.ItemUtils;
import com.bx.magicSmp.utils.NightVisionUtils;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

public class PlayerRespawnListener
implements Listener {
    private final MagicSmp plugin;

    public PlayerRespawnListener(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        boolean duelRespawnHandled = false;
        boolean ffaRespawnHandled = false;
        if (!duelRespawnHandled && !ffaRespawnHandled) {
            Location pearlLocation;
            Location location = pearlLocation = this.plugin.getEnderPearlManager() != null ? this.plugin.getEnderPearlManager().consumePendingTeleport(player.getUniqueId()) : null;
            if (pearlLocation != null) {
                Object finalPearlLocation = pearlLocation.clone();
                event.setRespawnLocation((Location)finalPearlLocation);
                boolean isStaffMode = false;
                this.plugin.getSpigotScheduler().runGlobalLater(() -> this.lambda$onRespawn$2(player, (Location)finalPearlLocation, isStaffMode), 1L);
                return;
            }
            boolean respawnOnBed = this.plugin.getConfigManager().getConfig().getBoolean("SETTINGS.RESPAWN-ON-BED", false);
            if (!respawnOnBed || !this.isRespawningAtBedOrAnchor(event, player)) {
                Location respawnLocation = this.plugin.getSpawnManager().resolveCommandDestination(SpawnManager.AreaType.SPAWN);
                if (respawnLocation == null) {
                    respawnLocation = this.plugin.getSpawnManager().getSpawnLocation();
                }
                if (respawnLocation == null) {
                    respawnLocation = this.plugin.getSpawnManager().makeSafeDestination(event.getRespawnLocation());
                }
                if (respawnLocation != null) {
                    Object finalRespawnLocation = respawnLocation.clone();
                    event.setRespawnLocation((Location)finalRespawnLocation);
                    boolean isStaffMode = false;
                    this.plugin.getSpigotScheduler().runGlobalLater(() -> this.lambda$onRespawn$5(player, (Location)finalRespawnLocation, isStaffMode), 1L);
                    return;
                }
            }
        }
        this.plugin.getSpigotScheduler().runGlobalLater(() -> {
            if (player.isOnline()) {
                this.plugin.getSpigotScheduler().runEntity((Entity)player, () -> {
                    if (player.isOnline()) {
                        NightVisionUtils.restoreIfEnabled(this.plugin, player);
                    }
                });
            }
        }, 2L);
        if (!ffaRespawnHandled) {
            PlayerRespawnListener.scheduleChainmailKit(this.plugin, player, 2L);
        }
    }

    private boolean shouldSnapToRespawnLocation(Location current, Location expected) {
        if (current == null || expected == null || current.getWorld() == null || expected.getWorld() == null) {
            return false;
        }
        if (!current.getWorld().equals(expected.getWorld())) {
            return true;
        }
        return current.distanceSquared(expected) > 0.36;
    }

    private boolean isRespawningAtBedOrAnchor(PlayerRespawnEvent event, Player player) {
        if (event.isBedSpawn() || event.isAnchorSpawn()) {
            return true;
        }
        Location respawnLoc = event.getRespawnLocation();
        if (respawnLoc == null) {
            return false;
        }
        Location bedLoc = player.getBedSpawnLocation();
        if (bedLoc == null) {
            return false;
        }
        return respawnLoc.getWorld() != null && respawnLoc.getWorld().equals(bedLoc.getWorld()) && respawnLoc.distanceSquared(bedLoc) < 9.0;
    }

    public static void scheduleChainmailKit(MagicSmp plugin, Player player, long delayTicks) {
        boolean playerEnabled;
        if (plugin == null || player == null) {
            return;
        }
        boolean chainmailEnabled = plugin.getConfigManager().getConfig().getBoolean("SETTINGS.CHAINMAIL-ON-RESPAWN", true);
        PlayerData data = plugin.getPlayerDataManager().get(player);
        boolean bl = playerEnabled = data == null || data.isChainmailOnRespawnEnabled();
        if (!chainmailEnabled || !playerEnabled) {
            return;
        }
        plugin.getSpigotScheduler().runEntityLater((Entity)player, () -> {
            if (player.isOnline()) {
                PlayerRespawnListener.giveChainmailKit(plugin, player);
            }
        }, Math.max(1L, delayTicks));
    }

    private static void giveChainmailKit(MagicSmp plugin, Player player) {
        List itemList = plugin.getConfigManager().getConfig().getList("SETTINGS.CHAINMAIL-RESPAWN-ITEMS");
        HashSet<Material> grantedMaterials = new HashSet<Material>();
        if (itemList != null) {
            for (Object obj : itemList) {
                ItemStack item;
                Material mat = Material.STONE;
                int amount = 1;
                String name = null;
                if (obj instanceof ConfigurationSection) {
                    ConfigurationSection section = (ConfigurationSection)obj;
                    mat = ItemUtils.parseMaterial(section.getString("MATERIAL", "STONE"));
                    amount = section.getInt("AMOUNT", 1);
                    name = section.getString("NAME");
                } else {
                    Object nameObj;
                    Object amtObj;
                    if (!(obj instanceof Map)) continue;
                    Map map = (Map)obj;
                    Object matObj = map.get("MATERIAL");
                    if (matObj != null) {
                        mat = ItemUtils.parseMaterial(matObj.toString());
                    }
                    if ((amtObj = map.get("AMOUNT")) != null) {
                        try {
                            amount = Integer.parseInt(amtObj.toString());
                        }
                        catch (NumberFormatException numberFormatException) {
                            // empty catch block
                        }
                    }
                    if ((nameObj = map.get("NAME")) != null) {
                        name = nameObj.toString();
                    }
                }
                if (name != null) {
                    item = ItemUtils.createItem(mat, name);
                    item.setAmount(amount);
                } else {
                    item = new ItemStack(mat, amount);
                }
                grantedMaterials.add(mat);
                PlayerRespawnListener.giveRespawnItem(player, item);
            }
        } else {
            PlayerRespawnListener.ensureDefaultItem(player, grantedMaterials, Material.CHAINMAIL_HELMET);
            PlayerRespawnListener.ensureDefaultItem(player, grantedMaterials, Material.CHAINMAIL_CHESTPLATE);
            PlayerRespawnListener.ensureDefaultItem(player, grantedMaterials, Material.CHAINMAIL_LEGGINGS);
            PlayerRespawnListener.ensureDefaultItem(player, grantedMaterials, Material.CHAINMAIL_BOOTS);
            PlayerRespawnListener.ensureDefaultItem(player, grantedMaterials, Material.STONE_SWORD);
            PlayerRespawnListener.ensureDefaultItem(player, grantedMaterials, Material.STONE_PICKAXE);
            PlayerRespawnListener.ensureDefaultItem(player, grantedMaterials, Material.STONE_AXE);
            PlayerRespawnListener.ensureDefaultItem(player, grantedMaterials, Material.STONE_SHOVEL);
        }
        player.updateInventory();
    }

    private static void ensureDefaultItem(Player player, Set<Material> grantedMaterials, Material material) {
        if (grantedMaterials.contains((Object)material)) {
            return;
        }
        PlayerRespawnListener.giveRespawnItem(player, new ItemStack(material));
    }

    private static void giveRespawnItem(Player player, ItemStack item) {
        if (PlayerRespawnListener.equipArmorIfApplicable(player, item)) {
            return;
        }
        PlayerRespawnListener.placeInPreferredSlot(player, item);
    }

    private static boolean equipArmorIfApplicable(Player player, ItemStack item) {
        PlayerInventory inventory = player.getInventory();
        String matName = item.getType().name();
        if (matName.endsWith("_HELMET")) {
            if (PlayerRespawnListener.isEmpty(inventory.getHelmet())) {
                inventory.setHelmet(item);
            } else {
                inventory.addItem(new ItemStack[]{item});
            }
            return true;
        }
        if (matName.endsWith("_CHESTPLATE")) {
            if (PlayerRespawnListener.isEmpty(inventory.getChestplate())) {
                inventory.setChestplate(item);
            } else {
                inventory.addItem(new ItemStack[]{item});
            }
            return true;
        }
        if (matName.endsWith("_LEGGINGS")) {
            if (PlayerRespawnListener.isEmpty(inventory.getLeggings())) {
                inventory.setLeggings(item);
            } else {
                inventory.addItem(new ItemStack[]{item});
            }
            return true;
        }
        if (matName.endsWith("_BOOTS")) {
            if (PlayerRespawnListener.isEmpty(inventory.getBoots())) {
                inventory.setBoots(item);
            } else {
                inventory.addItem(new ItemStack[]{item});
            }
            return true;
        }
        return false;
    }

    private static void placeInPreferredSlot(Player player, ItemStack item) {
        PlayerInventory inventory = player.getInventory();
        int preferredSlot = PlayerRespawnListener.getPreferredHotbarSlot(item.getType());
        if (preferredSlot >= 0 && PlayerRespawnListener.isEmpty(inventory.getItem(preferredSlot))) {
            inventory.setItem(preferredSlot, item);
            return;
        }
        inventory.addItem(new ItemStack[]{item});
    }

    private static int getPreferredHotbarSlot(Material material) {
        return switch (material) {
            case Material.STONE_SWORD -> 0;
            case Material.STONE_PICKAXE -> 1;
            case Material.STONE_AXE -> 2;
            case Material.STONE_SHOVEL -> 3;
            default -> -1;
        };
    }

    private static boolean isEmpty(ItemStack item) {
        return item == null || item.getType().isAir();
    }

    private /* synthetic */ void lambda$onRespawn$5(Player player, Location finalRespawnLocation, boolean isStaffMode) {
        if (!player.isOnline()) {
            return;
        }
        this.plugin.getSpigotScheduler().teleport((Entity)player, finalRespawnLocation).thenAccept(success -> this.plugin.getSpigotScheduler().runEntity((Entity)player, () -> {
            if (player.isOnline()) {
                NightVisionUtils.restoreIfEnabled(this.plugin, player);
                if (!isStaffMode) {
                    PlayerRespawnListener.scheduleChainmailKit(this.plugin, player, 0L);
                }
            }
        }));
    }

    private /* synthetic */ void lambda$onRespawn$2(Player player, Location finalPearlLocation, boolean isStaffMode) {
        if (!player.isOnline()) {
            return;
        }
        this.plugin.getSpigotScheduler().teleport((Entity)player, finalPearlLocation).thenAccept(success -> this.plugin.getSpigotScheduler().runEntity((Entity)player, () -> {
            if (player.isOnline()) {
                NightVisionUtils.restoreIfEnabled(this.plugin, player);
                if (!isStaffMode) {
                    PlayerRespawnListener.scheduleChainmailKit(this.plugin, player, 0L);
                }
            }
        }));
    }
}

