/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.md_5.bungee.api.chat.BaseComponent
 *  org.bukkit.entity.Entity
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.player.AsyncPlayerChatEvent
 */
package com.bx.magicSmp.listeners;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.managers.ChatManager;
import com.bx.magicSmp.managers.FeatureManager;
import com.bx.magicSmp.models.PunishmentRecord;
import com.bx.magicSmp.models.PunishmentType;
import com.bx.magicSmp.models.Team;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.NumberUtils;
import java.util.UUID;
import net.md_5.bungee.api.chat.BaseComponent;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

public class ChatListener
implements Listener {
    private final MagicSmp plugin;

    public ChatListener(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority=EventPriority.NORMAL)
    public void onChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        ChatManager chatManager = this.plugin.getChatManager();
        String rawMessage = event.getMessage();
        if (this.plugin.getHomeManager().hasPendingInput(player.getUniqueId())) {
            event.setCancelled(true);
            this.plugin.getSpigotScheduler().runEntity((Entity)player, () -> this.plugin.getHomeManager().handlePendingInput(player, rawMessage));
            return;
        }
        if (this.plugin.getTeamManager().hasPendingSearchInput(player.getUniqueId())) {
            event.setCancelled(true);
            this.plugin.getSpigotScheduler().runEntity((Entity)player, () -> this.plugin.getTeamManager().handlePendingSearchInput(player, rawMessage));
            return;
        }
        PunishmentRecord activeMute = this.plugin.getPunishmentManager().getActiveRecord(player.getUniqueId(), player.getName(), PunishmentType.MUTE).orElse(null);
        if (activeMute != null) {
            event.setCancelled(true);
            this.plugin.getSpigotScheduler().runEntity((Entity)player, () -> player.sendMessage(ColorUtils.toComponent(this.mutedChatMessage(activeMute))));
            return;
        }
        if (this.plugin.getTeamManager().isTeamChatEnabled(player.getUniqueId())) {
            event.setCancelled(true);
            Team team = this.plugin.getTeamManager().getTeam(player);
            if (team == null) {
                this.plugin.getTeamManager().setTeamChat(player.getUniqueId(), false);
                this.plugin.getSpigotScheduler().runEntity((Entity)player, () -> player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessage("TEAM.NO-TEAM"))));
                return;
            }
            if (!this.plugin.getTeamManager().canUseTeamChat(team, player.getUniqueId())) {
                this.plugin.getTeamManager().setTeamChat(player.getUniqueId(), false);
                this.plugin.getSpigotScheduler().runEntity((Entity)player, () -> player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessage("TEAM.NO-TEAM-CHAT-PERMISSION"))));
                return;
            }
            String teamFormat = "&8[&b" + team.getName().toUpperCase() + "&8] &7%player%&8: &f%message%";
            BaseComponent[] component = this.plugin.getHoverStatsManager().buildChatComponent(player, "", rawMessage, teamFormat);
            for (UUID uuid : team.getMemberUuids()) {
                Player member = Bukkit.getPlayer(uuid);
                if (member == null) continue;
                this.plugin.getSpigotScheduler().runEntity((Entity)member, () -> member.spigot().sendMessage(component));
            }
            return;
        }
        if (!this.plugin.getFeatureManager().isEnabled(FeatureManager.Feature.CHAT)) {
            return;
        }
        if (chatManager.isGlobalChatMuted() && !chatManager.isMuteBypassed(player)) {
            event.setCancelled(true);
            this.plugin.getSpigotScheduler().runEntity((Entity)player, () -> player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("CHAT-MANAGER.GLOBAL-MUTED-BLOCK", "&c\u0262\u029f\u1d0f\u0299\u1d00\u029f \u1d04\u029c\u1d00\u1d1b \u026a\u0455 \u1d04\u1d1c\u0280\u0280\u1d07\u0274\u1d1b\u029f\u028f \u1d0d\u1d1c\u1d1b\u1d07\u1d05."))));
            return;
        }
        ChatManager.FilterResult filterResult = chatManager.validateGlobalMessage(player, rawMessage);
        if (!filterResult.allowed()) {
            event.setCancelled(true);
            this.plugin.getSpigotScheduler().runEntity((Entity)player, () -> player.sendMessage(ColorUtils.toComponent(filterResult.blockMessage())));
            return;
        }
        ChatManager.DelayResult delayResult = chatManager.checkAndTrackDelay(player);
        if (!delayResult.allowed()) {
            event.setCancelled(true);
            String delayMessage = this.plugin.getConfigManager().getMessageOrDefault("CHAT-MANAGER.GLOBAL-DELAY-BLOCK", "&c\u028f\u1d0f\u1d1c \u1d0d\u1d1c\u0455\u1d1b \u1d21\u1d00\u026a\u1d1b &f{seconds}\u0455 &c\u0299\u1d07\ua730\u1d0f\u0280\u1d07 \u1d04\u029c\u1d00\u1d1b\u1d1b\u026a\u0274\u0262 \u1d00\u0262\u1d00\u026a\u0274.").replace("{seconds}", String.valueOf(delayResult.remainingSeconds())).replace("%seconds%", String.valueOf(delayResult.remainingSeconds()));
            this.plugin.getSpigotScheduler().runEntity((Entity)player, () -> player.sendMessage(ColorUtils.toComponent(delayMessage)));
            return;
        }
        chatManager.trackAcceptedGlobalMessage(player, rawMessage);
    }

    private String resolvePrefix(Player player) {
        return "";
    }

    private String mutedChatMessage(PunishmentRecord record) {
        return this.plugin.getConfigManager().getMessageOrDefault("PUNISHMENTS.MUTE", "&c&l\u028f\u1d0f\u1d1c \u029c\u1d00\u1d20\u1d07 \u0299\u1d07\u1d07\u0274 \u1d0d\u1d1c\u1d1b\u1d07\u1d05!\n&8&m----------------------------\n&7\u0280\u1d07\u1d00\u0455\u1d0f\u0274: &f%reason%\n&7\u1d07x\u1d18\u026a\u0280\u1d07\u0455: &f%nicest_expiration%\n&7\u1d0d\u1d1c\u1d1b\u1d07\u1d05 \u0299\u028f: &f%issuer%\n&8&m----------------------------\n&7\u028f\u1d0f\u1d1c \u1d04\u1d00\u0274\u0274\u1d0f\u1d1b \u0455\u1d18\u1d07\u1d00\u1d0b \u026a\u0274 \u1d04\u029c\u1d00\u1d1b", this.punishmentPlaceholders(record));
    }

    private String[] punishmentPlaceholders(PunishmentRecord record) {
        String expires = this.formatExpires(record);
        String issuer = this.formatIssuer(record);
        String reason = record == null || record.getReason() == null ? "" : record.getReason();
        String player = record == null || record.getTargetNameSnapshot() == null ? "" : record.getTargetNameSnapshot();
        String id = record == null ? "" : String.valueOf(record.getId());
        String type = record == null || record.getType() == null ? "" : record.getType().name();
        return new String[]{"%reason%", reason, "{reason}", reason, "%nicest_expiration%", expires, "{nicest_expiration}", expires, "%expires%", expires, "{expires}", expires, "%expires_at%", expires, "{expires_at}", expires, "%expiration%", expires, "{expiration}", expires, "%expiry%", expires, "{expiry}", expires, "%duration%", expires, "{duration}", expires, "%issuer%", issuer, "{issuer}", issuer, "%staff%", issuer, "{staff}", issuer, "%by%", issuer, "{by}", issuer, "%player%", player, "{player}", player, "%target%", player, "{target}", player, "%id%", id, "{id}", id, "%type%", type, "{type}", type};
    }

    private String formatExpires(PunishmentRecord record) {
        if (record == null || record.getExpiresAt() == null) {
            return "Permanent";
        }
        long remainingSeconds = Math.max(0L, (record.getExpiresAt() - System.currentTimeMillis()) / 1000L);
        if (remainingSeconds <= 0L) {
            return "Expired";
        }
        if (this.plugin != null && this.plugin.getLanguageManager() != null) {
            return this.plugin.getLanguageManager().formatDuration(remainingSeconds, true);
        }
        return NumberUtils.formatCountdown(remainingSeconds);
    }

    private String formatIssuer(PunishmentRecord record) {
        if (record == null) {
            return "unknown";
        }
        String issuer = record.getIssuerNameSnapshot();
        return issuer == null || issuer.isBlank() ? "unknown" : issuer;
    }
}

