/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.entity.Entity
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.player.PlayerJoinEvent
 *  org.bukkit.event.player.PlayerLoginEvent
 *  org.bukkit.event.player.PlayerLoginEvent$Result
 *  org.bukkit.event.player.PlayerQuitEvent
 *  org.bukkit.event.player.PlayerRespawnEvent
 *  org.bukkit.event.player.PlayerTeleportEvent
 */
package com.bx.magicSmp.listeners;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.managers.ScoreboardManager;
import com.bx.magicSmp.models.PlayerData;
import com.bx.magicSmp.models.PunishmentRecord;
import com.bx.magicSmp.models.PunishmentType;
import com.bx.magicSmp.models.ThreeChoice;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.NightVisionUtils;
import com.bx.magicSmp.utils.NumberUtils;
import com.bx.magicSmp.utils.TitleUtils;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.ItemStack;

public class PlayerJoinQuitListener
implements Listener {
    private final MagicSmp plugin;

    public PlayerJoinQuitListener(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onLogin(PlayerLoginEvent event) {
        if (event.getResult() != PlayerLoginEvent.Result.ALLOWED) {
            return;
        }
        UUID uuid = event.getPlayer().getUniqueId();
        if (uuid == null) {
            return;
        }
        String playerName = event.getPlayer().getName();
        PunishmentRecord blacklist = this.plugin.getPunishmentManager().getActiveRecord(uuid, playerName, PunishmentType.BLACKLIST).orElse(null);
        if (blacklist != null) {
            event.disallow(PlayerLoginEvent.Result.KICK_BANNED, ColorUtils.colorize(this.kickMessage(blacklist)));
            return;
        }
        PunishmentRecord ban = this.plugin.getPunishmentManager().getActiveRecord(uuid, playerName, PunishmentType.BAN).orElse(null);
        if (ban != null) {
            event.disallow(PlayerLoginEvent.Result.KICK_BANNED, ColorUtils.colorize(this.kickMessage(ban)));
        }
    }

    @EventHandler(priority=EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent event) {
        block17: {
            Location spawn;
            boolean spawnOnFirstJoin;
            Player player = event.getPlayer();
            String joinMsg = event.getJoinMessage();
            if (this.plugin.getMaintenanceManager() != null && this.plugin.getMaintenanceManager().isMaintenanceActive()) {
                String bypassPerm = this.plugin.getConfigManager().getConfig().getString("MAINTENANCE.BYPASS_PERMISSION", "MagicSMP.ADMIN.MAINTENANCE.BYPASS");
                if (!player.hasPermission(bypassPerm)) {
                    boolean useProxy = this.plugin.getConfigManager().getConfig().getBoolean("MAINTENANCE.USE_PROXY", true);
                    String notAllowedMsg = this.plugin.getConfigManager().getConfig().getString("MAINTENANCE.MESSAGES.NOT_ALLOWED", "&d[\u1d0d\u1d00\u026a\u0274\u1d1b\u1d07\u0274\u1d00\u0274\u1d04\u1d07] &c\u1d1b\u029c\u026a\u0455 \u0455\u1d07\u0280\u1d20\u1d07\u0280 \u026a\u0455 \u1d04\u1d1c\u0280\u0280\u1d07\u0274\u1d1b\u029f\u028f \u026a\u0274 \u1d0d\u1d00\u026a\u0274\u1d1b\u1d07\u0274\u1d00\u0274\u1d04\u1d07. \u0280\u1d07\u1d05\u026a\u0280\u1d07\u1d04\u1d1b\u026a\u0274\u0262 \u1d1b\u1d0f \u029f\u1d0f\u0299\u0299\u028f...");
                    player.sendMessage(ColorUtils.toComponent(notAllowedMsg));
                    if (useProxy) {
                        String lobby = this.plugin.getMaintenanceManager().getLobbyServer();
                        this.plugin.getMaintenanceManager().sendToLobby(player, lobby);
                        this.plugin.getSpigotScheduler().runEntityLater((Entity)player, () -> {
                            if (player.isOnline()) {
                                String kickMessage = this.plugin.getConfigManager().getConfig().getString("MAINTENANCE.MESSAGES.KICK_FALLBACK", "&c\u1d1b\u029c\u026a\u0455 \u0455\u1d07\u0280\u1d20\u1d07\u0280 \u026a\u0455 \u026a\u0274 \u1d0d\u1d00\u026a\u0274\u1d1b\u1d07\u0274\u1d00\u0274\u1d04\u1d07 \u1d00\u0274\u1d05 \u0274\u1d0f \u029f\u1d0f\u0299\u0299\u028f \u026a\u0455 \u1d00\u1d20\u1d00\u026a\u029f\u1d00\u0299\u029f\u1d07.");
                                player.kickPlayer(ColorUtils.colorize(kickMessage));
                            }
                        }, 40L);
                    } else {
                        String lobbyWorld;
                        World world;
                        Location loc;
                        String localServerId = this.plugin.getConfigManager().getConfig().getString("NETWORK.LOCAL_SERVER_ID", "local");
                        if (this.plugin.getDatabaseManager().getMaintenanceLocation(player.getUniqueId(), localServerId) == null && (loc = player.getLocation()).getWorld() != null) {
                            this.plugin.getDatabaseManager().saveMaintenanceLocation(player.getUniqueId(), localServerId, loc.getWorld().getName(), loc.getX(), loc.getY(), loc.getZ(), loc.getYaw(), loc.getPitch());
                        }
                        if ((world = Bukkit.getWorld((String)(lobbyWorld = this.plugin.getConfigManager().getConfig().getString("MAINTENANCE.LOBBY_WORLD", "WORLD")))) != null) {
                            this.plugin.getSpigotScheduler().runEntityLater((Entity)player, () -> {
                                if (player.isOnline()) {
                                    this.plugin.getSpigotScheduler().teleport((Entity)player, world.getSpawnLocation());
                                }
                            }, 1L);
                        }
                    }
                    ScoreboardManager scoreboardManager = this.plugin.getScoreboardManager();
                    if (scoreboardManager != null) {
                        scoreboardManager.setupPlayer(player);
                    }
                    return;
                }
                String bypassJoinMsg = this.plugin.getConfigManager().getConfig().getString("MAINTENANCE.MESSAGES.BYPASS_JOIN", "&d[\u1d0d\u1d00\u026a\u0274\u1d1b\u1d07\u0274\u1d00\u0274\u1d04\u1d07] &7\u028f\u1d0f\u1d1c \u1d0a\u1d0f\u026a\u0274\u1d07\u1d05 \u1d21\u029c\u026a\u029f\u1d07 \u1d0d\u1d00\u026a\u0274\u1d1b\u1d07\u0274\u1d00\u0274\u1d04\u1d07 \u1d0d\u1d0f\u1d05\u1d07 \u026a\u0455 \u1d00\u1d04\u1d1b\u026a\u1d20\u1d07.");
                player.sendMessage(ColorUtils.toComponent(bypassJoinMsg));
            } else if (this.plugin.getMaintenanceManager() != null) {
                String localServerId = this.plugin.getConfigManager().getConfig().getString("NETWORK.LOCAL_SERVER_ID", "local");
                Location savedLoc = this.plugin.getDatabaseManager().getMaintenanceLocation(player.getUniqueId(), localServerId);
                if (savedLoc != null) {
                    this.plugin.getSpigotScheduler().runEntityLater((Entity)player, () -> {
                        if (player.isOnline()) {
                            this.plugin.getSpigotScheduler().teleport((Entity)player, savedLoc).thenAccept(success -> this.plugin.getSpigotScheduler().runEntity((Entity)player, () -> {
                                if (player.isOnline()) {
                                    this.plugin.getDatabaseManager().deleteMaintenanceLocation(player.getUniqueId(), localServerId);
                                }
                            }));
                        }
                    }, 1L);
                }
            }
            this.plugin.getPlayerDataManager().loadOrCreate(player);
            NightVisionUtils.restoreIfEnabled(this.plugin, player);
            this.plugin.getShopManager().loadPreference(player.getUniqueId());
            this.plugin.getIgnoreManager().loadPlayer(player.getUniqueId());
            if (this.plugin.getFriendsManager() != null) {
                this.plugin.getFriendsManager().handleJoin(player);
            }
            if (player.getAddress() != null && player.getAddress().getAddress() != null) {
                this.plugin.getDatabaseManager().savePlayerIpAddressAsync(player.getUniqueId(), player.getAddress().getAddress().getHostAddress(), System.currentTimeMillis());
            }
            this.plugin.getHomeManager().loadHomes(player);
            this.plugin.getAmethystToolsManager().sanitizePlayerInventory(player, true);
            this.plugin.getFreezeManager().handleJoin(player);
            this.plugin.getRtpZoneManager().clearState(player.getUniqueId());
            if (player.isInvulnerable()) {
                boolean inGodMode;
                boolean bl = inGodMode = this.plugin.getGodModeManager() != null && this.plugin.getGodModeManager().isInGodMode(player.getUniqueId());
                if (!inGodMode) {
                    player.setInvulnerable(false);
                }
            }
            this.plugin.getPlayerVisibilityManager().handleJoin(player);
            if (!player.hasPlayedBefore() && (spawnOnFirstJoin = this.plugin.getConfigManager().getConfig().getBoolean("SETTINGS.TELEPORT-SPAWN-ON-FIRST-JOIN", true)) && this.plugin.getSpawnManager().hasSpawn() && (spawn = this.plugin.getSpawnManager().getSpawnLocation()) != null) {
                this.plugin.getSpigotScheduler().teleport((Entity)player, spawn);
            }
            if (this.plugin.getAuctionHouseManager() != null) {
                this.plugin.getSpigotScheduler().runEntityLater((Entity)player, () -> {
                    if (player.isOnline()) {
                        this.plugin.getAuctionHouseManager().processAutoClaims(player);
                    }
                }, 20L);
            }
            if (this.plugin.getUpdateManager() != null && this.plugin.getUpdateManager().isUpdateAvailable() && (player.isOp() || player.hasPermission("MagicSMP.admin") || player.hasPermission("MagicSMP.updatechecker"))) {
                this.plugin.getSpigotScheduler().runEntityLater((Entity)player, () -> {
                    if (player.isOnline()) {
                        String currentVer = this.plugin.getDescription().getVersion();
                        String latestVer = this.plugin.getUpdateManager().getLatestVersion();
                        player.sendMessage(ColorUtils.colorize("&8&m--------------------------------------------------", player));
                        player.sendMessage(ColorUtils.colorize("&9&lMagicSMP &7\u00bb &c&lA new update is available!", player));
                        player.sendMessage(ColorUtils.colorize("&7Current version: &c" + currentVer + " &8| &7Latest version: &a" + latestVer, player));
                        player.sendMessage(ColorUtils.colorize("&cPlease download the update from the official repository:", player));
                        player.sendMessage(ColorUtils.colorize("&bhttps://github.com/BeestoXd/MagicSMP", player));
                        player.sendMessage(ColorUtils.colorize("&8&m--------------------------------------------------", player));
                    }
                }, 40L);
            }
            ScoreboardManager scoreboardManager = this.plugin.getScoreboardManager();
            if (scoreboardManager == null) break block17;
            scoreboardManager.setupPlayer(player);
        }
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onTeleport(PlayerTeleportEvent event) {
    }

    @EventHandler(priority=EventPriority.MONITOR)
    public void onRespawn(PlayerRespawnEvent event) {
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        String quitMsg = event.getQuitMessage();
        TitleUtils.cancelPendingReset(player.getUniqueId());
        this.plugin.getStaffChatManager().clearPlayerState(player.getUniqueId());
        this.plugin.getStaffAlertManager().clearPlayerState(player.getUniqueId());
        if (this.plugin.getCombatManager().isInCombat(player.getUniqueId()) && this.plugin.getCombatManager().isKillOnLogoutEnabled() && !this.isHandledBySpecialCombatSession(player)) {
            for (ItemStack item : player.getInventory().getContents()) {
                if (item == null || item.getType().isAir()) continue;
                player.getWorld().dropItemNaturally(player.getLocation(), item);
            }
            for (ItemStack item : player.getInventory().getArmorContents()) {
                if (item == null || item.getType().isAir()) continue;
                player.getWorld().dropItemNaturally(player.getLocation(), item);
            }
            for (ItemStack item : player.getInventory().getExtraContents()) {
                if (item == null || item.getType().isAir()) continue;
                player.getWorld().dropItemNaturally(player.getLocation(), item);
            }
            player.getInventory().clear();
            player.setHealth(0.0);
        }
        this.plugin.getCombatManager().clearTag(player.getUniqueId());
        this.plugin.getTeleportManager().cancel(player.getUniqueId());
        this.plugin.getTPAManager().removeRequest(player.getUniqueId());
        this.plugin.getTPAManager().clearQueuedRequestsForTarget(player.getUniqueId());
        this.plugin.getTPAManager().cancelRequestsByRequester(player.getUniqueId());
        this.plugin.getWorthManager().clearWorthDisplay(player);
        PlayerData playerData = this.plugin.getDatabaseManager().loadPlayer(player.getUniqueId());
        if (playerData != null) {
            try {
                YamlConfiguration yamlConfig = new YamlConfiguration();
                yamlConfig.set("contents", (Object)player.getInventory().getContents());
                String inventoryString = yamlConfig.saveToString();
                playerData.setInventory(inventoryString);
                this.plugin.getDatabaseManager().savePlayerAsync(playerData);
            }
            catch (Exception e) {
                this.plugin.getLogger().warning("Failed to save inventory for " + player.getName() + ": " + e.getMessage());
            }
        }
        this.plugin.getPlayerDataManager().unload(player.getUniqueId());
        this.plugin.getHomeManager().unloadHomes(player.getUniqueId());
        this.plugin.getRtpZoneManager().clearState(player);
        this.plugin.getRtpManager().clearSearch(player.getUniqueId());
        this.plugin.getFreezeManager().handleQuit(player);
        this.plugin.getChatManager().clearPlayerState(player.getUniqueId());
        this.plugin.getPrivateMessageManager().clearPlayer(player.getUniqueId());
        this.plugin.getIgnoreManager().unloadPlayer(player.getUniqueId());
        if (this.plugin.getFriendsManager() != null) {
            this.plugin.getFriendsManager().handleQuit(player);
        }
        if (this.plugin.getAuctionHouseManager() != null) {
            this.plugin.getAuctionHouseManager().cleanupPlayer(player.getUniqueId());
        }
        this.plugin.getShopManager().cleanupPlayer(player.getUniqueId());
        this.plugin.getPlayerVisibilityManager().clearPlayer(player.getUniqueId());
        this.plugin.getTeamManager().setTeamChat(player.getUniqueId(), false);
        this.plugin.getTeamManager().clearSearchState(player.getUniqueId());
    }

    private boolean isHandledBySpecialCombatSession(Player player) {
        UUID uuid = player.getUniqueId();
        return false;
    }

    private boolean shouldReceiveJoinLeaveMessage(Player receiver, Player joiner) {
        PlayerData receiverData = this.plugin.getPlayerDataManager().get(receiver);
        if (receiverData == null) {
            return true;
        }
        ThreeChoice choice = receiverData.getJoinLeaveMessagesChoice();
        if (choice == ThreeChoice.OFF) {
            return false;
        }
        if (choice == ThreeChoice.FRIENDS_FOLLOWED) {
            return this.plugin.getFriendsManager() != null && this.plugin.getFriendsManager().isFollowing(receiver.getUniqueId(), joiner.getUniqueId());
        }
        return true;
    }

    private String kickMessage(PunishmentRecord record) {
        return this.plugin.getConfigManager().getMessageOrDefault(record.getType() == PunishmentType.BLACKLIST ? "PUNISHMENTS.BLACKLIST" : "PUNISHMENTS.BAN", record.getType() == PunishmentType.BLACKLIST ? "&4&l\u028f\u1d0f\u1d1c \u029c\u1d00\u1d20\u1d07 \u0299\u1d07\u1d07\u0274 \u0299\u029f\u1d00\u1d04\u1d0b\u029f\u026a\u0455\u1d1b\u1d07\u1d05!\n&8&m----------------------------\n&7\u0280\u1d07\u1d00\u0455\u1d0f\u0274: &f%reason%\n&7\u0299\u029f\u1d00\u1d04\u1d0b\u029f\u026a\u0455\u1d1b\u1d07\u1d05 \u0299\u028f: &f%issuer%\n&8&m----------------------------\n&4\u028f\u1d0f\u1d1c \u1d04\u1d00\u0274\u0274\u1d0f\u1d1b \u1d0a\u1d0f\u026a\u0274 \u1d1b\u029c\u1d07 \u0455\u1d07\u0280\u1d20\u1d07\u0280" : "&c&l\u028f\u1d0f\u1d1c \u029c\u1d00\u1d20\u1d07 \u0299\u1d07\u1d07\u0274 \u0299\u1d00\u0274\u0274\u1d07\u1d05!\n&8&m----------------------------\n&7\u0280\u1d07\u1d00\u0455\u1d0f\u0274: &f%reason%\n&7\u1d07x\u1d18\u026a\u0280\u1d07\u0455: &f%nicest_expiration%\n&7\u0299\u1d00\u0274\u0274\u1d07\u1d05 \u0299\u028f: &f%issuer%\n&8&m----------------------------\n&7\u1d00\u1d18\u1d18\u1d07\u1d00\u029f \u1d00\u1d1b: &fdiscord.example.space", this.punishmentPlaceholders(record));
    }

    private String[] punishmentPlaceholders(PunishmentRecord record) {
        String expires = this.formatExpires(record);
        String issuer = this.formatIssuer(record);
        String reason = record == null || record.getReason() == null ? "" : record.getReason();
        String player = record == null || record.getTargetNameSnapshot() == null ? "" : record.getTargetNameSnapshot();
        String id = record == null ? "" : String.valueOf(record.getId());
        String type = record == null || record.getType() == null ? "" : record.getType().name();
        return new String[]{"%reason%", reason, "{reason}", reason, "%nicest_expiration%", expires, "{nicest_expiration}", expires, "%expires%", expires, "{expires}", expires, "%expires_at%", expires, "{expires_at}", expires, "%expiration%", expires, "{expiration}", expires, "%expiry%", expires, "{expiry}", expires, "%duration%", expires, "{duration}", expires, "%issuer%", issuer, "{issuer}", issuer, "%staff%", issuer, "{staff}", issuer, "%by%", issuer, "{by}", issuer, "%player%", player, "{player}", player, "%target%", player, "{target}", player, "%id%", id, "{id}", id, "%type%", type, "{type}", type};
    }

    private String formatExpires(PunishmentRecord record) {
        if (record == null || record.getExpiresAt() == null) {
            return "Permanent";
        }
        long remainingSeconds = Math.max(0L, (record.getExpiresAt() - System.currentTimeMillis()) / 1000L);
        if (remainingSeconds <= 0L) {
            return "Expired";
        }
        if (this.plugin != null && this.plugin.getLanguageManager() != null) {
            return this.plugin.getLanguageManager().formatDuration(remainingSeconds, true);
        }
        return NumberUtils.formatCountdown(remainingSeconds);
    }

    private String formatIssuer(PunishmentRecord record) {
        if (record == null) {
            return "unknown";
        }
        String issuer = record.getIssuerNameSnapshot();
        return issuer == null || issuer.isBlank() ? "unknown" : issuer;
    }
}

