/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.block.Block
 *  org.bukkit.block.BlockState
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.EnderCrystal
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.TNTPrimed
 *  org.bukkit.entity.minecart.ExplosiveMinecart
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.entity.EntityDamageByBlockEvent
 *  org.bukkit.event.entity.EntityDamageByEntityEvent
 *  org.bukkit.event.entity.EntityDamageEvent$DamageCause
 */
package com.bx.magicSmp.listeners;

import com.bx.magicSmp.MagicSmp;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.entity.minecart.ExplosiveMinecart;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByBlockEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;

public class ExplosionDamageListener
implements Listener {
    private final MagicSmp plugin;

    public ExplosionDamageListener(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority=EventPriority.HIGH, ignoreCancelled=true)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        Entity entity = event.getEntity();
        if (!(entity instanceof Player)) {
            return;
        }
        Player player = (Player)entity;
        EntityDamageEvent.DamageCause cause = event.getCause();
        if (cause != EntityDamageEvent.DamageCause.ENTITY_EXPLOSION && cause != EntityDamageEvent.DamageCause.BLOCK_EXPLOSION) {
            return;
        }
        FileConfiguration config = this.plugin.getConfigManager().getConfig();
        if (event.getDamager() instanceof EnderCrystal) {
            boolean enabled = config.getBoolean("END-CRYSTAL.ENABLED", false);
            if (!enabled) {
                return;
            }
            double multiplier = config.getDouble("END-CRYSTAL.DAMAGE", 2.0);
            event.setDamage(event.getDamage() * multiplier);
            return;
        }
        if (event.getDamager() instanceof TNTPrimed) {
            boolean enabled = config.getBoolean("TNT.ENABLED", true);
            if (!enabled) {
                event.setCancelled(true);
            } else {
                double multiplier = config.getDouble("TNT.DAMAGE", 1.0);
                event.setDamage(event.getDamage() * multiplier);
            }
            return;
        }
        if (event.getDamager() instanceof ExplosiveMinecart) {
            boolean enabled = config.getBoolean("TNT-MINECART.ENABLED", true);
            if (!enabled) {
                event.setCancelled(true);
            } else {
                double multiplier = config.getDouble("TNT-MINECART.DAMAGE", 1.0);
                event.setDamage(event.getDamage() * multiplier);
            }
            return;
        }
        if (cause == EntityDamageEvent.DamageCause.ENTITY_EXPLOSION) {
            boolean enabled = config.getBoolean("OTHER-EXPLOSIONS.ENABLED", true);
            if (!enabled) {
                event.setCancelled(true);
            } else {
                double multiplier = config.getDouble("OTHER-EXPLOSIONS.DAMAGE", 1.0);
                event.setDamage(event.getDamage() * multiplier);
            }
        }
    }

    @EventHandler(priority=EventPriority.HIGH, ignoreCancelled=true)
    public void onEntityDamageByBlock(EntityDamageByBlockEvent event) {
        Entity entity = event.getEntity();
        if (!(entity instanceof Player)) {
            return;
        }
        Player player = (Player)entity;
        EntityDamageEvent.DamageCause cause = event.getCause();
        if (cause != EntityDamageEvent.DamageCause.BLOCK_EXPLOSION) {
            return;
        }
        FileConfiguration config = this.plugin.getConfigManager().getConfig();
        if (this.isRespawnAnchorDamage(event)) {
            boolean enabled = config.getBoolean("RESPAWN-ANCHOR.ENABLED", false);
            if (!enabled) {
                return;
            }
            double multiplier = config.getDouble("RESPAWN-ANCHOR.DAMAGE", 2.0);
            event.setDamage(event.getDamage() * multiplier);
            return;
        }
        boolean enabled = config.getBoolean("OTHER-EXPLOSIONS.ENABLED", true);
        if (!enabled) {
            event.setCancelled(true);
        } else {
            double multiplier = config.getDouble("OTHER-EXPLOSIONS.DAMAGE", 1.0);
            event.setDamage(event.getDamage() * multiplier);
        }
    }

    private boolean isRespawnAnchorDamage(EntityDamageByBlockEvent event) {
        Block damager = event.getDamager();
        if (damager != null && damager.getType() == Material.RESPAWN_ANCHOR) {
            return true;
        }
        BlockState state = event.getDamagerBlockState();
        return state != null && state.getType() == Material.RESPAWN_ANCHOR;
    }
}

