/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.event.Event$Result
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.event.inventory.InventoryCloseEvent
 *  org.bukkit.event.inventory.InventoryDragEvent
 */
package com.bx.magicSmp.listeners;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.menus.BaseMenu;
import com.bx.magicSmp.menus.RTPMenu;
import com.bx.magicSmp.menus.SellMenu;
import java.lang.invoke.LambdaMetafactory;
import org.bukkit.entity.Entity;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

public class InventoryClickListener
implements Listener {
    private final MagicSmp plugin;

    public InventoryClickListener(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        HumanEntity humanEntity = event.getWhoClicked();
        if (!(humanEntity instanceof Player)) {
            return;
        }
        Player player = (Player)humanEntity;
        Inventory inv = event.getInventory();
        InventoryHolder inventoryHolder = inv.getHolder();
        if (!(inventoryHolder instanceof BaseMenu)) {
            return;
        }
        BaseMenu menu = (BaseMenu)inventoryHolder;
        Inventory topInventory = event.getView().getTopInventory();
        if (menu instanceof SellMenu) {
            SellMenu sellMenu = (SellMenu)menu;
            sellMenu.handleInventoryClick(event);
            return;
        }
        if (menu instanceof RTPMenu) {
            this.handleRtpMenuClick(event, player, menu);
            return;
        }
        event.setCancelled(true);
        if (event.getClickedInventory() == null || !event.getClickedInventory().equals(topInventory)) {
            return;
        }
        if (event.getCurrentItem() == null) {
            return;
        }
        menu.handleClick(event.getSlot(), player, event.getClick());
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        HumanEntity humanEntity;
        Inventory inv = event.getInventory();
        InventoryHolder inventoryHolder = inv.getHolder();
        if (!(inventoryHolder instanceof BaseMenu)) {
            return;
        }
        BaseMenu menu = (BaseMenu)inventoryHolder;
        if (menu instanceof SellMenu) {
            SellMenu sellMenu = (SellMenu)menu;
            sellMenu.handleInventoryDrag(event);
            return;
        }
        if (menu instanceof RTPMenu && (humanEntity = event.getWhoClicked()) instanceof Player) {
            Player player = (Player)humanEntity;
            event.setCancelled(true);
            event.setResult(Event.Result.DENY);
            this.syncInventory(player);
            return;
        }
        event.setCancelled(true);
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        HumanEntity humanEntity = event.getPlayer();
        if (!(humanEntity instanceof Player)) {
            return;
        }
        Player player = (Player)humanEntity;
        InventoryHolder inventoryHolder = event.getInventory().getHolder();
        if (inventoryHolder instanceof BaseMenu) {
            BaseMenu menu = (BaseMenu)inventoryHolder;
            menu.onClose(player);
        }
    }

    private void handleRtpMenuClick(InventoryClickEvent event, Player player, BaseMenu menu) {
        Inventory topInventory = event.getView().getTopInventory();
        Object originalCursor = event.getCursor() == null ? null : event.getCursor().clone();
        int rawSlot = event.getRawSlot();
        ClickType clickType = event.getClick();
        boolean validTopClick = event.getClickedInventory() != null && event.getClickedInventory().equals(topInventory) && event.getCurrentItem() != null && !event.getCurrentItem().getType().isAir();
        event.setCancelled(true);
        event.setResult(Event.Result.DENY);
        this.plugin.getSpigotScheduler().runEntity((Entity)player, () -> InventoryClickListener.lambda$handleRtpMenuClick$0(player, (ItemStack)originalCursor, validTopClick, menu, rawSlot, clickType));
    }

    private void handleProtectedMenuClick(InventoryClickEvent event, Player player, BaseMenu menu) {
        Inventory topInventory = event.getView().getTopInventory();
        Object originalCursor = event.getCursor() == null ? null : event.getCursor().clone();
        int rawSlot = event.getRawSlot();
        ClickType clickType = event.getClick();
        boolean validTopClick = event.getClickedInventory() != null && event.getClickedInventory().equals(topInventory) && event.getCurrentItem() != null && !event.getCurrentItem().getType().isAir();
        event.setCancelled(true);
        event.setResult(Event.Result.DENY);
        this.plugin.getSpigotScheduler().runEntity((Entity)player, () -> InventoryClickListener.lambda$handleProtectedMenuClick$1(player, (ItemStack)originalCursor, validTopClick, menu, rawSlot, clickType));
    }

    private void syncInventory(Player player) {
        this.plugin.getSpigotScheduler().runEntity((Entity)player, player::updateInventory);
    }

    private static /* synthetic */ void lambda$handleProtectedMenuClick$1(Player player, ItemStack originalCursor, boolean validTopClick, BaseMenu menu, int rawSlot, ClickType clickType) {
        if (!player.isOnline()) {
            return;
        }
        player.setItemOnCursor(originalCursor);
        player.updateInventory();
        if (validTopClick) {
            menu.handleClick(rawSlot, player, clickType);
        }
    }

    private static /* synthetic */ void lambda$handleRtpMenuClick$0(Player player, ItemStack originalCursor, boolean validTopClick, BaseMenu menu, int rawSlot, ClickType clickType) {
        if (!player.isOnline()) {
            return;
        }
        player.setItemOnCursor(originalCursor);
        player.closeInventory();
        player.updateInventory();
        if (validTopClick) {
            menu.handleClick(rawSlot, player, clickType);
        }
    }
}

