/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.GameMode
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.player.PlayerMoveEvent
 *  org.bukkit.permissions.Permissible
 */
package com.bx.magicSmp.listeners;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.PermissionUtils;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.permissions.Permissible;

public class PlayerMoveListener
implements Listener {
    private final MagicSmp plugin;

    public PlayerMoveListener(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        if (event.getFrom().getBlockX() == event.getTo().getBlockX() && event.getFrom().getBlockZ() == event.getTo().getBlockZ() && event.getFrom().getBlockY() == event.getTo().getBlockY()) {
            return;
        }
        if (player.getAllowFlight() && player.getGameMode() != GameMode.CREATIVE && player.getGameMode() != GameMode.SPECTATOR && this.plugin.getConfigManager().getConfig().getBoolean("FLY-SYSTEM.AUTO-DISABLE-OUTSIDE", true) && !PermissionUtils.has((Permissible)player, "MagicSMP.staff.fly")) {
            String playerFlyPerm = this.plugin.getConfigManager().getConfig().getString("FLY-SYSTEM.PLAYER-FLY-PERMISSION", "MagicSMP.player.fly");
            if (PermissionUtils.has((Permissible)player, playerFlyPerm)) {
                boolean inCombat;
                boolean inSpawn = this.plugin.getSpawnManager().isInSpawnCuboid(player);
                boolean bl = inCombat = this.plugin.getCombatManager() != null && this.plugin.getCombatManager().isInCombat(player.getUniqueId());
                if (!inSpawn || inCombat) {
                    player.setFlying(false);
                    player.setAllowFlight(false);
                    String msg = this.plugin.getConfigManager().getMessageOrDefault("FLY.PLAYER_DISABLED", "&c\u2717 &7Flight deactivated because you left the allowed area or entered combat.");
                    player.sendMessage(ColorUtils.toComponent(msg));
                }
            } else {
                player.setFlying(false);
                player.setAllowFlight(false);
            }
        }
        if (this.plugin.getTeleportManager().hasPending(player.getUniqueId())) {
            this.plugin.getTeleportManager().checkMovement(player);
        }
    }
}

