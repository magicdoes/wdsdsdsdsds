/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.comphenix.protocol.PacketType
 *  com.comphenix.protocol.PacketType$Play$Server
 *  com.comphenix.protocol.ProtocolLibrary
 *  com.comphenix.protocol.ProtocolManager
 *  com.comphenix.protocol.events.ListenerPriority
 *  com.comphenix.protocol.events.PacketAdapter
 *  com.comphenix.protocol.events.PacketContainer
 *  com.comphenix.protocol.events.PacketEvent
 *  com.comphenix.protocol.events.PacketListener
 *  org.bukkit.GameMode
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Item
 *  org.bukkit.entity.LivingEntity
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.entity.EntityPickupItemEvent
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.event.inventory.InventoryCloseEvent
 *  org.bukkit.event.inventory.InventoryDragEvent
 *  org.bukkit.event.inventory.InventoryOpenEvent
 *  org.bukkit.event.player.PlayerJoinEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 *  org.bukkit.plugin.Plugin
 */
package com.bx.magicSmp.listeners;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.menus.BaseMenu;
import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.ProtocolManager;
import com.comphenix.protocol.events.ListenerPriority;
import com.comphenix.protocol.events.PacketAdapter;
import com.comphenix.protocol.events.PacketContainer;
import com.comphenix.protocol.events.PacketEvent;
import com.comphenix.protocol.events.PacketListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Item;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

public class WorthPacketDisplay
implements Listener {
    private final MagicSmp plugin;
    private final ProtocolManager protocolManager;
    private final Set<UUID> inPluginMenu = ConcurrentHashMap.newKeySet();
    private final Set<UUID> pendingRefresh = ConcurrentHashMap.newKeySet();
    private final Map<UUID, Material> suppressedMaterials = new ConcurrentHashMap<UUID, Material>();
    private final Set<UUID> openInventories = ConcurrentHashMap.newKeySet();

    public WorthPacketDisplay(MagicSmp plugin) {
        this.plugin = plugin;
        this.protocolManager = ProtocolLibrary.getProtocolManager();
        this.registerPacketListener();
        this.registerAttemptPickupListener();
    }

    private void registerAttemptPickupListener() {
        try {
            Class<?> eventClass = Class.forName("org.bukkit.event.player.PlayerAttemptPickupItemEvent");
            this.plugin.getServer().getPluginManager().registerEvent(eventClass, (Listener)this, EventPriority.LOWEST, (listener, event) -> {
                try {
                    Player player = (Player)event.getClass().getMethod("getPlayer", new Class[0]).invoke((Object)event, new Object[0]);
                    Item itemEntity = (Item)event.getClass().getMethod("getItem", new Class[0]).invoke((Object)event, new Object[0]);
                    ItemStack current = itemEntity.getItemStack();
                    if (player.getGameMode() != GameMode.CREATIVE) {
                        this.plugin.getWorthManager().stripStorageWorthDisplayForNativePickup(player, current);
                    }
                }
                catch (Exception exception) {
                    // empty catch block
                }
            }, (Plugin)this.plugin, true);
        }
        catch (ClassNotFoundException classNotFoundException) {
            // empty catch block
        }
    }

    private void registerPacketListener() {
        final MagicSmp uds = this.plugin;
        this.protocolManager.addPacketListener((PacketListener)new PacketAdapter((Plugin)this.plugin, ListenerPriority.NORMAL, new PacketType[]{PacketType.Play.Server.SET_SLOT, PacketType.Play.Server.WINDOW_ITEMS}){

            public void onPacketSending(PacketEvent event) {
                if (event.isPlayerTemporary()) {
                    return;
                }
                Player player = event.getPlayer();
                if (player == null || player.getGameMode() == GameMode.CREATIVE) {
                    return;
                }
                Material suppressedMat = WorthPacketDisplay.this.suppressedMaterials.get(player.getUniqueId());
                if (!uds.getWorthManager().isWorthDisplayEnabledFor(player)) {
                    return;
                }
                PacketContainer packet = event.getPacket();
                if (event.getPacketType() == PacketType.Play.Server.SET_SLOT) {
                    ItemStack item = (ItemStack)packet.getItemModifier().read(0);
                    if (item != null && item.getType() == suppressedMat) {
                        return;
                    }
                    ItemStack rendered = uds.getWorthManager().renderClientWorthDisplay(item);
                    if (rendered != item) {
                        packet.getItemModifier().write(0, (Object)rendered);
                    }
                    return;
                }
                List items = (List)packet.getItemListModifier().read(0);
                if (items == null || items.isEmpty()) {
                    return;
                }
                ArrayList<ItemStack> updated = new ArrayList<ItemStack>(items.size());
                boolean changed = false;
                for (int i = 0; i < items.size(); ++i) {
                    ItemStack item = (ItemStack)items.get(i);
                    if (item != null && item.getType() == suppressedMat) {
                        updated.add(item);
                        continue;
                    }
                    ItemStack rendered = uds.getWorthManager().renderClientWorthDisplay(item);
                    if (rendered != item) {
                        changed = true;
                        updated.add(rendered);
                        continue;
                    }
                    updated.add(item);
                }
                if (changed) {
                    packet.getItemListModifier().write(0, updated);
                }
            }
        });
    }

    private static int readWindowId(PacketContainer packet) {
        if (packet.getIntegers().size() > 0) {
            return (Integer)packet.getIntegers().read(0);
        }
        return -1;
    }

    private static int readSlotIndex(PacketContainer packet) {
        if (packet.getShorts().size() > 0) {
            return ((Short)packet.getShorts().read(0)).shortValue();
        }
        if (packet.getIntegers().size() > 2) {
            return (Integer)packet.getIntegers().read(2);
        }
        return -1;
    }

    @EventHandler
    public void onInventoryOpen(InventoryOpenEvent event) {
        this.openInventories.add(event.getPlayer().getUniqueId());
        if (event.getInventory().getHolder() instanceof BaseMenu) {
            this.inPluginMenu.add(event.getPlayer().getUniqueId());
        } else {
            this.plugin.getWorthManager().sanitizeInventory(event.getInventory());
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        UUID uuid = event.getPlayer().getUniqueId();
        this.inPluginMenu.remove(uuid);
        this.suppressedMaterials.remove(uuid);
        this.openInventories.remove(uuid);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        UUID uuid = event.getPlayer().getUniqueId();
        this.suppressedMaterials.remove(uuid);
        this.inPluginMenu.remove(uuid);
        this.openInventories.remove(uuid);
        this.plugin.getWorthManager().clearWorthDisplay(event.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        UUID uuid = event.getPlayer().getUniqueId();
        this.suppressedMaterials.remove(uuid);
        this.inPluginMenu.remove(uuid);
        this.openInventories.remove(uuid);
        this.pendingRefresh.remove(uuid);
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onPickup(EntityPickupItemEvent event) {
        LivingEntity livingEntity = event.getEntity();
        if (!(livingEntity instanceof Player)) {
            return;
        }
        Player player = (Player)livingEntity;
        ItemStack current = event.getItem().getItemStack();
        ItemStack stripped = this.plugin.getWorthManager().stripWorthDisplay(current);
        if (stripped != current) {
            event.getItem().setItemStack(stripped);
        }
        this.plugin.getWorthManager().stripStorageWorthDisplayForNativePickup(player, current);
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onInventoryClick(InventoryClickEvent event) {
        HumanEntity humanEntity;
        ItemStack stripped;
        ItemStack cursor;
        ItemStack stripped2;
        ItemStack current = event.getCurrentItem();
        if (current != null && (stripped2 = this.plugin.getWorthManager().stripWorthDisplay(current)) != current) {
            event.setCurrentItem(stripped2);
        }
        if ((cursor = event.getCursor()) != null && !cursor.getType().isAir() && (stripped = this.plugin.getWorthManager().stripWorthDisplay(cursor)) != cursor) {
            event.setCursor(stripped);
        }
        if (!((humanEntity = event.getWhoClicked()) instanceof Player)) {
            return;
        }
        Player player = (Player)humanEntity;
        this.openInventories.add(player.getUniqueId());
        if (cursor != null && !cursor.getType().isAir()) {
            this.suppressedMaterials.put(player.getUniqueId(), cursor.getType());
        } else if (current != null && !current.getType().isAir()) {
            this.suppressedMaterials.put(player.getUniqueId(), current.getType());
        }
        this.scheduleCursorEval(player);
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onInventoryDrag(InventoryDragEvent event) {
        HumanEntity humanEntity = event.getWhoClicked();
        if (humanEntity instanceof Player) {
            Player player = (Player)humanEntity;
            ItemStack oldCursor = event.getOldCursor();
            if (oldCursor != null && !oldCursor.getType().isAir()) {
                this.suppressedMaterials.put(player.getUniqueId(), oldCursor.getType());
            }
            this.scheduleCursorEval(player);
        }
    }

    private void scheduleCursorEval(Player player) {
        if (this.inPluginMenu.contains(player.getUniqueId())) {
            return;
        }
        if (!this.plugin.getWorthManager().isWorthDisplayEnabledFor(player)) {
            return;
        }
        if (!this.pendingRefresh.add(player.getUniqueId())) {
            return;
        }
        this.plugin.getSpigotScheduler().runEntityLater((Entity)player, () -> {
            UUID uuid = player.getUniqueId();
            this.pendingRefresh.remove(uuid);
            if (!player.isOnline() || player.getGameMode() == GameMode.CREATIVE) {
                this.suppressedMaterials.remove(uuid);
                return;
            }
            ItemStack onCursor = player.getItemOnCursor();
            if (onCursor != null && !onCursor.getType().isAir()) {
                this.suppressedMaterials.put(uuid, onCursor.getType());
            } else {
                this.suppressedMaterials.remove(uuid);
            }
            if (this.openInventories.contains(uuid)) {
                player.updateInventory();
            }
        }, 1L);
    }
}

