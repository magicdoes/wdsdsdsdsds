/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.player.PlayerDropItemEvent
 *  org.bukkit.permissions.Permissible
 *  org.bukkit.plugin.Plugin
 */
package com.bx.magicSmp.listeners;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.PermissionUtils;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.permissions.Permissible;
import org.bukkit.plugin.Plugin;

public class ItemDropListener
implements Listener {
    private final MagicSmp plugin;

    public ItemDropListener(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority=EventPriority.HIGH, ignoreCancelled=true)
    public void onPlayerDropItem(PlayerDropItemEvent event) {
        Player player = event.getPlayer();
        boolean preventSpawn = this.plugin.getConfigManager().getConfig().getBoolean("PREVENT-ITEM-DROP.SPAWN", true);
        if (!preventSpawn) {
            return;
        }
        String bypassPermission = this.plugin.getConfigManager().getConfig().getString("PREVENT-ITEM-DROP.BYPASS-PERMISSION", "MagicSMP.preventdrop.bypass");
        if (PermissionUtils.has((Permissible)player, bypassPermission)) {
            return;
        }
        boolean block = false;
        if (preventSpawn && this.isInSpawnArea(player)) {
            block = true;
        }
        if (block) {
            event.setCancelled(true);
            Bukkit.getScheduler().runTask((Plugin)this.plugin, () -> {
                if (player.isOnline()) {
                    player.updateInventory();
                }
            });
            String message = this.plugin.getConfigManager().getConfig().getString("PREVENT-ITEM-DROP.MESSAGE", "&c\u2717 You are not allowed to drop items in spawn areas!");
            if (message != null && !message.isBlank()) {
                player.sendMessage(ColorUtils.toComponent(message));
            }
        }
    }

    private boolean isInSpawnArea(Player player) {
        return this.plugin.getSpawnManager().isInSpawnCuboid(player);
    }
}

