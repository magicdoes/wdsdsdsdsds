/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.md_5.bungee.api.chat.BaseComponent
 *  net.md_5.bungee.api.chat.HoverEvent
 *  net.md_5.bungee.api.chat.HoverEvent$Action
 *  net.md_5.bungee.api.chat.TextComponent
 *  org.bukkit.GameRule
 *  org.bukkit.advancement.Advancement
 *  org.bukkit.event.player.PlayerAdvancementDoneEvent
 *  org.bukkit.event.world.WorldLoadEvent
 */
package com.bx.magicSmp.listeners;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.models.PlayerData;
import com.bx.magicSmp.models.ThreeChoice;
import com.bx.magicSmp.utils.ColorUtils;
import net.md_5.bungee.api.chat.BaseComponent;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.GameRule;
import org.bukkit.World;
import org.bukkit.advancement.Advancement;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerAdvancementDoneEvent;
import org.bukkit.event.world.WorldLoadEvent;

public class PlayerAdvancementDoneListener
implements Listener {
    private final MagicSmp plugin;

    public PlayerAdvancementDoneListener(MagicSmp plugin) {
        this.plugin = plugin;
        this.disableVanillaAnnouncements();
    }

    private void disableVanillaAnnouncements() {
        for (World world : Bukkit.getWorlds()) {
            this.setAnnounceAdvancements(world, false);
        }
    }

    @EventHandler
    public void onWorldLoad(WorldLoadEvent event) {
        this.setAnnounceAdvancements(event.getWorld(), false);
    }

    private void setAnnounceAdvancements(World world, boolean value) {
        if (world == null) {
            return;
        }
        try {
            GameRule rule = GameRule.getByName((String)"announceAdvancements");
            if (rule != null) {
                world.setGameRule(rule, value);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    @EventHandler
    public void onAdvancementDone(PlayerAdvancementDoneEvent event) {
        Advancement adv = event.getAdvancement();
        if (adv.getDisplay() == null) {
            return;
        }
        Player player = event.getPlayer();
        String title = adv.getDisplay().getTitle();
        if (title == null || title.isEmpty()) {
            return;
        }
        String titleColor = "&a";
        String frameText = "made the advancement";
        if (adv.getDisplay().getType() != null) {
            switch (adv.getDisplay().getType()) {
                case GOAL: {
                    titleColor = "&6";
                    frameText = "reached the goal";
                    break;
                }
                case CHALLENGE: {
                    titleColor = "&5";
                    frameText = "completed the challenge";
                }
            }
        }
        String displayName = player.getName();
        String prefix = ColorUtils.colorize(displayName + " &7has " + frameText + " ");
        String coloredTitle = ColorUtils.colorize(titleColor + "[" + title + "]");
        String description = adv.getDisplay().getDescription();
        TextComponent announcement = new TextComponent();
        announcement.addExtra((BaseComponent)new TextComponent(TextComponent.fromLegacyText((String)prefix)));
        TextComponent titleComponent = new TextComponent(TextComponent.fromLegacyText((String)coloredTitle));
        if (description != null && !description.isBlank()) {
            titleComponent.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, ColorUtils.toBaseComponents("&7" + description, player)));
        }
        announcement.addExtra((BaseComponent)titleComponent);
        this.plugin.getSpigotScheduler().forEachOnlinePlayer(p -> {
            if (this.shouldReceiveAdvancement((Player)p, player)) {
                p.spigot().sendMessage((BaseComponent)announcement);
            }
        });
    }

    private boolean shouldReceiveAdvancement(Player receiver, Player victim) {
        PlayerData receiverData = this.plugin.getPlayerDataManager().get(receiver);
        if (receiverData == null) {
            return true;
        }
        ThreeChoice choice = receiverData.getAdvancementMessagesChoice();
        if (choice == ThreeChoice.OFF) {
            return false;
        }
        if (choice == ThreeChoice.FRIENDS_FOLLOWED) {
            return this.plugin.getFriendsManager() != null && this.plugin.getFriendsManager().isFollowing(receiver.getUniqueId(), victim.getUniqueId());
        }
        return true;
    }
}

