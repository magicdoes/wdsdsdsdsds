/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.GameMode
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Item
 *  org.bukkit.entity.LivingEntity
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.block.Action
 *  org.bukkit.event.block.BlockBreakEvent
 *  org.bukkit.event.block.BlockDamageEvent
 *  org.bukkit.event.entity.EntityPickupItemEvent
 *  org.bukkit.event.entity.PlayerDeathEvent
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.event.inventory.InventoryCloseEvent
 *  org.bukkit.event.inventory.InventoryDragEvent
 *  org.bukkit.event.inventory.InventoryOpenEvent
 *  org.bukkit.event.inventory.InventoryType
 *  org.bukkit.event.player.PlayerDropItemEvent
 *  org.bukkit.event.player.PlayerGameModeChangeEvent
 *  org.bukkit.event.player.PlayerInteractEvent
 *  org.bukkit.event.player.PlayerJoinEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 *  org.bukkit.plugin.Plugin
 */
package com.bx.magicSmp.listeners;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.menus.BaseMenu;
import com.bx.magicSmp.menus.SellMenu;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.GameMode;
import org.bukkit.entity.Entity;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Item;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockDamageEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerGameModeChangeEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

public class WorthDisplayListener
implements Listener {
    private static final long AMETHYST_REFRESH_DELAY_TICKS = 20L;
    private final MagicSmp plugin;
    private final Set<UUID> dirtyPlayers = ConcurrentHashMap.newKeySet();
    private final Set<UUID> pendingRefreshes = ConcurrentHashMap.newKeySet();
    private final Set<UUID> forceUpdatePlayers = ConcurrentHashMap.newKeySet();
    private final Map<UUID, Long> lastMiningTimes = new ConcurrentHashMap<UUID, Long>();

    public WorthDisplayListener(MagicSmp plugin) {
        this.plugin = plugin;
        this.startDirtySyncTask();
        this.registerAttemptPickupListener();
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        this.plugin.getWorthManager().clearWorthDisplay(event.getPlayer());
        this.queueRefresh(event.getPlayer(), 2L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        UUID uuid = event.getPlayer().getUniqueId();
        this.pendingRefreshes.remove(uuid);
        this.dirtyPlayers.remove(uuid);
        this.forceUpdatePlayers.remove(uuid);
        this.lastMiningTimes.remove(uuid);
        this.plugin.getWorthManager().clearWorthDisplay(event.getPlayer());
    }

    @EventHandler(ignoreCancelled=true)
    public void onGameModeChange(PlayerGameModeChangeEvent event) {
        if (event.getNewGameMode() == GameMode.CREATIVE) {
            this.queueClear(event.getPlayer(), 1L);
            return;
        }
        this.queueRefresh(event.getPlayer(), 2L);
    }

    @EventHandler(ignoreCancelled=true)
    public void onInventoryOpen(InventoryOpenEvent event) {
        HumanEntity humanEntity = event.getPlayer();
        if (!(humanEntity instanceof Player)) {
            return;
        }
        Player player = (Player)humanEntity;
        if (this.isPlayerInventoryView(event.getInventory())) {
            return;
        }
        if (this.plugin.getInvseeManager().isInvseeInventory(event.getInventory())) {
            return;
        }
        if (!(event.getInventory().getHolder() instanceof SellMenu) && !(event.getInventory().getHolder() instanceof BaseMenu)) {
            this.plugin.getWorthManager().sanitizeInventory(event.getInventory());
        }
        if (this.isShulkerInventory(event.getInventory())) {
            this.queueRefresh(player, 1L);
            return;
        }
        this.queueRefresh(player, 1L);
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onInventoryClick(InventoryClickEvent event) {
        HumanEntity humanEntity = event.getWhoClicked();
        if (!(humanEntity instanceof Player)) {
            return;
        }
        Player player = (Player)humanEntity;
        if (player.getGameMode() == GameMode.CREATIVE) {
            return;
        }
        if (this.isAmethystItem(event.getCurrentItem()) || this.isAmethystItem(event.getCursor())) {
            return;
        }
        Inventory topInventory = event.getView().getTopInventory();
        if (topInventory.getHolder() instanceof SellMenu || topInventory.getHolder() instanceof BaseMenu || this.plugin.getInvseeManager().isInvseeInventory(topInventory)) {
            return;
        }
        ItemStack cursor = event.getCursor();
        ItemStack current = event.getCurrentItem();
        boolean isStacking = cursor != null && !cursor.getType().isAir() && current != null && !current.getType().isAir() && this.plugin.getWorthManager().isSimilarIgnoringWorth(cursor, current);
        boolean strippedAny = false;
        if (event.getClick() == ClickType.DOUBLE_CLICK) {
            this.plugin.getWorthManager().mergeStorageStacksForNativeBehavior(player);
            strippedAny = true;
        } else if (isStacking) {
            ClickType click = event.getClick();
            if (click == ClickType.LEFT || click == ClickType.RIGHT) {
                int maxStack = current.getMaxStackSize();
                int currentAmount = current.getAmount();
                if (currentAmount < maxStack) {
                    event.setCancelled(true);
                    int cursorAmount = cursor.getAmount();
                    int transfer = click == ClickType.LEFT ? Math.min(cursorAmount, maxStack - currentAmount) : 1;
                    Object newCurrent = current.clone();
                    newCurrent.setAmount(currentAmount + transfer);
                    newCurrent = this.plugin.getWorthManager().stripWorthDisplay((ItemStack)newCurrent);
                    Object newCursor = cursor.clone();
                    newCursor.setAmount(cursorAmount - transfer);
                    newCursor = newCursor.getAmount() <= 0 ? null : this.plugin.getWorthManager().stripWorthDisplay((ItemStack)newCursor);
                    event.getClickedInventory().setItem(event.getSlot(), (ItemStack)newCurrent);
                    player.setItemOnCursor((ItemStack)newCursor);
                    this.plugin.getWorthManager().mergePlayerStorageStacks(player);
                    this.queueRefresh(player, 1L, true);
                    return;
                }
            }
        } else if (event.getClick().isShiftClick() && current != null && !current.getType().isAir()) {
            ItemStack strippedCurrent;
            if (this.plugin.getWorthManager().stripStorageWorthDisplayForNativePickup(player, current)) {
                strippedAny = true;
            }
            if ((strippedCurrent = this.plugin.getWorthManager().stripWorthDisplay(current)) != current) {
                event.setCurrentItem(strippedCurrent);
                strippedAny = true;
            }
            this.plugin.getWorthManager().mergePlayerStorageStacks(player);
        }
        if (this.isShulkerInventory(topInventory)) {
            this.plugin.getWorthManager().sanitizeInventory(topInventory);
        }
        this.queueRefresh(player, 1L, strippedAny);
    }

    @EventHandler(ignoreCancelled=true)
    public void onInventoryDrag(InventoryDragEvent event) {
        HumanEntity humanEntity = event.getWhoClicked();
        if (!(humanEntity instanceof Player)) {
            return;
        }
        Player player = (Player)humanEntity;
        if (this.isAmethystItem(event.getOldCursor())) {
            return;
        }
        if (this.isShulkerInventory(event.getView().getTopInventory())) {
            this.queueRefresh(player, 1L);
            return;
        }
        this.queueRefresh(player, 1L);
    }

    @EventHandler(ignoreCancelled=true)
    public void onInventoryClose(InventoryCloseEvent event) {
        if (this.isPlayerInventoryView(event.getInventory())) {
            return;
        }
        if (this.plugin.getInvseeManager().isInvseeInventory(event.getInventory())) {
            return;
        }
        if (!(event.getInventory().getHolder() instanceof SellMenu) && !(event.getInventory().getHolder() instanceof BaseMenu)) {
            this.plugin.getWorthManager().sanitizeInventory(event.getInventory());
        }
    }

    @EventHandler(ignoreCancelled=true)
    public void onDrop(PlayerDropItemEvent event) {
        event.getItemDrop().setItemStack(this.plugin.getWorthManager().stripWorthDisplay(event.getItemDrop().getItemStack()));
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onPickup(EntityPickupItemEvent event) {
        LivingEntity livingEntity = event.getEntity();
        if (livingEntity instanceof Player) {
            Player player = (Player)livingEntity;
            if (player.getGameMode() == GameMode.CREATIVE) {
                return;
            }
            ItemStack current = event.getItem().getItemStack();
            if (this.isAmethystItem(current)) {
                return;
            }
            ItemStack stripped = this.plugin.getWorthManager().stripWorthDisplay(current);
            if (stripped != current) {
                event.getItem().setItemStack(stripped);
            }
            this.plugin.getWorthManager().stripStorageWorthDisplayForNativePickup(player, current);
            this.plugin.getWorthManager().mergePlayerStorageStacks(player);
            this.queueRefresh(player, 1L);
        }
    }

    private void registerAttemptPickupListener() {
        try {
            Class<?> eventClass = Class.forName("org.bukkit.event.player.PlayerAttemptPickupItemEvent");
            this.plugin.getServer().getPluginManager().registerEvent(eventClass, (Listener)this, EventPriority.LOWEST, (listener, event) -> {
                try {
                    Player player = (Player)event.getClass().getMethod("getPlayer", new Class[0]).invoke((Object)event, new Object[0]);
                    Item itemEntity = (Item)event.getClass().getMethod("getItem", new Class[0]).invoke((Object)event, new Object[0]);
                    ItemStack current = itemEntity.getItemStack();
                    if (player.getGameMode() != GameMode.CREATIVE && !this.isAmethystItem(current)) {
                        this.plugin.getWorthManager().stripStorageWorthDisplayForNativePickup(player, current);
                        this.plugin.getWorthManager().mergePlayerStorageStacks(player);
                        this.queueRefresh(player, 1L);
                    }
                }
                catch (Exception exception) {
                    // empty catch block
                }
            }, (Plugin)this.plugin, true);
        }
        catch (ClassNotFoundException classNotFoundException) {
            // empty catch block
        }
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        List drops = event.getDrops();
        for (int index = 0; index < drops.size(); ++index) {
            drops.set(index, this.plugin.getWorthManager().stripWorthDisplay((ItemStack)drops.get(index)));
        }
        UUID uuid = event.getEntity().getUniqueId();
        this.pendingRefreshes.remove(uuid);
        this.dirtyPlayers.remove(uuid);
        this.plugin.getWorthManager().clearWorthDisplay(event.getEntity());
    }

    private void queueRefresh(Player player, long delayTicks) {
        this.queueRefresh(player, delayTicks, false);
    }

    private void queueRefresh(Player player, long delayTicks, boolean forceUpdate) {
        long effectiveDelay = delayTicks;
        if (this.plugin.getAmethystToolsManager().isVisualSyncSuppressed(player.getUniqueId())) {
            effectiveDelay = Math.max(effectiveDelay, 20L);
        }
        UUID uuid = player.getUniqueId();
        if (forceUpdate) {
            this.forceUpdatePlayers.add(uuid);
        }
        if (!this.pendingRefreshes.add(uuid)) {
            return;
        }
        this.plugin.getSpigotScheduler().runEntityLater((Entity)player, () -> {
            this.pendingRefreshes.remove(uuid);
            if (!player.isOnline()) {
                this.forceUpdatePlayers.remove(uuid);
                return;
            }
            this.dirtyPlayers.add(uuid);
        }, effectiveDelay);
    }

    private void queueClear(Player player, long delayTicks) {
        this.plugin.getSpigotScheduler().runEntityLater((Entity)player, () -> {
            if (!player.isOnline()) {
                return;
            }
            this.pendingRefreshes.remove(player.getUniqueId());
            this.dirtyPlayers.remove(player.getUniqueId());
            this.plugin.getWorthManager().clearWorthDisplay(player);
        }, delayTicks);
    }

    private void startDirtySyncTask() {
        this.plugin.getSpigotScheduler().runGlobalTimer(this::syncDirtyPlayers, 1L, 1L);
    }

    private void syncDirtyPlayers() {
        if (this.dirtyPlayers.isEmpty()) {
            return;
        }
        for (UUID uuid : Set.copyOf(this.dirtyPlayers)) {
            Player player = this.plugin.getServer().getPlayer(uuid);
            boolean forceUpdate = this.forceUpdatePlayers.contains(uuid);
            if (!forceUpdate && player != null && player.isOnline()) {
                long lastMining = this.lastMiningTimes.getOrDefault(uuid, 0L);
                if (System.currentTimeMillis() - lastMining < 1500L) continue;
            }
            this.dirtyPlayers.remove(uuid);
            if (player == null || !player.isOnline()) {
                this.forceUpdatePlayers.remove(uuid);
                this.lastMiningTimes.remove(uuid);
                continue;
            }
            this.forceUpdatePlayers.remove(uuid);
            this.plugin.getSpigotScheduler().runEntity((Entity)player, () -> {
                if (!player.isOnline()) {
                    return;
                }
                if (player.getGameMode() == GameMode.CREATIVE) {
                    this.plugin.getWorthManager().clearWorthDisplay(player);
                    this.sanitizeOpenShulkerInventory(player);
                    return;
                }
                this.plugin.getWorthManager().syncWorthDisplay(player, forceUpdate);
                this.syncOpenShulkerInventory(player);
                Inventory topInventory = player.getOpenInventory().getTopInventory();
                if (topInventory != null && !this.isPlayerInventoryView(topInventory) && !this.isShulkerInventory(topInventory)) {
                    this.plugin.getWorthManager().sanitizeInventory(topInventory);
                }
            });
        }
    }

    private boolean isPlayerInventoryView(Inventory inventory) {
        return inventory != null && (inventory.getHolder() instanceof Player || inventory.getType() == InventoryType.CRAFTING || inventory.getType() == InventoryType.CREATIVE);
    }

    private void syncOpenShulkerInventory(Player player) {
        Inventory inventory = player.getOpenInventory().getTopInventory();
        if (!this.isShulkerInventory(inventory)) {
            return;
        }
        this.plugin.getWorthManager().syncWorthDisplay(player, inventory);
    }

    private void sanitizeOpenShulkerInventory(Player player) {
        Inventory inventory = player.getOpenInventory().getTopInventory();
        if (!this.isShulkerInventory(inventory)) {
            return;
        }
        this.plugin.getWorthManager().sanitizeInventory(inventory);
    }

    private boolean isShulkerInventory(Inventory inventory) {
        return inventory != null && inventory.getType() == InventoryType.SHULKER_BOX;
    }

    private boolean isAmethystItem(ItemStack item) {
        return this.plugin.getAmethystToolsManager().isAmethystTool(item);
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=false)
    public void onBlockDamage(BlockDamageEvent event) {
        this.lastMiningTimes.put(event.getPlayer().getUniqueId(), System.currentTimeMillis());
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=false)
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (event.getAction() == Action.LEFT_CLICK_BLOCK) {
            this.lastMiningTimes.put(event.getPlayer().getUniqueId(), System.currentTimeMillis());
        }
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onBlockBreak(BlockBreakEvent event) {
        this.lastMiningTimes.put(event.getPlayer().getUniqueId(), System.currentTimeMillis());
    }
}

