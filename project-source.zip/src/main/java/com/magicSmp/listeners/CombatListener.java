/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.block.Block
 *  org.bukkit.block.BlockState
 *  org.bukkit.entity.EnderCrystal
 *  org.bukkit.entity.EnderPearl
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.LivingEntity
 *  org.bukkit.entity.Projectile
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.entity.EntityDamageByBlockEvent
 *  org.bukkit.event.entity.EntityDamageByEntityEvent
 *  org.bukkit.event.player.PlayerCommandPreprocessEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 *  org.bukkit.event.player.PlayerTeleportEvent
 *  org.bukkit.event.player.PlayerTeleportEvent$TeleportCause
 *  org.bukkit.projectiles.ProjectileSource
 */
package com.bx.magicSmp.listeners;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.models.Team;
import com.bx.magicSmp.utils.ColorUtils;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.EnderPearl;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByBlockEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.projectiles.ProjectileSource;

public class CombatListener
implements Listener {
    private final MagicSmp plugin;

    public CombatListener(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onDamage(EntityDamageByEntityEvent event) {
        Team team;
        if (!this.plugin.getCombatManager().isEnabled()) {
            return;
        }
        Entity entity = event.getEntity();
        if (!(entity instanceof Player)) {
            return;
        }
        Player victim = (Player)entity;
        DamageSource source = this.resolveDamageSource(event.getDamager());
        if (!CombatListener.shouldTagVictim(source, this.plugin.getCombatManager().isMobCombatEnabled(), this.plugin.getCombatManager().isEnderCrystalCombatEnabled())) {
            return;
        }
        Player attacker = this.resolvePlayerAttacker(event.getDamager());
        if (this.shouldBypassGlobalCombat(attacker, victim)) {
            return;
        }
        if (this.plugin.getCombatManager().isExcludedWorld(victim.getWorld().getName())) {
            return;
        }
        if (attacker != null && !attacker.getUniqueId().equals(victim.getUniqueId()) && this.plugin.getTeamManager().areTeammates(attacker.getUniqueId(), victim.getUniqueId()) && (team = this.plugin.getTeamManager().getTeam(attacker)) != null && !team.isFriendlyFireEnabled()) {
            event.setCancelled(true);
            return;
        }
        this.plugin.getCombatManager().tag(victim);
        if (attacker != null) {
            this.plugin.getCombatManager().tag(attacker);
        }
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onRespawnAnchorDamage(EntityDamageByBlockEvent event) {
        Player victim;
        block3: {
            block2: {
                Entity entity;
                if (!this.plugin.getCombatManager().isEnabled() || !this.plugin.getCombatManager().isRespawnAnchorCombatEnabled() || !((entity = event.getEntity()) instanceof Player)) break block2;
                victim = (Player)entity;
                if (this.isRespawnAnchorDamage(event) && !this.shouldBypassGlobalCombat(null, victim) && !this.plugin.getCombatManager().isExcludedWorld(victim.getWorld().getName())) break block3;
            }
            return;
        }
        this.plugin.getCombatManager().tag(victim);
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onEnderPearlTeleport(PlayerTeleportEvent event) {
        if (!this.plugin.getCombatManager().isEnabled() || !this.plugin.getCombatManager().isEnderPearlCombatEnabled() || event.getCause() != PlayerTeleportEvent.TeleportCause.ENDER_PEARL) {
            return;
        }
        Player player = event.getPlayer();
        if (this.shouldBypassGlobalCombat(null, player) || this.plugin.getCombatManager().isExcludedWorld(player.getWorld().getName())) {
            return;
        }
        this.plugin.getCombatManager().tag(player);
    }

    static boolean shouldTagVictim(DamageSource source, boolean mobsEnabled, boolean enderCrystalsEnabled) {
        return switch (source.ordinal()) {
            default -> throw new MatchException(null, null);
            case 0 -> true;
            case 1 -> mobsEnabled;
            case 2 -> enderCrystalsEnabled;
            case 3 -> false;
        };
    }

    private DamageSource resolveDamageSource(Entity damager) {
        Projectile projectile;
        ProjectileSource shooter;
        if (damager instanceof EnderCrystal) {
            return DamageSource.ENDER_CRYSTAL;
        }
        if (damager instanceof EnderPearl) {
            return this.plugin.getCombatManager().isEnderPearlCombatEnabled() ? DamageSource.PLAYER : DamageSource.OTHER;
        }
        if (this.resolvePlayerAttacker(damager) != null) {
            return DamageSource.PLAYER;
        }
        if (damager instanceof LivingEntity) {
            return DamageSource.MOB;
        }
        if (damager instanceof Projectile && (shooter = (projectile = (Projectile)damager).getShooter()) instanceof LivingEntity) {
            return DamageSource.MOB;
        }
        return DamageSource.OTHER;
    }

    private Player resolvePlayerAttacker(Entity damager) {
        if (damager instanceof Player) {
            Player player = (Player)damager;
            return player;
        }
        if (damager instanceof Projectile) {
            ProjectileSource projectileSource;
            Projectile projectile = (Projectile)damager;
            if (!(damager instanceof EnderPearl) && (projectileSource = projectile.getShooter()) instanceof Player) {
                Player player = (Player)projectileSource;
                return player;
            }
        }
        return null;
    }

    private boolean isRespawnAnchorDamage(EntityDamageByBlockEvent event) {
        Block damager = event.getDamager();
        if (damager != null && damager.getType() == Material.RESPAWN_ANCHOR) {
            return true;
        }
        BlockState state = event.getDamagerBlockState();
        return state != null && state.getType() == Material.RESPAWN_ANCHOR;
    }

    private boolean shouldBypassGlobalCombat(Player attacker, Player victim) {
        return false;
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        if (!this.plugin.getCombatManager().isEnabled()) {
            return;
        }
        Player player = event.getPlayer();
        if (!this.plugin.getCombatManager().isInCombat(player.getUniqueId())) {
            return;
        }
        if (this.plugin.getCombatManager().isExcludedWorld(player.getWorld().getName())) {
            return;
        }
        String cmd = event.getMessage().split(" ")[0].toLowerCase();
        if (this.plugin.getCombatManager().isBlockedCommand(cmd)) {
            event.setCancelled(true);
            String msg = this.plugin.getConfigManager().getConfig().getString("COMBAT-MANAGER.BLOCK-MESSAGE", "&cyou can't use this command in your current status.");
            player.sendMessage(ColorUtils.toComponent(msg));
        }
    }

    @EventHandler(priority=EventPriority.LOWEST)
    public void onQuit(PlayerQuitEvent event) {
    }

    static enum DamageSource {
        PLAYER,
        MOB,
        ENDER_CRYSTAL,
        OTHER;

    }
}

