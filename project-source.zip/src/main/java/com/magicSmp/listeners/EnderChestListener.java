/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.block.Block
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.event.Event$Result
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.block.Action
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.event.inventory.InventoryCloseEvent
 *  org.bukkit.event.inventory.InventoryDragEvent
 *  org.bukkit.event.inventory.InventoryOpenEvent
 *  org.bukkit.event.inventory.InventoryType
 *  org.bukkit.event.player.PlayerInteractEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 *  org.bukkit.inventory.EquipmentSlot
 */
package com.bx.magicSmp.listeners;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.managers.CrashProtectionManager;
import java.lang.invoke.LambdaMetafactory;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public class EnderChestListener
implements Listener {
    private final MagicSmp plugin;

    public EnderChestListener(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onEnderChestInteract(PlayerInteractEvent event) {
        if (!this.plugin.getEnderChestManager().shouldInterceptVanillaOpen()) {
            return;
        }
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        if (event.getHand() != null && event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        Block clickedBlock = event.getClickedBlock();
        if (clickedBlock == null || clickedBlock.getType() != Material.ENDER_CHEST) {
            return;
        }
        Player player = event.getPlayer();
        Location sourceLocation = clickedBlock.getLocation();
        event.setCancelled(true);
        this.plugin.getSpigotScheduler().runEntity((Entity)player, () -> {
            if (!player.isOnline()) {
                return;
            }
            this.plugin.getEnderChestManager().open(player, sourceLocation);
        });
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onInventoryOpen(InventoryOpenEvent event) {
        HumanEntity humanEntity = event.getPlayer();
        if (!(humanEntity instanceof Player)) {
            return;
        }
        Player player = (Player)humanEntity;
        if (!this.plugin.getEnderChestManager().shouldInterceptVanillaOpen()) {
            return;
        }
        if (event.getInventory().getType() != InventoryType.ENDER_CHEST) {
            return;
        }
        if (this.plugin.getEnderChestManager().isCustomEnderChest(event.getInventory())) {
            return;
        }
        event.setCancelled(true);
        this.plugin.getSpigotScheduler().runEntity((Entity)player, () -> {
            if (!player.isOnline()) {
                return;
            }
            this.plugin.getEnderChestManager().open(player);
        });
    }

    @EventHandler(ignoreCancelled=true)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!this.plugin.getEnderChestManager().isEnabled()) {
            return;
        }
        if (this.plugin.getEnderChestManager().isInspectionView(event.getView())) {
            HumanEntity humanEntity = event.getWhoClicked();
            if (humanEntity instanceof Player) {
                Player viewer = (Player)humanEntity;
                if (this.plugin.getEnderChestManager().isEcseeEditable(viewer)) {
                    this.plugin.getSpigotScheduler().runEntity((Entity)viewer, () -> {
                        if (viewer.isOnline()) {
                            this.plugin.getEnderChestManager().syncInspectionBackToTarget(event.getView().getTopInventory());
                        }
                    });
                    return;
                }
            }
            event.setCancelled(true);
            event.setResult(Event.Result.DENY);
            return;
        }
        if (this.blockUnsafeInsert(event)) {
            return;
        }
        this.plugin.getEnderChestManager().markDirty(event.getView());
    }

    @EventHandler(ignoreCancelled=true)
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!this.plugin.getEnderChestManager().isEnabled()) {
            return;
        }
        if (this.plugin.getEnderChestManager().isInspectionView(event.getView())) {
            HumanEntity humanEntity = event.getWhoClicked();
            if (humanEntity instanceof Player) {
                Player viewer = (Player)humanEntity;
                if (this.plugin.getEnderChestManager().isEcseeEditable(viewer)) {
                    this.plugin.getSpigotScheduler().runEntity((Entity)viewer, () -> {
                        if (viewer.isOnline()) {
                            this.plugin.getEnderChestManager().syncInspectionBackToTarget(event.getView().getTopInventory());
                        }
                    });
                    return;
                }
            }
            event.setCancelled(true);
            event.setResult(Event.Result.DENY);
            return;
        }
        if (this.blockUnsafeDrag(event)) {
            return;
        }
        this.plugin.getEnderChestManager().markDirty(event.getView());
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        HumanEntity humanEntity = event.getPlayer();
        if (humanEntity instanceof Player) {
            Player player = (Player)humanEntity;
            this.plugin.getEnderChestManager().handleInspectionClose(player, event.getInventory());
            this.plugin.getEnderChestManager().handleClose(player, event.getInventory());
        }
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        this.plugin.getEnderChestManager().handleInspectionViewerQuit(event.getPlayer());
        this.plugin.getEnderChestManager().handleQuit(event.getPlayer());
    }

    private boolean blockUnsafeInsert(InventoryClickEvent event) {
        Player player;
        block12: {
            block11: {
                HumanEntity humanEntity = event.getWhoClicked();
                if (!(humanEntity instanceof Player)) break block11;
                player = (Player)humanEntity;
                if (this.plugin.getEnderChestManager().isCustomEnderChestView(event.getView())) break block12;
            }
            return false;
        }
        Inventory topInventory = event.getView().getTopInventory();
        boolean clickedTop = event.getRawSlot() >= 0 && event.getRawSlot() < topInventory.getSize();
        ItemStack candidate = null;
        if (clickedTop) {
            int hotbarButton;
            candidate = event.getCursor();
            if ((candidate == null || candidate.getType().isAir()) && event.getClick() == ClickType.NUMBER_KEY && (hotbarButton = event.getHotbarButton()) >= 0) {
                candidate = player.getInventory().getItem(hotbarButton);
            }
            if ((candidate == null || candidate.getType().isAir()) && event.getClick() == ClickType.SWAP_OFFHAND) {
                candidate = player.getInventory().getItemInOffHand();
            }
        } else if (event.isShiftClick()) {
            candidate = event.getCurrentItem();
        }
        if (candidate == null || candidate.getType().isAir()) {
            return false;
        }
        if (this.plugin.getCrashProtectionManager().validateOrNotify(player, candidate, CrashProtectionManager.Context.ENDER_CHEST).allowed()) {
            return false;
        }
        event.setCancelled(true);
        this.plugin.getSpigotScheduler().runEntity((Entity)player, (Runnable)LambdaMetafactory.metafactory(null, null, null, ()V, updateInventory(), ()V)((Player)player));
        return true;
    }

    private boolean blockUnsafeDrag(InventoryDragEvent event) {
        Player player;
        block7: {
            block6: {
                HumanEntity humanEntity = event.getWhoClicked();
                if (!(humanEntity instanceof Player)) break block6;
                player = (Player)humanEntity;
                if (this.plugin.getEnderChestManager().isCustomEnderChestView(event.getView())) break block7;
            }
            return false;
        }
        Inventory topInventory = event.getView().getTopInventory();
        boolean draggingIntoTop = event.getRawSlots().stream().anyMatch(slot -> slot >= 0 && slot < topInventory.getSize());
        if (!draggingIntoTop) {
            return false;
        }
        ItemStack candidate = event.getOldCursor();
        if (candidate == null || candidate.getType().isAir()) {
            return false;
        }
        if (this.plugin.getCrashProtectionManager().validateOrNotify(player, candidate, CrashProtectionManager.Context.ENDER_CHEST).allowed()) {
            return false;
        }
        event.setCancelled(true);
        this.plugin.getSpigotScheduler().runEntity((Entity)player, (Runnable)LambdaMetafactory.metafactory(null, null, null, ()V, updateInventory(), ()V)((Player)player));
        return true;
    }
}

