/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.Phantom
 *  org.bukkit.event.entity.EntityTargetEvent
 */
package com.bx.magicSmp.listeners;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.managers.FeatureManager;
import com.bx.magicSmp.models.PlayerData;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Phantom;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityTargetEvent;

public class PhantomListener
implements Listener {
    private final MagicSmp plugin;

    public PhantomListener(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPhantomTarget(EntityTargetEvent event) {
        if (!this.plugin.getFeatureManager().isEnabled(FeatureManager.Feature.PHANTOM)) {
            return;
        }
        if (!(event.getEntity() instanceof Phantom)) {
            return;
        }
        Entity entity = event.getTarget();
        if (!(entity instanceof Player)) {
            return;
        }
        Player player = (Player)entity;
        PlayerData data = this.plugin.getPlayerDataManager().get(player);
        if (data != null && !data.isPhantomEnabled()) {
            event.setCancelled(true);
        }
    }
}

