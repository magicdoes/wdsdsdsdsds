/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.event.inventory.InventoryOpenEvent
 *  org.bukkit.event.player.AsyncPlayerChatEvent
 *  org.bukkit.event.player.PlayerCommandPreprocessEvent
 *  org.bukkit.event.player.PlayerInteractEvent
 */
package com.bx.magicSmp.listeners;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.utils.PlayerContext;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerInteractEvent;

public class PlayerContextListener
implements Listener {
    private final MagicSmp plugin;

    public PlayerContextListener(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority=EventPriority.LOWEST)
    public void onCommandLowest(PlayerCommandPreprocessEvent event) {
        PlayerContext.set(event.getPlayer());
    }

    @EventHandler(priority=EventPriority.LOWEST)
    public void onInventoryClickLowest(InventoryClickEvent event) {
        HumanEntity humanEntity = event.getWhoClicked();
        if (humanEntity instanceof Player) {
            Player player = (Player)humanEntity;
            PlayerContext.set(player);
        }
    }

    @EventHandler(priority=EventPriority.LOWEST)
    public void onInventoryOpenLowest(InventoryOpenEvent event) {
        HumanEntity humanEntity = event.getPlayer();
        if (humanEntity instanceof Player) {
            Player player = (Player)humanEntity;
            PlayerContext.set(player);
        }
    }

    @EventHandler(priority=EventPriority.LOWEST)
    public void onInteractLowest(PlayerInteractEvent event) {
        PlayerContext.set(event.getPlayer());
    }

    @EventHandler(priority=EventPriority.LOWEST)
    public void onChatLowest(AsyncPlayerChatEvent event) {
        PlayerContext.set(event.getPlayer());
    }

    @EventHandler(priority=EventPriority.MONITOR)
    public void onCommandMonitor(PlayerCommandPreprocessEvent event) {
        PlayerContext.clear();
    }

    @EventHandler(priority=EventPriority.MONITOR)
    public void onInventoryClickMonitor(InventoryClickEvent event) {
        PlayerContext.clear();
    }

    @EventHandler(priority=EventPriority.MONITOR)
    public void onInventoryOpenMonitor(InventoryOpenEvent event) {
        PlayerContext.clear();
    }

    @EventHandler(priority=EventPriority.MONITOR)
    public void onInteractMonitor(PlayerInteractEvent event) {
        PlayerContext.clear();
    }

    @EventHandler(priority=EventPriority.MONITOR)
    public void onChatMonitor(AsyncPlayerChatEvent event) {
        PlayerContext.clear();
    }
}

