/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.tasks;

import com.bx.magicSmp.MagicSmp;

public class ScoreboardTask
implements Runnable {
    private final MagicSmp plugin;

    public ScoreboardTask(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public void run() {
    }

    public static void start(MagicSmp plugin) {
    }
}

