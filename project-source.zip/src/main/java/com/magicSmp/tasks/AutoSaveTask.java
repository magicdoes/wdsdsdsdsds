/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.tasks;

import com.bx.magicSmp.MagicSmp;

public class AutoSaveTask
implements Runnable {
    private final MagicSmp plugin;

    public AutoSaveTask(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public void run() {
        this.plugin.getPlayerDataManager().autoSaveDirty();
        if (this.plugin.getConfigManager().getDatabase().getBoolean("DATABASE.MONGODB.SYNC-ON-AUTOSAVE", true)) {
            this.plugin.getDatabaseManager().flush();
        }
    }

    public static void start(MagicSmp plugin) {
        plugin.getSpigotScheduler().runAsyncTimer(new AutoSaveTask(plugin), 6000L, 6000L);
    }
}

