/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.tasks;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.managers.OptimizationManager;

public class TablistTask
implements Runnable {
    private final MagicSmp plugin;

    public TablistTask(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public void run() {
        if (this.plugin.getOptimizationManager() != null && !this.plugin.getOptimizationManager().shouldRun(OptimizationManager.OptimizedTask.TABLIST)) {
            return;
        }
        this.plugin.getTablistManager().forceUpdateAll();
    }

    public static void start(MagicSmp plugin) {
        plugin.getSpigotScheduler().runGlobalTimer(new TablistTask(plugin), 40L, 40L);
    }
}

