/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.tasks;

import com.bx.magicSmp.MagicSmp;

public class ClearLagTask
implements Runnable {
    private static final int[] WARN_AT = new int[]{60, 30, 15, 10, 5, 4, 3, 2, 1};
    private final MagicSmp plugin;
    private int secondsLeft;

    public ClearLagTask(MagicSmp plugin) {
        this.plugin = plugin;
        this.secondsLeft = plugin.getClearLagManager().getIntervalMinutes() * 60;
    }

    @Override
    public void run() {
        if (!this.plugin.getClearLagManager().isEnabled()) {
            return;
        }
        --this.secondsLeft;
        for (int w : WARN_AT) {
            if (this.secondsLeft != w) continue;
            this.plugin.getClearLagManager().broadcastCountdown(w);
            return;
        }
        if (this.secondsLeft <= 0) {
            this.plugin.getClearLagManager().clearEntities();
            this.secondsLeft = this.plugin.getClearLagManager().getIntervalMinutes() * 60;
        }
    }

    public static void start(MagicSmp plugin) {
        plugin.getSpigotScheduler().runGlobalTimer(new ClearLagTask(plugin), 20L, 20L);
    }
}

