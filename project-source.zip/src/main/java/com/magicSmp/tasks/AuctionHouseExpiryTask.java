/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.tasks;

import com.bx.magicSmp.MagicSmp;

public class AuctionHouseExpiryTask
implements Runnable {
    private final MagicSmp plugin;

    private AuctionHouseExpiryTask(MagicSmp plugin) {
        this.plugin = plugin;
    }

    public static void start(MagicSmp plugin) {
        long configuredSeconds = plugin.getConfigManager().getAuctionHouse().getLong("SETTINGS.EXPIRE_CHECK_SECONDS", 30L);
        long periodTicks = Math.max(20L, configuredSeconds * 20L);
        plugin.getSpigotScheduler().runAsyncTimer(new AuctionHouseExpiryTask(plugin), periodTicks, periodTicks);
    }

    @Override
    public void run() {
        if (this.plugin.getAuctionHouseManager() != null && this.plugin.getAuctionHouseManager().isEnabled()) {
            this.plugin.getAuctionHouseManager().expireListings().exceptionally(throwable -> {
                this.plugin.getLogger().warning("Auction House expiry scan failed: " + throwable.getMessage());
                return 0;
            });
        }
    }
}

