/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.tasks;

import com.bx.magicSmp.MagicSmp;
import org.bukkit.entity.Player;

public class RTPZoneTask
implements Runnable {
    private final MagicSmp plugin;

    public RTPZoneTask(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public void run() {
        if (this.plugin.getRtpZoneManager() == null || !this.plugin.getRtpZoneManager().isEnabled()) {
            return;
        }
        this.plugin.getSpigotScheduler().forEachOnlinePlayer(player -> this.plugin.getRtpZoneManager().tick((Player)player));
    }

    public static void start(MagicSmp plugin) {
        plugin.getSpigotScheduler().runGlobalTimer(new RTPZoneTask(plugin), 20L, 20L);
    }
}

