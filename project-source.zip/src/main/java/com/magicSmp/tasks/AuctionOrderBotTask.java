/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.tasks;

import com.bx.magicSmp.MagicSmp;

public final class AuctionOrderBotTask
implements Runnable {
    private final MagicSmp plugin;

    private AuctionOrderBotTask(MagicSmp plugin) {
        this.plugin = plugin;
    }

    public static void start(MagicSmp plugin) {
        long periodTicks = 400L;
        plugin.getSpigotScheduler().runAsyncTimer(new AuctionOrderBotTask(plugin), periodTicks, periodTicks);
    }

    @Override
    public void run() {
        if (this.plugin.getAuctionOrderBotManager() != null) {
            this.plugin.getAuctionOrderBotManager().tick();
        }
    }
}

