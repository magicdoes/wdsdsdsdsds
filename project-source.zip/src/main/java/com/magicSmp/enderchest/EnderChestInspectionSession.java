/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.enderchest;

import java.util.UUID;
import org.bukkit.inventory.Inventory;

public class EnderChestInspectionSession {
    private final UUID viewerUuid;
    private final UUID targetUuid;
    private final String targetName;
    private final Inventory inventory;
    private long lastSyncMillis;

    public EnderChestInspectionSession(UUID viewerUuid, UUID targetUuid, String targetName, Inventory inventory) {
        this.viewerUuid = viewerUuid;
        this.targetUuid = targetUuid;
        this.targetName = targetName;
        this.inventory = inventory;
        this.lastSyncMillis = System.currentTimeMillis();
    }

    public UUID getViewerUuid() {
        return this.viewerUuid;
    }

    public UUID getTargetUuid() {
        return this.targetUuid;
    }

    public String getTargetName() {
        return this.targetName;
    }

    public Inventory getInventory() {
        return this.inventory;
    }

    public long getLastSyncMillis() {
        return this.lastSyncMillis;
    }

    public void markSynced() {
        this.lastSyncMillis = System.currentTimeMillis();
    }
}

