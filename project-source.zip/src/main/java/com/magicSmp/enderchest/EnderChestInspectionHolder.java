/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.enderchest;

import java.util.UUID;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public class EnderChestInspectionHolder
implements InventoryHolder {
    private final UUID viewerUuid;
    private final UUID targetUuid;
    private Inventory inventory;

    public EnderChestInspectionHolder(UUID viewerUuid, UUID targetUuid) {
        this.viewerUuid = viewerUuid;
        this.targetUuid = targetUuid;
    }

    public UUID getViewerUuid() {
        return this.viewerUuid;
    }

    public UUID getTargetUuid() {
        return this.targetUuid;
    }

    public void bind(Inventory inventory) {
        this.inventory = inventory;
    }

    @Override
    public Inventory getInventory() {
        return this.inventory;
    }
}

