/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.enderchest;

import java.util.UUID;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public class EnderChestHolder
implements InventoryHolder {
    private final UUID ownerUuid;
    private final int rows;
    private Inventory inventory;

    public EnderChestHolder(UUID ownerUuid, int rows) {
        this.ownerUuid = ownerUuid;
        this.rows = rows;
    }

    public UUID getOwnerUuid() {
        return this.ownerUuid;
    }

    public int getRows() {
        return this.rows;
    }

    public void bind(Inventory inventory) {
        this.inventory = inventory;
    }

    @Override
    public Inventory getInventory() {
        return this.inventory;
    }
}

