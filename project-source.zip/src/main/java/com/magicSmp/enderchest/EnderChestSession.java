/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.enderchest;

import java.util.UUID;
import org.bukkit.inventory.Inventory;

public class EnderChestSession {
    private final UUID ownerUuid;
    private final Inventory inventory;
    private final int rows;
    private boolean dirty;
    private long lastSaveMillis;

    public EnderChestSession(UUID ownerUuid, Inventory inventory, int rows) {
        this.ownerUuid = ownerUuid;
        this.inventory = inventory;
        this.rows = rows;
        this.dirty = false;
        this.lastSaveMillis = System.currentTimeMillis();
    }

    public UUID getOwnerUuid() {
        return this.ownerUuid;
    }

    public Inventory getInventory() {
        return this.inventory;
    }

    public int getRows() {
        return this.rows;
    }

    public boolean isDirty() {
        return this.dirty;
    }

    public long getLastSaveMillis() {
        return this.lastSaveMillis;
    }

    public void markDirty() {
        this.dirty = true;
    }

    public void markSaved() {
        this.dirty = false;
        this.lastSaveMillis = System.currentTimeMillis();
    }
}

