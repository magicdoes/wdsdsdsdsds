package com.bx.magicSmp.invsee;

public final class OfflineInvseeBridge {
    private OfflineInvseeBridge() {}
    public static void saveOffline(Object manager, Object session) {
        // Decompiled build recovery: offline inventory persistence is unavailable.
        // Online invsee write-back remains handled by InvseeManager.
    }
}
