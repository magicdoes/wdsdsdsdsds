/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.invsee;

import java.util.UUID;
import org.bukkit.inventory.Inventory;

public class InvseeSession {
    private final UUID viewerUuid;
    private final UUID targetUuid;
    private final Inventory inventory;
    private final String targetName;
    private boolean editable;
    private boolean frozen;
    private boolean writeBackScheduled;
    private long lastSyncMillis;

    public InvseeSession(UUID viewerUuid, UUID targetUuid, Inventory inventory, String targetName, boolean editable) {
        this.viewerUuid = viewerUuid;
        this.targetUuid = targetUuid;
        this.inventory = inventory;
        this.targetName = targetName;
        this.editable = editable;
        this.frozen = false;
        this.writeBackScheduled = false;
        this.lastSyncMillis = System.currentTimeMillis();
    }

    public UUID getViewerUuid() {
        return this.viewerUuid;
    }

    public UUID getTargetUuid() {
        return this.targetUuid;
    }

    public Inventory getInventory() {
        return this.inventory;
    }

    public String getTargetName() {
        return this.targetName;
    }

    public boolean isEditable() {
        return this.editable;
    }

    public boolean isFrozen() {
        return this.frozen;
    }

    public boolean isWriteBackScheduled() {
        return this.writeBackScheduled;
    }

    public long getLastSyncMillis() {
        return this.lastSyncMillis;
    }

    public void setEditable(boolean editable) {
        this.editable = editable;
    }

    public void markSynced() {
        this.lastSyncMillis = System.currentTimeMillis();
    }

    public void scheduleWriteBack() {
        this.writeBackScheduled = true;
    }

    public void completeWriteBack() {
        this.writeBackScheduled = false;
    }

    public void freeze() {
        this.frozen = true;
        this.writeBackScheduled = false;
    }

    public void setFrozen(boolean frozen) {
        this.frozen = frozen;
    }
}

