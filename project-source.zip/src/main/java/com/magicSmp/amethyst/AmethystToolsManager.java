/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Color
 *  org.bukkit.NamespacedKey
 *  org.bukkit.Particle
 *  org.bukkit.Particle$DustOptions
 *  org.bukkit.block.BlockState
 *  org.bukkit.block.ShulkerBox
 *  org.bukkit.block.data.BlockData
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.PlayerInventory
 *  org.bukkit.inventory.meta.BlockStateMeta
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.persistence.PersistentDataContainer
 *  org.bukkit.persistence.PersistentDataType
 *  org.bukkit.plugin.Plugin
 */
package com.bx.magicSmp.amethyst;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.amethyst.AmethystToolType;
import com.bx.magicSmp.managers.FeatureManager;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.ItemUtils;
import com.bx.magicSmp.utils.NumberUtils;
import com.bx.magicSmp.utils.ShulkerBoxSupport;
import com.bx.magicSmp.utils.SoundUtils;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.block.BlockState;
import org.bukkit.block.ShulkerBox;
import org.bukkit.block.data.BlockData;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.BlockStateMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

public class AmethystToolsManager {
    public final NamespacedKey KEY_TYPE;
    public final NamespacedKey KEY_EXPIRY;
    public final NamespacedKey KEY_OWNER;
    public final NamespacedKey KEY_ID;
    private static final long DEFAULT_USE_COOLDOWN_MS = 250L;
    private static final long DEFAULT_VISUAL_SYNC_SUPPRESSION_MS = 3000L;
    private final MagicSmp plugin;
    private final Map<UUID, Long> useCooldowns = new HashMap<UUID, Long>();
    private final Map<UUID, Long> visualSyncSuppressions = new HashMap<UUID, Long>();

    public AmethystToolsManager(MagicSmp plugin) {
        this.plugin = plugin;
        this.KEY_TYPE = new NamespacedKey((Plugin)plugin, "amethyst_tool_type");
        this.KEY_EXPIRY = new NamespacedKey((Plugin)plugin, "amethyst_tool_expiry");
        this.KEY_OWNER = new NamespacedKey((Plugin)plugin, "amethyst_tool_owner");
        this.KEY_ID = new NamespacedKey((Plugin)plugin, "amethyst_tool_id");
    }

    public ItemStack createTool(AmethystToolType type, UUID ownerUuid, long durationSeconds) {
        ItemMeta meta;
        ConfigurationSection cfg = this.getToolSection(type);
        if (cfg == null) {
            return null;
        }
        Material material = ItemUtils.parseMaterial(cfg.getString("MATERIAL", "IRON_PICKAXE"));
        long duration = durationSeconds > 0L ? durationSeconds : cfg.getLong("DURATION", 86400L);
        long expiryEpoch = System.currentTimeMillis() / 1000L + duration;
        ArrayList<String> resolvedLore = new ArrayList<String>();
        for (String line : cfg.getStringList("LORE")) {
            resolvedLore.add(line.replace("{time}", NumberUtils.formatTimeLong(duration)));
        }
        ItemStack item = ItemUtils.createItem(material, cfg.getString("NAME", "&d&lamethyst tool"), resolvedLore);
        item.setAmount(1);
        List enchants = cfg.getStringList("ENCHANTMENTS");
        if (!enchants.isEmpty()) {
            ItemUtils.addEnchantments(item, enchants);
        }
        if ((meta = item.getItemMeta()) == null) {
            return item;
        }
        meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_UNBREAKABLE});
        meta.setUnbreakable(true);
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        pdc.set(this.KEY_TYPE, PersistentDataType.STRING, (Object)type.name());
        pdc.set(this.KEY_EXPIRY, PersistentDataType.LONG, (Object)expiryEpoch);
        pdc.set(this.KEY_ID, PersistentDataType.STRING, (Object)UUID.randomUUID().toString());
        if (ownerUuid != null) {
            pdc.set(this.KEY_OWNER, PersistentDataType.STRING, (Object)ownerUuid.toString());
        }
        item.setItemMeta(meta);
        return item;
    }

    public boolean isEnabled() {
        return this.plugin.getFeatureManager().isEnabled(FeatureManager.Feature.AMETHYST_TOOLS);
    }

    public boolean hasAmethystMetadata(ItemStack item) {
        return item != null && item.hasItemMeta() && item.getItemMeta().getPersistentDataContainer().has(this.KEY_TYPE, PersistentDataType.STRING);
    }

    public boolean isAmethystTool(ItemStack item) {
        return this.isEnabled() && this.hasAmethystMetadata(item);
    }

    public boolean hasValidSignature(ItemStack item) {
        if (!this.hasAmethystMetadata(item)) {
            return false;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return false;
        }
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        if (!pdc.has(this.KEY_EXPIRY, PersistentDataType.LONG)) {
            return false;
        }
        if (this.requiresItemId() && !pdc.has(this.KEY_ID, PersistentDataType.STRING)) {
            return false;
        }
        AmethystToolType type = this.getToolType(item);
        if (type == null) {
            return false;
        }
        ConfigurationSection cfg = this.getToolSection(type);
        if (cfg == null) {
            return false;
        }
        Material expected = ItemUtils.parseMaterial(cfg.getString("MATERIAL", item.getType().name()));
        return item.getType() == expected;
    }

    public AmethystToolType getToolType(ItemStack item) {
        if (!this.hasAmethystMetadata(item)) {
            return null;
        }
        String raw = (String)item.getItemMeta().getPersistentDataContainer().get(this.KEY_TYPE, PersistentDataType.STRING);
        return AmethystToolType.fromString(raw);
    }

    public String getItemId(ItemStack item) {
        if (!this.isAmethystTool(item)) {
            return null;
        }
        return (String)item.getItemMeta().getPersistentDataContainer().get(this.KEY_ID, PersistentDataType.STRING);
    }

    public long getExpiryEpoch(ItemStack item) {
        if (!this.hasAmethystMetadata(item)) {
            return 0L;
        }
        return (Long)item.getItemMeta().getPersistentDataContainer().getOrDefault(this.KEY_EXPIRY, PersistentDataType.LONG, (Object)0L);
    }

    public long getRemainingSeconds(ItemStack item) {
        long expiry = this.getExpiryEpoch(item);
        if (expiry <= 0L) {
            return 0L;
        }
        return expiry - System.currentTimeMillis() / 1000L;
    }

    public boolean isExpired(ItemStack item) {
        return this.getRemainingSeconds(item) <= 0L;
    }

    public ItemStack createRewardCopy(ItemStack template, UUID ownerUuid, long durationSeconds) {
        if (!this.hasAmethystMetadata(template)) {
            return null;
        }
        Object reward = template.clone();
        reward.setAmount(1);
        ItemMeta meta = reward.getItemMeta();
        if (meta == null) {
            return null;
        }
        String rawType = (String)meta.getPersistentDataContainer().get(this.KEY_TYPE, PersistentDataType.STRING);
        AmethystToolType type = AmethystToolType.fromString(rawType);
        if (type == null) {
            return null;
        }
        long duration = durationSeconds > 0L ? durationSeconds : this.getConfiguredDuration(type);
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        pdc.set(this.KEY_EXPIRY, PersistentDataType.LONG, (Object)(System.currentTimeMillis() / 1000L + Math.max(1L, duration)));
        pdc.set(this.KEY_ID, PersistentDataType.STRING, (Object)UUID.randomUUID().toString());
        if (ownerUuid != null) {
            pdc.set(this.KEY_OWNER, PersistentDataType.STRING, (Object)ownerUuid.toString());
        }
        reward.setItemMeta(meta);
        this.updateLoreCountdown((ItemStack)reward);
        return reward;
    }

    public boolean ensureIdentity(ItemStack item, UUID defaultOwner, boolean forceNewId) {
        if (!this.isAmethystTool(item)) {
            return false;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return false;
        }
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        AmethystToolType type = this.getToolType(item);
        if (type == null) {
            return false;
        }
        boolean changed = false;
        if (!pdc.has(this.KEY_EXPIRY, PersistentDataType.LONG)) {
            long defaultDuration = this.getToolSection(type) != null ? this.getToolSection(type).getLong("DURATION", 86400L) : 86400L;
            pdc.set(this.KEY_EXPIRY, PersistentDataType.LONG, (Object)(System.currentTimeMillis() / 1000L + defaultDuration));
            changed = true;
        }
        if (forceNewId || !pdc.has(this.KEY_ID, PersistentDataType.STRING)) {
            pdc.set(this.KEY_ID, PersistentDataType.STRING, (Object)UUID.randomUUID().toString());
            changed = true;
        }
        if (defaultOwner != null && !pdc.has(this.KEY_OWNER, PersistentDataType.STRING)) {
            pdc.set(this.KEY_OWNER, PersistentDataType.STRING, (Object)defaultOwner.toString());
            changed = true;
        }
        if (changed) {
            item.setItemMeta(meta);
        }
        return changed;
    }

    public boolean isOwnedBy(Player player, ItemStack item) {
        if (!this.isAmethystTool(item) || !this.isOwnerBindingEnabled()) {
            return true;
        }
        String owner = (String)item.getItemMeta().getPersistentDataContainer().get(this.KEY_OWNER, PersistentDataType.STRING);
        return owner == null || owner.equalsIgnoreCase(player.getUniqueId().toString());
    }

    public boolean isOnCooldown(UUID uuid) {
        Long last = this.useCooldowns.get(uuid);
        return last != null && System.currentTimeMillis() - last < this.getUseCooldownMs();
    }

    public void stampCooldown(UUID uuid) {
        this.useCooldowns.put(uuid, System.currentTimeMillis());
    }

    public void removeCooldown(UUID uuid) {
        this.useCooldowns.remove(uuid);
    }

    public boolean updateLoreCountdown(ItemStack item) {
        if (!this.hasAmethystMetadata(item)) {
            return false;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return false;
        }
        List lore = meta.getLore();
        if (lore == null || lore.isEmpty()) {
            return false;
        }
        AmethystToolType type = this.getToolType(item);
        if (type == null) {
            return false;
        }
        ConfigurationSection cfg = this.getToolSection(type);
        if (cfg == null) {
            return false;
        }
        List templateLore = cfg.getStringList("LORE");
        int targetIndex = -1;
        for (int i = 0; i < templateLore.size(); ++i) {
            if (!((String)templateLore.get(i)).contains("{time}")) continue;
            targetIndex = i;
            break;
        }
        if (targetIndex == -1 || targetIndex >= lore.size()) {
            return false;
        }
        long remaining = this.getRemainingSeconds(item);
        String timeStr = remaining > 0L ? NumberUtils.formatTimeLong(remaining) : "&cexpired";
        String replacement = ColorUtils.toComponent("&#BDC3C7" + timeStr);
        if (ColorUtils.strip((String)lore.get(targetIndex)).equals(ColorUtils.strip(replacement))) {
            return false;
        }
        ArrayList<String> newLore = new ArrayList<String>(lore);
        newLore.set(targetIndex, replacement);
        meta.setLore(newLore);
        item.setItemMeta(meta);
        return true;
    }

    public long getConfiguredDuration(AmethystToolType type) {
        ConfigurationSection section = this.getToolSection(type);
        return section == null ? 86400L : Math.max(1L, section.getLong("DURATION", 86400L));
    }

    public long getToolDuration(ItemStack item) {
        if (!this.hasAmethystMetadata(item)) {
            return 0L;
        }
        AmethystToolType type = this.getToolType(item);
        if (type == null) {
            return 0L;
        }
        return this.getConfiguredDuration(type);
    }

    public ItemStack createDisplayCopy(ItemStack template, long durationSeconds) {
        if (!this.hasAmethystMetadata(template)) {
            return template;
        }
        Object display = template.clone();
        ItemMeta meta = display.getItemMeta();
        if (meta == null) {
            return display;
        }
        AmethystToolType type = this.getToolType((ItemStack)display);
        if (type == null) {
            return display;
        }
        long duration = durationSeconds > 0L ? durationSeconds : this.getConfiguredDuration(type);
        meta.getPersistentDataContainer().set(this.KEY_EXPIRY, PersistentDataType.LONG, (Object)(System.currentTimeMillis() / 1000L + Math.max(1L, duration)));
        display.setItemMeta(meta);
        this.updateLoreCountdown((ItemStack)display);
        return display;
    }

    public boolean refreshAmethystItemsInShulker(ItemStack shulkerItem, UUID ownerUuid, long durationSeconds) {
        if (!ShulkerBoxSupport.isShulkerBox(shulkerItem)) {
            return false;
        }
        ItemMeta itemMeta = shulkerItem.getItemMeta();
        if (!(itemMeta instanceof BlockStateMeta)) {
            return false;
        }
        BlockStateMeta bsm = (BlockStateMeta)itemMeta;
        BlockState blockState = bsm.getBlockState();
        if (!(blockState instanceof ShulkerBox)) {
            return false;
        }
        ShulkerBox box = (ShulkerBox)blockState;
        ItemStack[] contents = box.getInventory().getContents();
        boolean changed = false;
        for (int i = 0; i < contents.length; ++i) {
            ItemStack current = contents[i];
            if (current == null || current.getType() == Material.AIR) continue;
            if (this.hasAmethystMetadata(current)) {
                ItemStack fresh = this.createRewardCopy(current, ownerUuid, durationSeconds);
                if (fresh == null) continue;
                contents[i] = fresh;
                changed = true;
                continue;
            }
            if (!ShulkerBoxSupport.isShulkerBox(current) || !this.refreshAmethystItemsInShulker(current, ownerUuid, durationSeconds)) continue;
            contents[i] = current;
            changed = true;
        }
        if (changed) {
            box.getInventory().setContents(contents);
            bsm.setBlockState((BlockState)box);
            shulkerItem.setItemMeta((ItemMeta)bsm);
        }
        return changed;
    }

    public boolean prepareCrateDisplayShulker(ItemStack shulkerItem, long durationSeconds) {
        if (!ShulkerBoxSupport.isShulkerBox(shulkerItem)) {
            return false;
        }
        ItemMeta itemMeta = shulkerItem.getItemMeta();
        if (!(itemMeta instanceof BlockStateMeta)) {
            return false;
        }
        BlockStateMeta bsm = (BlockStateMeta)itemMeta;
        BlockState blockState = bsm.getBlockState();
        if (!(blockState instanceof ShulkerBox)) {
            return false;
        }
        ShulkerBox box = (ShulkerBox)blockState;
        ItemStack[] contents = box.getInventory().getContents();
        boolean changed = false;
        for (int i = 0; i < contents.length; ++i) {
            ItemStack current = contents[i];
            if (current == null || current.getType() == Material.AIR) continue;
            if (this.hasAmethystMetadata(current)) {
                contents[i] = this.createDisplayCopy(current, durationSeconds);
                changed = true;
                continue;
            }
            if (!ShulkerBoxSupport.isShulkerBox(current) || !this.prepareCrateDisplayShulker(current, durationSeconds)) continue;
            contents[i] = current;
            changed = true;
        }
        if (changed) {
            box.getInventory().setContents(contents);
            bsm.setBlockState((BlockState)box);
            shulkerItem.setItemMeta((ItemMeta)bsm);
        }
        return changed;
    }

    public void sanitizePlayerInventory(Player player, boolean notifyExpired) {
        PlayerInventory inventory = player.getInventory();
        for (int slot = 0; slot < inventory.getSize(); ++slot) {
            this.sanitizeInventorySlot(player, slot, notifyExpired);
        }
    }

    public boolean sanitizeInventorySlot(Player player, int slot, boolean notifyExpired) {
        PlayerInventory inventory = player.getInventory();
        ItemStack item = inventory.getItem(slot);
        if (!this.isAmethystTool(item)) {
            return false;
        }
        boolean changed = this.ensureIdentity(item, player.getUniqueId(), false);
        if (item.getAmount() > 1) {
            this.splitStack(player, slot, item);
            changed = true;
            item = inventory.getItem(slot);
            if (item == null) {
                return true;
            }
        }
        if (!this.hasValidSignature(item)) {
            inventory.setItem(slot, null);
            return true;
        }
        if (this.isExpired(item)) {
            this.expireItem(player, slot, item, notifyExpired);
            return true;
        }
        if (changed) {
            inventory.setItem(slot, item);
        }
        return changed;
    }

    public boolean sanitizeHeldItem(Player player, boolean notifyExpired) {
        return this.sanitizeInventorySlot(player, player.getInventory().getHeldItemSlot(), notifyExpired);
    }

    public boolean sanitizeExternalInventorySlot(Player player, Inventory inventory, int slot, boolean notifyExpired) {
        if (inventory == null) {
            return false;
        }
        ItemStack item = inventory.getItem(slot);
        if (!this.isAmethystTool(item)) {
            return false;
        }
        boolean changed = this.ensureIdentity(item, null, false);
        if (item.getAmount() > 1) {
            this.splitExternalStack(player, inventory, slot, item);
            changed = true;
            item = inventory.getItem(slot);
            if (item == null) {
                return true;
            }
        }
        if (!this.hasValidSignature(item)) {
            inventory.setItem(slot, null);
            return true;
        }
        if (this.isExpired(item)) {
            AmethystToolType type = this.getToolType(item);
            inventory.setItem(slot, null);
            this.sendExpireFeedback(player, type, notifyExpired);
            return true;
        }
        if (changed) {
            inventory.setItem(slot, item);
        }
        return changed;
    }

    private void splitStack(Player player, int slot, ItemStack stack) {
        if (!this.isAmethystTool(stack) || stack.getAmount() <= 1) {
            return;
        }
        PlayerInventory inventory = player.getInventory();
        int amount = stack.getAmount();
        Object base = stack.clone();
        base.setAmount(1);
        this.ensureIdentity((ItemStack)base, player.getUniqueId(), true);
        inventory.setItem(slot, (ItemStack)base);
        for (int i = 1; i < amount; ++i) {
            Object extra = stack.clone();
            extra.setAmount(1);
            this.ensureIdentity((ItemStack)extra, player.getUniqueId(), true);
            HashMap leftovers = inventory.addItem(new ItemStack[]{extra});
            leftovers.values().forEach(leftover -> player.getWorld().dropItemNaturally(player.getLocation(), (ItemStack)leftover));
        }
    }

    public void expireHeldItem(Player player) {
        int slot = player.getInventory().getHeldItemSlot();
        ItemStack item = player.getInventory().getItem(slot);
        if (this.isAmethystTool(item)) {
            this.expireItem(player, slot, item, true);
        }
    }

    public boolean sanitizeCursorItem(Player player, boolean notifyExpired) {
        ItemStack cursor = player.getItemOnCursor();
        if (!this.isAmethystTool(cursor)) {
            return false;
        }
        boolean changed = this.ensureIdentity(cursor, player.getUniqueId(), false);
        if (cursor.getAmount() > 1) {
            this.splitCursorStack(player, cursor);
            changed = true;
            cursor = player.getItemOnCursor();
            if (cursor == null) {
                return true;
            }
        }
        if (!this.hasValidSignature(cursor)) {
            player.setItemOnCursor(null);
            return true;
        }
        if (this.isExpired(cursor)) {
            this.expireCursorItem(player, cursor, notifyExpired);
            return true;
        }
        if (changed) {
            player.setItemOnCursor(cursor);
        }
        return changed;
    }

    public void expireItem(Player player, int slot, ItemStack item, boolean sendFeedback) {
        if (!this.isAmethystTool(item)) {
            return;
        }
        AmethystToolType type = this.getToolType(item);
        player.getInventory().setItem(slot, null);
        this.sendExpireFeedback(player, type, sendFeedback);
    }

    private void splitCursorStack(Player player, ItemStack stack) {
        if (!this.isAmethystTool(stack) || stack.getAmount() <= 1) {
            return;
        }
        int amount = stack.getAmount();
        Object base = stack.clone();
        base.setAmount(1);
        this.ensureIdentity((ItemStack)base, player.getUniqueId(), true);
        player.setItemOnCursor((ItemStack)base);
        for (int i = 1; i < amount; ++i) {
            Object extra = stack.clone();
            extra.setAmount(1);
            this.ensureIdentity((ItemStack)extra, player.getUniqueId(), true);
            HashMap leftovers = player.getInventory().addItem(new ItemStack[]{extra});
            leftovers.values().forEach(leftover -> player.getWorld().dropItemNaturally(player.getLocation(), (ItemStack)leftover));
        }
    }

    private void splitExternalStack(Player player, Inventory inventory, int slot, ItemStack stack) {
        if (!this.isAmethystTool(stack) || stack.getAmount() <= 1) {
            return;
        }
        int amount = stack.getAmount();
        Object base = stack.clone();
        base.setAmount(1);
        this.ensureIdentity((ItemStack)base, null, true);
        inventory.setItem(slot, (ItemStack)base);
        for (int i = 1; i < amount; ++i) {
            Object extra = stack.clone();
            extra.setAmount(1);
            this.ensureIdentity((ItemStack)extra, null, true);
            player.getWorld().dropItemNaturally(player.getLocation(), (ItemStack)extra);
        }
    }

    private void expireCursorItem(Player player, ItemStack item, boolean sendFeedback) {
        if (!this.isAmethystTool(item)) {
            return;
        }
        AmethystToolType type = this.getToolType(item);
        player.setItemOnCursor(null);
        this.sendExpireFeedback(player, type, sendFeedback);
    }

    private void sendExpireFeedback(Player player, AmethystToolType type, boolean sendFeedback) {
        if (!sendFeedback) {
            return;
        }
        String toolName = type != null ? type.getDisplayName() : "Amethyst Tool";
        SoundUtils.play(player, this.getSound("EXPIRE"));
        this.spawnAmethystParticles(player.getLocation().add(0.0, 1.0, 0.0));
        String msg = this.getMessage("EXPIRED", "{tool}", toolName);
        player.sendMessage(ColorUtils.toComponent(msg));
    }

    public ConfigurationSection getToolSection(AmethystToolType type) {
        ConfigurationSection root = this.plugin.getConfigManager().getAmethystTools().getConfigurationSection("AMETHYST-TOOLS");
        if (root == null) {
            return null;
        }
        return root.getConfigurationSection(type.getConfigKey());
    }

    public List<String> getExcludedWorlds() {
        ConfigurationSection root = this.plugin.getConfigManager().getAmethystTools().getConfigurationSection("AMETHYST-TOOLS");
        if (root == null) {
            return Collections.emptyList();
        }
        return root.getStringList("EXCLUDED-WORLDS");
    }

    public boolean isExcludedWorld(String worldName) {
        return this.getExcludedWorlds().stream().anyMatch(excluded -> excluded.equalsIgnoreCase(worldName));
    }

    public String getMessage(String key) {
        ConfigurationSection msgs = this.plugin.getConfigManager().getAmethystTools().getConfigurationSection("AMETHYST-MESSAGES");
        if (msgs == null) {
            return key;
        }
        String prefix = msgs.getString("PREFIX", "&#9B59B6[amethyst] &r");
        String raw = msgs.getString(key, key);
        return raw.replace("{prefix}", prefix);
    }

    public String getMessage(String key, String ... replacements) {
        String msg = this.getMessage(key);
        int i = 0;
        while (i + 1 < replacements.length) {
            msg = msg.replace(replacements[i], replacements[i + 1]);
            i += 2;
        }
        return msg;
    }

    public String getSound(String key) {
        ConfigurationSection root = this.plugin.getConfigManager().getAmethystTools().getConfigurationSection("AMETHYST-TOOLS.SOUNDS");
        if (root == null) {
            return "";
        }
        return root.getString(key, "");
    }

    public String getToolPermission(AmethystToolType type) {
        ConfigurationSection section = this.getToolSection(type);
        if (section == null) {
            return "";
        }
        return section.getString("PERMISSION", "").trim();
    }

    public boolean isOwnerBindingEnabled() {
        return this.getSecuritySection().getBoolean("BIND-TO-OWNER", false);
    }

    public boolean requiresItemId() {
        return this.getSecuritySection().getBoolean("REQUIRE-ITEM-ID", true);
    }

    public boolean shouldBlockAutomationPickup() {
        return this.getSecuritySection().getBoolean("BLOCK-HOPPER-PICKUP", true);
    }

    public long getUseCooldownMs() {
        return Math.max(0L, this.getSecuritySection().getLong("CLICK-COOLDOWN-MS", 250L));
    }

    public void suppressVisualSync(UUID uuid) {
        this.suppressVisualSync(uuid, 3000L);
    }

    public void suppressVisualSync(UUID uuid, long durationMs) {
        if (uuid == null || durationMs <= 0L) {
            return;
        }
        this.visualSyncSuppressions.put(uuid, System.currentTimeMillis() + durationMs);
    }

    public boolean isVisualSyncSuppressed(UUID uuid) {
        if (uuid == null) {
            return false;
        }
        Long until = this.visualSyncSuppressions.get(uuid);
        if (until == null) {
            return false;
        }
        if (until <= System.currentTimeMillis()) {
            this.visualSyncSuppressions.remove(uuid);
            return false;
        }
        return true;
    }

    public Set<Material> getDisabledBlocks() {
        return this.parseMaterialSet(this.getToolSection(AmethystToolType.DRILL), "DISABLED-BLOCKS");
    }

    public Set<Material> getAllowedBlocks() {
        return this.parseMaterialSet(this.getToolSection(AmethystToolType.SHOVEL), "ALLOWED-BLOCKS");
    }

    public Set<Material> getLogBlocks() {
        return this.parseMaterialSet(this.getToolSection(AmethystToolType.CHOPPER), "LOG-BLOCKS");
    }

    private Set<Material> parseMaterialSet(ConfigurationSection section, String key) {
        if (section == null) {
            return EnumSet.noneOf(Material.class);
        }
        EnumSet<Material> set = EnumSet.noneOf(Material.class);
        for (String name : section.getStringList(key)) {
            try {
                set.add(Material.valueOf(name.toUpperCase(Locale.ROOT).trim()));
            }
            catch (IllegalArgumentException illegalArgumentException) {}
        }
        return set;
    }

    public void spawnAmethystParticles(Location location) {
        ConfigurationSection root = this.plugin.getConfigManager().getAmethystTools().getConfigurationSection("AMETHYST-TOOLS.PARTICLES");
        if (root == null || !root.getBoolean("ENABLED", true) || location.getWorld() == null) {
            return;
        }
        int count = root.getInt("COUNT", 12);
        double spread = root.getDouble("SPREAD", 0.4);
        String particleName = root.getString("TYPE", "BLOCK").toUpperCase(Locale.ROOT);
        Material blockMaterial = ItemUtils.parseMaterial(root.getString("BLOCK-MATERIAL", "PURPLE_CONCRETE_POWDER"));
        try {
            Particle particle = Particle.valueOf((String)particleName);
            if (particle.getDataType() == BlockData.class) {
                BlockData blockData = blockMaterial.createBlockData();
                location.getWorld().spawnParticle(particle, location.clone().add(0.5, 0.5, 0.5), count, spread, spread, spread, 0.0, blockData);
                return;
            }
        }
        catch (IllegalArgumentException particle) {
            // empty catch block
        }
        Particle.DustOptions dust = new Particle.DustOptions(Color.fromRGB((int)155, (int)89, (int)182), 1.2f);
        location.getWorld().spawnParticle(Particle.DUST, location.clone().add(0.5, 0.5, 0.5), count, spread, spread, spread, 0.0, dust);
    }

    private ConfigurationSection getSecuritySection() {
        ConfigurationSection root = this.plugin.getConfigManager().getAmethystTools().getConfigurationSection("AMETHYST-TOOLS.SECURITY");
        if (root != null) {
            return root;
        }
        return this.plugin.getConfigManager().getAmethystTools().createSection("AMETHYST-TOOLS.SECURITY");
    }
}

