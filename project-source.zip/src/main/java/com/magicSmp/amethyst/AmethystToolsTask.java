/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.amethyst;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.amethyst.AmethystToolsManager;
import com.bx.magicSmp.managers.FeatureManager;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class AmethystToolsTask
implements Runnable {
    private final MagicSmp plugin;
    private final AmethystToolsManager manager;

    private AmethystToolsTask(MagicSmp plugin) {
        this.plugin = plugin;
        this.manager = plugin.getAmethystToolsManager();
    }

    public static void start(MagicSmp plugin) {
        plugin.getSpigotScheduler().runGlobalTimer(new AmethystToolsTask(plugin), 20L, 20L);
    }

    @Override
    public void run() {
        if (!this.plugin.getFeatureManager().isEnabled(FeatureManager.Feature.AMETHYST_TOOLS)) {
            return;
        }
        this.plugin.getSpigotScheduler().forEachOnlinePlayer(this::checkInventory);
    }

    private void checkInventory(Player player) {
        ItemStack[] contents = player.getInventory().getContents();
        for (int slot = 0; slot < contents.length; ++slot) {
            ItemStack item = contents[slot];
            if (item != null && !item.getType().isAir() && item.hasItemMeta() && this.manager.isAmethystTool(item) && !this.manager.sanitizeInventorySlot(player, slot, true)) continue;
        }
        if (this.manager.isVisualSyncSuppressed(player.getUniqueId())) {
            return;
        }
        this.syncHeldCountdown(player);
        this.syncOffHandCountdown(player);
        this.syncCursorCountdown(player);
    }

    private void syncHeldCountdown(Player player) {
        int heldSlot = player.getInventory().getHeldItemSlot();
        if (this.manager.sanitizeInventorySlot(player, heldSlot, true)) {
            return;
        }
        ItemStack held = player.getInventory().getItem(heldSlot);
        if (this.manager.isAmethystTool(held) && this.manager.updateLoreCountdown(held)) {
            player.getInventory().setItem(heldSlot, held);
        }
    }

    private void syncOffHandCountdown(Player player) {
        ItemStack offHand = player.getInventory().getItemInOffHand();
        if (!this.manager.isAmethystTool(offHand)) {
            return;
        }
        if (this.manager.sanitizeInventorySlot(player, 40, true)) {
            return;
        }
        offHand = player.getInventory().getItemInOffHand();
        if (this.manager.isAmethystTool(offHand) && this.manager.updateLoreCountdown(offHand)) {
            player.getInventory().setItemInOffHand(offHand);
        }
    }

    private void syncCursorCountdown(Player player) {
        if (this.manager.sanitizeCursorItem(player, true)) {
            return;
        }
        ItemStack cursor = player.getItemOnCursor();
        if (this.manager.isAmethystTool(cursor) && this.manager.updateLoreCountdown(cursor)) {
            player.setItemOnCursor(cursor);
        }
    }
}

