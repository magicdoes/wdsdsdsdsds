/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.amethyst;

public enum AmethystToolType {
    DRILL("Amethyst Drill"),
    CHOPPER("Amethyst Tree Chopper"),
    SELL_AXE("Amethyst Sell Axe"),
    SHOVEL("Amethyst Shovel"),
    BUCKET("Amethyst Bucket");

    private final String displayName;

    private AmethystToolType(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return this.displayName;
    }

    public static AmethystToolType fromString(String name) {
        if (name == null) {
            return null;
        }
        try {
            return AmethystToolType.valueOf(name.toUpperCase().replace(" ", "_").replace("-", "_"));
        }
        catch (IllegalArgumentException e) {
            return null;
        }
    }

    public String getConfigKey() {
        return switch (this.ordinal()) {
            default -> throw new MatchException(null, null);
            case 0 -> "DRILL";
            case 1 -> "CHOPPER";
            case 2 -> "SELL-AXE";
            case 3 -> "SHOVEL";
            case 4 -> "BUCKET";
        };
    }
}

