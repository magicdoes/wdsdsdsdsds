/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.GameMode
 *  org.bukkit.block.Block
 *  org.bukkit.block.BlockFace
 *  org.bukkit.block.BlockState
 *  org.bukkit.block.Container
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Item
 *  org.bukkit.entity.LivingEntity
 *  org.bukkit.event.Event
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.block.Action
 *  org.bukkit.event.block.BlockBreakEvent
 *  org.bukkit.event.block.BlockDamageEvent
 *  org.bukkit.event.entity.EntityPickupItemEvent
 *  org.bukkit.event.inventory.InventoryAction
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.event.inventory.InventoryDragEvent
 *  org.bukkit.event.inventory.InventoryMoveItemEvent
 *  org.bukkit.event.inventory.InventoryPickupItemEvent
 *  org.bukkit.event.inventory.PrepareAnvilEvent
 *  org.bukkit.event.player.PlayerDropItemEvent
 *  org.bukkit.event.player.PlayerInteractEvent
 *  org.bukkit.inventory.EquipmentSlot
 *  org.bukkit.permissions.Permissible
 *  org.bukkit.plugin.Plugin
 */
package com.bx.magicSmp.amethyst;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.amethyst.AmethystToolType;
import com.bx.magicSmp.amethyst.AmethystToolsManager;
import com.bx.magicSmp.managers.ShopManager;
import com.bx.magicSmp.models.EconomyReason;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.PermissionUtils;
import com.bx.magicSmp.utils.SoundUtils;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.BlockState;
import org.bukkit.block.Container;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Entity;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Item;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockDamageEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.inventory.InventoryPickupItemEvent;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.permissions.Permissible;
import org.bukkit.plugin.Plugin;

public class AmethystToolsListener
implements Listener {
    private final MagicSmp plugin;
    private final AmethystToolsManager manager;
    private final ThreadLocal<Boolean> isProcessingAoe = ThreadLocal.withInitial(() -> false);

    public AmethystToolsListener(MagicSmp plugin) {
        this.plugin = plugin;
        this.manager = plugin.getAmethystToolsManager();
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onBlockDamage(BlockDamageEvent event) {
        Player player = event.getPlayer();
        ItemStack item = player.getInventory().getItemInMainHand();
        if (this.manager.isAmethystTool(item)) {
            this.manager.suppressVisualSync(player.getUniqueId(), 10000L);
        }
    }

    @EventHandler(priority=EventPriority.HIGH, ignoreCancelled=true)
    public void onBlockBreak(BlockBreakEvent event) {
        if (this.isProcessingAoe.get().booleanValue()) {
            return;
        }
        Player player = event.getPlayer();
        if (player.getGameMode() == GameMode.CREATIVE) {
            return;
        }
        ItemStack item = player.getInventory().getItemInMainHand();
        if (!this.manager.isAmethystTool(item)) {
            return;
        }
        if (item.getAmount() > 1) {
            this.manager.sanitizeHeldItem(player, false);
            return;
        }
        this.manager.ensureIdentity(item, player.getUniqueId(), false);
        AmethystToolType type = this.manager.getToolType(item);
        if (type != AmethystToolType.DRILL && type != AmethystToolType.SHOVEL && type != AmethystToolType.CHOPPER && type != AmethystToolType.SELL_AXE) {
            return;
        }
        if (type == AmethystToolType.SELL_AXE) {
            if (!this.canUseTool(player, item, type, false, true)) {
                event.setCancelled(true);
                player.sendBlockChange(event.getBlock().getLocation(), event.getBlock().getBlockData());
                return;
            }
            event.setCancelled(true);
            player.sendBlockChange(event.getBlock().getLocation(), event.getBlock().getBlockData());
            this.handleSellAxeBreak(event, player, item);
            return;
        }
        if (!this.canUseTool(player, item, type, false, true)) {
            event.setCancelled(true);
            player.sendBlockChange(event.getBlock().getLocation(), event.getBlock().getBlockData());
            return;
        }
        switch (type) {
            case DRILL: {
                this.handleDrill(event, player, item);
                break;
            }
            case SHOVEL: {
                this.handleShovel(event, player, item);
                break;
            }
            case CHOPPER: {
                this.handleChopper(event, player, item);
                break;
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void handleDrill(BlockBreakEvent event, Player player, ItemStack item) {
        this.manager.suppressVisualSync(player.getUniqueId(), 10000L);
        Block origin = event.getBlock();
        ConfigurationSection cfg = this.manager.getToolSection(AmethystToolType.DRILL);
        int radius = cfg != null ? cfg.getInt("RADIUS", 1) : 1;
        Set<Material> disabled = this.manager.getDisabledBlocks();
        if (disabled.contains((Object)origin.getType())) {
            return;
        }
        List<Block> toBreak = this.getAoeBlocks(origin, player, radius);
        toBreak.remove(origin);
        int count = 1;
        int particlesSpawned = 0;
        this.manager.spawnAmethystParticles(origin.getLocation());
        this.isProcessingAoe.set(true);
        try {
            for (Block block : toBreak) {
                if (disabled.contains((Object)block.getType()) || block.getType().isAir()) continue;
                BlockBreakEvent simulated = new BlockBreakEvent(block, player);
                this.plugin.getServer().getPluginManager().callEvent((Event)simulated);
                if (simulated.isCancelled()) {
                    player.sendBlockChange(block.getLocation(), block.getBlockData());
                    continue;
                }
                block.breakNaturally(item);
                player.sendBlockChange(block.getLocation(), Material.AIR.createBlockData());
                if (particlesSpawned < 4) {
                    this.manager.spawnAmethystParticles(block.getLocation());
                    ++particlesSpawned;
                }
                ++count;
            }
        }
        finally {
            this.isProcessingAoe.set(false);
        }
        SoundUtils.play(player, this.manager.getSound("BREAK"));
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void handleShovel(BlockBreakEvent event, Player player, ItemStack item) {
        this.manager.suppressVisualSync(player.getUniqueId(), 10000L);
        Block origin = event.getBlock();
        ConfigurationSection cfg = this.manager.getToolSection(AmethystToolType.SHOVEL);
        int radius = cfg != null ? cfg.getInt("RADIUS", 1) : 1;
        Set<Material> allowed = this.manager.getAllowedBlocks();
        if (!allowed.contains((Object)origin.getType())) {
            return;
        }
        List<Block> toBreak = this.getAoeBlocks(origin, player, radius);
        toBreak.remove(origin);
        int count = 1;
        int particlesSpawned = 0;
        this.manager.spawnAmethystParticles(origin.getLocation());
        this.isProcessingAoe.set(true);
        try {
            for (Block block : toBreak) {
                if (!allowed.contains((Object)block.getType()) || block.getType().isAir()) continue;
                BlockBreakEvent simulated = new BlockBreakEvent(block, player);
                this.plugin.getServer().getPluginManager().callEvent((Event)simulated);
                if (simulated.isCancelled()) {
                    player.sendBlockChange(block.getLocation(), block.getBlockData());
                    continue;
                }
                block.breakNaturally(item);
                player.sendBlockChange(block.getLocation(), Material.AIR.createBlockData());
                if (particlesSpawned < 4) {
                    this.manager.spawnAmethystParticles(block.getLocation());
                    ++particlesSpawned;
                }
                ++count;
            }
        }
        finally {
            this.isProcessingAoe.set(false);
        }
        SoundUtils.play(player, this.manager.getSound("BREAK"));
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void handleChopper(BlockBreakEvent event, Player player, ItemStack item) {
        this.manager.suppressVisualSync(player.getUniqueId(), 10000L);
        Block origin = event.getBlock();
        Set<Material> logBlocks = this.manager.getLogBlocks();
        if (!logBlocks.contains((Object)origin.getType())) {
            return;
        }
        ConfigurationSection cfg = this.manager.getToolSection(AmethystToolType.CHOPPER);
        int maxLogs = cfg != null ? cfg.getInt("MAX-LOGS", 128) : 128;
        List<Block> logs = this.bfsLogs(origin, logBlocks, maxLogs);
        logs.remove(origin);
        int count = 1;
        int particlesSpawned = 0;
        this.manager.spawnAmethystParticles(origin.getLocation());
        this.isProcessingAoe.set(true);
        try {
            for (Block log : logs) {
                if (log.getType().isAir()) continue;
                BlockBreakEvent simulated = new BlockBreakEvent(log, player);
                this.plugin.getServer().getPluginManager().callEvent((Event)simulated);
                if (simulated.isCancelled()) {
                    player.sendBlockChange(log.getLocation(), log.getBlockData());
                    continue;
                }
                log.breakNaturally(item);
                player.sendBlockChange(log.getLocation(), Material.AIR.createBlockData());
                if (particlesSpawned < 5) {
                    this.manager.spawnAmethystParticles(log.getLocation());
                    ++particlesSpawned;
                }
                ++count;
            }
        }
        finally {
            this.isProcessingAoe.set(false);
        }
        SoundUtils.play(player, this.manager.getSound("BREAK"));
    }

    private void handleSellAxeBreak(BlockBreakEvent event, Player player, ItemStack item) {
        this.manager.suppressVisualSync(player.getUniqueId(), 10000L);
        Block origin = event.getBlock();
        if (origin.getType() != Material.CHEST && origin.getType() != Material.TRAPPED_CHEST && origin.getType() != Material.BARREL) {
            return;
        }
        BlockState blockState = origin.getState();
        if (!(blockState instanceof Container)) {
            return;
        }
        Container container = (Container)blockState;
        Inventory containerInventory = container.getInventory();
        ShopManager.SellResult result = this.plugin.getShopManager().sellInventoryContents(player, containerInventory, 0, containerInventory.getSize(), EconomyReason.AMETHYST_SELL, true);
        if (result.status() == ShopManager.SellStatus.NO_SELLABLE_ITEMS) {
            return;
        }
        if (result.status() == ShopManager.SellStatus.TRANSACTION_FAILED) {
            return;
        }
        this.manager.spawnAmethystParticles(origin.getLocation().add(0.5, 1.0, 0.5));
        SoundUtils.play(player, this.manager.getSound("USE"));
    }

    @EventHandler(priority=EventPriority.HIGH, ignoreCancelled=true)
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        Player player = event.getPlayer();
        if (player.getGameMode() == GameMode.CREATIVE) {
            return;
        }
        ItemStack item = player.getInventory().getItemInMainHand();
        if (!this.manager.isAmethystTool(item)) {
            return;
        }
        if (event.getAction() == Action.LEFT_CLICK_BLOCK) {
            this.manager.suppressVisualSync(player.getUniqueId(), 10000L);
            return;
        }
        if (item.getAmount() > 1) {
            this.manager.sanitizeHeldItem(player, false);
            event.setCancelled(true);
            return;
        }
        this.manager.ensureIdentity(item, player.getUniqueId(), false);
        AmethystToolType type = this.manager.getToolType(item);
        if (type == null) {
            event.setCancelled(true);
            return;
        }
        switch (type) {
            case SELL_AXE: {
                if (event.getAction() != Action.RIGHT_CLICK_BLOCK) {
                    return;
                }
                if (!this.canUseTool(player, item, type, true, true)) {
                    event.setCancelled(true);
                    return;
                }
                event.setCancelled(true);
                this.handleSellAxe(event, player);
                break;
            }
            case BUCKET: {
                if (event.getAction() != Action.RIGHT_CLICK_BLOCK) {
                    return;
                }
                if (!this.canUseTool(player, item, type, true, true)) {
                    event.setCancelled(true);
                    return;
                }
                event.setCancelled(true);
                this.handleBucket(event, player);
                break;
            }
        }
    }

    private void handleSellAxe(PlayerInteractEvent event, Player player) {
        this.manager.suppressVisualSync(player.getUniqueId());
        Block clicked = event.getClickedBlock();
        if (clicked == null) {
            return;
        }
        if (clicked.getType() != Material.CHEST && clicked.getType() != Material.TRAPPED_CHEST && clicked.getType() != Material.BARREL) {
            return;
        }
        BlockState blockState = clicked.getState();
        if (!(blockState instanceof Container)) {
            return;
        }
        Container container = (Container)blockState;
        Inventory containerInventory = container.getInventory();
        ShopManager.SellResult result = this.plugin.getShopManager().sellInventoryContents(player, containerInventory, 0, containerInventory.getSize(), EconomyReason.AMETHYST_SELL, true);
        if (result.status() == ShopManager.SellStatus.NO_SELLABLE_ITEMS) {
            return;
        }
        if (result.status() == ShopManager.SellStatus.TRANSACTION_FAILED) {
            return;
        }
        this.manager.spawnAmethystParticles(clicked.getLocation().add(0.5, 1.0, 0.5));
        SoundUtils.play(player, this.manager.getSound("USE"));
    }

    private void handleBucket(PlayerInteractEvent event, Player player) {
        int maxDrain;
        this.manager.suppressVisualSync(player.getUniqueId(), 10000L);
        Block clicked = event.getClickedBlock();
        if (clicked == null || clicked.getType() != Material.WATER) {
            return;
        }
        ConfigurationSection cfg = this.manager.getToolSection(AmethystToolType.BUCKET);
        int radius = cfg != null ? cfg.getInt("DRAIN-RADIUS", 1) : 1;
        List<Block> waterBlocks = this.bfsWater(clicked, radius, maxDrain = cfg != null ? cfg.getInt("MAX-DRAIN", 27) : 27);
        if (waterBlocks.isEmpty()) {
            return;
        }
        int particleCount = 0;
        for (Block water : waterBlocks) {
            water.setType(Material.AIR);
            player.sendBlockChange(water.getLocation(), Material.AIR.createBlockData());
            if (particleCount >= 5) continue;
            this.manager.spawnAmethystParticles(water.getLocation());
            ++particleCount;
        }
        SoundUtils.play(player, this.manager.getSound("USE"));
    }

    @EventHandler(priority=EventPriority.HIGH, ignoreCancelled=true)
    public void onInventoryClick(InventoryClickEvent event) {
        HumanEntity humanEntity = event.getWhoClicked();
        if (!(humanEntity instanceof Player)) {
            return;
        }
        Player player = (Player)humanEntity;
        if (player.getGameMode() == GameMode.CREATIVE) {
            return;
        }
        ItemStack current = event.getCurrentItem();
        ItemStack cursor = event.getCursor();
        boolean currentIsAmethystTool = this.manager.isAmethystTool(current);
        boolean cursorIsAmethystTool = this.manager.isAmethystTool(cursor);
        if (!currentIsAmethystTool && !cursorIsAmethystTool) {
            return;
        }
        if (currentIsAmethystTool && cursorIsAmethystTool) {
            event.setCancelled(true);
            if (player.getGameMode() == GameMode.CREATIVE) {
                Inventory clickedInventory = event.getClickedInventory();
                int clickedSlot = event.getSlot();
                Object currentSnapshot = current.clone();
                Object cursorSnapshot = cursor.clone();
                this.manager.suppressVisualSync(player.getUniqueId());
                this.plugin.getSpigotScheduler().runEntity((Entity)player, () -> this.lambda$onInventoryClick$1(player, clickedInventory, clickedSlot, (ItemStack)currentSnapshot, (ItemStack)cursorSnapshot));
            }
            return;
        }
        if (currentIsAmethystTool) {
            this.manager.ensureIdentity(current, event.getClickedInventory() == player.getInventory() ? player.getUniqueId() : null, false);
            if (current.getAmount() > 1) {
                if (event.getClickedInventory() == player.getInventory()) {
                    this.manager.sanitizeInventorySlot(player, event.getSlot(), false);
                } else {
                    this.manager.sanitizeExternalInventorySlot(player, event.getClickedInventory(), event.getSlot(), false);
                }
                event.setCancelled(true);
                return;
            }
            if (!this.manager.hasValidSignature(current)) {
                event.setCurrentItem(null);
                event.setCancelled(true);
                return;
            }
            if (this.manager.isExpired(current)) {
                event.setCurrentItem(null);
                event.setCancelled(true);
                return;
            }
        }
        if (cursorIsAmethystTool) {
            this.manager.ensureIdentity(cursor, player.getUniqueId(), false);
            if (cursor.getAmount() > 1) {
                this.manager.sanitizeCursorItem(player, false);
                event.setCancelled(true);
                return;
            }
            if (!this.manager.hasValidSignature(cursor) || this.manager.isExpired(cursor)) {
                player.setItemOnCursor(null);
                event.setCancelled(true);
                return;
            }
        }
        if (event.getAction() == InventoryAction.COLLECT_TO_CURSOR) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGH, ignoreCancelled=true)
    public void onInventoryDrag(InventoryDragEvent event) {
        HumanEntity humanEntity = event.getWhoClicked();
        if (!(humanEntity instanceof Player)) {
            return;
        }
        Player player = (Player)humanEntity;
        if (player.getGameMode() == GameMode.CREATIVE) {
            return;
        }
        ItemStack oldCursor = event.getOldCursor();
        if (!this.manager.isAmethystTool(oldCursor)) {
            return;
        }
        this.manager.ensureIdentity(oldCursor, player.getUniqueId(), false);
        if (!this.manager.hasValidSignature(oldCursor) || this.manager.isExpired(oldCursor) || oldCursor.getAmount() > 1) {
            this.manager.sanitizeCursorItem(player, false);
        }
        event.setCancelled(true);
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onPrepareAnvil(PrepareAnvilEvent event) {
        if (this.manager.isAmethystTool(event.getInventory().getItem(0)) || this.manager.isAmethystTool(event.getInventory().getItem(1))) {
            event.setResult(null);
        }
    }

    @EventHandler(priority=EventPriority.HIGH, ignoreCancelled=true)
    public void onInventoryMoveItem(InventoryMoveItemEvent event) {
        if (!this.manager.shouldBlockAutomationPickup()) {
            return;
        }
        if (this.manager.isAmethystTool(event.getItem())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGH, ignoreCancelled=true)
    public void onInventoryPickupItem(InventoryPickupItemEvent event) {
        if (!this.manager.shouldBlockAutomationPickup()) {
            return;
        }
        if (this.manager.isAmethystTool(event.getItem().getItemStack())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGH, ignoreCancelled=true)
    public void onDrop(PlayerDropItemEvent event) {
        Player player = event.getPlayer();
        if (player.getGameMode() == GameMode.CREATIVE) {
            return;
        }
        Item droppedEntity = event.getItemDrop();
        ItemStack item = droppedEntity.getItemStack();
        if (!this.manager.isAmethystTool(item)) {
            return;
        }
        this.manager.ensureIdentity(item, player.getUniqueId(), false);
        if (!this.manager.hasValidSignature(item) || item.getAmount() > 1) {
            event.setCancelled(true);
            this.manager.sanitizeHeldItem(player, false);
            Bukkit.getScheduler().runTask((Plugin)this.plugin, () -> {
                if (player.isOnline()) {
                    player.updateInventory();
                }
            });
            return;
        }
        if (this.manager.isExpired(item)) {
            event.setCancelled(true);
            this.manager.sanitizeHeldItem(player, true);
            Bukkit.getScheduler().runTask((Plugin)this.plugin, () -> {
                if (player.isOnline()) {
                    player.updateInventory();
                }
            });
            return;
        }
        droppedEntity.setItemStack(item);
    }

    @EventHandler(priority=EventPriority.HIGH, ignoreCancelled=true)
    public void onEntityPickupItem(EntityPickupItemEvent event) {
        LivingEntity livingEntity = event.getEntity();
        if (!(livingEntity instanceof Player)) {
            return;
        }
        Player player = (Player)livingEntity;
        if (player.getGameMode() == GameMode.CREATIVE) {
            return;
        }
        Item itemEntity = event.getItem();
        ItemStack stack = itemEntity.getItemStack();
        if (!this.manager.isAmethystTool(stack)) {
            return;
        }
        this.manager.ensureIdentity(stack, player.getUniqueId(), false);
        if (!this.manager.hasValidSignature(stack) || stack.getAmount() > 1) {
            itemEntity.remove();
            event.setCancelled(true);
            return;
        }
        if (this.manager.isExpired(stack)) {
            itemEntity.remove();
            event.setCancelled(true);
            return;
        }
        if (!this.manager.isOwnedBy(player, stack)) {
            player.sendMessage(ColorUtils.toComponent(this.manager.getMessage("WRONG-OWNER")));
            event.setCancelled(true);
            return;
        }
        itemEntity.setItemStack(stack);
    }

    private boolean canUseTool(Player player, ItemStack item, AmethystToolType type, boolean checkCooldown, boolean sendFeedback) {
        if (!this.manager.hasValidSignature(item)) {
            return false;
        }
        if (this.manager.isExcludedWorld(player.getWorld().getName())) {
            if (sendFeedback) {
                player.sendMessage(ColorUtils.toComponent(this.manager.getMessage("EXCLUDED-WORLD")));
            }
            return false;
        }
        if (this.manager.isExpired(item)) {
            this.manager.expireHeldItem(player);
            return false;
        }
        String permission = this.manager.getToolPermission(type);
        if (!permission.isBlank() && !PermissionUtils.has((Permissible)player, permission)) {
            if (sendFeedback) {
                player.sendMessage(ColorUtils.toComponent(this.manager.getMessage("NO-PERMISSION")));
            }
            return false;
        }
        if (!this.manager.isOwnedBy(player, item)) {
            if (sendFeedback) {
                player.sendMessage(ColorUtils.toComponent(this.manager.getMessage("WRONG-OWNER")));
            }
            return false;
        }
        if (checkCooldown && this.manager.isOnCooldown(player.getUniqueId())) {
            return false;
        }
        if (checkCooldown) {
            this.manager.stampCooldown(player.getUniqueId());
        }
        return true;
    }

    private List<Block> getAoeBlocks(Block origin, Player player, int radius) {
        ArrayList<Block> blocks = new ArrayList<Block>();
        BlockFace face = this.getPlayerFace(player);
        int ox = origin.getX();
        int oy = origin.getY();
        int oz = origin.getZ();
        for (int a = -radius; a <= radius; ++a) {
            for (int b = -radius; b <= radius; ++b) {
                Block block = face == BlockFace.UP || face == BlockFace.DOWN ? origin.getWorld().getBlockAt(ox + a, oy, oz + b) : (face == BlockFace.NORTH || face == BlockFace.SOUTH ? origin.getWorld().getBlockAt(ox + a, oy + b, oz) : origin.getWorld().getBlockAt(ox, oy + b, oz + a));
                blocks.add(block);
            }
        }
        return blocks;
    }

    private BlockFace getPlayerFace(Player player) {
        float yaw = player.getLocation().getYaw();
        float pitch = player.getLocation().getPitch();
        if (pitch < -45.0f) {
            return BlockFace.UP;
        }
        if (pitch > 45.0f) {
            return BlockFace.DOWN;
        }
        if ((yaw = (yaw % 360.0f + 360.0f) % 360.0f) < 45.0f || yaw >= 315.0f) {
            return BlockFace.SOUTH;
        }
        if (yaw < 135.0f) {
            return BlockFace.WEST;
        }
        if (yaw < 225.0f) {
            return BlockFace.NORTH;
        }
        return BlockFace.EAST;
    }

    private List<Block> bfsLogs(Block start, Set<Material> logMaterials, int maxLogs) {
        ArrayList<Block> result = new ArrayList<Block>();
        HashSet<Location> visited = new HashSet<Location>();
        LinkedList<Block> queue = new LinkedList<Block>();
        queue.add(start);
        visited.add(start.getLocation());
        BlockFace[] faces = new BlockFace[]{BlockFace.UP, BlockFace.DOWN, BlockFace.NORTH, BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST};
        while (!queue.isEmpty() && result.size() < maxLogs) {
            Block current = (Block)queue.poll();
            if (!logMaterials.contains((Object)current.getType())) continue;
            result.add(current);
            for (BlockFace face : faces) {
                Block neighbor = current.getRelative(face);
                if (visited.contains(neighbor.getLocation()) || !logMaterials.contains((Object)neighbor.getType())) continue;
                visited.add(neighbor.getLocation());
                queue.add(neighbor);
            }
        }
        return result;
    }

    private List<Block> bfsWater(Block start, int radius, int max) {
        ArrayList<Block> result = new ArrayList<Block>();
        HashSet<Location> visited = new HashSet<Location>();
        LinkedList<Block> queue = new LinkedList<Block>();
        int sx = start.getX();
        int sy = start.getY();
        int sz = start.getZ();
        for (int dx = -radius; dx <= radius; ++dx) {
            for (int dy = -radius; dy <= radius; ++dy) {
                for (int dz = -radius; dz <= radius; ++dz) {
                    Block block = start.getWorld().getBlockAt(sx + dx, sy + dy, sz + dz);
                    if (block.getType() != Material.WATER || !visited.add(block.getLocation())) continue;
                    queue.add(block);
                }
            }
        }
        BlockFace[] faces = new BlockFace[]{BlockFace.UP, BlockFace.DOWN, BlockFace.NORTH, BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST};
        block3: while (!queue.isEmpty() && result.size() < max) {
            Block current = (Block)queue.poll();
            if (current.getType() != Material.WATER) continue;
            result.add(current);
            for (BlockFace face : faces) {
                Block neighbor = current.getRelative(face);
                if (result.size() + queue.size() >= max) continue block3;
                if (neighbor.getType() != Material.WATER || !visited.add(neighbor.getLocation())) continue;
                queue.add(neighbor);
            }
        }
        return result;
    }

    private /* synthetic */ void lambda$onInventoryClick$1(Player player, Inventory clickedInventory, int clickedSlot, ItemStack currentSnapshot, ItemStack cursorSnapshot) {
        if (!player.isOnline()) {
            return;
        }
        this.manager.suppressVisualSync(player.getUniqueId());
        if (clickedInventory != null && clickedSlot >= 0 && clickedSlot < clickedInventory.getSize()) {
            clickedInventory.setItem(clickedSlot, (ItemStack)currentSnapshot.clone());
        }
        player.setItemOnCursor((ItemStack)cursorSnapshot.clone());
        player.updateInventory();
    }
}

