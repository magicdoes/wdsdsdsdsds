/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.models;

import java.util.UUID;
import org.bukkit.inventory.ItemStack;

public record AuctionClaim(long id, UUID ownerUuid, ClaimType claimType, long sourceListingId, double moneyAmount, ItemStack item, long createdAt, long claimedAt) {
    public boolean claimed() {
        return this.claimedAt > 0L;
    }

    public boolean moneyClaim() {
        return this.claimType == ClaimType.MONEY;
    }

    public boolean itemClaim() {
        return this.claimType == ClaimType.ITEM;
    }

    public static enum ClaimType {
        MONEY,
        ITEM;


        public static ClaimType fromDatabase(String rawValue) {
            if (rawValue == null || rawValue.isBlank()) {
                return ITEM;
            }
            try {
                return ClaimType.valueOf(rawValue.trim().toUpperCase());
            }
            catch (IllegalArgumentException ignored) {
                return ITEM;
            }
        }
    }
}

