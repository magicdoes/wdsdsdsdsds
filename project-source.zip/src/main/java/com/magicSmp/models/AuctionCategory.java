/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.models;

import java.util.Locale;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

public enum AuctionCategory {
    ALL("All", Material.COMPASS),
    BLOCKS("Blocks", Material.GRASS_BLOCK),
    TOOLS("Tools", Material.DIAMOND_PICKAXE),
    FOOD("Food", Material.GOLDEN_CARROT),
    COMBAT("Combat", Material.DIAMOND_SWORD),
    POTIONS("Potions", Material.POTION),
    BOOKS("Books", Material.ENCHANTED_BOOK),
    INGREDIENTS("Ingredients", Material.BLAZE_POWDER),
    UTILITIES("Utilities", Material.ENDER_CHEST);

    private final String displayName;
    private final Material icon;

    private AuctionCategory(String displayName, Material icon) {
        this.displayName = displayName;
        this.icon = icon;
    }

    public String defaultDisplayName() {
        return this.displayName;
    }

    public Material defaultIcon() {
        return this.icon;
    }

    public boolean matches(ItemStack item) {
        if (this == ALL) {
            return true;
        }
        if (item == null) {
            return false;
        }
        Material type = item.getType();
        if (type == Material.AIR || type.name().endsWith("_AIR")) {
            return false;
        }
        return switch (this.ordinal()) {
            case 1 -> this.matches(type, type.isBlock(), false);
            case 3 -> this.matches(type, false, type.isEdible());
            default -> this.matches(type, false, false);
        };
    }

    public boolean matches(Material type, boolean block, boolean edible) {
        if (this == ALL) {
            return true;
        }
        if (type == null || type == Material.AIR || type.name().endsWith("_AIR")) {
            return false;
        }
        String name = type.name();
        return switch (this.ordinal()) {
            default -> throw new MatchException(null, null);
            case 0 -> true;
            case 1 -> block;
            case 2 -> {
                if (name.endsWith("_AXE") || name.endsWith("_PICKAXE") || name.endsWith("_SHOVEL") || name.endsWith("_HOE") || type == Material.SHEARS || type == Material.FLINT_AND_STEEL || type == Material.FISHING_ROD) {
                    yield true;
                }
                yield false;
            }
            case 3 -> edible;
            case 4 -> {
                if (name.endsWith("_SWORD") || name.endsWith("_AXE") || name.endsWith("_HELMET") || name.endsWith("_CHESTPLATE") || name.endsWith("_LEGGINGS") || name.endsWith("_BOOTS") || name.endsWith("_BOW") || type == Material.CROSSBOW || type == Material.TRIDENT || type == Material.SHIELD) {
                    yield true;
                }
                yield false;
            }
            case 5 -> {
                if (type == Material.POTION || type == Material.SPLASH_POTION || type == Material.LINGERING_POTION || type == Material.TIPPED_ARROW) {
                    yield true;
                }
                yield false;
            }
            case 6 -> {
                if (type == Material.BOOK || type == Material.WRITABLE_BOOK || type == Material.WRITTEN_BOOK || type == Material.ENCHANTED_BOOK || type == Material.KNOWLEDGE_BOOK) {
                    yield true;
                }
                yield false;
            }
            case 7 -> {
                if (type == Material.BLAZE_POWDER || type == Material.BLAZE_ROD || type == Material.GUNPOWDER || type == Material.STRING || type == Material.SPIDER_EYE || type == Material.FERMENTED_SPIDER_EYE || type == Material.GLISTERING_MELON_SLICE || type == Material.GHAST_TEAR || type == Material.MAGMA_CREAM || type == Material.RABBIT_FOOT || type == Material.PHANTOM_MEMBRANE || type == Material.SUGAR || type == Material.REDSTONE || type == Material.GLOWSTONE_DUST || type == Material.NETHER_WART) {
                    yield true;
                }
                yield false;
            }
            case 8 -> type == Material.ENDER_CHEST || type == Material.CHEST || type == Material.BARREL || type == Material.SHULKER_BOX || name.endsWith("_SHULKER_BOX") || type == Material.ELYTRA || type == Material.LEAD || type == Material.NAME_TAG || type == Material.COMPASS || type == Material.RECOVERY_COMPASS || type == Material.CLOCK;
        };
    }

    public static AuctionCategory from(String raw) {
        if (raw == null || raw.isBlank()) {
            return ALL;
        }
        try {
            return AuctionCategory.valueOf(raw.trim().toUpperCase(Locale.ROOT));
        }
        catch (IllegalArgumentException ignored) {
            return ALL;
        }
    }

    public static AuctionCategory findCategoryForItem(ItemStack item) {
        if (item == null || item.getType() == Material.AIR) {
            return ALL;
        }
        for (AuctionCategory category : AuctionCategory.values()) {
            if (category == ALL || !category.matches(item)) continue;
            return category;
        }
        return ALL;
    }
}

