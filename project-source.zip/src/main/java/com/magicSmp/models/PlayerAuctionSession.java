/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.models;

import com.bx.magicSmp.models.AuctionBrowseRequest;
import java.util.UUID;

public final class PlayerAuctionSession {
    private final UUID playerId;
    private AuctionBrowseRequest request;

    public PlayerAuctionSession(UUID playerId, AuctionBrowseRequest request) {
        this.playerId = playerId;
        this.request = request;
    }

    public UUID playerId() {
        return this.playerId;
    }

    public AuctionBrowseRequest request() {
        return this.request;
    }

    public void request(AuctionBrowseRequest request) {
        this.request = request;
    }
}

