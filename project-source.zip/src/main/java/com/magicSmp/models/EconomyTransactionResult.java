/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.models;

import com.bx.magicSmp.models.EconomyFailureReason;
import com.bx.magicSmp.models.EconomyReason;
import java.util.UUID;

public record EconomyTransactionResult(boolean success, EconomyFailureReason failureReason, EconomyReason reason, UUID targetUuid, String displayName, double amount, double beforeBalance, double afterBalance) {
    public boolean invalidAmount() {
        return this.failureReason == EconomyFailureReason.INVALID_AMOUNT;
    }

    public boolean playerNotFound() {
        return this.failureReason == EconomyFailureReason.PLAYER_NOT_FOUND;
    }

    public boolean noPlayerData() {
        return this.failureReason == EconomyFailureReason.NO_PLAYER_DATA;
    }

    public boolean insufficientFunds() {
        return this.failureReason == EconomyFailureReason.INSUFFICIENT_FUNDS;
    }
}

