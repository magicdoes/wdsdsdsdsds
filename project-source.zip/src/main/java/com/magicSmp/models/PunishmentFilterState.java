/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.models;

public enum PunishmentFilterState {
    ALL("All"),
    ACTIVE("Active"),
    INACTIVE("inactive");

    private final String displayName;

    private PunishmentFilterState(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return this.displayName;
    }

    public PunishmentFilterState next() {
        return switch (this.ordinal()) {
            default -> throw new MatchException(null, null);
            case 0 -> ACTIVE;
            case 1 -> INACTIVE;
            case 2 -> ALL;
        };
    }
}

