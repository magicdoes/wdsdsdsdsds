/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.models;

import java.lang.invoke.LambdaMetafactory;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.function.Function;
import org.bukkit.inventory.ItemStack;

public record DeliveryDraft(UUID playerUuid, long orderId, List<ItemStack> acceptedItems, int quantity, double payout, long createdAt) {
    public DeliveryDraft {
        acceptedItems = DeliveryDraft.copy(acceptedItems);
    }

    private static List<ItemStack> copy(List<ItemStack> items) {
        return items == null ? List.of() : items.stream().filter(Objects::nonNull).map(ItemStack::clone).toList();
    }
}

