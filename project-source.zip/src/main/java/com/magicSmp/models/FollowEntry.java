/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.models;

import java.util.UUID;

public record FollowEntry(UUID followerUuid, UUID followedUuid, String followedNameSnapshot, boolean transactionsEnabled, boolean messagesEnabled, boolean paymentsEnabled, boolean activityEnabled, boolean tpaAutoAcceptEnabled, boolean teleportRequestsEnabled, long createdAt) {
}

