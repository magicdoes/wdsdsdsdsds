/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.models;

import com.bx.magicSmp.models.Home;
import com.bx.magicSmp.models.PlayerData;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.bukkit.Location;

public final class ProfileSnapshot {
    private final UUID uuid;
    private final String username;
    private final boolean online;
    private final PlayerData playerData;
    private final List<Home> homes;
    private final String teamName;
    private final Location currentLocation;

    public ProfileSnapshot(UUID uuid, String username, boolean online, PlayerData playerData, List<Home> homes, String teamName, Location currentLocation) {
        this.uuid = uuid;
        this.username = username;
        this.online = online;
        this.playerData = playerData;
        this.homes = List.copyOf(homes == null ? List.of() : new ArrayList<Home>(homes));
        this.teamName = teamName;
        this.currentLocation = currentLocation == null ? null : currentLocation.clone();
    }

    public UUID getUuid() {
        return this.uuid;
    }

    public String getUsername() {
        return this.username;
    }

    public boolean isOnline() {
        return this.online;
    }

    public PlayerData getPlayerData() {
        return this.playerData;
    }

    public List<Home> getHomes() {
        return this.homes;
    }

    public int getHomeCount() {
        return this.homes.size();
    }

    public String getTeamName() {
        return this.teamName;
    }

    public Location getCurrentLocation() {
        return this.currentLocation == null ? null : this.currentLocation.clone();
    }

    public boolean hasCurrentLocation() {
        return this.currentLocation != null;
    }

    public boolean hasPlayerData() {
        return this.playerData != null;
    }
}

