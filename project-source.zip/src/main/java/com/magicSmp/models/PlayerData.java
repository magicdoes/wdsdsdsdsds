/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.models;

import com.bx.magicSmp.models.ThreeChoice;
import com.bx.magicSmp.models.TwoChoice;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import org.bukkit.Location;

public class PlayerData {
    private final UUID uuid;
    private String username;
    private double money;
    private int kills;
    private int deaths;
    private long playtimeSeconds;
    private long blocksPlaced;
    private long blocksBroken;
    private long mobsKilled;
    private int killStreak;
    private int highestKillStreak;
    private double moneySpent;
    private double moneyMade;
    private long sessionStartMillis;
    private boolean tpauto;
    private boolean phantomEnabled;
    private ThreeChoice paymentsChoice;
    private boolean scoreboardVisible;
    private boolean payAlertsEnabled;
    private boolean hotbarMessagesEnabled;
    private boolean worthDisplayEnabled;
    private boolean clearEntitiesMessagesEnabled;
    private boolean bountyAlertsEnabled;
    private boolean tpaConfirmMenuEnabled;
    private boolean chainmailOnRespawnEnabled;
    private ThreeChoice tpaRequestsChoice;
    private boolean autoTpaHereEnabled;
    private ThreeChoice tpaHereRequestsChoice;
    private boolean teamInvitesEnabled;
    private boolean mobSpawnEnabled;
    private boolean payConfirmMenuEnabled;
    private boolean totemParticlesEnabled;
    private boolean fastCrystalsEnabled;
    private boolean amethystBreakMessagesEnabled;
    private ThreeChoice privateMessagesChoice;
    private boolean keyAllNotificationsEnabled;
    private boolean duelRequestsEnabled;
    private boolean publicChatEnabled;
    private boolean serverBroadcastsEnabled;
    private boolean auctionNotificationsEnabled;
    private boolean explosionParticlesEnabled;
    private boolean hideAllPlayersEnabled;
    private boolean notificationSoundsEnabled;
    private boolean rtpCoordinatesEnabled;
    private boolean orderNotificationsEnabled;
    private boolean teamChatVisible;
    private boolean duelMusicEnabled;
    private boolean quietSpawnEnabled;
    private boolean nightVisionEnabled;
    private long keyAllRemainingSeconds;
    private long keyAllAnchorPlaytimeSeconds;
    private boolean dirty;
    private String inventory;
    private boolean destroyPearlOnDeath;
    private boolean randomizedCoords;
    private TwoChoice deathMessagesChoice;
    private ThreeChoice advancementMessagesChoice;
    private ThreeChoice joinLeaveMessagesChoice;
    private boolean teleportAlertsEnabled;
    private boolean followAlertsEnabled;
    private boolean explosionSoundsEnabled;
    private boolean displayDonutPlusEnabled;
    private long mobSpawnDisabledUntil;
    private long phantomDisabledUntil;
    private transient int randomOffsetX = 0;
    private transient int randomOffsetZ = 0;
    private transient boolean randomOffsetInitialized = false;

    public PlayerData(UUID uuid, String username) {
        this.uuid = uuid;
        this.username = username;
        this.money = 0.0;
        this.kills = 0;
        this.deaths = 0;
        this.playtimeSeconds = 0L;
        this.blocksPlaced = 0L;
        this.blocksBroken = 0L;
        this.mobsKilled = 0L;
        this.killStreak = 0;
        this.highestKillStreak = 0;
        this.moneySpent = 0.0;
        this.moneyMade = 0.0;
        this.sessionStartMillis = System.currentTimeMillis();
        this.tpauto = false;
        this.phantomEnabled = true;
        this.paymentsChoice = ThreeChoice.ANYONE;
        this.scoreboardVisible = true;
        this.payAlertsEnabled = true;
        this.hotbarMessagesEnabled = true;
        this.worthDisplayEnabled = true;
        this.clearEntitiesMessagesEnabled = true;
        this.bountyAlertsEnabled = true;
        this.tpaConfirmMenuEnabled = true;
        this.chainmailOnRespawnEnabled = true;
        this.tpaRequestsChoice = ThreeChoice.ANYONE;
        this.autoTpaHereEnabled = false;
        this.tpaHereRequestsChoice = ThreeChoice.ANYONE;
        this.teamInvitesEnabled = true;
        this.mobSpawnEnabled = true;
        this.payConfirmMenuEnabled = true;
        this.totemParticlesEnabled = true;
        this.fastCrystalsEnabled = true;
        this.amethystBreakMessagesEnabled = true;
        this.privateMessagesChoice = ThreeChoice.ANYONE;
        this.keyAllNotificationsEnabled = true;
        this.duelRequestsEnabled = true;
        this.publicChatEnabled = true;
        this.serverBroadcastsEnabled = true;
        this.auctionNotificationsEnabled = true;
        this.explosionParticlesEnabled = true;
        this.hideAllPlayersEnabled = false;
        this.notificationSoundsEnabled = true;
        this.rtpCoordinatesEnabled = true;
        this.orderNotificationsEnabled = true;
        this.teamChatVisible = true;
        this.duelMusicEnabled = true;
        this.quietSpawnEnabled = false;
        this.nightVisionEnabled = false;
        this.keyAllRemainingSeconds = -1L;
        this.keyAllAnchorPlaytimeSeconds = 0L;
        this.dirty = false;
        this.inventory = null;
        this.destroyPearlOnDeath = true;
        this.randomizedCoords = false;
        this.deathMessagesChoice = TwoChoice.FRIENDS_FOLLOWED;
        this.advancementMessagesChoice = ThreeChoice.ANYONE;
        this.joinLeaveMessagesChoice = ThreeChoice.ANYONE;
        this.teleportAlertsEnabled = true;
        this.followAlertsEnabled = true;
        this.explosionSoundsEnabled = true;
        this.displayDonutPlusEnabled = true;
        this.mobSpawnDisabledUntil = 0L;
        this.phantomDisabledUntil = 0L;
    }

    public UUID getUuid() {
        return this.uuid;
    }

    public String getUsername() {
        return this.username;
    }

    public void setUsername(String username) {
        this.username = username;
        this.dirty = true;
    }

    public double getMoney() {
        return this.money;
    }

    public void setMoney(double money) {
        this.money = Math.max(0.0, money);
        this.dirty = true;
    }

    public void addMoney(double amount) {
        this.setMoney(this.money + amount);
    }

    public boolean removeMoney(double amount) {
        if (this.money < amount) {
            return false;
        }
        this.setMoney(this.money - amount);
        return true;
    }

    public boolean hasMoney(double amount) {
        return this.money >= amount;
    }

    public int getKills() {
        return this.kills;
    }

    public void setKills(int kills) {
        this.kills = Math.max(0, kills);
        this.dirty = true;
    }

    public void addKill() {
        ++this.kills;
        this.dirty = true;
    }

    public int getDeaths() {
        return this.deaths;
    }

    public void setDeaths(int deaths) {
        this.deaths = Math.max(0, deaths);
        this.dirty = true;
    }

    public void addDeath() {
        ++this.deaths;
        this.dirty = true;
    }

    public long getPlaytimeSeconds() {
        return this.playtimeSeconds;
    }

    public void setPlaytimeSeconds(long playtimeSeconds) {
        this.playtimeSeconds = Math.max(0L, playtimeSeconds);
        this.dirty = true;
    }

    public long getSessionStartMillis() {
        return this.sessionStartMillis;
    }

    public void setSessionStartMillis(long sessionStartMillis) {
        this.sessionStartMillis = sessionStartMillis;
    }

    public long getTotalPlaytimeSeconds() {
        return this.playtimeSeconds + (System.currentTimeMillis() - this.sessionStartMillis) / 1000L;
    }

    public void commitSession() {
        long now = System.currentTimeMillis();
        this.playtimeSeconds += (now - this.sessionStartMillis) / 1000L;
        this.sessionStartMillis = now;
        this.dirty = true;
    }

    public long getBlocksPlaced() {
        return this.blocksPlaced;
    }

    public void setBlocksPlaced(long blocksPlaced) {
        this.blocksPlaced = Math.max(0L, blocksPlaced);
        this.dirty = true;
    }

    public void addBlocksPlaced(long amount) {
        this.setBlocksPlaced(this.blocksPlaced + amount);
    }

    public long getBlocksBroken() {
        return this.blocksBroken;
    }

    public void setBlocksBroken(long blocksBroken) {
        this.blocksBroken = Math.max(0L, blocksBroken);
        this.dirty = true;
    }

    public void addBlocksBroken(long amount) {
        this.setBlocksBroken(this.blocksBroken + amount);
    }

    public long getMobsKilled() {
        return this.mobsKilled;
    }

    public void setMobsKilled(long mobsKilled) {
        this.mobsKilled = Math.max(0L, mobsKilled);
        this.dirty = true;
    }

    public void addMobKill() {
        this.setMobsKilled(this.mobsKilled + 1L);
    }

    public int getKillStreak() {
        return this.killStreak;
    }

    public void setKillStreak(int killStreak) {
        this.killStreak = Math.max(0, killStreak);
        this.dirty = true;
    }

    public int getHighestKillStreak() {
        return this.highestKillStreak;
    }

    public void setHighestKillStreak(int highestKillStreak) {
        this.highestKillStreak = Math.max(0, highestKillStreak);
        this.dirty = true;
    }

    public void addKillStreak() {
        ++this.killStreak;
        if (this.killStreak > this.highestKillStreak) {
            this.highestKillStreak = this.killStreak;
        }
        this.dirty = true;
    }

    public void resetKillStreak() {
        this.killStreak = 0;
        this.dirty = true;
    }

    public double getMoneySpent() {
        return this.moneySpent;
    }

    public void setMoneySpent(double moneySpent) {
        this.moneySpent = Math.max(0.0, moneySpent);
        this.dirty = true;
    }

    public void addMoneySpent(double amount) {
        this.setMoneySpent(this.moneySpent + amount);
    }

    public double getMoneyMade() {
        return this.moneyMade;
    }

    public void setMoneyMade(double moneyMade) {
        this.moneyMade = Math.max(0.0, moneyMade);
        this.dirty = true;
    }

    public void addMoneyMade(double amount) {
        this.setMoneyMade(this.moneyMade + amount);
    }

    public boolean isTpauto() {
        return this.tpauto;
    }

    public void setTpauto(boolean tpauto) {
        this.tpauto = tpauto;
        this.dirty = true;
    }

    public boolean isPhantomEnabled() {
        if (!this.phantomEnabled && this.phantomDisabledUntil > 0L && System.currentTimeMillis() > this.phantomDisabledUntil) {
            this.phantomEnabled = true;
            this.phantomDisabledUntil = 0L;
            this.dirty = true;
        }
        return this.phantomEnabled;
    }

    public void setPhantomEnabled(boolean phantomEnabled) {
        this.phantomEnabled = phantomEnabled;
        this.dirty = true;
    }

    public long getPhantomDisabledUntil() {
        return this.phantomDisabledUntil;
    }

    public void setPhantomDisabledUntil(long phantomDisabledUntil) {
        this.phantomDisabledUntil = phantomDisabledUntil;
        this.dirty = true;
    }

    public boolean isPaymentsEnabled() {
        return this.paymentsChoice != ThreeChoice.OFF;
    }

    public void setPaymentsEnabled(boolean paymentsEnabled) {
        this.paymentsChoice = paymentsEnabled ? ThreeChoice.ANYONE : ThreeChoice.OFF;
        this.dirty = true;
    }

    public ThreeChoice getPaymentsChoice() {
        return this.paymentsChoice;
    }

    public void setPaymentsChoice(ThreeChoice paymentsChoice) {
        this.paymentsChoice = paymentsChoice;
        this.dirty = true;
    }

    public boolean isScoreboardVisible() {
        return this.scoreboardVisible;
    }

    public void setScoreboardVisible(boolean scoreboardVisible) {
        this.scoreboardVisible = scoreboardVisible;
        this.dirty = true;
    }

    public boolean isPayAlertsEnabled() {
        return this.payAlertsEnabled;
    }

    public void setPayAlertsEnabled(boolean payAlertsEnabled) {
        this.payAlertsEnabled = payAlertsEnabled;
        this.dirty = true;
    }

    public boolean isHotbarMessagesEnabled() {
        return this.hotbarMessagesEnabled;
    }

    public void setHotbarMessagesEnabled(boolean hotbarMessagesEnabled) {
        this.hotbarMessagesEnabled = hotbarMessagesEnabled;
        this.dirty = true;
    }

    public boolean isWorthDisplayEnabled() {
        return this.worthDisplayEnabled;
    }

    public void setWorthDisplayEnabled(boolean worthDisplayEnabled) {
        this.worthDisplayEnabled = worthDisplayEnabled;
        this.dirty = true;
    }

    public boolean isClearEntitiesMessagesEnabled() {
        return this.clearEntitiesMessagesEnabled;
    }

    public void setClearEntitiesMessagesEnabled(boolean clearEntitiesMessagesEnabled) {
        this.clearEntitiesMessagesEnabled = clearEntitiesMessagesEnabled;
        this.dirty = true;
    }

    public boolean isBountyAlertsEnabled() {
        return this.bountyAlertsEnabled;
    }

    public void setBountyAlertsEnabled(boolean bountyAlertsEnabled) {
        this.bountyAlertsEnabled = bountyAlertsEnabled;
        this.dirty = true;
    }

    public boolean isTpaConfirmMenuEnabled() {
        return this.tpaConfirmMenuEnabled;
    }

    public void setTpaConfirmMenuEnabled(boolean tpaConfirmMenuEnabled) {
        this.tpaConfirmMenuEnabled = tpaConfirmMenuEnabled;
        this.dirty = true;
    }

    public boolean isChainmailOnRespawnEnabled() {
        return this.chainmailOnRespawnEnabled;
    }

    public void setChainmailOnRespawnEnabled(boolean chainmailOnRespawnEnabled) {
        this.chainmailOnRespawnEnabled = chainmailOnRespawnEnabled;
        this.dirty = true;
    }

    public boolean isTpaRequestsEnabled() {
        return this.tpaRequestsChoice != ThreeChoice.OFF;
    }

    public void setTpaRequestsEnabled(boolean tpaRequestsEnabled) {
        this.tpaRequestsChoice = tpaRequestsEnabled ? ThreeChoice.ANYONE : ThreeChoice.OFF;
        this.dirty = true;
    }

    public ThreeChoice getTpaRequestsChoice() {
        return this.tpaRequestsChoice;
    }

    public void setTpaRequestsChoice(ThreeChoice tpaRequestsChoice) {
        this.tpaRequestsChoice = tpaRequestsChoice;
        this.dirty = true;
    }

    public boolean isAutoTpaHereEnabled() {
        return this.autoTpaHereEnabled;
    }

    public void setAutoTpaHereEnabled(boolean autoTpaHereEnabled) {
        this.autoTpaHereEnabled = autoTpaHereEnabled;
        this.dirty = true;
    }

    public boolean isTpaHereRequestsEnabled() {
        return this.tpaHereRequestsChoice != ThreeChoice.OFF;
    }

    public void setTpaHereRequestsEnabled(boolean tpaHereRequestsEnabled) {
        this.tpaHereRequestsChoice = tpaHereRequestsEnabled ? ThreeChoice.ANYONE : ThreeChoice.OFF;
        this.dirty = true;
    }

    public ThreeChoice getTpaHereRequestsChoice() {
        return this.tpaHereRequestsChoice;
    }

    public void setTpaHereRequestsChoice(ThreeChoice tpaHereRequestsChoice) {
        this.tpaHereRequestsChoice = tpaHereRequestsChoice;
        this.dirty = true;
    }

    public boolean isTeamInvitesEnabled() {
        return this.teamInvitesEnabled;
    }

    public void setTeamInvitesEnabled(boolean teamInvitesEnabled) {
        this.teamInvitesEnabled = teamInvitesEnabled;
        this.dirty = true;
    }

    public boolean isMobSpawnEnabled() {
        if (!this.mobSpawnEnabled && this.mobSpawnDisabledUntil > 0L && System.currentTimeMillis() > this.mobSpawnDisabledUntil) {
            this.mobSpawnEnabled = true;
            this.mobSpawnDisabledUntil = 0L;
            this.dirty = true;
        }
        return this.mobSpawnEnabled;
    }

    public void setMobSpawnEnabled(boolean mobSpawnEnabled) {
        this.mobSpawnEnabled = mobSpawnEnabled;
        this.dirty = true;
    }

    public long getMobSpawnDisabledUntil() {
        return this.mobSpawnDisabledUntil;
    }

    public void setMobSpawnDisabledUntil(long mobSpawnDisabledUntil) {
        this.mobSpawnDisabledUntil = mobSpawnDisabledUntil;
        this.dirty = true;
    }

    public boolean isPayConfirmMenuEnabled() {
        return this.payConfirmMenuEnabled;
    }

    public void setPayConfirmMenuEnabled(boolean payConfirmMenuEnabled) {
        this.payConfirmMenuEnabled = payConfirmMenuEnabled;
        this.dirty = true;
    }

    public boolean isTotemParticlesEnabled() {
        return this.totemParticlesEnabled;
    }

    public void setTotemParticlesEnabled(boolean totemParticlesEnabled) {
        this.totemParticlesEnabled = totemParticlesEnabled;
        this.dirty = true;
    }

    public boolean isFastCrystalsEnabled() {
        return this.fastCrystalsEnabled;
    }

    public void setFastCrystalsEnabled(boolean fastCrystalsEnabled) {
        this.fastCrystalsEnabled = fastCrystalsEnabled;
        this.dirty = true;
    }

    public boolean isAmethystBreakMessagesEnabled() {
        return this.amethystBreakMessagesEnabled;
    }

    public void setAmethystBreakMessagesEnabled(boolean amethystBreakMessagesEnabled) {
        this.amethystBreakMessagesEnabled = amethystBreakMessagesEnabled;
        this.dirty = true;
    }

    public boolean isPrivateMessagesEnabled() {
        return this.privateMessagesChoice != ThreeChoice.OFF;
    }

    public void setPrivateMessagesEnabled(boolean privateMessagesEnabled) {
        this.privateMessagesChoice = privateMessagesEnabled ? ThreeChoice.ANYONE : ThreeChoice.OFF;
        this.dirty = true;
    }

    public ThreeChoice getPrivateMessagesChoice() {
        return this.privateMessagesChoice;
    }

    public void setPrivateMessagesChoice(ThreeChoice privateMessagesChoice) {
        this.privateMessagesChoice = privateMessagesChoice;
        this.dirty = true;
    }

    public boolean isKeyAllNotificationsEnabled() {
        return this.keyAllNotificationsEnabled;
    }

    public void setKeyAllNotificationsEnabled(boolean keyAllNotificationsEnabled) {
        this.keyAllNotificationsEnabled = keyAllNotificationsEnabled;
        this.dirty = true;
    }

    public boolean isDuelRequestsEnabled() {
        return this.duelRequestsEnabled;
    }

    public void setDuelRequestsEnabled(boolean duelRequestsEnabled) {
        this.duelRequestsEnabled = duelRequestsEnabled;
        this.dirty = true;
    }

    public boolean isPublicChatEnabled() {
        return this.publicChatEnabled;
    }

    public void setPublicChatEnabled(boolean publicChatEnabled) {
        this.publicChatEnabled = publicChatEnabled;
        this.dirty = true;
    }

    public boolean isServerBroadcastsEnabled() {
        return this.serverBroadcastsEnabled;
    }

    public void setServerBroadcastsEnabled(boolean serverBroadcastsEnabled) {
        this.serverBroadcastsEnabled = serverBroadcastsEnabled;
        this.dirty = true;
    }

    public boolean isAuctionNotificationsEnabled() {
        return this.auctionNotificationsEnabled;
    }

    public void setAuctionNotificationsEnabled(boolean auctionNotificationsEnabled) {
        this.auctionNotificationsEnabled = auctionNotificationsEnabled;
        this.dirty = true;
    }

    public boolean isExplosionParticlesEnabled() {
        return this.explosionParticlesEnabled;
    }

    public void setExplosionParticlesEnabled(boolean explosionParticlesEnabled) {
        this.explosionParticlesEnabled = explosionParticlesEnabled;
        this.dirty = true;
    }

    public boolean isHideAllPlayersEnabled() {
        return this.hideAllPlayersEnabled;
    }

    public void setHideAllPlayersEnabled(boolean hideAllPlayersEnabled) {
        this.hideAllPlayersEnabled = hideAllPlayersEnabled;
        this.dirty = true;
    }

    public boolean isNotificationSoundsEnabled() {
        return this.notificationSoundsEnabled;
    }

    public void setNotificationSoundsEnabled(boolean notificationSoundsEnabled) {
        this.notificationSoundsEnabled = notificationSoundsEnabled;
        this.dirty = true;
    }

    public boolean isRtpCoordinatesEnabled() {
        return this.rtpCoordinatesEnabled;
    }

    public void setRtpCoordinatesEnabled(boolean rtpCoordinatesEnabled) {
        this.rtpCoordinatesEnabled = rtpCoordinatesEnabled;
        this.dirty = true;
    }

    public boolean isOrderNotificationsEnabled() {
        return this.orderNotificationsEnabled;
    }

    public void setOrderNotificationsEnabled(boolean orderNotificationsEnabled) {
        this.orderNotificationsEnabled = orderNotificationsEnabled;
        this.dirty = true;
    }

    public boolean isTeamChatVisible() {
        return this.teamChatVisible;
    }

    public void setTeamChatVisible(boolean teamChatVisible) {
        this.teamChatVisible = teamChatVisible;
        this.dirty = true;
    }

    public boolean isDuelMusicEnabled() {
        return this.duelMusicEnabled;
    }

    public void setDuelMusicEnabled(boolean duelMusicEnabled) {
        this.duelMusicEnabled = duelMusicEnabled;
        this.dirty = true;
    }

    public boolean isQuietSpawnEnabled() {
        return this.quietSpawnEnabled;
    }

    public void setQuietSpawnEnabled(boolean quietSpawnEnabled) {
        this.quietSpawnEnabled = quietSpawnEnabled;
        this.dirty = true;
    }

    public boolean isNightVisionEnabled() {
        return this.nightVisionEnabled;
    }

    public void setNightVisionEnabled(boolean nightVisionEnabled) {
        this.nightVisionEnabled = nightVisionEnabled;
        this.dirty = true;
    }

    public long getKeyAllRemainingSeconds() {
        long remaining;
        if (this.keyAllRemainingSeconds < 0L) {
            return this.keyAllRemainingSeconds;
        }
        long elapsed = this.getTotalPlaytimeSeconds() - this.keyAllAnchorPlaytimeSeconds;
        if (elapsed < 0L) {
            elapsed = 0L;
        }
        return (remaining = this.keyAllRemainingSeconds - elapsed) < 0L ? 0L : remaining;
    }

    public void setKeyAllRemainingSeconds(long keyAllRemainingSeconds) {
        this.keyAllRemainingSeconds = Math.max(-1L, keyAllRemainingSeconds);
        this.keyAllAnchorPlaytimeSeconds = this.getTotalPlaytimeSeconds();
        this.dirty = true;
    }

    public boolean isDirty() {
        return this.dirty;
    }

    public void setDirty(boolean dirty) {
        this.dirty = dirty;
    }

    public void markDirty() {
        this.dirty = true;
    }

    public void resetTrackedStats(long newSessionStartMillis) {
        this.kills = 0;
        this.deaths = 0;
        this.playtimeSeconds = 0L;
        this.blocksPlaced = 0L;
        this.blocksBroken = 0L;
        this.mobsKilled = 0L;
        this.killStreak = 0;
        this.highestKillStreak = 0;
        this.moneySpent = 0.0;
        this.moneyMade = 0.0;
        this.sessionStartMillis = newSessionStartMillis;
        this.keyAllAnchorPlaytimeSeconds = 0L;
        this.dirty = true;
    }

    public boolean isDestroyPearlOnDeath() {
        return this.destroyPearlOnDeath;
    }

    public void setDestroyPearlOnDeath(boolean destroyPearlOnDeath) {
        this.destroyPearlOnDeath = destroyPearlOnDeath;
        this.dirty = true;
    }

    public boolean isRandomizedCoords() {
        return this.randomizedCoords;
    }

    public void setRandomizedCoords(boolean randomizedCoords) {
        this.randomizedCoords = randomizedCoords;
        this.dirty = true;
    }

    private synchronized void ensureRandomOffset() {
        if (!this.randomOffsetInitialized) {
            ThreadLocalRandom rng = ThreadLocalRandom.current();
            this.randomOffsetX = (rng.nextBoolean() ? 1 : -1) * rng.nextInt(1000, 50000);
            this.randomOffsetZ = (rng.nextBoolean() ? 1 : -1) * rng.nextInt(1000, 50000);
            this.randomOffsetInitialized = true;
        }
    }

    public void setRandomOffsetForTesting(int offsetX, int offsetZ) {
        this.randomOffsetX = offsetX;
        this.randomOffsetZ = offsetZ;
        this.randomOffsetInitialized = true;
    }

    public int getDisplayX(int actualX) {
        if (!this.randomizedCoords) {
            return actualX;
        }
        this.ensureRandomOffset();
        return actualX + this.randomOffsetX;
    }

    public int getDisplayY(int actualY) {
        return actualY;
    }

    public int getDisplayZ(int actualZ) {
        if (!this.randomizedCoords) {
            return actualZ;
        }
        this.ensureRandomOffset();
        return actualZ + this.randomOffsetZ;
    }

    public String getInventory() {
        return this.inventory;
    }

    public void setInventory(String inventory) {
        this.inventory = inventory;
        this.dirty = true;
    }

    public String getDisplayCoords(Location loc) {
        if (loc == null) {
            return "0, 0, 0";
        }
        int x = this.getDisplayX(loc.getBlockX());
        int y = this.getDisplayY(loc.getBlockY());
        int z = this.getDisplayZ(loc.getBlockZ());
        return x + ", " + y + ", " + z;
    }

    public TwoChoice getDeathMessagesChoice() {
        return this.deathMessagesChoice;
    }

    public void setDeathMessagesChoice(TwoChoice deathMessagesChoice) {
        this.deathMessagesChoice = deathMessagesChoice;
        this.dirty = true;
    }

    public ThreeChoice getAdvancementMessagesChoice() {
        return this.advancementMessagesChoice;
    }

    public void setAdvancementMessagesChoice(ThreeChoice advancementMessagesChoice) {
        this.advancementMessagesChoice = advancementMessagesChoice;
        this.dirty = true;
    }

    public ThreeChoice getJoinLeaveMessagesChoice() {
        return this.joinLeaveMessagesChoice;
    }

    public void setJoinLeaveMessagesChoice(ThreeChoice joinLeaveMessagesChoice) {
        this.joinLeaveMessagesChoice = joinLeaveMessagesChoice;
        this.dirty = true;
    }

    public boolean isTeleportAlertsEnabled() {
        return this.teleportAlertsEnabled;
    }

    public void setTeleportAlertsEnabled(boolean teleportAlertsEnabled) {
        this.teleportAlertsEnabled = teleportAlertsEnabled;
        this.dirty = true;
    }

    public boolean isFollowAlertsEnabled() {
        return this.followAlertsEnabled;
    }

    public void setFollowAlertsEnabled(boolean followAlertsEnabled) {
        this.followAlertsEnabled = followAlertsEnabled;
        this.dirty = true;
    }

    public boolean isExplosionSoundsEnabled() {
        return this.explosionSoundsEnabled;
    }

    public void setExplosionSoundsEnabled(boolean explosionSoundsEnabled) {
        this.explosionSoundsEnabled = explosionSoundsEnabled;
        this.dirty = true;
    }

    public boolean isDisplayDonutPlusEnabled() {
        return this.displayDonutPlusEnabled;
    }

    public void setDisplayDonutPlusEnabled(boolean displayDonutPlusEnabled) {
        this.displayDonutPlusEnabled = displayDonutPlusEnabled;
        this.dirty = true;
    }
}

