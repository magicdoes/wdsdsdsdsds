/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.models;

import java.util.UUID;
import org.bukkit.inventory.ItemStack;

public record AuctionListing(long id, UUID sellerUuid, String sellerName, UUID buyerUuid, Status status, double price, double tax, ItemStack item, long createdAt, long expiresAt, long soldAt, long cancelledAt, long expiredAt, String category) {
    public AuctionListing(long id, UUID sellerUuid, String sellerName, UUID buyerUuid, Status status, double price, double tax, ItemStack item, long createdAt, long expiresAt, long soldAt, long cancelledAt, long expiredAt) {
        this(id, sellerUuid, sellerName, buyerUuid, status, price, tax, item, createdAt, expiresAt, soldAt, cancelledAt, expiredAt, "ALL");
    }

    public boolean active() {
        return this.status == Status.ACTIVE;
    }

    public boolean sold() {
        return this.status == Status.SOLD;
    }

    public boolean expired() {
        return this.status == Status.EXPIRED;
    }

    public boolean cancelled() {
        return this.status == Status.CANCELLED;
    }

    public double sellerPayout() {
        return Math.max(0.0, this.price - this.tax);
    }

    public long secondsRemaining(long nowMillis) {
        return Math.max(0L, (this.expiresAt - nowMillis) / 1000L);
    }

    public static enum Status {
        ACTIVE,
        SOLD,
        EXPIRED,
        CANCELLED;


        public static Status fromDatabase(String rawValue) {
            if (rawValue == null || rawValue.isBlank()) {
                return ACTIVE;
            }
            try {
                return Status.valueOf(rawValue.trim().toUpperCase());
            }
            catch (IllegalArgumentException ignored) {
                return ACTIVE;
            }
        }
    }
}

