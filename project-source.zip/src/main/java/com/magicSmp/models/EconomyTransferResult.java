/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.models;

import com.bx.magicSmp.models.EconomyFailureReason;
import com.bx.magicSmp.models.EconomyReason;
import java.util.UUID;

public record EconomyTransferResult(boolean success, EconomyFailureReason failureReason, EconomyReason reason, UUID senderUuid, String senderName, UUID recipientUuid, String recipientName, double amount, double senderBeforeBalance, double senderAfterBalance, double recipientBeforeBalance, double recipientAfterBalance) {
    public boolean invalidAmount() {
        return this.failureReason == EconomyFailureReason.INVALID_AMOUNT;
    }

    public boolean insufficientFunds() {
        return this.failureReason == EconomyFailureReason.INSUFFICIENT_FUNDS;
    }

    public boolean sameAccount() {
        return this.failureReason == EconomyFailureReason.SAME_ACCOUNT;
    }

    public boolean playerNotFound() {
        return this.failureReason == EconomyFailureReason.PLAYER_NOT_FOUND;
    }

    public boolean noPlayerData() {
        return this.failureReason == EconomyFailureReason.NO_PLAYER_DATA;
    }
}

