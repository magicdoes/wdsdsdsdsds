/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.models;

public record WorthResult(boolean sellable, boolean container, double unitWorth, double totalWorth, double baseWorth, double containerContentsWorth, String resolutionType, String sourceKey, String categoryKey) {
    public static WorthResult unsellable() {
        return new WorthResult(false, false, -1.0, -1.0, 0.0, 0.0, "unsellable", "", "");
    }

    public boolean hasContainerContentsWorth() {
        return this.containerContentsWorth > 0.0;
    }
}

