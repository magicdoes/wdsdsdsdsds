/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.models;

public enum TwoChoice {
    OFF,
    FRIENDS_FOLLOWED;


    public static TwoChoice fromInt(int val) {
        if (val < 0 || val >= TwoChoice.values().length) {
            return FRIENDS_FOLLOWED;
        }
        return TwoChoice.values()[val];
    }
}

