/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.models;

import com.bx.magicSmp.models.PunishmentScope;
import com.bx.magicSmp.models.PunishmentType;
import java.util.UUID;

public final class PunishmentRecord {
    private final long id;
    private final UUID targetUuid;
    private final String targetNameSnapshot;
    private final PunishmentType type;
    private final String reason;
    private final UUID issuerUuid;
    private final String issuerNameSnapshot;
    private final long issuedAt;
    private final Long expiresAt;
    private final UUID removedByUuid;
    private final String removedByNameSnapshot;
    private final Long removedAt;
    private final String removalReason;
    private final String sourceServer;
    private final PunishmentScope scope;

    public PunishmentRecord(long id, UUID targetUuid, String targetNameSnapshot, PunishmentType type, String reason, UUID issuerUuid, String issuerNameSnapshot, long issuedAt, Long expiresAt, UUID removedByUuid, String removedByNameSnapshot, Long removedAt, String removalReason, String sourceServer, PunishmentScope scope) {
        this.id = id;
        this.targetUuid = targetUuid;
        this.targetNameSnapshot = targetNameSnapshot == null ? "" : targetNameSnapshot;
        this.type = type == null ? PunishmentType.WARN : type;
        this.reason = reason == null || reason.isBlank() ? "no reason specified" : reason;
        this.issuerUuid = issuerUuid;
        this.issuerNameSnapshot = issuerNameSnapshot == null ? "" : issuerNameSnapshot;
        this.issuedAt = issuedAt;
        this.expiresAt = expiresAt;
        this.removedByUuid = removedByUuid;
        this.removedByNameSnapshot = removedByNameSnapshot == null ? "" : removedByNameSnapshot;
        this.removedAt = removedAt;
        this.removalReason = removalReason == null ? "" : removalReason;
        this.sourceServer = sourceServer == null || sourceServer.isBlank() ? "local" : sourceServer;
        this.scope = scope == null ? PunishmentScope.SERVER : scope;
    }

    public long getId() {
        return this.id;
    }

    public UUID getTargetUuid() {
        return this.targetUuid;
    }

    public String getTargetNameSnapshot() {
        return this.targetNameSnapshot;
    }

    public PunishmentType getType() {
        return this.type;
    }

    public String getReason() {
        return this.reason;
    }

    public UUID getIssuerUuid() {
        return this.issuerUuid;
    }

    public String getIssuerNameSnapshot() {
        return this.issuerNameSnapshot;
    }

    public long getIssuedAt() {
        return this.issuedAt;
    }

    public Long getExpiresAt() {
        return this.expiresAt;
    }

    public UUID getRemovedByUuid() {
        return this.removedByUuid;
    }

    public String getRemovedByNameSnapshot() {
        return this.removedByNameSnapshot;
    }

    public Long getRemovedAt() {
        return this.removedAt;
    }

    public String getRemovalReason() {
        return this.removalReason;
    }

    public String getSourceServer() {
        return this.sourceServer;
    }

    public PunishmentScope getScope() {
        return this.scope;
    }

    public boolean hasExpiry() {
        return this.expiresAt != null && this.expiresAt > 0L;
    }

    public boolean isTemporary() {
        return this.hasExpiry();
    }

    public boolean isRemoved() {
        return this.removedAt != null && this.removedAt > 0L;
    }
}

