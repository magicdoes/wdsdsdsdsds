/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.models;

import com.bx.magicSmp.managers.AuctionHouseManager;
import com.bx.magicSmp.models.AuctionCategory;

public record AuctionBrowseRequest(int page, AuctionHouseManager.AuctionSort sort, AuctionCategory category, String search) {
    public AuctionBrowseRequest {
        page = Math.max(1, page);
        sort = sort == null ? AuctionHouseManager.AuctionSort.NEWEST : sort;
        category = category == null ? AuctionCategory.ALL : category;
        search = search == null ? "" : search.trim();
    }

    public AuctionBrowseRequest withPage(int nextPage) {
        return new AuctionBrowseRequest(nextPage, this.sort, this.category, this.search);
    }

    public AuctionBrowseRequest withSort(AuctionHouseManager.AuctionSort nextSort) {
        return new AuctionBrowseRequest(1, nextSort, this.category, this.search);
    }

    public AuctionBrowseRequest withCategory(AuctionCategory nextCategory) {
        return new AuctionBrowseRequest(1, this.sort, nextCategory, this.search);
    }

    public AuctionBrowseRequest withSearch(String nextSearch) {
        return new AuctionBrowseRequest(1, this.sort, this.category, nextSearch);
    }
}

