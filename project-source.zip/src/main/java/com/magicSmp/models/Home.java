/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.models;

import java.util.UUID;
import org.bukkit.Location;

public class Home {
    private final UUID ownerUuid;
    private String name;
    private Location location;
    private long createdAt;

    public Home(UUID ownerUuid, String name, Location location) {
        this(ownerUuid, name, location, System.currentTimeMillis());
    }

    public Home(UUID ownerUuid, String name, Location location, long createdAt) {
        this.ownerUuid = ownerUuid;
        this.name = name;
        this.location = location;
        this.createdAt = createdAt;
    }

    public UUID getOwnerUuid() {
        return this.ownerUuid;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Location getLocation() {
        return this.location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    public long getCreatedAt() {
        return this.createdAt;
    }

    public void setCreatedAt(long createdAt) {
        this.createdAt = createdAt;
    }
}

