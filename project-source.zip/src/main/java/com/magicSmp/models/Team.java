/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.models;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Location;

public class Team {
    private final String name;
    private UUID leaderUuid;
    private Location home;
    private boolean friendlyFireEnabled;
    private final Map<UUID, TeamMember> members = new LinkedHashMap<UUID, TeamMember>();

    public Team(String name, UUID leaderUuid) {
        this.name = name;
        this.leaderUuid = leaderUuid;
        this.friendlyFireEnabled = false;
    }

    public String getName() {
        return this.name;
    }

    public UUID getLeaderUuid() {
        return this.leaderUuid;
    }

    public void setLeaderUuid(UUID leaderUuid) {
        this.leaderUuid = leaderUuid;
    }

    public Location getHome() {
        return this.home;
    }

    public void setHome(Location home) {
        this.home = home;
    }

    public boolean hasHome() {
        return this.home != null;
    }

    public boolean isFriendlyFireEnabled() {
        return this.friendlyFireEnabled;
    }

    public void setFriendlyFireEnabled(boolean friendlyFireEnabled) {
        this.friendlyFireEnabled = friendlyFireEnabled;
    }

    public Map<UUID, TeamMember> getMembers() {
        return this.members;
    }

    public Collection<UUID> getMemberUuids() {
        return this.members.keySet();
    }

    public int getMemberCount() {
        return this.members.size();
    }

    public void addMember(UUID uuid) {
        this.members.put(uuid, new TeamMember(uuid));
    }

    public void removeMember(UUID uuid) {
        this.members.remove(uuid);
    }

    public boolean isMember(UUID uuid) {
        return this.members.containsKey(uuid);
    }

    public boolean isLeader(UUID uuid) {
        return this.leaderUuid != null && this.leaderUuid.equals(uuid);
    }

    public TeamMember getMember(UUID uuid) {
        return this.members.get(uuid);
    }

    public static class TeamMember {
        private final UUID uuid;
        private boolean canEditHome;
        private boolean canManageTeammates;
        private boolean canTogglePvp;
        private boolean canVisitHome;
        private boolean canUseTeamChat;

        public TeamMember(UUID uuid) {
            this.uuid = uuid;
            this.canEditHome = false;
            this.canManageTeammates = false;
            this.canTogglePvp = false;
            this.canVisitHome = true;
            this.canUseTeamChat = true;
        }

        public UUID getUuid() {
            return this.uuid;
        }

        public boolean canEditHome() {
            return this.canEditHome;
        }

        public void setCanEditHome(boolean b) {
            this.canEditHome = b;
        }

        public boolean canManageTeammates() {
            return this.canManageTeammates;
        }

        public void setCanManageTeammates(boolean b) {
            this.canManageTeammates = b;
        }

        public boolean canTogglePvp() {
            return this.canTogglePvp;
        }

        public void setCanTogglePvp(boolean canTogglePvp) {
            this.canTogglePvp = canTogglePvp;
        }

        public boolean canVisitHome() {
            return this.canVisitHome;
        }

        public void setCanVisitHome(boolean canVisitHome) {
            this.canVisitHome = canVisitHome;
        }

        public boolean canUseTeamChat() {
            return this.canUseTeamChat;
        }

        public void setCanUseTeamChat(boolean canUseTeamChat) {
            this.canUseTeamChat = canUseTeamChat;
        }
    }
}

