/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.models;

import com.bx.magicSmp.models.AuctionClaim;
import com.bx.magicSmp.models.AuctionListing;
import java.util.ArrayList;
import java.util.List;

public final class AuctionPlayerEntries {
    private AuctionPlayerEntries() {
    }

    public static List<Object> combine(List<AuctionListing> listings, List<AuctionClaim> claims, boolean claimsEnabled) {
        ArrayList<AuctionClaim> entries = new ArrayList<AuctionClaim>(listings == null ? List.of() : listings);
        if (claimsEnabled && claims != null) {
            entries.addAll(claims);
        }
        return List.copyOf(entries);
    }
}

