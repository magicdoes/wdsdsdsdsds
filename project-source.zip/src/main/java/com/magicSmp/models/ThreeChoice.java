/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.models;

public enum ThreeChoice {
    OFF,
    ANYONE,
    FRIENDS_FOLLOWED;


    public static ThreeChoice fromInt(int val) {
        if (val < 0 || val >= ThreeChoice.values().length) {
            return ANYONE;
        }
        return ThreeChoice.values()[val];
    }
}

