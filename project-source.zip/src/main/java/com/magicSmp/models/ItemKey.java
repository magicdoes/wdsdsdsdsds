/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.NamespacedKey
 *  org.bukkit.enchantments.Enchantment
 *  org.bukkit.inventory.meta.Damageable
 *  org.bukkit.inventory.meta.EnchantmentStorageMeta
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.inventory.meta.PotionMeta
 *  org.bukkit.potion.PotionData
 *  org.bukkit.potion.PotionType
 */
package com.bx.magicSmp.models;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionData;
import org.bukkit.potion.PotionType;

public final class ItemKey {
    public final Material material;
    public final PotionType potionType;
    public final Map<String, Integer> enchants;

    private ItemKey(Material material, PotionType potionType, Map<String, Integer> enchants) {
        this.material = material != null ? material : Material.AIR;
        this.potionType = potionType;
        this.enchants = enchants != null ? Collections.unmodifiableMap(new LinkedHashMap<String, Integer>(enchants)) : Collections.emptyMap();
    }

    public static ItemKey of(Material material) {
        return new ItemKey(material, null, null);
    }

    public static ItemKey potion(Material material, PotionType potionType) {
        return new ItemKey(material, potionType, null);
    }

    public static ItemKey book(Map<Enchantment, Integer> enchants) {
        LinkedHashMap<String, Integer> stringEnchants = new LinkedHashMap<String, Integer>();
        if (enchants != null) {
            for (Map.Entry<Enchantment, Integer> entry : enchants.entrySet()) {
                stringEnchants.put(ItemKey.keyOf(entry.getKey()), entry.getValue());
            }
        }
        return new ItemKey(Material.ENCHANTED_BOOK, null, stringEnchants);
    }

    public static ItemKey fromStack(ItemStack item) {
        ItemMeta meta;
        if (item == null || item.getType().isAir()) {
            return ItemKey.of(Material.AIR);
        }
        Material mat = item.getType();
        ItemMeta itemMeta = meta = item.hasItemMeta() ? item.getItemMeta() : null;
        if (mat == Material.ENCHANTED_BOOK) {
            LinkedHashMap<String, Integer> enchants = new LinkedHashMap<String, Integer>();
            if (meta instanceof EnchantmentStorageMeta) {
                EnchantmentStorageMeta esm = (EnchantmentStorageMeta)meta;
                for (Map.Entry entry : esm.getStoredEnchants().entrySet()) {
                    enchants.put(ItemKey.keyOf((Enchantment)entry.getKey()), (Integer)entry.getValue());
                }
            }
            return new ItemKey(mat, null, enchants);
        }
        if (ItemKey.isPotionLike(mat)) {
            PotionType pType = null;
            if (meta instanceof PotionMeta) {
                PotionMeta pm = (PotionMeta)meta;
                try {
                    pType = pm.getBasePotionType();
                }
                catch (Exception | NoSuchMethodError e) {
                    try {
                        pType = pm.getBasePotionData().getType();
                    }
                    catch (Exception exception) {
                        // empty catch block
                    }
                }
            }
            return new ItemKey(mat, pType, null);
        }
        LinkedHashMap<String, Integer> enchants = new LinkedHashMap<String, Integer>();
        if (meta != null && meta.hasEnchants()) {
            for (Map.Entry entry : meta.getEnchants().entrySet()) {
                enchants.put(ItemKey.keyOf((Enchantment)entry.getKey()), (Integer)entry.getValue());
            }
        }
        return new ItemKey(mat, null, enchants);
    }

    public boolean matches(ItemStack item) {
        Damageable dmg;
        ItemMeta meta;
        if (item == null || item.getType() != this.material) {
            return false;
        }
        ItemMeta itemMeta = meta = item.hasItemMeta() ? item.getItemMeta() : null;
        if (this.material == Material.ENCHANTED_BOOK) {
            if (!(meta instanceof EnchantmentStorageMeta)) {
                return false;
            }
            EnchantmentStorageMeta esm = (EnchantmentStorageMeta)meta;
            Map itemEnchants = esm.getStoredEnchants();
            for (Map.Entry<String, Integer> reqEntry : this.enchants.entrySet()) {
                Enchantment reqEnch = ItemKey.findByKey(reqEntry.getKey());
                if (reqEnch == null) {
                    return false;
                }
                Integer itemLvl = (Integer)itemEnchants.get(reqEnch);
                if (itemLvl != null && itemLvl.equals(reqEntry.getValue())) continue;
                return false;
            }
            return true;
        }
        if (ItemKey.isPotionLike(this.material)) {
            if (!(meta instanceof PotionMeta)) {
                return false;
            }
            PotionMeta pm = (PotionMeta)meta;
            PotionType itemPType = null;
            try {
                itemPType = pm.getBasePotionType();
            }
            catch (Exception | NoSuchMethodError e) {
                try {
                    itemPType = pm.getBasePotionData().getType();
                }
                catch (Exception reqEntry) {
                    // empty catch block
                }
            }
            return Objects.equals(this.potionType, itemPType);
        }
        if (!this.enchants.isEmpty()) {
            if (meta == null) {
                return false;
            }
            Map itemEnchants = meta.getEnchants();
            for (Map.Entry<String, Integer> reqEntry : this.enchants.entrySet()) {
                Enchantment reqEnch = ItemKey.findByKey(reqEntry.getKey());
                if (reqEnch == null) {
                    return false;
                }
                Integer itemLvl = (Integer)itemEnchants.get(reqEnch);
                if (itemLvl != null && itemLvl.equals(reqEntry.getValue())) continue;
                return false;
            }
        }
        return !(meta instanceof Damageable) || !(dmg = (Damageable)meta).hasDamage() || dmg.getDamage() <= 0;
    }

    public boolean isVariant() {
        return !this.enchants.isEmpty() || ItemKey.isPotionLike(this.material) && this.potionType != null;
    }

    public static boolean isPotionLike(Material material) {
        return material == Material.POTION || material == Material.SPLASH_POTION || material == Material.LINGERING_POTION || material == Material.TIPPED_ARROW;
    }

    public ItemStack buildIcon() {
        ItemStack item = new ItemStack(this.material);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return item;
        }
        if (this.material == Material.ENCHANTED_BOOK) {
            EnchantmentStorageMeta esm = (EnchantmentStorageMeta)meta;
            for (Map.Entry<String, Integer> entry : this.enchants.entrySet()) {
                Enchantment ench = ItemKey.findByKey(entry.getKey());
                if (ench == null) continue;
                esm.addStoredEnchant(ench, entry.getValue().intValue(), true);
            }
        } else if (ItemKey.isPotionLike(this.material) && this.potionType != null) {
            PotionMeta pm = (PotionMeta)meta;
            try {
                pm.setBasePotionType(this.potionType);
            }
            catch (Exception | NoSuchMethodError e) {
                try {
                    pm.setBasePotionData(new PotionData(this.potionType));
                }
                catch (Exception entry) {}
            }
        } else {
            for (Map.Entry<String, Integer> entry : this.enchants.entrySet()) {
                Enchantment ench = ItemKey.findByKey(entry.getKey());
                if (ench == null) continue;
                meta.addEnchant(ench, entry.getValue().intValue(), true);
            }
        }
        item.setItemMeta(meta);
        return item;
    }

    public String displayName() {
        if (this.material == Material.ENCHANTED_BOOK && !this.enchants.isEmpty()) {
            if (this.enchants.size() == 1) {
                Map.Entry<String, Integer> entry2 = this.enchants.entrySet().iterator().next();
                return ItemKey.bookEnchantLabel(entry2.getKey(), entry2.getValue());
            }
            Object label = this.enchants.entrySet().stream().limit(3L).map(entry -> ItemKey.bookEnchantLabel((String)entry.getKey(), (Integer)entry.getValue())).collect(Collectors.joining(", "));
            if (this.enchants.size() > 3) {
                label = (String)label + ", ...";
            }
            return label;
        }
        if (ItemKey.isPotionLike(this.material) && this.potionType != null) {
            String effectName = ItemKey.potionEffectName(this.potionType);
            boolean strong = this.potionType.name().startsWith("STRONG_");
            boolean longDuration = this.potionType.name().startsWith("LONG_");
            String prefix = switch (this.material) {
                case Material.POTION -> "Potion of ";
                case Material.SPLASH_POTION -> "Splash Potion of ";
                case Material.LINGERING_POTION -> "Lingering Potion of ";
                case Material.TIPPED_ARROW -> "Tipped Arrow of ";
                default -> "";
            };
            if (strong) {
                return prefix + effectName + " II";
            }
            if (longDuration) {
                return prefix + "Long " + effectName;
            }
            return prefix + effectName;
        }
        return ItemKey.niceName(this.material);
    }

    public List<String> enchantLoreLines(String highlightPrefix) {
        if (this.enchants.isEmpty()) {
            return Collections.emptyList();
        }
        ArrayList<String> lines = new ArrayList<String>();
        for (Map.Entry<String, Integer> entry : this.enchants.entrySet()) {
            Enchantment ench = ItemKey.findByKey(entry.getKey());
            String name = ench != null ? ItemKey.title(ench.getKey().getKey().replace('_', ' ')) : ItemKey.title(entry.getKey().replace('_', ' '));
            lines.add(highlightPrefix + name + " " + ItemKey.roman(entry.getValue()));
        }
        return lines;
    }

    private static String bookEnchantLabel(String name, int level) {
        Enchantment ench = ItemKey.findByKey(name);
        String labelName = name;
        if (name.contains(":")) {
            labelName = name.substring(name.indexOf(58) + 1);
        }
        labelName = ItemKey.title(labelName.replace('_', ' '));
        int maxLvl = 1;
        if (ench != null) {
            maxLvl = Math.max(1, ench.getMaxLevel());
        }
        if (maxLvl <= 1 || level <= 1) {
            return labelName;
        }
        return labelName + " " + ItemKey.roman(level);
    }

    private static String potionEffectName(PotionType type) {
        String name = type.name().replaceFirst("^(LONG_|STRONG_)", "");
        return ItemKey.title(name.replace('_', ' '));
    }

    private static String title(String s) {
        if (s == null || s.isEmpty()) {
            return "";
        }
        return Arrays.stream(s.split(" ")).map(word -> word.isEmpty() ? "" : Character.toUpperCase(word.charAt(0)) + word.substring(1).toLowerCase(Locale.ENGLISH)).collect(Collectors.joining(" "));
    }

    public static String niceName(Material material) {
        if (material == null) {
            return "";
        }
        return ItemKey.title(material.name().replace('_', ' '));
    }

    private static String roman(int n) {
        if (n <= 0) {
            return "";
        }
        int[] values = new int[]{1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
        String[] symbols = new String[]{"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < values.length; ++i) {
            while (n >= values[i]) {
                n -= values[i];
                sb.append(symbols[i]);
            }
        }
        return sb.toString();
    }

    private static String keyOf(Enchantment ench) {
        if (ench == null) {
            return "";
        }
        return ench.getKey().getKey().toLowerCase(Locale.ENGLISH);
    }

    private static Enchantment findByKey(String key) {
        if (key == null) {
            return null;
        }
        String cleanKey = key.toLowerCase(Locale.ENGLISH).replace("minecraft:", "");
        try {
            NamespacedKey nsk = NamespacedKey.minecraft((String)cleanKey);
            Enchantment ench = Enchantment.getByKey((NamespacedKey)nsk);
            if (ench != null) {
                return ench;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        for (Enchantment ench : Enchantment.values()) {
            if (!ench.getName().equalsIgnoreCase(cleanKey) && !ench.getKey().getKey().equalsIgnoreCase(cleanKey)) continue;
            return ench;
        }
        return null;
    }

    public String serialize() {
        if (this.material == Material.ENCHANTED_BOOK && !this.enchants.isEmpty()) {
            String serialized = this.enchants.entrySet().stream().map(entry -> (String)entry.getKey() + "=" + String.valueOf(entry.getValue())).collect(Collectors.joining(","));
            return "BOOK|" + serialized;
        }
        if (ItemKey.isPotionLike(this.material) && this.potionType != null) {
            return this.material.name() + "|POTION:" + this.potionType.name();
        }
        if (!this.enchants.isEmpty()) {
            String serialized = this.enchants.entrySet().stream().map(entry -> (String)entry.getKey() + "=" + String.valueOf(entry.getValue())).collect(Collectors.joining(","));
            return this.material.name() + "|ENCH:" + serialized;
        }
        return this.material.name();
    }

    public static ItemKey deserialize(String s) {
        if (s == null || s.isEmpty()) {
            return null;
        }
        if (s.startsWith("BOOK|")) {
            String data = s.substring("BOOK|".length());
            LinkedHashMap<String, Integer> map = new LinkedHashMap<String, Integer>();
            if (!data.isEmpty()) {
                for (String part : data.split(",")) {
                    String[] split = part.split("=");
                    if (split.length != 2) continue;
                    try {
                        map.put(split[0], Integer.parseInt(split[1]));
                    }
                    catch (NumberFormatException numberFormatException) {
                        // empty catch block
                    }
                }
            }
            return new ItemKey(Material.ENCHANTED_BOOK, null, map);
        }
        if (s.contains("|POTION:")) {
            String[] split = s.split("\\|POTION:");
            Material mat = Material.matchMaterial((String)split[0]);
            PotionType pType = PotionType.valueOf((String)split[1]);
            return new ItemKey(mat, pType, null);
        }
        if (s.contains("|ENCH:")) {
            String[] split = s.split("\\|ENCH:");
            Material mat = Material.matchMaterial((String)split[0]);
            LinkedHashMap<String, Integer> map = new LinkedHashMap<String, Integer>();
            if (split.length > 1 && !split[1].isEmpty()) {
                for (String part : split[1].split(",")) {
                    String[] partSplit = part.split("=");
                    if (partSplit.length != 2) continue;
                    try {
                        map.put(partSplit[0], Integer.parseInt(partSplit[1]));
                    }
                    catch (NumberFormatException numberFormatException) {
                        // empty catch block
                    }
                }
            }
            return new ItemKey(mat, null, map);
        }
        Material mat = Material.matchMaterial((String)s);
        return new ItemKey(mat, null, null);
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        ItemKey itemKey = (ItemKey)o;
        return this.material == itemKey.material && this.potionType == itemKey.potionType && Objects.equals(this.enchants, itemKey.enchants);
    }

    public int hashCode() {
        return Objects.hash(new Object[]{this.material, this.potionType, this.enchants});
    }

    public String toString() {
        return this.serialize();
    }
}

