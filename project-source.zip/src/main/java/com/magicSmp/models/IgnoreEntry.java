/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.models;

import java.util.UUID;

public record IgnoreEntry(UUID ownerUuid, UUID ignoredUuid, String ignoredNameSnapshot, long createdAt) {
}

