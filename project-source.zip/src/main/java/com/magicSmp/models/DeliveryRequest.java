/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.models;

import java.lang.invoke.LambdaMetafactory;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;
import org.bukkit.inventory.ItemStack;

public record DeliveryRequest(long orderId, List<ItemStack> items, int expectedQuantity, double expectedPriceEach) {
    public DeliveryRequest {
        items = items == null ? List.of() : items.stream().filter(Objects::nonNull).map(ItemStack::clone).toList();
    }
}

