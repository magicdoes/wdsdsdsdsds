/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.models;

public enum PunishmentState {
    ACTIVE("Active", true),
    EXPIRED("Expired", false),
    REMOVED("Removed", false);

    private final String displayName;
    private final boolean active;

    private PunishmentState(String displayName, boolean active) {
        this.displayName = displayName;
        this.active = active;
    }

    public String getDisplayName() {
        return this.displayName;
    }

    public boolean isActive() {
        return this.active;
    }
}

