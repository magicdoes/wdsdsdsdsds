/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.models;

import java.util.UUID;

public record PlayerLogEntry(long id, UUID playerUuid, String playerName, String category, String logType, String details, long timestamp) {
}

