/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.models;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;

public record ShopPreference(UUID playerId, Set<String> favorites) {
    public ShopPreference {
        favorites = favorites == null ? Set.of() : Set.copyOf(new LinkedHashSet<String>(favorites));
    }

    public ShopPreference withFavorite(String favoriteId, boolean favorite) {
        LinkedHashSet<String> updated = new LinkedHashSet<String>(this.favorites);
        if (favorite) {
            updated.add(favoriteId);
        } else {
            updated.remove(favoriteId);
        }
        return new ShopPreference(this.playerId, updated);
    }
}

