/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.models;

public enum EconomyFailureReason {
    NONE,
    INVALID_AMOUNT,
    PLAYER_NOT_FOUND,
    NO_PLAYER_DATA,
    INSUFFICIENT_FUNDS,
    SAME_ACCOUNT;

}

