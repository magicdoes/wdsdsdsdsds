/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.models;

import com.bx.magicSmp.models.PunishmentFilterState;
import com.bx.magicSmp.models.PunishmentSortOrder;
import com.bx.magicSmp.models.PunishmentType;

public record PunishmentQuery(PunishmentType typeFilter, PunishmentFilterState stateFilter, PunishmentSortOrder sortOrder) {
    public PunishmentQuery {
        stateFilter = stateFilter == null ? PunishmentFilterState.ALL : stateFilter;
        sortOrder = sortOrder == null ? PunishmentSortOrder.NEWEST : sortOrder;
    }

    public static PunishmentQuery defaultQuery() {
        return new PunishmentQuery(null, PunishmentFilterState.ALL, PunishmentSortOrder.NEWEST);
    }

    public PunishmentQuery nextTypeFilter() {
        return new PunishmentQuery(PunishmentType.nextFilter(this.typeFilter), this.stateFilter, this.sortOrder);
    }

    public PunishmentQuery nextStateFilter() {
        return new PunishmentQuery(this.typeFilter, this.stateFilter.next(), this.sortOrder);
    }

    public PunishmentQuery nextSortOrder() {
        return new PunishmentQuery(this.typeFilter, this.stateFilter, this.sortOrder.next());
    }
}

