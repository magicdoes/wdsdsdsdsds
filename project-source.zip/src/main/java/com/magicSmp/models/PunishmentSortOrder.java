/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.models;

public enum PunishmentSortOrder {
    NEWEST("Newest"),
    OLDEST("Oldest");

    private final String displayName;

    private PunishmentSortOrder(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return this.displayName;
    }

    public PunishmentSortOrder next() {
        return this == NEWEST ? OLDEST : NEWEST;
    }
}

