/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.timeseries;

import com.bx.magicSmp.libs.redis.clients.jedis.args.Rawable;
import com.bx.magicSmp.libs.redis.clients.jedis.util.SafeEncoder;

public enum DuplicatePolicy implements Rawable
{
    BLOCK,
    FIRST,
    LAST,
    MIN,
    MAX,
    SUM;

    private final byte[] raw = SafeEncoder.encode(this.name());

    @Override
    public byte[] getRaw() {
        return this.raw;
    }
}

