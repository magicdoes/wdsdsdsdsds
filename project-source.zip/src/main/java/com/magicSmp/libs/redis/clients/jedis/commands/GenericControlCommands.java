/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.Module;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.ConfigCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.ScriptingControlCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.SlowlogCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.params.FailoverParams;
import java.util.List;

public interface GenericControlCommands
extends ConfigCommands,
ScriptingControlCommands,
SlowlogCommands {
    public String failover();

    public String failover(FailoverParams var1);

    public String failoverAbort();

    public List<Module> moduleList();
}

