/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.bloom.commands.RedisBloomPipelineCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.json.commands.RedisJsonPipelineCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.search.RediSearchPipelineCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.timeseries.RedisTimeSeriesPipelineCommands;

public interface RedisModulePipelineCommands
extends RediSearchPipelineCommands,
RedisJsonPipelineCommands,
RedisTimeSeriesPipelineCommands,
RedisBloomPipelineCommands {
}

