/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.executors;

import com.bx.magicSmp.libs.redis.clients.jedis.CommandObject;
import com.bx.magicSmp.libs.redis.clients.jedis.Connection;
import com.bx.magicSmp.libs.redis.clients.jedis.executors.CommandExecutor;
import com.bx.magicSmp.libs.redis.clients.jedis.providers.ConnectionProvider;
import com.bx.magicSmp.libs.redis.clients.jedis.util.IOUtils;

public class DefaultCommandExecutor
implements CommandExecutor {
    protected final ConnectionProvider provider;

    public DefaultCommandExecutor(ConnectionProvider provider) {
        this.provider = provider;
    }

    @Override
    public void close() {
        IOUtils.closeQuietly(this.provider);
    }

    @Override
    public final <T> T executeCommand(CommandObject<T> commandObject) {
        try (Connection connection = this.provider.getConnection(commandObject.getArguments());){
            T t = connection.executeCommand(commandObject);
            return t;
        }
    }
}

