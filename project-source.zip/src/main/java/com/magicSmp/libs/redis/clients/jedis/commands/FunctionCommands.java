/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.args.FlushMode;
import com.bx.magicSmp.libs.redis.clients.jedis.args.FunctionRestorePolicy;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.FunctionStats;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.LibraryInfo;
import java.util.List;

public interface FunctionCommands {
    public Object fcall(String var1, List<String> var2, List<String> var3);

    public Object fcallReadonly(String var1, List<String> var2, List<String> var3);

    public String functionDelete(String var1);

    public byte[] functionDump();

    public String functionFlush();

    public String functionFlush(FlushMode var1);

    public String functionKill();

    public List<LibraryInfo> functionList();

    public List<LibraryInfo> functionList(String var1);

    public List<LibraryInfo> functionListWithCode();

    public List<LibraryInfo> functionListWithCode(String var1);

    public String functionLoad(String var1);

    public String functionLoadReplace(String var1);

    public String functionRestore(byte[] var1);

    public String functionRestore(byte[] var1, FunctionRestorePolicy var2);

    public FunctionStats functionStats();
}

