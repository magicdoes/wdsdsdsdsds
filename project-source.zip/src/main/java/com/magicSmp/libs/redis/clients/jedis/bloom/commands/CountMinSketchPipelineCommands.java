/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.bloom.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.Response;
import java.util.List;
import java.util.Map;

public interface CountMinSketchPipelineCommands {
    public Response<String> cmsInitByDim(String var1, long var2, long var4);

    public Response<String> cmsInitByProb(String var1, double var2, double var4);

    public Response<List<Long>> cmsIncrBy(String var1, Map<String, Long> var2);

    public Response<List<Long>> cmsQuery(String var1, String ... var2);

    public Response<String> cmsMerge(String var1, String ... var2);

    public Response<String> cmsMerge(String var1, Map<String, Long> var2);

    public Response<Map<String, Object>> cmsInfo(String var1);
}

