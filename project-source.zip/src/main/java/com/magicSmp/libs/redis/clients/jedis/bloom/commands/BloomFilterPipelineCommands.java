/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.bloom.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.Response;
import com.bx.magicSmp.libs.redis.clients.jedis.bloom.BFInsertParams;
import com.bx.magicSmp.libs.redis.clients.jedis.bloom.BFReserveParams;
import java.util.List;
import java.util.Map;

public interface BloomFilterPipelineCommands {
    public Response<String> bfReserve(String var1, double var2, long var4);

    public Response<String> bfReserve(String var1, double var2, long var4, BFReserveParams var6);

    public Response<Boolean> bfAdd(String var1, String var2);

    public Response<List<Boolean>> bfMAdd(String var1, String ... var2);

    public Response<List<Boolean>> bfInsert(String var1, String ... var2);

    public Response<List<Boolean>> bfInsert(String var1, BFInsertParams var2, String ... var3);

    public Response<Boolean> bfExists(String var1, String var2);

    public Response<List<Boolean>> bfMExists(String var1, String ... var2);

    public Response<Map.Entry<Long, byte[]>> bfScanDump(String var1, long var2);

    public Response<String> bfLoadChunk(String var1, long var2, byte[] var4);

    public Response<Long> bfCard(String var1);

    public Response<Map<String, Object>> bfInfo(String var1);
}

