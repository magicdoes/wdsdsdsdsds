/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.executors;

import com.bx.magicSmp.libs.redis.clients.jedis.CommandObject;

public interface CommandExecutor
extends AutoCloseable {
    public <T> T executeCommand(CommandObject<T> var1);

    default public <T> T broadcastCommand(CommandObject<T> commandObject) {
        return this.executeCommand(commandObject);
    }
}

