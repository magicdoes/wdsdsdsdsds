/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.search.aggr;

import com.bx.magicSmp.libs.redis.clients.jedis.search.aggr.Reducer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Group {
    private final List<String> fields = new ArrayList<String>();
    private final List<Reducer> reducers = new ArrayList<Reducer>();

    public Group(String ... fields) {
        this.fields.addAll(Arrays.asList(fields));
    }

    public Group reduce(Reducer r) {
        this.reducers.add(r);
        return this;
    }

    public void addArgs(List<Object> args) {
        args.add(this.fields.size());
        args.addAll(this.fields);
        this.reducers.forEach(r -> r.addArgs(args));
    }
}

