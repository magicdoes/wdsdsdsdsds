/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis;

import com.bx.magicSmp.libs.redis.clients.jedis.Builder;
import com.bx.magicSmp.libs.redis.clients.jedis.CommandArguments;
import com.bx.magicSmp.libs.redis.clients.jedis.args.Rawable;
import java.util.Iterator;

public class CommandObject<T> {
    private final CommandArguments arguments;
    private final Builder<T> builder;

    public CommandObject(CommandArguments args, Builder<T> builder) {
        this.arguments = args;
        this.builder = builder;
    }

    public CommandArguments getArguments() {
        return this.arguments;
    }

    public Builder<T> getBuilder() {
        return this.builder;
    }

    public int hashCode() {
        int hashCode = 1;
        for (Rawable e : this.arguments) {
            hashCode = 31 * hashCode + e.hashCode();
        }
        hashCode = 31 * hashCode + this.builder.hashCode();
        return hashCode;
    }

    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof CommandObject)) {
            return false;
        }
        Iterator<Rawable> e1 = this.arguments.iterator();
        Iterator<Rawable> e2 = ((CommandObject)o).arguments.iterator();
        while (e1.hasNext() && e2.hasNext()) {
            Rawable o1 = e1.next();
            Rawable o2 = e2.next();
            if (o1 != null ? o1.equals(o2) : o2 == null) continue;
            return false;
        }
        if (e1.hasNext() || e2.hasNext()) {
            return false;
        }
        return this.builder == ((CommandObject)o).builder;
    }
}

