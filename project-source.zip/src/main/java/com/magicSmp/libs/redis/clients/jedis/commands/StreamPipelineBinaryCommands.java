/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.Response;
import com.bx.magicSmp.libs.redis.clients.jedis.StreamEntryID;
import com.bx.magicSmp.libs.redis.clients.jedis.args.StreamDeletionPolicy;
import com.bx.magicSmp.libs.redis.clients.jedis.params.XAddParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.XAutoClaimParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.XCfgSetParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.XClaimParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.XPendingParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.XReadGroupParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.XReadParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.XTrimParams;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.StreamEntryBinary;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.StreamEntryDeletionResult;
import java.util.List;
import java.util.Map;

public interface StreamPipelineBinaryCommands {
    default public Response<byte[]> xadd(byte[] key, Map<byte[], byte[]> hash, XAddParams params) {
        return this.xadd(key, params, hash);
    }

    public Response<byte[]> xadd(byte[] var1, XAddParams var2, Map<byte[], byte[]> var3);

    public Response<Long> xlen(byte[] var1);

    public Response<List<Object>> xrange(byte[] var1, byte[] var2, byte[] var3);

    public Response<List<Object>> xrange(byte[] var1, byte[] var2, byte[] var3, int var4);

    public Response<List<Object>> xrevrange(byte[] var1, byte[] var2, byte[] var3);

    public Response<List<Object>> xrevrange(byte[] var1, byte[] var2, byte[] var3, int var4);

    public Response<Long> xack(byte[] var1, byte[] var2, byte[] ... var3);

    public Response<List<StreamEntryDeletionResult>> xackdel(byte[] var1, byte[] var2, byte[] ... var3);

    public Response<List<StreamEntryDeletionResult>> xackdel(byte[] var1, byte[] var2, StreamDeletionPolicy var3, byte[] ... var4);

    public Response<String> xgroupCreate(byte[] var1, byte[] var2, byte[] var3, boolean var4);

    public Response<String> xgroupSetID(byte[] var1, byte[] var2, byte[] var3);

    public Response<Long> xgroupDestroy(byte[] var1, byte[] var2);

    public Response<Boolean> xgroupCreateConsumer(byte[] var1, byte[] var2, byte[] var3);

    public Response<Long> xgroupDelConsumer(byte[] var1, byte[] var2, byte[] var3);

    public Response<Long> xdel(byte[] var1, byte[] ... var2);

    public Response<List<StreamEntryDeletionResult>> xdelex(byte[] var1, byte[] ... var2);

    public Response<List<StreamEntryDeletionResult>> xdelex(byte[] var1, StreamDeletionPolicy var2, byte[] ... var3);

    public Response<Long> xtrim(byte[] var1, long var2, boolean var4);

    public Response<Long> xtrim(byte[] var1, XTrimParams var2);

    public Response<Object> xpending(byte[] var1, byte[] var2);

    public Response<List<Object>> xpending(byte[] var1, byte[] var2, XPendingParams var3);

    public Response<List<byte[]>> xclaim(byte[] var1, byte[] var2, byte[] var3, long var4, XClaimParams var6, byte[] ... var7);

    public Response<List<byte[]>> xclaimJustId(byte[] var1, byte[] var2, byte[] var3, long var4, XClaimParams var6, byte[] ... var7);

    public Response<List<Object>> xautoclaim(byte[] var1, byte[] var2, byte[] var3, long var4, byte[] var6, XAutoClaimParams var7);

    public Response<List<Object>> xautoclaimJustId(byte[] var1, byte[] var2, byte[] var3, long var4, byte[] var6, XAutoClaimParams var7);

    public Response<Object> xinfoStream(byte[] var1);

    public Response<Object> xinfoStreamFull(byte[] var1);

    public Response<Object> xinfoStreamFull(byte[] var1, int var2);

    public Response<List<Object>> xinfoGroups(byte[] var1);

    public Response<List<Object>> xinfoConsumers(byte[] var1, byte[] var2);

    @Deprecated
    public Response<List<Object>> xread(XReadParams var1, Map.Entry<byte[], byte[]> ... var2);

    @Deprecated
    public Response<List<Object>> xreadGroup(byte[] var1, byte[] var2, XReadGroupParams var3, Map.Entry<byte[], byte[]> ... var4);

    public Response<List<Map.Entry<byte[], List<StreamEntryBinary>>>> xreadBinary(XReadParams var1, Map<byte[], StreamEntryID> var2);

    public Response<Map<byte[], List<StreamEntryBinary>>> xreadBinaryAsMap(XReadParams var1, Map<byte[], StreamEntryID> var2);

    public Response<List<Map.Entry<byte[], List<StreamEntryBinary>>>> xreadGroupBinary(byte[] var1, byte[] var2, XReadGroupParams var3, Map<byte[], StreamEntryID> var4);

    public Response<Map<byte[], List<StreamEntryBinary>>> xreadGroupBinaryAsMap(byte[] var1, byte[] var2, XReadGroupParams var3, Map<byte[], StreamEntryID> var4);

    public Response<byte[]> xcfgset(byte[] var1, XCfgSetParams var2);
}

