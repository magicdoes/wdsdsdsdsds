/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis;

import com.bx.magicSmp.libs.redis.clients.jedis.CommandObjects;
import com.bx.magicSmp.libs.redis.clients.jedis.PipeliningBase;
import com.bx.magicSmp.libs.redis.clients.jedis.Response;
import java.io.Closeable;

public abstract class AbstractPipeline
extends PipeliningBase
implements Closeable {
    protected AbstractPipeline(CommandObjects commandObjects) {
        super(commandObjects);
    }

    @Override
    public abstract void close();

    public abstract void sync();

    public Response<Long> publish(String channel, String message) {
        return this.appendCommand(this.commandObjects.publish(channel, message));
    }

    public Response<Long> publish(byte[] channel, byte[] message) {
        return this.appendCommand(this.commandObjects.publish(channel, message));
    }
}

