/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.args;

public interface Rawable {
    public byte[] getRaw();

    public int hashCode();

    public boolean equals(Object var1);
}

