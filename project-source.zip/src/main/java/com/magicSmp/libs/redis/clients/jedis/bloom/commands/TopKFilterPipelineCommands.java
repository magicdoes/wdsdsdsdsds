/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.bloom.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.Response;
import java.util.List;
import java.util.Map;

public interface TopKFilterPipelineCommands {
    public Response<String> topkReserve(String var1, long var2);

    public Response<String> topkReserve(String var1, long var2, long var4, long var6, double var8);

    public Response<List<String>> topkAdd(String var1, String ... var2);

    public Response<List<String>> topkIncrBy(String var1, Map<String, Long> var2);

    public Response<List<Boolean>> topkQuery(String var1, String ... var2);

    public Response<List<String>> topkList(String var1);

    public Response<Map<String, Long>> topkListWithCount(String var1);

    public Response<Map<String, Object>> topkInfo(String var1);
}

