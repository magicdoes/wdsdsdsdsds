/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.bloom.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.Response;
import com.bx.magicSmp.libs.redis.clients.jedis.bloom.TDigestMergeParams;
import java.util.List;
import java.util.Map;

public interface TDigestSketchPipelineCommands {
    public Response<String> tdigestCreate(String var1);

    public Response<String> tdigestCreate(String var1, int var2);

    public Response<String> tdigestReset(String var1);

    public Response<String> tdigestMerge(String var1, String ... var2);

    public Response<String> tdigestMerge(TDigestMergeParams var1, String var2, String ... var3);

    public Response<Map<String, Object>> tdigestInfo(String var1);

    public Response<String> tdigestAdd(String var1, double ... var2);

    public Response<List<Double>> tdigestCDF(String var1, double ... var2);

    public Response<List<Double>> tdigestQuantile(String var1, double ... var2);

    public Response<Double> tdigestMin(String var1);

    public Response<Double> tdigestMax(String var1);

    public Response<Double> tdigestTrimmedMean(String var1, double var2, double var4);

    public Response<List<Long>> tdigestRank(String var1, double ... var2);

    public Response<List<Long>> tdigestRevRank(String var1, double ... var2);

    public Response<List<Double>> tdigestByRank(String var1, long ... var2);

    public Response<List<Double>> tdigestByRevRank(String var1, long ... var2);
}

