/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.Response;
import com.bx.magicSmp.libs.redis.clients.jedis.args.ExpiryOption;
import com.bx.magicSmp.libs.redis.clients.jedis.params.MigrateParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.RestoreParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.ScanParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.SortingParams;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.ScanResult;
import com.bx.magicSmp.libs.redis.clients.jedis.util.CompareCondition;
import java.util.List;
import java.util.Set;

public interface KeyPipelineCommands {
    public Response<Boolean> exists(String var1);

    public Response<Long> exists(String ... var1);

    public Response<Long> persist(String var1);

    public Response<String> type(String var1);

    public Response<byte[]> dump(String var1);

    public Response<String> restore(String var1, long var2, byte[] var4);

    public Response<String> restore(String var1, long var2, byte[] var4, RestoreParams var5);

    public Response<Long> expire(String var1, long var2);

    public Response<Long> expire(String var1, long var2, ExpiryOption var4);

    public Response<Long> pexpire(String var1, long var2);

    public Response<Long> pexpire(String var1, long var2, ExpiryOption var4);

    public Response<Long> expireTime(String var1);

    public Response<Long> pexpireTime(String var1);

    public Response<Long> expireAt(String var1, long var2);

    public Response<Long> expireAt(String var1, long var2, ExpiryOption var4);

    public Response<Long> pexpireAt(String var1, long var2);

    public Response<Long> pexpireAt(String var1, long var2, ExpiryOption var4);

    public Response<Long> ttl(String var1);

    public Response<Long> pttl(String var1);

    public Response<Long> touch(String var1);

    public Response<Long> touch(String ... var1);

    public Response<List<String>> sort(String var1);

    public Response<Long> sort(String var1, String var2);

    public Response<List<String>> sort(String var1, SortingParams var2);

    public Response<Long> sort(String var1, SortingParams var2, String var3);

    public Response<List<String>> sortReadonly(String var1, SortingParams var2);

    public Response<Long> del(String var1);

    public Response<Long> delex(String var1, CompareCondition var2);

    public Response<String> digestKey(String var1);

    public Response<Long> del(String ... var1);

    public Response<Long> unlink(String var1);

    public Response<Long> unlink(String ... var1);

    public Response<Boolean> copy(String var1, String var2, boolean var3);

    public Response<String> rename(String var1, String var2);

    public Response<Long> renamenx(String var1, String var2);

    public Response<Long> memoryUsage(String var1);

    public Response<Long> memoryUsage(String var1, int var2);

    public Response<Long> objectRefcount(String var1);

    public Response<String> objectEncoding(String var1);

    public Response<Long> objectIdletime(String var1);

    public Response<Long> objectFreq(String var1);

    public Response<String> migrate(String var1, int var2, String var3, int var4);

    public Response<String> migrate(String var1, int var2, int var3, MigrateParams var4, String ... var5);

    public Response<Set<String>> keys(String var1);

    public Response<ScanResult<String>> scan(String var1);

    public Response<ScanResult<String>> scan(String var1, ScanParams var2);

    public Response<ScanResult<String>> scan(String var1, ScanParams var2, String var3);

    public Response<String> randomKey();
}

