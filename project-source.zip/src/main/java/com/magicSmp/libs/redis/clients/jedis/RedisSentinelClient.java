/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis;

import com.bx.magicSmp.libs.redis.clients.jedis.CommandObjects;
import com.bx.magicSmp.libs.redis.clients.jedis.HostAndPort;
import com.bx.magicSmp.libs.redis.clients.jedis.Pipeline;
import com.bx.magicSmp.libs.redis.clients.jedis.RedisProtocol;
import com.bx.magicSmp.libs.redis.clients.jedis.UnifiedJedis;
import com.bx.magicSmp.libs.redis.clients.jedis.builders.SentinelClientBuilder;
import com.bx.magicSmp.libs.redis.clients.jedis.csc.Cache;
import com.bx.magicSmp.libs.redis.clients.jedis.executors.CommandExecutor;
import com.bx.magicSmp.libs.redis.clients.jedis.providers.ConnectionProvider;
import com.bx.magicSmp.libs.redis.clients.jedis.providers.SentineledConnectionProvider;

public class RedisSentinelClient
extends UnifiedJedis {
    private RedisSentinelClient(CommandExecutor commandExecutor, ConnectionProvider connectionProvider, CommandObjects commandObjects, RedisProtocol redisProtocol, Cache cache) {
        super(commandExecutor, connectionProvider, commandObjects, redisProtocol, cache);
    }

    public static Builder builder() {
        return new Builder();
    }

    public HostAndPort getCurrentMaster() {
        return ((SentineledConnectionProvider)this.provider).getCurrentMaster();
    }

    @Override
    public Pipeline pipelined() {
        return (Pipeline)super.pipelined();
    }

    public static class Builder
    extends SentinelClientBuilder<RedisSentinelClient> {
        @Override
        protected RedisSentinelClient createClient() {
            return new RedisSentinelClient(this.commandExecutor, this.connectionProvider, this.commandObjects, this.clientConfig.getRedisProtocol(), this.cache);
        }
    }
}

