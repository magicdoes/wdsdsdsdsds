/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.Response;
import java.util.List;

public interface ScriptingKeyPipelineCommands {
    public Response<Object> eval(String var1);

    public Response<Object> eval(String var1, int var2, String ... var3);

    public Response<Object> eval(String var1, List<String> var2, List<String> var3);

    public Response<Object> evalReadonly(String var1, List<String> var2, List<String> var3);

    public Response<Object> evalsha(String var1);

    public Response<Object> evalsha(String var1, int var2, String ... var3);

    public Response<Object> evalsha(String var1, List<String> var2, List<String> var3);

    public Response<Object> evalshaReadonly(String var1, List<String> var2, List<String> var3);
}

