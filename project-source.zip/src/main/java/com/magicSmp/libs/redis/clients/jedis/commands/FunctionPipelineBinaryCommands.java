/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.Response;
import com.bx.magicSmp.libs.redis.clients.jedis.args.FlushMode;
import com.bx.magicSmp.libs.redis.clients.jedis.args.FunctionRestorePolicy;
import java.util.List;

public interface FunctionPipelineBinaryCommands {
    public Response<Object> fcall(byte[] var1, List<byte[]> var2, List<byte[]> var3);

    public Response<Object> fcallReadonly(byte[] var1, List<byte[]> var2, List<byte[]> var3);

    public Response<String> functionDelete(byte[] var1);

    public Response<byte[]> functionDump();

    public Response<String> functionFlush();

    public Response<String> functionFlush(FlushMode var1);

    public Response<String> functionKill();

    public Response<List<Object>> functionListBinary();

    public Response<List<Object>> functionList(byte[] var1);

    public Response<List<Object>> functionListWithCodeBinary();

    public Response<List<Object>> functionListWithCode(byte[] var1);

    public Response<String> functionLoad(byte[] var1);

    public Response<String> functionLoadReplace(byte[] var1);

    public Response<String> functionRestore(byte[] var1);

    public Response<String> functionRestore(byte[] var1, FunctionRestorePolicy var2);

    public Response<Object> functionStatsBinary();
}

