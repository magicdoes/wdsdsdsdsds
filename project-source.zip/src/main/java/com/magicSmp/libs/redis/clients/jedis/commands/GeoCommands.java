/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.GeoCoordinate;
import com.bx.magicSmp.libs.redis.clients.jedis.args.GeoUnit;
import com.bx.magicSmp.libs.redis.clients.jedis.params.GeoAddParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.GeoRadiusParam;
import com.bx.magicSmp.libs.redis.clients.jedis.params.GeoRadiusStoreParam;
import com.bx.magicSmp.libs.redis.clients.jedis.params.GeoSearchParam;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.GeoRadiusResponse;
import java.util.List;
import java.util.Map;

public interface GeoCommands {
    public long geoadd(String var1, double var2, double var4, String var6);

    public long geoadd(String var1, Map<String, GeoCoordinate> var2);

    public long geoadd(String var1, GeoAddParams var2, Map<String, GeoCoordinate> var3);

    public Double geodist(String var1, String var2, String var3);

    public Double geodist(String var1, String var2, String var3, GeoUnit var4);

    public List<String> geohash(String var1, String ... var2);

    public List<GeoCoordinate> geopos(String var1, String ... var2);

    public List<GeoRadiusResponse> georadius(String var1, double var2, double var4, double var6, GeoUnit var8);

    public List<GeoRadiusResponse> georadiusReadonly(String var1, double var2, double var4, double var6, GeoUnit var8);

    public List<GeoRadiusResponse> georadius(String var1, double var2, double var4, double var6, GeoUnit var8, GeoRadiusParam var9);

    public List<GeoRadiusResponse> georadiusReadonly(String var1, double var2, double var4, double var6, GeoUnit var8, GeoRadiusParam var9);

    public List<GeoRadiusResponse> georadiusByMember(String var1, String var2, double var3, GeoUnit var5);

    public List<GeoRadiusResponse> georadiusByMemberReadonly(String var1, String var2, double var3, GeoUnit var5);

    public List<GeoRadiusResponse> georadiusByMember(String var1, String var2, double var3, GeoUnit var5, GeoRadiusParam var6);

    public List<GeoRadiusResponse> georadiusByMemberReadonly(String var1, String var2, double var3, GeoUnit var5, GeoRadiusParam var6);

    public long georadiusStore(String var1, double var2, double var4, double var6, GeoUnit var8, GeoRadiusParam var9, GeoRadiusStoreParam var10);

    public long georadiusByMemberStore(String var1, String var2, double var3, GeoUnit var5, GeoRadiusParam var6, GeoRadiusStoreParam var7);

    public List<GeoRadiusResponse> geosearch(String var1, String var2, double var3, GeoUnit var5);

    public List<GeoRadiusResponse> geosearch(String var1, GeoCoordinate var2, double var3, GeoUnit var5);

    public List<GeoRadiusResponse> geosearch(String var1, String var2, double var3, double var5, GeoUnit var7);

    public List<GeoRadiusResponse> geosearch(String var1, GeoCoordinate var2, double var3, double var5, GeoUnit var7);

    public List<GeoRadiusResponse> geosearch(String var1, GeoSearchParam var2);

    public long geosearchStore(String var1, String var2, String var3, double var4, GeoUnit var6);

    public long geosearchStore(String var1, String var2, GeoCoordinate var3, double var4, GeoUnit var6);

    public long geosearchStore(String var1, String var2, String var3, double var4, double var6, GeoUnit var8);

    public long geosearchStore(String var1, String var2, GeoCoordinate var3, double var4, double var6, GeoUnit var8);

    public long geosearchStore(String var1, String var2, GeoSearchParam var3);

    public long geosearchStoreStoreDist(String var1, String var2, GeoSearchParam var3);
}

