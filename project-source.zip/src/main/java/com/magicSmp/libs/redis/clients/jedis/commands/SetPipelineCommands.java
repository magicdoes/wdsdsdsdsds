/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.Response;
import com.bx.magicSmp.libs.redis.clients.jedis.params.ScanParams;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.ScanResult;
import java.util.List;
import java.util.Set;

public interface SetPipelineCommands {
    public Response<Long> sadd(String var1, String ... var2);

    public Response<Set<String>> smembers(String var1);

    public Response<Long> srem(String var1, String ... var2);

    public Response<String> spop(String var1);

    public Response<Set<String>> spop(String var1, long var2);

    public Response<Long> scard(String var1);

    public Response<Boolean> sismember(String var1, String var2);

    public Response<List<Boolean>> smismember(String var1, String ... var2);

    public Response<String> srandmember(String var1);

    public Response<List<String>> srandmember(String var1, int var2);

    default public Response<ScanResult<String>> sscan(String key, String cursor) {
        return this.sscan(key, cursor, new ScanParams());
    }

    public Response<ScanResult<String>> sscan(String var1, String var2, ScanParams var3);

    public Response<Set<String>> sdiff(String ... var1);

    public Response<Long> sdiffstore(String var1, String ... var2);

    @Deprecated
    default public Response<Long> sdiffStore(String dstKey, String ... keys) {
        return this.sdiffstore(dstKey, keys);
    }

    public Response<Set<String>> sinter(String ... var1);

    public Response<Long> sinterstore(String var1, String ... var2);

    public Response<Long> sintercard(String ... var1);

    public Response<Long> sintercard(int var1, String ... var2);

    public Response<Set<String>> sunion(String ... var1);

    public Response<Long> sunionstore(String var1, String ... var2);

    public Response<Long> smove(String var1, String var2, String var3);
}

