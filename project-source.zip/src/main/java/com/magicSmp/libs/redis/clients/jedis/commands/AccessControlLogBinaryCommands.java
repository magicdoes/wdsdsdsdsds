/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.CommandArguments;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.AccessControlUser;
import java.util.List;

public interface AccessControlLogBinaryCommands {
    public byte[] aclWhoAmIBinary();

    public byte[] aclGenPassBinary();

    public byte[] aclGenPassBinary(int var1);

    public List<byte[]> aclListBinary();

    public List<byte[]> aclUsersBinary();

    public AccessControlUser aclGetUser(byte[] var1);

    public String aclSetUser(byte[] var1);

    public String aclSetUser(byte[] var1, byte[] ... var2);

    public long aclDelUser(byte[] ... var1);

    public List<byte[]> aclCatBinary();

    public List<byte[]> aclCat(byte[] var1);

    public List<byte[]> aclLogBinary();

    public List<byte[]> aclLogBinary(int var1);

    public String aclLogReset();

    public String aclLoad();

    public String aclSave();

    public byte[] aclDryRunBinary(byte[] var1, byte[] var2, byte[] ... var3);

    public byte[] aclDryRunBinary(byte[] var1, CommandArguments var2);
}

