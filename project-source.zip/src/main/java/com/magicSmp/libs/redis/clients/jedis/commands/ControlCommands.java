/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.commands.AccessControlLogCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.ClientCommands;
import java.util.List;
import java.util.Map;

public interface ControlCommands
extends AccessControlLogCommands,
ClientCommands {
    public List<Object> role();

    public Long objectRefcount(String var1);

    public String objectEncoding(String var1);

    public Long objectIdletime(String var1);

    public List<String> objectHelp();

    public Long objectFreq(String var1);

    public String memoryDoctor();

    public Long memoryUsage(String var1);

    public Long memoryUsage(String var1, int var2);

    public String memoryPurge();

    public Map<String, Object> memoryStats();
}

