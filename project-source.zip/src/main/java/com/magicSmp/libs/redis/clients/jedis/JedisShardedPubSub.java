/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis;

import com.bx.magicSmp.libs.redis.clients.jedis.JedisShardedPubSubBase;
import com.bx.magicSmp.libs.redis.clients.jedis.util.SafeEncoder;

public abstract class JedisShardedPubSub
extends JedisShardedPubSubBase<String> {
    @Override
    protected final String encode(byte[] raw) {
        return SafeEncoder.encode(raw);
    }
}

