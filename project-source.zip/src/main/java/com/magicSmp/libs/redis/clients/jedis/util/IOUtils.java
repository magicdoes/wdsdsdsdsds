/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.util;

import java.io.IOException;
import java.net.Socket;

public class IOUtils {
    public static void closeQuietly(Socket sock) {
        if (sock != null) {
            try {
                sock.close();
            }
            catch (IOException iOException) {
                // empty catch block
            }
        }
    }

    public static void closeQuietly(AutoCloseable resource) {
        if (resource != null) {
            try {
                resource.close();
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
    }

    private IOUtils() {
        throw new InstantiationError("Must not instantiate this class");
    }
}

