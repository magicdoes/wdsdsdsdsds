/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.search;

import com.bx.magicSmp.libs.redis.clients.jedis.CommandArguments;
import com.bx.magicSmp.libs.redis.clients.jedis.params.IParams;
import com.bx.magicSmp.libs.redis.clients.jedis.search.SearchProtocol;

public class FTProfileParams
implements IParams {
    private boolean limited;

    public static FTProfileParams profileParams() {
        return new FTProfileParams();
    }

    public FTProfileParams limited() {
        this.limited = true;
        return this;
    }

    @Override
    public void addParams(CommandArguments args) {
        if (this.limited) {
            args.add(SearchProtocol.SearchKeyword.LIMITED);
        }
    }
}

