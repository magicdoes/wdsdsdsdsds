/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.timeseries;

import com.bx.magicSmp.libs.redis.clients.jedis.Response;
import com.bx.magicSmp.libs.redis.clients.jedis.timeseries.AggregationType;
import com.bx.magicSmp.libs.redis.clients.jedis.timeseries.TSAddParams;
import com.bx.magicSmp.libs.redis.clients.jedis.timeseries.TSAlterParams;
import com.bx.magicSmp.libs.redis.clients.jedis.timeseries.TSCreateParams;
import com.bx.magicSmp.libs.redis.clients.jedis.timeseries.TSDecrByParams;
import com.bx.magicSmp.libs.redis.clients.jedis.timeseries.TSElement;
import com.bx.magicSmp.libs.redis.clients.jedis.timeseries.TSGetParams;
import com.bx.magicSmp.libs.redis.clients.jedis.timeseries.TSIncrByParams;
import com.bx.magicSmp.libs.redis.clients.jedis.timeseries.TSInfo;
import com.bx.magicSmp.libs.redis.clients.jedis.timeseries.TSMGetElement;
import com.bx.magicSmp.libs.redis.clients.jedis.timeseries.TSMGetParams;
import com.bx.magicSmp.libs.redis.clients.jedis.timeseries.TSMRangeElements;
import com.bx.magicSmp.libs.redis.clients.jedis.timeseries.TSMRangeParams;
import com.bx.magicSmp.libs.redis.clients.jedis.timeseries.TSRangeParams;
import java.util.List;
import java.util.Map;

public interface RedisTimeSeriesPipelineCommands {
    public Response<String> tsCreate(String var1);

    public Response<String> tsCreate(String var1, TSCreateParams var2);

    public Response<Long> tsDel(String var1, long var2, long var4);

    public Response<String> tsAlter(String var1, TSAlterParams var2);

    public Response<Long> tsAdd(String var1, double var2);

    public Response<Long> tsAdd(String var1, long var2, double var4);

    @Deprecated
    public Response<Long> tsAdd(String var1, long var2, double var4, TSCreateParams var6);

    public Response<Long> tsAdd(String var1, long var2, double var4, TSAddParams var6);

    public Response<List<Long>> tsMAdd(Map.Entry<String, TSElement> ... var1);

    public Response<Long> tsIncrBy(String var1, double var2);

    public Response<Long> tsIncrBy(String var1, double var2, long var4);

    public Response<Long> tsIncrBy(String var1, double var2, TSIncrByParams var4);

    public Response<Long> tsDecrBy(String var1, double var2);

    public Response<Long> tsDecrBy(String var1, double var2, long var4);

    public Response<Long> tsDecrBy(String var1, double var2, TSDecrByParams var4);

    public Response<List<TSElement>> tsRange(String var1, long var2, long var4);

    public Response<List<TSElement>> tsRange(String var1, TSRangeParams var2);

    public Response<List<TSElement>> tsRevRange(String var1, long var2, long var4);

    public Response<List<TSElement>> tsRevRange(String var1, TSRangeParams var2);

    public Response<Map<String, TSMRangeElements>> tsMRange(long var1, long var3, String ... var5);

    public Response<Map<String, TSMRangeElements>> tsMRange(TSMRangeParams var1);

    public Response<Map<String, TSMRangeElements>> tsMRevRange(long var1, long var3, String ... var5);

    public Response<Map<String, TSMRangeElements>> tsMRevRange(TSMRangeParams var1);

    public Response<TSElement> tsGet(String var1);

    public Response<TSElement> tsGet(String var1, TSGetParams var2);

    public Response<Map<String, TSMGetElement>> tsMGet(TSMGetParams var1, String ... var2);

    public Response<String> tsCreateRule(String var1, String var2, AggregationType var3, long var4);

    public Response<String> tsCreateRule(String var1, String var2, AggregationType var3, long var4, long var6);

    public Response<String> tsDeleteRule(String var1, String var2);

    public Response<List<String>> tsQueryIndex(String ... var1);

    public Response<TSInfo> tsInfo(String var1);

    public Response<TSInfo> tsInfoDebug(String var1);
}

