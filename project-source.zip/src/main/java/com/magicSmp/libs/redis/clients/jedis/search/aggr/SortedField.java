/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.search.aggr;

public class SortedField {
    private final String fieldName;
    private final SortOrder sortOrder;

    public SortedField(String fieldName, SortOrder order) {
        this.fieldName = fieldName;
        this.sortOrder = order;
    }

    public final String getOrder() {
        return this.sortOrder.toString();
    }

    public final String getField() {
        return this.fieldName;
    }

    public static SortedField asc(String field) {
        return new SortedField(field, SortOrder.ASC);
    }

    public static SortedField desc(String field) {
        return new SortedField(field, SortOrder.DESC);
    }

    public static enum SortOrder {
        ASC,
        DESC;

    }
}

