/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.timeseries;

import com.bx.magicSmp.libs.redis.clients.jedis.timeseries.TSElement;
import com.bx.magicSmp.libs.redis.clients.jedis.util.KeyValue;
import java.util.Map;

public class TSMGetElement
extends KeyValue<String, TSElement> {
    private final Map<String, String> labels;

    public TSMGetElement(String key, Map<String, String> labels, TSElement value) {
        super(key, value);
        this.labels = labels;
    }

    public Map<String, String> getLabels() {
        return this.labels;
    }

    public TSElement getElement() {
        return (TSElement)this.getValue();
    }

    @Override
    public String toString() {
        return this.getClass().getSimpleName() + "{key=" + (String)this.getKey() + ", labels=" + this.labels + ", element=" + this.getElement() + '}';
    }
}

