/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.Response;
import com.bx.magicSmp.libs.redis.clients.jedis.args.ListDirection;
import com.bx.magicSmp.libs.redis.clients.jedis.args.ListPosition;
import com.bx.magicSmp.libs.redis.clients.jedis.params.LPosParams;
import com.bx.magicSmp.libs.redis.clients.jedis.util.KeyValue;
import java.util.List;

public interface ListPipelineCommands {
    public Response<Long> rpush(String var1, String ... var2);

    public Response<Long> lpush(String var1, String ... var2);

    public Response<Long> llen(String var1);

    public Response<List<String>> lrange(String var1, long var2, long var4);

    public Response<String> ltrim(String var1, long var2, long var4);

    public Response<String> lindex(String var1, long var2);

    public Response<String> lset(String var1, long var2, String var4);

    public Response<Long> lrem(String var1, long var2, String var4);

    public Response<String> lpop(String var1);

    public Response<List<String>> lpop(String var1, int var2);

    public Response<Long> lpos(String var1, String var2);

    public Response<Long> lpos(String var1, String var2, LPosParams var3);

    public Response<List<Long>> lpos(String var1, String var2, LPosParams var3, long var4);

    public Response<String> rpop(String var1);

    public Response<List<String>> rpop(String var1, int var2);

    public Response<Long> linsert(String var1, ListPosition var2, String var3, String var4);

    public Response<Long> lpushx(String var1, String ... var2);

    public Response<Long> rpushx(String var1, String ... var2);

    public Response<List<String>> blpop(int var1, String var2);

    public Response<KeyValue<String, String>> blpop(double var1, String var3);

    public Response<List<String>> brpop(int var1, String var2);

    public Response<KeyValue<String, String>> brpop(double var1, String var3);

    public Response<List<String>> blpop(int var1, String ... var2);

    public Response<KeyValue<String, String>> blpop(double var1, String ... var3);

    public Response<List<String>> brpop(int var1, String ... var2);

    public Response<KeyValue<String, String>> brpop(double var1, String ... var3);

    public Response<String> rpoplpush(String var1, String var2);

    public Response<String> brpoplpush(String var1, String var2, int var3);

    public Response<String> lmove(String var1, String var2, ListDirection var3, ListDirection var4);

    public Response<String> blmove(String var1, String var2, ListDirection var3, ListDirection var4, double var5);

    public Response<KeyValue<String, List<String>>> lmpop(ListDirection var1, String ... var2);

    public Response<KeyValue<String, List<String>>> lmpop(ListDirection var1, int var2, String ... var3);

    public Response<KeyValue<String, List<String>>> blmpop(double var1, ListDirection var3, String ... var4);

    public Response<KeyValue<String, List<String>>> blmpop(double var1, ListDirection var3, int var4, String ... var5);
}

