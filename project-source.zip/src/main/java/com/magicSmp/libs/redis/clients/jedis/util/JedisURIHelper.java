/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.util;

import com.bx.magicSmp.libs.redis.clients.jedis.HostAndPort;
import com.bx.magicSmp.libs.redis.clients.jedis.RedisProtocol;
import java.net.URI;

public final class JedisURIHelper {
    private static final String REDIS = "redis";
    private static final String REDISS = "rediss";

    private JedisURIHelper() {
        throw new InstantiationError("Must not instantiate this class");
    }

    public static HostAndPort getHostAndPort(URI uri) {
        return new HostAndPort(uri.getHost(), uri.getPort());
    }

    public static String getUser(URI uri) {
        String userInfo = uri.getUserInfo();
        if (userInfo != null) {
            String user = userInfo.split(":", 2)[0];
            if (user.isEmpty()) {
                user = null;
            }
            return user;
        }
        return null;
    }

    public static String getPassword(URI uri) {
        String userInfo = uri.getUserInfo();
        if (userInfo != null) {
            String[] userAndPassword = userInfo.split(":", 2);
            if (userAndPassword.length < 2) {
                throw new IllegalArgumentException("Password not provided in uri.");
            }
            return userAndPassword[1];
        }
        return null;
    }

    public static boolean hasDbIndex(URI uri) {
        if (uri.getPath() == null || uri.getPath().isEmpty()) {
            return false;
        }
        String[] pathSplit = uri.getPath().split("/", 2);
        return pathSplit.length > 1 && !pathSplit[1].isEmpty();
    }

    public static int getDBIndex(URI uri) {
        String[] pathSplit = uri.getPath().split("/", 2);
        if (pathSplit.length > 1) {
            String dbIndexStr = pathSplit[1];
            if (dbIndexStr.isEmpty()) {
                return 0;
            }
            return Integer.parseInt(dbIndexStr);
        }
        return 0;
    }

    public static RedisProtocol getRedisProtocol(URI uri) {
        String[] params;
        if (uri.getQuery() == null) {
            return null;
        }
        for (String param : params = uri.getQuery().split("&")) {
            int idx = param.indexOf("=");
            if (idx < 0 || !"protocol".equals(param.substring(0, idx))) continue;
            String ver = param.substring(idx + 1);
            for (RedisProtocol proto : RedisProtocol.values()) {
                if (!proto.version().equals(ver)) continue;
                return proto;
            }
            throw new IllegalArgumentException("Unknown protocol " + ver);
        }
        return null;
    }

    public static boolean isValid(URI uri) {
        return !JedisURIHelper.isEmpty(uri.getScheme()) && !JedisURIHelper.isEmpty(uri.getHost()) && uri.getPort() != -1;
    }

    private static boolean isEmpty(String value) {
        return value == null || value.trim().length() == 0;
    }

    public static boolean isRedisScheme(URI uri) {
        return REDIS.equals(uri.getScheme());
    }

    public static boolean isRedisSSLScheme(URI uri) {
        return REDISS.equals(uri.getScheme());
    }
}

