/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.commands.BitCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.params.GetExParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.LCSParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.MSetExParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.SetParams;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.LCSMatchResult;
import java.util.List;

public interface StringCommands
extends BitCommands {
    public String set(String var1, String var2);

    public String set(String var1, String var2, SetParams var3);

    public String get(String var1);

    public String setGet(String var1, String var2);

    public String setGet(String var1, String var2, SetParams var3);

    public String getDel(String var1);

    public String getEx(String var1, GetExParams var2);

    public long setrange(String var1, long var2, String var4);

    public String getrange(String var1, long var2, long var4);

    @Deprecated
    public String getSet(String var1, String var2);

    @Deprecated
    public long setnx(String var1, String var2);

    @Deprecated
    public String setex(String var1, long var2, String var4);

    @Deprecated
    public String psetex(String var1, long var2, String var4);

    public List<String> mget(String ... var1);

    public String mset(String ... var1);

    public long msetnx(String ... var1);

    public boolean msetex(MSetExParams var1, String ... var2);

    public long incr(String var1);

    public long incrBy(String var1, long var2);

    public double incrByFloat(String var1, double var2);

    public long decr(String var1);

    public long decrBy(String var1, long var2);

    public long append(String var1, String var2);

    @Deprecated
    public String substr(String var1, int var2, int var3);

    public long strlen(String var1);

    public LCSMatchResult lcs(String var1, String var2, LCSParams var3);
}

