/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.bloom.commands;

import java.util.Collections;
import java.util.List;
import java.util.Map;

public interface TopKFilterCommands {
    public String topkReserve(String var1, long var2);

    public String topkReserve(String var1, long var2, long var4, long var6, double var8);

    public List<String> topkAdd(String var1, String ... var2);

    default public String topkIncrBy(String key, String item, long increment) {
        return this.topkIncrBy(key, Collections.singletonMap(item, increment)).get(0);
    }

    public List<String> topkIncrBy(String var1, Map<String, Long> var2);

    public List<Boolean> topkQuery(String var1, String ... var2);

    public List<String> topkList(String var1);

    public Map<String, Long> topkListWithCount(String var1);

    public Map<String, Object> topkInfo(String var1);
}

