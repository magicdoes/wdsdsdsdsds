/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.args.ExpiryOption;
import com.bx.magicSmp.libs.redis.clients.jedis.params.HGetExParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.HSetExParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.ScanParams;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.ScanResult;
import java.util.List;
import java.util.Map;
import java.util.Set;

public interface HashCommands {
    public long hset(String var1, String var2, String var3);

    public long hset(String var1, Map<String, String> var2);

    public long hsetex(String var1, HSetExParams var2, String var3, String var4);

    public long hsetex(String var1, HSetExParams var2, Map<String, String> var3);

    public String hget(String var1, String var2);

    public List<String> hgetex(String var1, HGetExParams var2, String ... var3);

    public List<String> hgetdel(String var1, String ... var2);

    public long hsetnx(String var1, String var2, String var3);

    @Deprecated
    public String hmset(String var1, Map<String, String> var2);

    public List<String> hmget(String var1, String ... var2);

    public long hincrBy(String var1, String var2, long var3);

    public double hincrByFloat(String var1, String var2, double var3);

    public boolean hexists(String var1, String var2);

    public long hdel(String var1, String ... var2);

    public long hlen(String var1);

    public Set<String> hkeys(String var1);

    public List<String> hvals(String var1);

    public Map<String, String> hgetAll(String var1);

    public String hrandfield(String var1);

    public List<String> hrandfield(String var1, long var2);

    public List<Map.Entry<String, String>> hrandfieldWithValues(String var1, long var2);

    default public ScanResult<Map.Entry<String, String>> hscan(String key, String cursor) {
        return this.hscan(key, cursor, new ScanParams());
    }

    public ScanResult<Map.Entry<String, String>> hscan(String var1, String var2, ScanParams var3);

    default public ScanResult<String> hscanNoValues(String key, String cursor) {
        return this.hscanNoValues(key, cursor, new ScanParams());
    }

    public ScanResult<String> hscanNoValues(String var1, String var2, ScanParams var3);

    public long hstrlen(String var1, String var2);

    public List<Long> hexpire(String var1, long var2, String ... var4);

    public List<Long> hexpire(String var1, long var2, ExpiryOption var4, String ... var5);

    public List<Long> hpexpire(String var1, long var2, String ... var4);

    public List<Long> hpexpire(String var1, long var2, ExpiryOption var4, String ... var5);

    public List<Long> hexpireAt(String var1, long var2, String ... var4);

    public List<Long> hexpireAt(String var1, long var2, ExpiryOption var4, String ... var5);

    public List<Long> hpexpireAt(String var1, long var2, String ... var4);

    public List<Long> hpexpireAt(String var1, long var2, ExpiryOption var4, String ... var5);

    public List<Long> hexpireTime(String var1, String ... var2);

    public List<Long> hpexpireTime(String var1, String ... var2);

    public List<Long> httl(String var1, String ... var2);

    public List<Long> hpttl(String var1, String ... var2);

    public List<Long> hpersist(String var1, String ... var2);
}

