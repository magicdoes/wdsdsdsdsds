/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.annots.Experimental;
import com.bx.magicSmp.libs.redis.clients.jedis.args.ExpiryOption;
import com.bx.magicSmp.libs.redis.clients.jedis.params.MigrateParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.RestoreParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.ScanParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.SortingParams;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.ScanResult;
import com.bx.magicSmp.libs.redis.clients.jedis.util.CompareCondition;
import java.util.List;
import java.util.Set;

public interface KeyBinaryCommands {
    public boolean exists(byte[] var1);

    public long exists(byte[] ... var1);

    public long persist(byte[] var1);

    public String type(byte[] var1);

    public byte[] dump(byte[] var1);

    public String restore(byte[] var1, long var2, byte[] var4);

    public String restore(byte[] var1, long var2, byte[] var4, RestoreParams var5);

    public long expire(byte[] var1, long var2);

    public long expire(byte[] var1, long var2, ExpiryOption var4);

    public long pexpire(byte[] var1, long var2);

    public long pexpire(byte[] var1, long var2, ExpiryOption var4);

    public long expireTime(byte[] var1);

    public long pexpireTime(byte[] var1);

    public long expireAt(byte[] var1, long var2);

    public long expireAt(byte[] var1, long var2, ExpiryOption var4);

    public long pexpireAt(byte[] var1, long var2);

    public long pexpireAt(byte[] var1, long var2, ExpiryOption var4);

    public long ttl(byte[] var1);

    public long pttl(byte[] var1);

    public long touch(byte[] var1);

    public long touch(byte[] ... var1);

    public List<byte[]> sort(byte[] var1);

    public List<byte[]> sort(byte[] var1, SortingParams var2);

    public long del(byte[] var1);

    @Experimental
    public long delex(byte[] var1, CompareCondition var2);

    @Experimental
    public byte[] digestKey(byte[] var1);

    public long del(byte[] ... var1);

    public long unlink(byte[] var1);

    public long unlink(byte[] ... var1);

    public boolean copy(byte[] var1, byte[] var2, boolean var3);

    public String rename(byte[] var1, byte[] var2);

    public long renamenx(byte[] var1, byte[] var2);

    public long sort(byte[] var1, SortingParams var2, byte[] var3);

    public long sort(byte[] var1, byte[] var2);

    public List<byte[]> sortReadonly(byte[] var1, SortingParams var2);

    public Long memoryUsage(byte[] var1);

    public Long memoryUsage(byte[] var1, int var2);

    public Long objectRefcount(byte[] var1);

    public byte[] objectEncoding(byte[] var1);

    public Long objectIdletime(byte[] var1);

    public Long objectFreq(byte[] var1);

    public String migrate(String var1, int var2, byte[] var3, int var4);

    public String migrate(String var1, int var2, int var3, MigrateParams var4, byte[] ... var5);

    public Set<byte[]> keys(byte[] var1);

    public ScanResult<byte[]> scan(byte[] var1);

    public ScanResult<byte[]> scan(byte[] var1, ScanParams var2);

    public ScanResult<byte[]> scan(byte[] var1, ScanParams var2, byte[] var3);

    public byte[] randomBinaryKey();
}

