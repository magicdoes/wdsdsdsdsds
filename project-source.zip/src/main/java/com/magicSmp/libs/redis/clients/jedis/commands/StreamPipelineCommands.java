/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.Response;
import com.bx.magicSmp.libs.redis.clients.jedis.StreamEntryID;
import com.bx.magicSmp.libs.redis.clients.jedis.args.StreamDeletionPolicy;
import com.bx.magicSmp.libs.redis.clients.jedis.params.XAddParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.XAutoClaimParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.XCfgSetParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.XClaimParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.XPendingParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.XReadGroupParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.XReadParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.XTrimParams;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.StreamConsumerInfo;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.StreamConsumersInfo;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.StreamEntry;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.StreamEntryDeletionResult;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.StreamFullInfo;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.StreamGroupInfo;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.StreamInfo;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.StreamPendingEntry;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.StreamPendingSummary;
import java.util.List;
import java.util.Map;

public interface StreamPipelineCommands {
    public Response<StreamEntryID> xadd(String var1, StreamEntryID var2, Map<String, String> var3);

    default public Response<StreamEntryID> xadd(String key, Map<String, String> hash, XAddParams params) {
        return this.xadd(key, params, hash);
    }

    public Response<StreamEntryID> xadd(String var1, XAddParams var2, Map<String, String> var3);

    public Response<Long> xlen(String var1);

    public Response<List<StreamEntry>> xrange(String var1, StreamEntryID var2, StreamEntryID var3);

    public Response<List<StreamEntry>> xrange(String var1, StreamEntryID var2, StreamEntryID var3, int var4);

    public Response<List<StreamEntry>> xrevrange(String var1, StreamEntryID var2, StreamEntryID var3);

    public Response<List<StreamEntry>> xrevrange(String var1, StreamEntryID var2, StreamEntryID var3, int var4);

    public Response<List<StreamEntry>> xrange(String var1, String var2, String var3);

    public Response<List<StreamEntry>> xrange(String var1, String var2, String var3, int var4);

    public Response<List<StreamEntry>> xrevrange(String var1, String var2, String var3);

    public Response<List<StreamEntry>> xrevrange(String var1, String var2, String var3, int var4);

    public Response<Long> xack(String var1, String var2, StreamEntryID ... var3);

    public Response<List<StreamEntryDeletionResult>> xackdel(String var1, String var2, StreamEntryID ... var3);

    public Response<List<StreamEntryDeletionResult>> xackdel(String var1, String var2, StreamDeletionPolicy var3, StreamEntryID ... var4);

    public Response<String> xgroupCreate(String var1, String var2, StreamEntryID var3, boolean var4);

    public Response<String> xgroupSetID(String var1, String var2, StreamEntryID var3);

    public Response<Long> xgroupDestroy(String var1, String var2);

    public Response<Boolean> xgroupCreateConsumer(String var1, String var2, String var3);

    public Response<Long> xgroupDelConsumer(String var1, String var2, String var3);

    public Response<StreamPendingSummary> xpending(String var1, String var2);

    public Response<List<StreamPendingEntry>> xpending(String var1, String var2, XPendingParams var3);

    public Response<Long> xdel(String var1, StreamEntryID ... var2);

    public Response<List<StreamEntryDeletionResult>> xdelex(String var1, StreamEntryID ... var2);

    public Response<List<StreamEntryDeletionResult>> xdelex(String var1, StreamDeletionPolicy var2, StreamEntryID ... var3);

    public Response<Long> xtrim(String var1, long var2, boolean var4);

    public Response<Long> xtrim(String var1, XTrimParams var2);

    public Response<List<StreamEntry>> xclaim(String var1, String var2, String var3, long var4, XClaimParams var6, StreamEntryID ... var7);

    public Response<List<StreamEntryID>> xclaimJustId(String var1, String var2, String var3, long var4, XClaimParams var6, StreamEntryID ... var7);

    public Response<Map.Entry<StreamEntryID, List<StreamEntry>>> xautoclaim(String var1, String var2, String var3, long var4, StreamEntryID var6, XAutoClaimParams var7);

    public Response<Map.Entry<StreamEntryID, List<StreamEntryID>>> xautoclaimJustId(String var1, String var2, String var3, long var4, StreamEntryID var6, XAutoClaimParams var7);

    public Response<StreamInfo> xinfoStream(String var1);

    public Response<StreamFullInfo> xinfoStreamFull(String var1);

    public Response<StreamFullInfo> xinfoStreamFull(String var1, int var2);

    public Response<List<StreamGroupInfo>> xinfoGroups(String var1);

    @Deprecated
    public Response<List<StreamConsumersInfo>> xinfoConsumers(String var1, String var2);

    public Response<List<StreamConsumerInfo>> xinfoConsumers2(String var1, String var2);

    public Response<List<Map.Entry<String, List<StreamEntry>>>> xread(XReadParams var1, Map<String, StreamEntryID> var2);

    public Response<Map<String, List<StreamEntry>>> xreadAsMap(XReadParams var1, Map<String, StreamEntryID> var2);

    public Response<List<Map.Entry<String, List<StreamEntry>>>> xreadGroup(String var1, String var2, XReadGroupParams var3, Map<String, StreamEntryID> var4);

    public Response<Map<String, List<StreamEntry>>> xreadGroupAsMap(String var1, String var2, XReadGroupParams var3, Map<String, StreamEntryID> var4);

    public Response<String> xcfgset(String var1, XCfgSetParams var2);
}

