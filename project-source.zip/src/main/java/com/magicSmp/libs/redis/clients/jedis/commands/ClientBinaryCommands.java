/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.args.ClientAttributeOption;
import com.bx.magicSmp.libs.redis.clients.jedis.args.ClientPauseMode;
import com.bx.magicSmp.libs.redis.clients.jedis.args.ClientType;
import com.bx.magicSmp.libs.redis.clients.jedis.args.UnblockType;
import com.bx.magicSmp.libs.redis.clients.jedis.params.ClientKillParams;

public interface ClientBinaryCommands {
    public String clientKill(byte[] var1);

    public String clientKill(String var1, int var2);

    public long clientKill(ClientKillParams var1);

    public byte[] clientGetnameBinary();

    public byte[] clientListBinary();

    public byte[] clientListBinary(ClientType var1);

    public byte[] clientListBinary(long ... var1);

    public byte[] clientInfoBinary();

    public String clientSetInfo(ClientAttributeOption var1, byte[] var2);

    public String clientSetname(byte[] var1);

    public long clientId();

    public long clientUnblock(long var1);

    public long clientUnblock(long var1, UnblockType var3);

    public String clientPause(long var1);

    public String clientPause(long var1, ClientPauseMode var3);

    public String clientUnpause();

    public String clientNoEvictOn();

    public String clientNoEvictOff();
}

