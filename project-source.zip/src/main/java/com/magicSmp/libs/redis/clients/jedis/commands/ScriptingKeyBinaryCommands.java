/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import java.util.List;

public interface ScriptingKeyBinaryCommands {
    public Object eval(byte[] var1);

    public Object eval(byte[] var1, int var2, byte[] ... var3);

    public Object eval(byte[] var1, List<byte[]> var2, List<byte[]> var3);

    public Object evalReadonly(byte[] var1, List<byte[]> var2, List<byte[]> var3);

    public Object evalsha(byte[] var1);

    public Object evalsha(byte[] var1, int var2, byte[] ... var3);

    public Object evalsha(byte[] var1, List<byte[]> var2, List<byte[]> var3);

    public Object evalshaReadonly(byte[] var1, List<byte[]> var2, List<byte[]> var3);
}

