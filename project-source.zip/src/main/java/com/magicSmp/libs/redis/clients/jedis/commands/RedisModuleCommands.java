/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.bloom.commands.RedisBloomCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.json.commands.RedisJsonCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.search.RediSearchCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.timeseries.RedisTimeSeriesCommands;

public interface RedisModuleCommands
extends RediSearchCommands,
RedisJsonCommands,
RedisTimeSeriesCommands,
RedisBloomCommands {
}

