/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.Response;
import com.bx.magicSmp.libs.redis.clients.jedis.params.ScanParams;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.ScanResult;
import java.util.List;
import java.util.Set;

public interface SetPipelineBinaryCommands {
    public Response<Long> sadd(byte[] var1, byte[] ... var2);

    public Response<Set<byte[]>> smembers(byte[] var1);

    public Response<Long> srem(byte[] var1, byte[] ... var2);

    public Response<byte[]> spop(byte[] var1);

    public Response<Set<byte[]>> spop(byte[] var1, long var2);

    public Response<Long> scard(byte[] var1);

    public Response<Boolean> sismember(byte[] var1, byte[] var2);

    public Response<List<Boolean>> smismember(byte[] var1, byte[] ... var2);

    public Response<byte[]> srandmember(byte[] var1);

    public Response<List<byte[]>> srandmember(byte[] var1, int var2);

    default public Response<ScanResult<byte[]>> sscan(byte[] key, byte[] cursor) {
        return this.sscan(key, cursor, new ScanParams());
    }

    public Response<ScanResult<byte[]>> sscan(byte[] var1, byte[] var2, ScanParams var3);

    public Response<Set<byte[]>> sdiff(byte[] ... var1);

    public Response<Long> sdiffstore(byte[] var1, byte[] ... var2);

    public Response<Set<byte[]>> sinter(byte[] ... var1);

    public Response<Long> sinterstore(byte[] var1, byte[] ... var2);

    public Response<Long> sintercard(byte[] ... var1);

    public Response<Long> sintercard(int var1, byte[] ... var2);

    public Response<Set<byte[]>> sunion(byte[] ... var1);

    public Response<Long> sunionstore(byte[] var1, byte[] ... var2);

    public Response<Long> smove(byte[] var1, byte[] var2, byte[] var3);
}

