/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.Response;
import com.bx.magicSmp.libs.redis.clients.jedis.args.FlushMode;
import com.bx.magicSmp.libs.redis.clients.jedis.util.KeyValue;
import java.util.List;

public interface SampleKeyedPipelineCommands {
    public Response<Long> waitReplicas(String var1, int var2, long var3);

    public Response<KeyValue<Long, Long>> waitAOF(String var1, long var2, long var4, long var6);

    public Response<Object> eval(String var1, String var2);

    public Response<Object> evalsha(String var1, String var2);

    public Response<List<Boolean>> scriptExists(String var1, String ... var2);

    public Response<String> scriptLoad(String var1, String var2);

    public Response<String> scriptFlush(String var1);

    public Response<String> scriptFlush(String var1, FlushMode var2);

    public Response<String> scriptKill(String var1);
}

