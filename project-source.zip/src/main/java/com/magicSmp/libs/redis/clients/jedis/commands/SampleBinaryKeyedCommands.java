/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.args.FlushMode;
import com.bx.magicSmp.libs.redis.clients.jedis.util.KeyValue;
import java.util.List;

public interface SampleBinaryKeyedCommands {
    public long waitReplicas(byte[] var1, int var2, long var3);

    public KeyValue<Long, Long> waitAOF(byte[] var1, long var2, long var4, long var6);

    public Object eval(byte[] var1, byte[] var2);

    public Object evalsha(byte[] var1, byte[] var2);

    public Boolean scriptExists(byte[] var1, byte[] var2);

    public List<Boolean> scriptExists(byte[] var1, byte[] ... var2);

    public byte[] scriptLoad(byte[] var1, byte[] var2);

    public String scriptFlush(byte[] var1);

    public String scriptFlush(byte[] var1, FlushMode var2);

    public String scriptKill(byte[] var1);
}

