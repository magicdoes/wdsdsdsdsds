/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.GeoCoordinate;
import com.bx.magicSmp.libs.redis.clients.jedis.Response;
import com.bx.magicSmp.libs.redis.clients.jedis.args.GeoUnit;
import com.bx.magicSmp.libs.redis.clients.jedis.params.GeoAddParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.GeoRadiusParam;
import com.bx.magicSmp.libs.redis.clients.jedis.params.GeoRadiusStoreParam;
import com.bx.magicSmp.libs.redis.clients.jedis.params.GeoSearchParam;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.GeoRadiusResponse;
import java.util.List;
import java.util.Map;

public interface GeoPipelineBinaryCommands {
    public Response<Long> geoadd(byte[] var1, double var2, double var4, byte[] var6);

    public Response<Long> geoadd(byte[] var1, Map<byte[], GeoCoordinate> var2);

    public Response<Long> geoadd(byte[] var1, GeoAddParams var2, Map<byte[], GeoCoordinate> var3);

    public Response<Double> geodist(byte[] var1, byte[] var2, byte[] var3);

    public Response<Double> geodist(byte[] var1, byte[] var2, byte[] var3, GeoUnit var4);

    public Response<List<byte[]>> geohash(byte[] var1, byte[] ... var2);

    public Response<List<GeoCoordinate>> geopos(byte[] var1, byte[] ... var2);

    public Response<List<GeoRadiusResponse>> georadius(byte[] var1, double var2, double var4, double var6, GeoUnit var8);

    public Response<List<GeoRadiusResponse>> georadiusReadonly(byte[] var1, double var2, double var4, double var6, GeoUnit var8);

    public Response<List<GeoRadiusResponse>> georadius(byte[] var1, double var2, double var4, double var6, GeoUnit var8, GeoRadiusParam var9);

    public Response<List<GeoRadiusResponse>> georadiusReadonly(byte[] var1, double var2, double var4, double var6, GeoUnit var8, GeoRadiusParam var9);

    public Response<List<GeoRadiusResponse>> georadiusByMember(byte[] var1, byte[] var2, double var3, GeoUnit var5);

    public Response<List<GeoRadiusResponse>> georadiusByMemberReadonly(byte[] var1, byte[] var2, double var3, GeoUnit var5);

    public Response<List<GeoRadiusResponse>> georadiusByMember(byte[] var1, byte[] var2, double var3, GeoUnit var5, GeoRadiusParam var6);

    public Response<List<GeoRadiusResponse>> georadiusByMemberReadonly(byte[] var1, byte[] var2, double var3, GeoUnit var5, GeoRadiusParam var6);

    public Response<Long> georadiusStore(byte[] var1, double var2, double var4, double var6, GeoUnit var8, GeoRadiusParam var9, GeoRadiusStoreParam var10);

    public Response<Long> georadiusByMemberStore(byte[] var1, byte[] var2, double var3, GeoUnit var5, GeoRadiusParam var6, GeoRadiusStoreParam var7);

    public Response<List<GeoRadiusResponse>> geosearch(byte[] var1, byte[] var2, double var3, GeoUnit var5);

    public Response<List<GeoRadiusResponse>> geosearch(byte[] var1, GeoCoordinate var2, double var3, GeoUnit var5);

    public Response<List<GeoRadiusResponse>> geosearch(byte[] var1, byte[] var2, double var3, double var5, GeoUnit var7);

    public Response<List<GeoRadiusResponse>> geosearch(byte[] var1, GeoCoordinate var2, double var3, double var5, GeoUnit var7);

    public Response<List<GeoRadiusResponse>> geosearch(byte[] var1, GeoSearchParam var2);

    public Response<Long> geosearchStore(byte[] var1, byte[] var2, byte[] var3, double var4, GeoUnit var6);

    public Response<Long> geosearchStore(byte[] var1, byte[] var2, GeoCoordinate var3, double var4, GeoUnit var6);

    public Response<Long> geosearchStore(byte[] var1, byte[] var2, byte[] var3, double var4, double var6, GeoUnit var8);

    public Response<Long> geosearchStore(byte[] var1, byte[] var2, GeoCoordinate var3, double var4, double var6, GeoUnit var8);

    public Response<Long> geosearchStore(byte[] var1, byte[] var2, GeoSearchParam var3);

    public Response<Long> geosearchStoreStoreDist(byte[] var1, byte[] var2, GeoSearchParam var3);
}

