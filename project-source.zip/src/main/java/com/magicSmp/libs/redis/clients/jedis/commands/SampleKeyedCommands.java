/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.args.FlushMode;
import com.bx.magicSmp.libs.redis.clients.jedis.util.KeyValue;
import java.util.List;

public interface SampleKeyedCommands {
    public long waitReplicas(String var1, int var2, long var3);

    public KeyValue<Long, Long> waitAOF(String var1, long var2, long var4, long var6);

    public Object eval(String var1, String var2);

    public Object evalsha(String var1, String var2);

    public Boolean scriptExists(String var1, String var2);

    public List<Boolean> scriptExists(String var1, String ... var2);

    public String scriptLoad(String var1, String var2);

    public String scriptFlush(String var1);

    public String scriptFlush(String var1, FlushMode var2);

    public String scriptKill(String var1);
}

