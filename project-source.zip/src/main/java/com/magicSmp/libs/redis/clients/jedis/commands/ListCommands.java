/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.args.ListDirection;
import com.bx.magicSmp.libs.redis.clients.jedis.args.ListPosition;
import com.bx.magicSmp.libs.redis.clients.jedis.params.LPosParams;
import com.bx.magicSmp.libs.redis.clients.jedis.util.KeyValue;
import java.util.List;

public interface ListCommands {
    public long rpush(String var1, String ... var2);

    public long lpush(String var1, String ... var2);

    public long llen(String var1);

    public List<String> lrange(String var1, long var2, long var4);

    public String ltrim(String var1, long var2, long var4);

    public String lindex(String var1, long var2);

    public String lset(String var1, long var2, String var4);

    public long lrem(String var1, long var2, String var4);

    public String lpop(String var1);

    public List<String> lpop(String var1, int var2);

    public Long lpos(String var1, String var2);

    public Long lpos(String var1, String var2, LPosParams var3);

    public List<Long> lpos(String var1, String var2, LPosParams var3, long var4);

    public String rpop(String var1);

    public List<String> rpop(String var1, int var2);

    public long linsert(String var1, ListPosition var2, String var3, String var4);

    public long lpushx(String var1, String ... var2);

    public long rpushx(String var1, String ... var2);

    public List<String> blpop(int var1, String ... var2);

    public List<String> blpop(int var1, String var2);

    public KeyValue<String, String> blpop(double var1, String ... var3);

    public KeyValue<String, String> blpop(double var1, String var3);

    public List<String> brpop(int var1, String ... var2);

    public List<String> brpop(int var1, String var2);

    public KeyValue<String, String> brpop(double var1, String ... var3);

    public KeyValue<String, String> brpop(double var1, String var3);

    @Deprecated
    public String rpoplpush(String var1, String var2);

    @Deprecated
    public String brpoplpush(String var1, String var2, int var3);

    public String lmove(String var1, String var2, ListDirection var3, ListDirection var4);

    public String blmove(String var1, String var2, ListDirection var3, ListDirection var4, double var5);

    public KeyValue<String, List<String>> lmpop(ListDirection var1, String ... var2);

    public KeyValue<String, List<String>> lmpop(ListDirection var1, int var2, String ... var3);

    public KeyValue<String, List<String>> blmpop(double var1, ListDirection var3, String ... var4);

    public KeyValue<String, List<String>> blmpop(double var1, ListDirection var3, int var4, String ... var5);
}

