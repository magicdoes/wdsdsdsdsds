/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.params.ScanParams;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.ScanResult;
import java.util.List;
import java.util.Set;

public interface SetBinaryCommands {
    public long sadd(byte[] var1, byte[] ... var2);

    public Set<byte[]> smembers(byte[] var1);

    public long srem(byte[] var1, byte[] ... var2);

    public byte[] spop(byte[] var1);

    public Set<byte[]> spop(byte[] var1, long var2);

    public long scard(byte[] var1);

    public boolean sismember(byte[] var1, byte[] var2);

    public List<Boolean> smismember(byte[] var1, byte[] ... var2);

    public byte[] srandmember(byte[] var1);

    public List<byte[]> srandmember(byte[] var1, int var2);

    default public ScanResult<byte[]> sscan(byte[] key, byte[] cursor) {
        return this.sscan(key, cursor, new ScanParams());
    }

    public ScanResult<byte[]> sscan(byte[] var1, byte[] var2, ScanParams var3);

    public Set<byte[]> sdiff(byte[] ... var1);

    public long sdiffstore(byte[] var1, byte[] ... var2);

    public Set<byte[]> sinter(byte[] ... var1);

    public long sinterstore(byte[] var1, byte[] ... var2);

    public long sintercard(byte[] ... var1);

    public long sintercard(int var1, byte[] ... var2);

    public Set<byte[]> sunion(byte[] ... var1);

    public long sunionstore(byte[] var1, byte[] ... var2);

    public long smove(byte[] var1, byte[] var2, byte[] var3);
}

