/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.args.ExpiryOption;
import com.bx.magicSmp.libs.redis.clients.jedis.params.HGetExParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.HSetExParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.ScanParams;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.ScanResult;
import java.util.List;
import java.util.Map;
import java.util.Set;

public interface HashBinaryCommands {
    public long hset(byte[] var1, byte[] var2, byte[] var3);

    public long hset(byte[] var1, Map<byte[], byte[]> var2);

    public long hsetex(byte[] var1, HSetExParams var2, byte[] var3, byte[] var4);

    public long hsetex(byte[] var1, HSetExParams var2, Map<byte[], byte[]> var3);

    public byte[] hget(byte[] var1, byte[] var2);

    public List<byte[]> hgetex(byte[] var1, HGetExParams var2, byte[] ... var3);

    public List<byte[]> hgetdel(byte[] var1, byte[] ... var2);

    public long hsetnx(byte[] var1, byte[] var2, byte[] var3);

    @Deprecated
    public String hmset(byte[] var1, Map<byte[], byte[]> var2);

    public List<byte[]> hmget(byte[] var1, byte[] ... var2);

    public long hincrBy(byte[] var1, byte[] var2, long var3);

    public double hincrByFloat(byte[] var1, byte[] var2, double var3);

    public boolean hexists(byte[] var1, byte[] var2);

    public long hdel(byte[] var1, byte[] ... var2);

    public long hlen(byte[] var1);

    public Set<byte[]> hkeys(byte[] var1);

    public List<byte[]> hvals(byte[] var1);

    public Map<byte[], byte[]> hgetAll(byte[] var1);

    public byte[] hrandfield(byte[] var1);

    public List<byte[]> hrandfield(byte[] var1, long var2);

    public List<Map.Entry<byte[], byte[]>> hrandfieldWithValues(byte[] var1, long var2);

    default public ScanResult<Map.Entry<byte[], byte[]>> hscan(byte[] key, byte[] cursor) {
        return this.hscan(key, cursor, new ScanParams());
    }

    public ScanResult<Map.Entry<byte[], byte[]>> hscan(byte[] var1, byte[] var2, ScanParams var3);

    default public ScanResult<byte[]> hscanNoValues(byte[] key, byte[] cursor) {
        return this.hscanNoValues(key, cursor, new ScanParams());
    }

    public ScanResult<byte[]> hscanNoValues(byte[] var1, byte[] var2, ScanParams var3);

    public long hstrlen(byte[] var1, byte[] var2);

    public List<Long> hexpire(byte[] var1, long var2, byte[] ... var4);

    public List<Long> hexpire(byte[] var1, long var2, ExpiryOption var4, byte[] ... var5);

    public List<Long> hpexpire(byte[] var1, long var2, byte[] ... var4);

    public List<Long> hpexpire(byte[] var1, long var2, ExpiryOption var4, byte[] ... var5);

    public List<Long> hexpireAt(byte[] var1, long var2, byte[] ... var4);

    public List<Long> hexpireAt(byte[] var1, long var2, ExpiryOption var4, byte[] ... var5);

    public List<Long> hpexpireAt(byte[] var1, long var2, byte[] ... var4);

    public List<Long> hpexpireAt(byte[] var1, long var2, ExpiryOption var4, byte[] ... var5);

    public List<Long> hexpireTime(byte[] var1, byte[] ... var2);

    public List<Long> hpexpireTime(byte[] var1, byte[] ... var2);

    public List<Long> httl(byte[] var1, byte[] ... var2);

    public List<Long> hpttl(byte[] var1, byte[] ... var2);

    public List<Long> hpersist(byte[] var1, byte[] ... var2);
}

