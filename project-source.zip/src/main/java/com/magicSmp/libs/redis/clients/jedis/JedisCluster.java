/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis;

import com.bx.magicSmp.libs.commons.pool2.impl.GenericObjectPoolConfig;
import com.bx.magicSmp.libs.redis.clients.jedis.AbstractTransaction;
import com.bx.magicSmp.libs.redis.clients.jedis.BinaryJedisShardedPubSub;
import com.bx.magicSmp.libs.redis.clients.jedis.ClusterCommandObjects;
import com.bx.magicSmp.libs.redis.clients.jedis.ClusterPipeline;
import com.bx.magicSmp.libs.redis.clients.jedis.CommandObject;
import com.bx.magicSmp.libs.redis.clients.jedis.CommandObjects;
import com.bx.magicSmp.libs.redis.clients.jedis.Connection;
import com.bx.magicSmp.libs.redis.clients.jedis.ConnectionPool;
import com.bx.magicSmp.libs.redis.clients.jedis.DefaultJedisClientConfig;
import com.bx.magicSmp.libs.redis.clients.jedis.HostAndPort;
import com.bx.magicSmp.libs.redis.clients.jedis.HostAndPortMapper;
import com.bx.magicSmp.libs.redis.clients.jedis.JedisClientConfig;
import com.bx.magicSmp.libs.redis.clients.jedis.JedisShardedPubSub;
import com.bx.magicSmp.libs.redis.clients.jedis.RedisProtocol;
import com.bx.magicSmp.libs.redis.clients.jedis.UnifiedJedis;
import com.bx.magicSmp.libs.redis.clients.jedis.annots.Experimental;
import com.bx.magicSmp.libs.redis.clients.jedis.builders.ClusterClientBuilder;
import com.bx.magicSmp.libs.redis.clients.jedis.csc.Cache;
import com.bx.magicSmp.libs.redis.clients.jedis.csc.CacheConfig;
import com.bx.magicSmp.libs.redis.clients.jedis.csc.CacheFactory;
import com.bx.magicSmp.libs.redis.clients.jedis.executors.ClusterCommandExecutor;
import com.bx.magicSmp.libs.redis.clients.jedis.executors.CommandExecutor;
import com.bx.magicSmp.libs.redis.clients.jedis.providers.ClusterConnectionProvider;
import com.bx.magicSmp.libs.redis.clients.jedis.providers.ConnectionProvider;
import com.bx.magicSmp.libs.redis.clients.jedis.util.JedisClusterCRC16;
import java.time.Duration;
import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;

@Deprecated
public class JedisCluster
extends UnifiedJedis {
    public static final String INIT_NO_ERROR_PROPERTY = "jedis.cluster.initNoError";
    public static final int DEFAULT_TIMEOUT = 2000;
    public static final int DEFAULT_MAX_ATTEMPTS = 5;

    public JedisCluster(HostAndPort node) {
        this(Collections.singleton(node));
    }

    public JedisCluster(HostAndPort node, int timeout) {
        this(Collections.singleton(node), timeout);
    }

    public JedisCluster(HostAndPort node, int timeout, int maxAttempts) {
        this(Collections.singleton(node), timeout, maxAttempts);
    }

    public JedisCluster(HostAndPort node, GenericObjectPoolConfig<Connection> poolConfig) {
        this(Collections.singleton(node), poolConfig);
    }

    public JedisCluster(HostAndPort node, int timeout, GenericObjectPoolConfig<Connection> poolConfig) {
        this(Collections.singleton(node), timeout, poolConfig);
    }

    public JedisCluster(HostAndPort node, int timeout, int maxAttempts, GenericObjectPoolConfig<Connection> poolConfig) {
        this(Collections.singleton(node), timeout, maxAttempts, poolConfig);
    }

    public JedisCluster(HostAndPort node, int connectionTimeout, int soTimeout, int maxAttempts, GenericObjectPoolConfig<Connection> poolConfig) {
        this(Collections.singleton(node), connectionTimeout, soTimeout, maxAttempts, poolConfig);
    }

    public JedisCluster(HostAndPort node, int connectionTimeout, int soTimeout, int maxAttempts, String password, GenericObjectPoolConfig<Connection> poolConfig) {
        this(Collections.singleton(node), connectionTimeout, soTimeout, maxAttempts, password, poolConfig);
    }

    public JedisCluster(HostAndPort node, int connectionTimeout, int soTimeout, int maxAttempts, String password, String clientName, GenericObjectPoolConfig<Connection> poolConfig) {
        this(Collections.singleton(node), connectionTimeout, soTimeout, maxAttempts, password, clientName, poolConfig);
    }

    public JedisCluster(HostAndPort node, int connectionTimeout, int soTimeout, int maxAttempts, String user, String password, String clientName, GenericObjectPoolConfig<Connection> poolConfig) {
        this(Collections.singleton(node), connectionTimeout, soTimeout, maxAttempts, user, password, clientName, poolConfig);
    }

    public JedisCluster(HostAndPort node, int connectionTimeout, int soTimeout, int maxAttempts, String password, String clientName, GenericObjectPoolConfig<Connection> poolConfig, boolean ssl) {
        this(Collections.singleton(node), connectionTimeout, soTimeout, maxAttempts, password, clientName, poolConfig, ssl);
    }

    public JedisCluster(HostAndPort node, int connectionTimeout, int soTimeout, int maxAttempts, String user, String password, String clientName, GenericObjectPoolConfig<Connection> poolConfig, boolean ssl) {
        this(Collections.singleton(node), connectionTimeout, soTimeout, maxAttempts, user, password, clientName, poolConfig, ssl);
    }

    public JedisCluster(HostAndPort node, JedisClientConfig clientConfig, int maxAttempts, GenericObjectPoolConfig<Connection> poolConfig) {
        this(Collections.singleton(node), clientConfig, maxAttempts, poolConfig);
    }

    public JedisCluster(Set<HostAndPort> nodes) {
        this(nodes, 2000);
    }

    public JedisCluster(Set<HostAndPort> nodes, int timeout) {
        this(nodes, (JedisClientConfig)DefaultJedisClientConfig.builder().timeoutMillis(timeout).build());
    }

    public JedisCluster(Set<HostAndPort> nodes, int timeout, int maxAttempts) {
        this(nodes, (JedisClientConfig)DefaultJedisClientConfig.builder().timeoutMillis(timeout).build(), maxAttempts);
    }

    public JedisCluster(Set<HostAndPort> nodes, String user, String password) {
        this(nodes, (JedisClientConfig)DefaultJedisClientConfig.builder().user(user).password(password).build());
    }

    public JedisCluster(Set<HostAndPort> nodes, String user, String password, HostAndPortMapper hostAndPortMap) {
        this(nodes, (JedisClientConfig)DefaultJedisClientConfig.builder().user(user).password(password).hostAndPortMapper(hostAndPortMap).build());
    }

    public JedisCluster(Set<HostAndPort> nodes, GenericObjectPoolConfig<Connection> poolConfig) {
        this(nodes, 2000, 5, poolConfig);
    }

    public JedisCluster(Set<HostAndPort> nodes, int timeout, GenericObjectPoolConfig<Connection> poolConfig) {
        this(nodes, timeout, 5, poolConfig);
    }

    public JedisCluster(Set<HostAndPort> clusterNodes, int timeout, int maxAttempts, GenericObjectPoolConfig<Connection> poolConfig) {
        this(clusterNodes, timeout, timeout, maxAttempts, poolConfig);
    }

    public JedisCluster(Set<HostAndPort> clusterNodes, int connectionTimeout, int soTimeout, int maxAttempts, GenericObjectPoolConfig<Connection> poolConfig) {
        this(clusterNodes, connectionTimeout, soTimeout, maxAttempts, null, poolConfig);
    }

    public JedisCluster(Set<HostAndPort> clusterNodes, int connectionTimeout, int soTimeout, int maxAttempts, String password, GenericObjectPoolConfig<Connection> poolConfig) {
        this(clusterNodes, connectionTimeout, soTimeout, maxAttempts, password, null, poolConfig);
    }

    public JedisCluster(Set<HostAndPort> clusterNodes, int connectionTimeout, int soTimeout, int maxAttempts, String password, String clientName, GenericObjectPoolConfig<Connection> poolConfig) {
        this(clusterNodes, connectionTimeout, soTimeout, maxAttempts, null, password, clientName, poolConfig);
    }

    public JedisCluster(Set<HostAndPort> clusterNodes, int connectionTimeout, int soTimeout, int maxAttempts, String user, String password, String clientName, GenericObjectPoolConfig<Connection> poolConfig) {
        this(clusterNodes, (JedisClientConfig)DefaultJedisClientConfig.builder().connectionTimeoutMillis(connectionTimeout).socketTimeoutMillis(soTimeout).user(user).password(password).clientName(clientName).build(), maxAttempts, poolConfig);
    }

    public JedisCluster(Set<HostAndPort> clusterNodes, int connectionTimeout, int soTimeout, int infiniteSoTimeout, int maxAttempts, String user, String password, String clientName, GenericObjectPoolConfig<Connection> poolConfig) {
        this(clusterNodes, (JedisClientConfig)DefaultJedisClientConfig.builder().connectionTimeoutMillis(connectionTimeout).socketTimeoutMillis(soTimeout).blockingSocketTimeoutMillis(infiniteSoTimeout).user(user).password(password).clientName(clientName).build(), maxAttempts, poolConfig);
    }

    public JedisCluster(Set<HostAndPort> clusterNodes, int connectionTimeout, int soTimeout, int maxAttempts, String password, String clientName, GenericObjectPoolConfig<Connection> poolConfig, boolean ssl) {
        this(clusterNodes, connectionTimeout, soTimeout, maxAttempts, null, password, clientName, poolConfig, ssl);
    }

    public JedisCluster(Set<HostAndPort> clusterNodes, int connectionTimeout, int soTimeout, int maxAttempts, String user, String password, String clientName, GenericObjectPoolConfig<Connection> poolConfig, boolean ssl) {
        this(clusterNodes, (JedisClientConfig)DefaultJedisClientConfig.builder().connectionTimeoutMillis(connectionTimeout).socketTimeoutMillis(soTimeout).user(user).password(password).clientName(clientName).ssl(ssl).build(), maxAttempts, poolConfig);
    }

    public JedisCluster(Set<HostAndPort> clusterNodes, JedisClientConfig clientConfig) {
        this(clusterNodes, clientConfig, 5);
    }

    public JedisCluster(Set<HostAndPort> clusterNodes, JedisClientConfig clientConfig, int maxAttempts) {
        this(clusterNodes, clientConfig, maxAttempts, Duration.ofMillis((long)clientConfig.getSocketTimeoutMillis() * (long)maxAttempts));
    }

    public JedisCluster(Set<HostAndPort> clusterNodes, JedisClientConfig clientConfig, int maxAttempts, Duration maxTotalRetriesDuration) {
        this(new ClusterConnectionProvider(clusterNodes, clientConfig), maxAttempts, maxTotalRetriesDuration, clientConfig.getRedisProtocol());
    }

    public JedisCluster(Set<HostAndPort> clusterNodes, JedisClientConfig clientConfig, GenericObjectPoolConfig<Connection> poolConfig) {
        this(clusterNodes, clientConfig, 5, poolConfig);
    }

    public JedisCluster(Set<HostAndPort> clusterNodes, JedisClientConfig clientConfig, int maxAttempts, GenericObjectPoolConfig<Connection> poolConfig) {
        this(clusterNodes, clientConfig, maxAttempts, Duration.ofMillis((long)clientConfig.getSocketTimeoutMillis() * (long)maxAttempts), poolConfig);
    }

    public JedisCluster(Set<HostAndPort> clusterNodes, JedisClientConfig clientConfig, int maxAttempts, Duration maxTotalRetriesDuration, GenericObjectPoolConfig<Connection> poolConfig) {
        this(new ClusterConnectionProvider(clusterNodes, clientConfig, poolConfig), maxAttempts, maxTotalRetriesDuration, clientConfig.getRedisProtocol());
    }

    public JedisCluster(Set<HostAndPort> clusterNodes, JedisClientConfig clientConfig, GenericObjectPoolConfig<Connection> poolConfig, Duration topologyRefreshPeriod, int maxAttempts, Duration maxTotalRetriesDuration) {
        this(new ClusterConnectionProvider(clusterNodes, clientConfig, poolConfig, topologyRefreshPeriod), maxAttempts, maxTotalRetriesDuration, clientConfig.getRedisProtocol());
    }

    public JedisCluster(ClusterConnectionProvider provider, int maxAttempts, Duration maxTotalRetriesDuration) {
        super(provider, maxAttempts, maxTotalRetriesDuration);
    }

    private JedisCluster(ClusterConnectionProvider provider, int maxAttempts, Duration maxTotalRetriesDuration, RedisProtocol protocol) {
        super(provider, maxAttempts, maxTotalRetriesDuration, protocol);
    }

    @Experimental
    public JedisCluster(Set<HostAndPort> hnp, JedisClientConfig jedisClientConfig, CacheConfig cacheConfig) {
        this(hnp, jedisClientConfig, CacheFactory.getCache(cacheConfig));
    }

    @Experimental
    public JedisCluster(Set<HostAndPort> clusterNodes, JedisClientConfig clientConfig, Cache clientSideCache) {
        this(clusterNodes, clientConfig, clientSideCache, 5, Duration.ofMillis(5 * clientConfig.getSocketTimeoutMillis()));
    }

    @Experimental
    public JedisCluster(Set<HostAndPort> clusterNodes, JedisClientConfig clientConfig, Cache clientSideCache, int maxAttempts, Duration maxTotalRetriesDuration) {
        this(new ClusterConnectionProvider(clusterNodes, clientConfig, clientSideCache), maxAttempts, maxTotalRetriesDuration, clientConfig.getRedisProtocol(), clientSideCache);
    }

    @Experimental
    public JedisCluster(Set<HostAndPort> clusterNodes, JedisClientConfig clientConfig, Cache clientSideCache, int maxAttempts, Duration maxTotalRetriesDuration, GenericObjectPoolConfig<Connection> poolConfig) {
        this(new ClusterConnectionProvider(clusterNodes, clientConfig, clientSideCache, poolConfig), maxAttempts, maxTotalRetriesDuration, clientConfig.getRedisProtocol(), clientSideCache);
    }

    @Experimental
    public JedisCluster(Set<HostAndPort> clusterNodes, JedisClientConfig clientConfig, Cache clientSideCache, GenericObjectPoolConfig<Connection> poolConfig) {
        this(new ClusterConnectionProvider(clusterNodes, clientConfig, clientSideCache, poolConfig), 5, Duration.ofMillis(5 * clientConfig.getSocketTimeoutMillis()), clientConfig.getRedisProtocol(), clientSideCache);
    }

    @Experimental
    public JedisCluster(Set<HostAndPort> clusterNodes, JedisClientConfig clientConfig, Cache clientSideCache, GenericObjectPoolConfig<Connection> poolConfig, Duration topologyRefreshPeriod, int maxAttempts, Duration maxTotalRetriesDuration) {
        this(new ClusterConnectionProvider(clusterNodes, clientConfig, clientSideCache, poolConfig, topologyRefreshPeriod), maxAttempts, maxTotalRetriesDuration, clientConfig.getRedisProtocol(), clientSideCache);
    }

    @Experimental
    private JedisCluster(ClusterConnectionProvider provider, int maxAttempts, Duration maxTotalRetriesDuration, RedisProtocol protocol, Cache clientSideCache) {
        super(provider, maxAttempts, maxTotalRetriesDuration, protocol, clientSideCache);
    }

    private JedisCluster(CommandExecutor commandExecutor, ConnectionProvider connectionProvider, CommandObjects commandObjects, RedisProtocol redisProtocol, Cache cache) {
        super(commandExecutor, connectionProvider, commandObjects, redisProtocol, cache);
    }

    public static Builder builder() {
        return new Builder();
    }

    public Map<String, ConnectionPool> getClusterNodes() {
        return ((ClusterConnectionProvider)this.provider).getNodes();
    }

    public Connection getConnectionFromSlot(int slot) {
        return ((ClusterConnectionProvider)this.provider).getConnectionFromSlot(slot);
    }

    public long spublish(String channel, String message) {
        return this.executeCommand(this.commandObjects.spublish(channel, message));
    }

    public long spublish(byte[] channel, byte[] message) {
        return this.executeCommand(this.commandObjects.spublish(channel, message));
    }

    public void ssubscribe(JedisShardedPubSub jedisPubSub, String ... channels) {
        try (Connection connection = this.getConnectionFromSlot(JedisClusterCRC16.getSlot(channels[0]));){
            jedisPubSub.proceed(connection, channels);
        }
    }

    public void ssubscribe(BinaryJedisShardedPubSub jedisPubSub, byte[] ... channels) {
        try (Connection connection = this.getConnectionFromSlot(JedisClusterCRC16.getSlot(channels[0]));){
            jedisPubSub.proceed(connection, (T[])channels);
        }
    }

    @Override
    public ClusterPipeline pipelined() {
        return this.pipelined(null);
    }

    public ClusterPipeline pipelined(ExecutorService executorService) {
        return new ClusterPipeline((ClusterConnectionProvider)this.provider, (ClusterCommandObjects)this.commandObjects, executorService);
    }

    @Override
    public AbstractTransaction transaction(boolean doMulti) {
        throw new UnsupportedOperationException();
    }

    public final <T> T executeCommandToReplica(CommandObject<T> commandObject) {
        if (!(this.executor instanceof ClusterCommandExecutor)) {
            throw new UnsupportedOperationException("Support only execute to replica in ClusterCommandExecutor");
        }
        return ((ClusterCommandExecutor)this.executor).executeCommandToReplica(commandObject);
    }

    public static class Builder
    extends ClusterClientBuilder<JedisCluster> {
        @Override
        protected JedisCluster createClient() {
            return new JedisCluster(this.commandExecutor, this.connectionProvider, this.commandObjects, this.clientConfig.getRedisProtocol(), this.cache);
        }
    }
}

