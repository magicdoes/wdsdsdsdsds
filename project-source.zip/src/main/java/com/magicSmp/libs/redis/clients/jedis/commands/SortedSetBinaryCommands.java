/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.args.SortedSetOption;
import com.bx.magicSmp.libs.redis.clients.jedis.params.ScanParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.ZAddParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.ZIncrByParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.ZParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.ZRangeParams;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.ScanResult;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.Tuple;
import com.bx.magicSmp.libs.redis.clients.jedis.util.KeyValue;
import java.util.List;
import java.util.Map;

public interface SortedSetBinaryCommands {
    public long zadd(byte[] var1, double var2, byte[] var4);

    public long zadd(byte[] var1, double var2, byte[] var4, ZAddParams var5);

    public long zadd(byte[] var1, Map<byte[], Double> var2);

    public long zadd(byte[] var1, Map<byte[], Double> var2, ZAddParams var3);

    public Double zaddIncr(byte[] var1, double var2, byte[] var4, ZAddParams var5);

    public long zrem(byte[] var1, byte[] ... var2);

    public double zincrby(byte[] var1, double var2, byte[] var4);

    public Double zincrby(byte[] var1, double var2, byte[] var4, ZIncrByParams var5);

    public Long zrank(byte[] var1, byte[] var2);

    public Long zrevrank(byte[] var1, byte[] var2);

    public KeyValue<Long, Double> zrankWithScore(byte[] var1, byte[] var2);

    public KeyValue<Long, Double> zrevrankWithScore(byte[] var1, byte[] var2);

    public List<byte[]> zrange(byte[] var1, long var2, long var4);

    @Deprecated
    public List<byte[]> zrevrange(byte[] var1, long var2, long var4);

    public List<Tuple> zrangeWithScores(byte[] var1, long var2, long var4);

    @Deprecated
    public List<Tuple> zrevrangeWithScores(byte[] var1, long var2, long var4);

    public List<byte[]> zrange(byte[] var1, ZRangeParams var2);

    public List<Tuple> zrangeWithScores(byte[] var1, ZRangeParams var2);

    public long zrangestore(byte[] var1, byte[] var2, ZRangeParams var3);

    public byte[] zrandmember(byte[] var1);

    public List<byte[]> zrandmember(byte[] var1, long var2);

    public List<Tuple> zrandmemberWithScores(byte[] var1, long var2);

    public long zcard(byte[] var1);

    public Double zscore(byte[] var1, byte[] var2);

    public List<Double> zmscore(byte[] var1, byte[] ... var2);

    public Tuple zpopmax(byte[] var1);

    public List<Tuple> zpopmax(byte[] var1, int var2);

    public Tuple zpopmin(byte[] var1);

    public List<Tuple> zpopmin(byte[] var1, int var2);

    public long zcount(byte[] var1, double var2, double var4);

    public long zcount(byte[] var1, byte[] var2, byte[] var3);

    @Deprecated
    public List<byte[]> zrangeByScore(byte[] var1, double var2, double var4);

    @Deprecated
    public List<byte[]> zrangeByScore(byte[] var1, byte[] var2, byte[] var3);

    @Deprecated
    public List<byte[]> zrevrangeByScore(byte[] var1, double var2, double var4);

    @Deprecated
    public List<byte[]> zrangeByScore(byte[] var1, double var2, double var4, int var6, int var7);

    @Deprecated
    public List<byte[]> zrevrangeByScore(byte[] var1, byte[] var2, byte[] var3);

    @Deprecated
    public List<byte[]> zrangeByScore(byte[] var1, byte[] var2, byte[] var3, int var4, int var5);

    @Deprecated
    public List<byte[]> zrevrangeByScore(byte[] var1, double var2, double var4, int var6, int var7);

    @Deprecated
    public List<Tuple> zrangeByScoreWithScores(byte[] var1, double var2, double var4);

    @Deprecated
    public List<Tuple> zrevrangeByScoreWithScores(byte[] var1, double var2, double var4);

    @Deprecated
    public List<Tuple> zrangeByScoreWithScores(byte[] var1, double var2, double var4, int var6, int var7);

    @Deprecated
    public List<byte[]> zrevrangeByScore(byte[] var1, byte[] var2, byte[] var3, int var4, int var5);

    @Deprecated
    public List<Tuple> zrangeByScoreWithScores(byte[] var1, byte[] var2, byte[] var3);

    @Deprecated
    public List<Tuple> zrevrangeByScoreWithScores(byte[] var1, byte[] var2, byte[] var3);

    @Deprecated
    public List<Tuple> zrangeByScoreWithScores(byte[] var1, byte[] var2, byte[] var3, int var4, int var5);

    @Deprecated
    public List<Tuple> zrevrangeByScoreWithScores(byte[] var1, double var2, double var4, int var6, int var7);

    @Deprecated
    public List<Tuple> zrevrangeByScoreWithScores(byte[] var1, byte[] var2, byte[] var3, int var4, int var5);

    public long zremrangeByRank(byte[] var1, long var2, long var4);

    public long zremrangeByScore(byte[] var1, double var2, double var4);

    public long zremrangeByScore(byte[] var1, byte[] var2, byte[] var3);

    public long zlexcount(byte[] var1, byte[] var2, byte[] var3);

    @Deprecated
    public List<byte[]> zrangeByLex(byte[] var1, byte[] var2, byte[] var3);

    @Deprecated
    public List<byte[]> zrangeByLex(byte[] var1, byte[] var2, byte[] var3, int var4, int var5);

    @Deprecated
    public List<byte[]> zrevrangeByLex(byte[] var1, byte[] var2, byte[] var3);

    @Deprecated
    public List<byte[]> zrevrangeByLex(byte[] var1, byte[] var2, byte[] var3, int var4, int var5);

    public long zremrangeByLex(byte[] var1, byte[] var2, byte[] var3);

    default public ScanResult<Tuple> zscan(byte[] key, byte[] cursor) {
        return this.zscan(key, cursor, new ScanParams());
    }

    public ScanResult<Tuple> zscan(byte[] var1, byte[] var2, ScanParams var3);

    public KeyValue<byte[], Tuple> bzpopmax(double var1, byte[] ... var3);

    public KeyValue<byte[], Tuple> bzpopmin(double var1, byte[] ... var3);

    public List<byte[]> zdiff(byte[] ... var1);

    public List<Tuple> zdiffWithScores(byte[] ... var1);

    @Deprecated
    public long zdiffStore(byte[] var1, byte[] ... var2);

    public long zdiffstore(byte[] var1, byte[] ... var2);

    public List<byte[]> zinter(ZParams var1, byte[] ... var2);

    public List<Tuple> zinterWithScores(ZParams var1, byte[] ... var2);

    public long zinterstore(byte[] var1, byte[] ... var2);

    public long zinterstore(byte[] var1, ZParams var2, byte[] ... var3);

    public long zintercard(byte[] ... var1);

    public long zintercard(long var1, byte[] ... var3);

    public List<byte[]> zunion(ZParams var1, byte[] ... var2);

    public List<Tuple> zunionWithScores(ZParams var1, byte[] ... var2);

    public long zunionstore(byte[] var1, byte[] ... var2);

    public long zunionstore(byte[] var1, ZParams var2, byte[] ... var3);

    public KeyValue<byte[], List<Tuple>> zmpop(SortedSetOption var1, byte[] ... var2);

    public KeyValue<byte[], List<Tuple>> zmpop(SortedSetOption var1, int var2, byte[] ... var3);

    public KeyValue<byte[], List<Tuple>> bzmpop(double var1, SortedSetOption var3, byte[] ... var4);

    public KeyValue<byte[], List<Tuple>> bzmpop(double var1, SortedSetOption var3, int var4, byte[] ... var5);
}

