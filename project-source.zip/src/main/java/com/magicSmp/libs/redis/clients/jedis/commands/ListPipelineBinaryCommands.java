/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.Response;
import com.bx.magicSmp.libs.redis.clients.jedis.args.ListDirection;
import com.bx.magicSmp.libs.redis.clients.jedis.args.ListPosition;
import com.bx.magicSmp.libs.redis.clients.jedis.params.LPosParams;
import com.bx.magicSmp.libs.redis.clients.jedis.util.KeyValue;
import java.util.List;

public interface ListPipelineBinaryCommands {
    public Response<Long> rpush(byte[] var1, byte[] ... var2);

    public Response<Long> lpush(byte[] var1, byte[] ... var2);

    public Response<Long> llen(byte[] var1);

    public Response<List<byte[]>> lrange(byte[] var1, long var2, long var4);

    public Response<String> ltrim(byte[] var1, long var2, long var4);

    public Response<byte[]> lindex(byte[] var1, long var2);

    public Response<String> lset(byte[] var1, long var2, byte[] var4);

    public Response<Long> lrem(byte[] var1, long var2, byte[] var4);

    public Response<byte[]> lpop(byte[] var1);

    public Response<List<byte[]>> lpop(byte[] var1, int var2);

    public Response<Long> lpos(byte[] var1, byte[] var2);

    public Response<Long> lpos(byte[] var1, byte[] var2, LPosParams var3);

    public Response<List<Long>> lpos(byte[] var1, byte[] var2, LPosParams var3, long var4);

    public Response<byte[]> rpop(byte[] var1);

    public Response<List<byte[]>> rpop(byte[] var1, int var2);

    public Response<Long> linsert(byte[] var1, ListPosition var2, byte[] var3, byte[] var4);

    public Response<Long> lpushx(byte[] var1, byte[] ... var2);

    public Response<Long> rpushx(byte[] var1, byte[] ... var2);

    public Response<List<byte[]>> blpop(int var1, byte[] ... var2);

    public Response<KeyValue<byte[], byte[]>> blpop(double var1, byte[] ... var3);

    public Response<List<byte[]>> brpop(int var1, byte[] ... var2);

    public Response<KeyValue<byte[], byte[]>> brpop(double var1, byte[] ... var3);

    public Response<byte[]> rpoplpush(byte[] var1, byte[] var2);

    public Response<byte[]> brpoplpush(byte[] var1, byte[] var2, int var3);

    public Response<byte[]> lmove(byte[] var1, byte[] var2, ListDirection var3, ListDirection var4);

    public Response<byte[]> blmove(byte[] var1, byte[] var2, ListDirection var3, ListDirection var4, double var5);

    public Response<KeyValue<byte[], List<byte[]>>> lmpop(ListDirection var1, byte[] ... var2);

    public Response<KeyValue<byte[], List<byte[]>>> lmpop(ListDirection var1, int var2, byte[] ... var3);

    public Response<KeyValue<byte[], List<byte[]>>> blmpop(double var1, ListDirection var3, byte[] ... var4);

    public Response<KeyValue<byte[], List<byte[]>>> blmpop(double var1, ListDirection var3, int var4, byte[] ... var5);
}

