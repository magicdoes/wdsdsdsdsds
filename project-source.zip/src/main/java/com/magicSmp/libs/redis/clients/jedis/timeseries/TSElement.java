/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.timeseries;

public class TSElement {
    private final long timestamp;
    private final double value;

    public TSElement(long timestamp, double value) {
        this.timestamp = timestamp;
        this.value = value;
    }

    public long getTimestamp() {
        return this.timestamp;
    }

    public double getValue() {
        return this.value;
    }

    public int hashCode() {
        return 31 * Long.hashCode(this.timestamp) + Long.hashCode(Double.doubleToLongBits(this.value));
    }

    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof TSElement)) {
            return false;
        }
        TSElement other = (TSElement)obj;
        return this.timestamp == other.timestamp && this.value == other.value;
    }

    public String toString() {
        return "(" + this.timestamp + ":" + this.value + ")";
    }
}

