/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.StreamEntryID;
import com.bx.magicSmp.libs.redis.clients.jedis.args.StreamDeletionPolicy;
import com.bx.magicSmp.libs.redis.clients.jedis.params.XAddParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.XAutoClaimParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.XCfgSetParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.XClaimParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.XPendingParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.XReadGroupParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.XReadParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.XTrimParams;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.StreamConsumerInfo;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.StreamConsumersInfo;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.StreamEntry;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.StreamEntryDeletionResult;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.StreamFullInfo;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.StreamGroupInfo;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.StreamInfo;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.StreamPendingEntry;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.StreamPendingSummary;
import java.util.List;
import java.util.Map;

public interface StreamCommands {
    public StreamEntryID xadd(String var1, StreamEntryID var2, Map<String, String> var3);

    default public StreamEntryID xadd(String key, Map<String, String> hash, XAddParams params) {
        return this.xadd(key, params, hash);
    }

    public StreamEntryID xadd(String var1, XAddParams var2, Map<String, String> var3);

    public long xlen(String var1);

    public List<StreamEntry> xrange(String var1, StreamEntryID var2, StreamEntryID var3);

    public List<StreamEntry> xrange(String var1, StreamEntryID var2, StreamEntryID var3, int var4);

    public List<StreamEntry> xrevrange(String var1, StreamEntryID var2, StreamEntryID var3);

    public List<StreamEntry> xrevrange(String var1, StreamEntryID var2, StreamEntryID var3, int var4);

    public List<StreamEntry> xrange(String var1, String var2, String var3);

    public List<StreamEntry> xrange(String var1, String var2, String var3, int var4);

    public List<StreamEntry> xrevrange(String var1, String var2, String var3);

    public List<StreamEntry> xrevrange(String var1, String var2, String var3, int var4);

    public long xack(String var1, String var2, StreamEntryID ... var3);

    public List<StreamEntryDeletionResult> xackdel(String var1, String var2, StreamEntryID ... var3);

    public List<StreamEntryDeletionResult> xackdel(String var1, String var2, StreamDeletionPolicy var3, StreamEntryID ... var4);

    public String xgroupCreate(String var1, String var2, StreamEntryID var3, boolean var4);

    public String xgroupSetID(String var1, String var2, StreamEntryID var3);

    public long xgroupDestroy(String var1, String var2);

    public boolean xgroupCreateConsumer(String var1, String var2, String var3);

    public long xgroupDelConsumer(String var1, String var2, String var3);

    public long xdel(String var1, StreamEntryID ... var2);

    public List<StreamEntryDeletionResult> xdelex(String var1, StreamEntryID ... var2);

    public List<StreamEntryDeletionResult> xdelex(String var1, StreamDeletionPolicy var2, StreamEntryID ... var3);

    public long xtrim(String var1, long var2, boolean var4);

    public long xtrim(String var1, XTrimParams var2);

    public StreamPendingSummary xpending(String var1, String var2);

    public List<StreamPendingEntry> xpending(String var1, String var2, XPendingParams var3);

    public List<StreamEntry> xclaim(String var1, String var2, String var3, long var4, XClaimParams var6, StreamEntryID ... var7);

    public List<StreamEntryID> xclaimJustId(String var1, String var2, String var3, long var4, XClaimParams var6, StreamEntryID ... var7);

    public Map.Entry<StreamEntryID, List<StreamEntry>> xautoclaim(String var1, String var2, String var3, long var4, StreamEntryID var6, XAutoClaimParams var7);

    public Map.Entry<StreamEntryID, List<StreamEntryID>> xautoclaimJustId(String var1, String var2, String var3, long var4, StreamEntryID var6, XAutoClaimParams var7);

    public StreamInfo xinfoStream(String var1);

    public StreamFullInfo xinfoStreamFull(String var1);

    public StreamFullInfo xinfoStreamFull(String var1, int var2);

    public List<StreamGroupInfo> xinfoGroups(String var1);

    @Deprecated
    public List<StreamConsumersInfo> xinfoConsumers(String var1, String var2);

    public List<StreamConsumerInfo> xinfoConsumers2(String var1, String var2);

    public List<Map.Entry<String, List<StreamEntry>>> xread(XReadParams var1, Map<String, StreamEntryID> var2);

    public Map<String, List<StreamEntry>> xreadAsMap(XReadParams var1, Map<String, StreamEntryID> var2);

    public List<Map.Entry<String, List<StreamEntry>>> xreadGroup(String var1, String var2, XReadGroupParams var3, Map<String, StreamEntryID> var4);

    public Map<String, List<StreamEntry>> xreadGroupAsMap(String var1, String var2, XReadGroupParams var3, Map<String, StreamEntryID> var4);

    public String xcfgset(String var1, XCfgSetParams var2);
}

