/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis;

import com.bx.magicSmp.libs.redis.clients.jedis.JedisShardedPubSubBase;

public abstract class BinaryJedisShardedPubSub
extends JedisShardedPubSubBase<byte[]> {
    @Override
    protected final byte[] encode(byte[] raw) {
        return raw;
    }
}

