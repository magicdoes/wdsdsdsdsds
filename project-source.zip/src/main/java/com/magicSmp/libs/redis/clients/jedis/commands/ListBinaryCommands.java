/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.args.ListDirection;
import com.bx.magicSmp.libs.redis.clients.jedis.args.ListPosition;
import com.bx.magicSmp.libs.redis.clients.jedis.params.LPosParams;
import com.bx.magicSmp.libs.redis.clients.jedis.util.KeyValue;
import java.util.List;

public interface ListBinaryCommands {
    public long rpush(byte[] var1, byte[] ... var2);

    public long lpush(byte[] var1, byte[] ... var2);

    public long llen(byte[] var1);

    public List<byte[]> lrange(byte[] var1, long var2, long var4);

    public String ltrim(byte[] var1, long var2, long var4);

    public byte[] lindex(byte[] var1, long var2);

    public String lset(byte[] var1, long var2, byte[] var4);

    public long lrem(byte[] var1, long var2, byte[] var4);

    public byte[] lpop(byte[] var1);

    public List<byte[]> lpop(byte[] var1, int var2);

    public Long lpos(byte[] var1, byte[] var2);

    public Long lpos(byte[] var1, byte[] var2, LPosParams var3);

    public List<Long> lpos(byte[] var1, byte[] var2, LPosParams var3, long var4);

    public byte[] rpop(byte[] var1);

    public List<byte[]> rpop(byte[] var1, int var2);

    public long linsert(byte[] var1, ListPosition var2, byte[] var3, byte[] var4);

    public long lpushx(byte[] var1, byte[] ... var2);

    public long rpushx(byte[] var1, byte[] ... var2);

    public List<byte[]> blpop(int var1, byte[] ... var2);

    public KeyValue<byte[], byte[]> blpop(double var1, byte[] ... var3);

    public List<byte[]> brpop(int var1, byte[] ... var2);

    public KeyValue<byte[], byte[]> brpop(double var1, byte[] ... var3);

    @Deprecated
    public byte[] rpoplpush(byte[] var1, byte[] var2);

    @Deprecated
    public byte[] brpoplpush(byte[] var1, byte[] var2, int var3);

    public byte[] lmove(byte[] var1, byte[] var2, ListDirection var3, ListDirection var4);

    public byte[] blmove(byte[] var1, byte[] var2, ListDirection var3, ListDirection var4, double var5);

    public KeyValue<byte[], List<byte[]>> lmpop(ListDirection var1, byte[] ... var2);

    public KeyValue<byte[], List<byte[]>> lmpop(ListDirection var1, int var2, byte[] ... var3);

    public KeyValue<byte[], List<byte[]>> blmpop(double var1, ListDirection var3, byte[] ... var4);

    public KeyValue<byte[], List<byte[]>> blmpop(double var1, ListDirection var3, int var4, byte[] ... var5);
}

