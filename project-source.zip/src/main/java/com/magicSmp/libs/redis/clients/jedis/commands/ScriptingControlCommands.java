/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.args.FlushMode;
import java.util.List;

public interface ScriptingControlCommands {
    public Boolean scriptExists(String var1);

    public List<Boolean> scriptExists(String ... var1);

    public Boolean scriptExists(byte[] var1);

    public List<Boolean> scriptExists(byte[] ... var1);

    public String scriptLoad(String var1);

    public byte[] scriptLoad(byte[] var1);

    public String scriptFlush();

    public String scriptFlush(FlushMode var1);

    public String scriptKill();
}

