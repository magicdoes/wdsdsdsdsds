/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.Response;
import com.bx.magicSmp.libs.redis.clients.jedis.annots.Experimental;
import com.bx.magicSmp.libs.redis.clients.jedis.params.VAddParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.VSimParams;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.RawVector;
import java.util.List;
import java.util.Map;

public interface VectorSetPipelineBinaryCommands {
    @Experimental
    public Response<Boolean> vadd(byte[] var1, float[] var2, byte[] var3);

    @Experimental
    public Response<Boolean> vadd(byte[] var1, float[] var2, byte[] var3, VAddParams var4);

    @Experimental
    public Response<Boolean> vaddFP32(byte[] var1, byte[] var2, byte[] var3);

    @Experimental
    public Response<Boolean> vaddFP32(byte[] var1, byte[] var2, byte[] var3, VAddParams var4);

    @Experimental
    public Response<Boolean> vadd(byte[] var1, float[] var2, byte[] var3, int var4, VAddParams var5);

    @Experimental
    public Response<Boolean> vaddFP32(byte[] var1, byte[] var2, byte[] var3, int var4, VAddParams var5);

    @Experimental
    public Response<List<byte[]>> vsim(byte[] var1, float[] var2);

    @Experimental
    public Response<List<byte[]>> vsim(byte[] var1, float[] var2, VSimParams var3);

    @Experimental
    public Response<Map<byte[], Double>> vsimWithScores(byte[] var1, float[] var2, VSimParams var3);

    @Experimental
    public Response<List<byte[]>> vsimByElement(byte[] var1, byte[] var2);

    @Experimental
    public Response<List<byte[]>> vsimByElement(byte[] var1, byte[] var2, VSimParams var3);

    @Experimental
    public Response<Map<byte[], Double>> vsimByElementWithScores(byte[] var1, byte[] var2, VSimParams var3);

    @Experimental
    public Response<Long> vdim(byte[] var1);

    @Experimental
    public Response<Long> vcard(byte[] var1);

    @Experimental
    public Response<List<Double>> vemb(byte[] var1, byte[] var2);

    @Experimental
    public Response<RawVector> vembRaw(byte[] var1, byte[] var2);

    @Experimental
    public Response<Boolean> vrem(byte[] var1, byte[] var2);

    @Experimental
    public Response<List<List<byte[]>>> vlinks(byte[] var1, byte[] var2);

    @Experimental
    public Response<List<Map<byte[], Double>>> vlinksWithScores(byte[] var1, byte[] var2);

    @Experimental
    public Response<byte[]> vrandmember(byte[] var1);

    @Experimental
    public Response<List<byte[]>> vrandmember(byte[] var1, int var2);

    @Experimental
    public Response<byte[]> vgetattr(byte[] var1, byte[] var2);

    @Experimental
    public Response<Boolean> vsetattr(byte[] var1, byte[] var2, byte[] var3);
}

