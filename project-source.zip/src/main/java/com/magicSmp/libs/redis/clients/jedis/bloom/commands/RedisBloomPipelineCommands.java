/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.bloom.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.bloom.commands.BloomFilterPipelineCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.bloom.commands.CountMinSketchPipelineCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.bloom.commands.CuckooFilterPipelineCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.bloom.commands.TDigestSketchPipelineCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.bloom.commands.TopKFilterPipelineCommands;

public interface RedisBloomPipelineCommands
extends BloomFilterPipelineCommands,
CuckooFilterPipelineCommands,
CountMinSketchPipelineCommands,
TopKFilterPipelineCommands,
TDigestSketchPipelineCommands {
}

