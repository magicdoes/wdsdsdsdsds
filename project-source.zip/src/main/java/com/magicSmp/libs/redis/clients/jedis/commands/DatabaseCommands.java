/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.args.FlushMode;
import com.bx.magicSmp.libs.redis.clients.jedis.params.MigrateParams;

public interface DatabaseCommands {
    public String select(int var1);

    public long dbSize();

    public String flushDB();

    public String flushDB(FlushMode var1);

    public String swapDB(int var1, int var2);

    public long move(String var1, int var2);

    public long move(byte[] var1, int var2);

    public boolean copy(String var1, String var2, int var3, boolean var4);

    public boolean copy(byte[] var1, byte[] var2, int var3, boolean var4);

    public String migrate(String var1, int var2, String var3, int var4, int var5);

    public String migrate(String var1, int var2, byte[] var3, int var4, int var5);

    public String migrate(String var1, int var2, int var3, int var4, MigrateParams var5, String ... var6);

    public String migrate(String var1, int var2, int var3, int var4, MigrateParams var5, byte[] ... var6);
}

