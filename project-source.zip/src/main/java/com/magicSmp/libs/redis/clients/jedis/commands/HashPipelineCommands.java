/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.Response;
import com.bx.magicSmp.libs.redis.clients.jedis.args.ExpiryOption;
import com.bx.magicSmp.libs.redis.clients.jedis.params.HGetExParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.HSetExParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.ScanParams;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.ScanResult;
import java.util.List;
import java.util.Map;
import java.util.Set;

public interface HashPipelineCommands {
    public Response<Long> hset(String var1, String var2, String var3);

    public Response<Long> hset(String var1, Map<String, String> var2);

    public Response<Long> hsetex(String var1, HSetExParams var2, String var3, String var4);

    public Response<Long> hsetex(String var1, HSetExParams var2, Map<String, String> var3);

    public Response<String> hget(String var1, String var2);

    public Response<List<String>> hgetex(String var1, HGetExParams var2, String ... var3);

    public Response<List<String>> hgetdel(String var1, String ... var2);

    public Response<Long> hsetnx(String var1, String var2, String var3);

    public Response<String> hmset(String var1, Map<String, String> var2);

    public Response<List<String>> hmget(String var1, String ... var2);

    public Response<Long> hincrBy(String var1, String var2, long var3);

    public Response<Double> hincrByFloat(String var1, String var2, double var3);

    public Response<Boolean> hexists(String var1, String var2);

    public Response<Long> hdel(String var1, String ... var2);

    public Response<Long> hlen(String var1);

    public Response<Set<String>> hkeys(String var1);

    public Response<List<String>> hvals(String var1);

    public Response<Map<String, String>> hgetAll(String var1);

    public Response<String> hrandfield(String var1);

    public Response<List<String>> hrandfield(String var1, long var2);

    public Response<List<Map.Entry<String, String>>> hrandfieldWithValues(String var1, long var2);

    default public Response<ScanResult<Map.Entry<String, String>>> hscan(String key, String cursor) {
        return this.hscan(key, cursor, new ScanParams());
    }

    public Response<ScanResult<Map.Entry<String, String>>> hscan(String var1, String var2, ScanParams var3);

    default public Response<ScanResult<String>> hscanNoValues(String key, String cursor) {
        return this.hscanNoValues(key, cursor, new ScanParams());
    }

    public Response<ScanResult<String>> hscanNoValues(String var1, String var2, ScanParams var3);

    public Response<Long> hstrlen(String var1, String var2);

    public Response<List<Long>> hexpire(String var1, long var2, String ... var4);

    public Response<List<Long>> hexpire(String var1, long var2, ExpiryOption var4, String ... var5);

    public Response<List<Long>> hpexpire(String var1, long var2, String ... var4);

    public Response<List<Long>> hpexpire(String var1, long var2, ExpiryOption var4, String ... var5);

    public Response<List<Long>> hexpireAt(String var1, long var2, String ... var4);

    public Response<List<Long>> hexpireAt(String var1, long var2, ExpiryOption var4, String ... var5);

    public Response<List<Long>> hpexpireAt(String var1, long var2, String ... var4);

    public Response<List<Long>> hpexpireAt(String var1, long var2, ExpiryOption var4, String ... var5);

    public Response<List<Long>> hexpireTime(String var1, String ... var2);

    public Response<List<Long>> hpexpireTime(String var1, String ... var2);

    public Response<List<Long>> httl(String var1, String ... var2);

    public Response<List<Long>> hpttl(String var1, String ... var2);

    public Response<List<Long>> hpersist(String var1, String ... var2);
}

