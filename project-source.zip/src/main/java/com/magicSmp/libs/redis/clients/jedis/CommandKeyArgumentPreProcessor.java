/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis;

import com.bx.magicSmp.libs.redis.clients.jedis.annots.Experimental;

@Experimental
public interface CommandKeyArgumentPreProcessor {
    public Object actualKey(Object var1);
}

