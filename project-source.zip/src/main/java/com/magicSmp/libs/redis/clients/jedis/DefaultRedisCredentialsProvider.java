/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis;

import com.bx.magicSmp.libs.redis.clients.jedis.RedisCredentials;
import com.bx.magicSmp.libs.redis.clients.jedis.RedisCredentialsProvider;

public final class DefaultRedisCredentialsProvider
implements RedisCredentialsProvider {
    private volatile RedisCredentials credentials;

    public DefaultRedisCredentialsProvider(RedisCredentials credentials) {
        this.credentials = credentials;
    }

    public void setCredentials(RedisCredentials credentials) {
        this.credentials = credentials;
    }

    @Override
    public RedisCredentials get() {
        return this.credentials;
    }
}

