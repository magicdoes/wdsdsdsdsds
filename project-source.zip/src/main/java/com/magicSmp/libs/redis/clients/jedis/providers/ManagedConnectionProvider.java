/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.providers;

import com.bx.magicSmp.libs.redis.clients.jedis.CommandArguments;
import com.bx.magicSmp.libs.redis.clients.jedis.Connection;
import com.bx.magicSmp.libs.redis.clients.jedis.providers.ConnectionProvider;

public class ManagedConnectionProvider
implements ConnectionProvider {
    private Connection connection;

    public final void setConnection(Connection connection) {
        this.connection = connection;
    }

    @Override
    public void close() {
    }

    @Override
    public final Connection getConnection() {
        return this.connection;
    }

    @Override
    public final Connection getConnection(CommandArguments args) {
        return this.connection;
    }
}

