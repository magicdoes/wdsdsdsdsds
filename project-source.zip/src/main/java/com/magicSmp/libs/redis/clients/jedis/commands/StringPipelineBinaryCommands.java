/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.Response;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.BitPipelineBinaryCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.params.GetExParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.LCSParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.MSetExParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.SetParams;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.LCSMatchResult;
import java.util.List;

public interface StringPipelineBinaryCommands
extends BitPipelineBinaryCommands {
    public Response<String> set(byte[] var1, byte[] var2);

    public Response<String> set(byte[] var1, byte[] var2, SetParams var3);

    public Response<byte[]> get(byte[] var1);

    public Response<byte[]> setGet(byte[] var1, byte[] var2);

    public Response<byte[]> setGet(byte[] var1, byte[] var2, SetParams var3);

    public Response<byte[]> getDel(byte[] var1);

    public Response<byte[]> getEx(byte[] var1, GetExParams var2);

    public Response<Long> setrange(byte[] var1, long var2, byte[] var4);

    public Response<byte[]> getrange(byte[] var1, long var2, long var4);

    @Deprecated
    public Response<byte[]> getSet(byte[] var1, byte[] var2);

    public Response<Long> setnx(byte[] var1, byte[] var2);

    public Response<String> setex(byte[] var1, long var2, byte[] var4);

    public Response<String> psetex(byte[] var1, long var2, byte[] var4);

    public Response<List<byte[]>> mget(byte[] ... var1);

    public Response<String> mset(byte[] ... var1);

    public Response<Long> msetnx(byte[] ... var1);

    public Response<Boolean> msetex(MSetExParams var1, byte[] ... var2);

    public Response<Long> incr(byte[] var1);

    public Response<Long> incrBy(byte[] var1, long var2);

    public Response<Double> incrByFloat(byte[] var1, double var2);

    public Response<Long> decr(byte[] var1);

    public Response<Long> decrBy(byte[] var1, long var2);

    public Response<Long> append(byte[] var1, byte[] var2);

    public Response<byte[]> substr(byte[] var1, int var2, int var3);

    public Response<Long> strlen(byte[] var1);

    public Response<LCSMatchResult> lcs(byte[] var1, byte[] var2, LCSParams var3);
}

