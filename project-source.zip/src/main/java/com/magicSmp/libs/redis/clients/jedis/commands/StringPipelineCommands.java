/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.Response;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.BitPipelineCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.params.GetExParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.LCSParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.MSetExParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.SetParams;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.LCSMatchResult;
import java.util.List;

public interface StringPipelineCommands
extends BitPipelineCommands {
    public Response<String> set(String var1, String var2);

    public Response<String> set(String var1, String var2, SetParams var3);

    public Response<String> get(String var1);

    public Response<String> setGet(String var1, String var2);

    public Response<String> setGet(String var1, String var2, SetParams var3);

    public Response<String> getDel(String var1);

    public Response<String> getEx(String var1, GetExParams var2);

    public Response<Long> setrange(String var1, long var2, String var4);

    public Response<String> getrange(String var1, long var2, long var4);

    @Deprecated
    public Response<String> getSet(String var1, String var2);

    public Response<Long> setnx(String var1, String var2);

    public Response<String> setex(String var1, long var2, String var4);

    public Response<String> psetex(String var1, long var2, String var4);

    public Response<List<String>> mget(String ... var1);

    public Response<String> mset(String ... var1);

    public Response<Long> msetnx(String ... var1);

    public Response<Boolean> msetex(MSetExParams var1, String ... var2);

    public Response<Long> incr(String var1);

    public Response<Long> incrBy(String var1, long var2);

    public Response<Double> incrByFloat(String var1, double var2);

    public Response<Long> decr(String var1);

    public Response<Long> decrBy(String var1, long var2);

    public Response<Long> append(String var1, String var2);

    public Response<String> substr(String var1, int var2, int var3);

    public Response<Long> strlen(String var1);

    public Response<LCSMatchResult> lcs(String var1, String var2, LCSParams var3);
}

