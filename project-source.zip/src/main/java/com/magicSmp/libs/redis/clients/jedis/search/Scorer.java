/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.search;

import com.bx.magicSmp.libs.redis.clients.jedis.CommandArguments;
import com.bx.magicSmp.libs.redis.clients.jedis.annots.Experimental;
import com.bx.magicSmp.libs.redis.clients.jedis.params.IParams;

@Experimental
public abstract class Scorer
implements IParams {
    private final String name;

    protected Scorer(String name) {
        this.name = name;
    }

    public final String getName() {
        return this.name;
    }

    @Override
    public final void addParams(CommandArguments args) {
        args.add(this.name);
    }

    public String toString() {
        return this.name;
    }
}

