/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis;

import com.bx.magicSmp.libs.redis.clients.jedis.HostAndPort;

@FunctionalInterface
public interface HostAndPortMapper {
    public HostAndPort getHostAndPort(HostAndPort var1);
}

