/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.annots.Experimental;
import com.bx.magicSmp.libs.redis.clients.jedis.args.ExpiryOption;
import com.bx.magicSmp.libs.redis.clients.jedis.params.MigrateParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.RestoreParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.ScanParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.SortingParams;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.ScanResult;
import com.bx.magicSmp.libs.redis.clients.jedis.util.CompareCondition;
import java.util.List;
import java.util.Set;

public interface KeyCommands {
    public boolean exists(String var1);

    public long exists(String ... var1);

    public long persist(String var1);

    public String type(String var1);

    public byte[] dump(String var1);

    public String restore(String var1, long var2, byte[] var4);

    public String restore(String var1, long var2, byte[] var4, RestoreParams var5);

    public long expire(String var1, long var2);

    public long expire(String var1, long var2, ExpiryOption var4);

    public long pexpire(String var1, long var2);

    public long pexpire(String var1, long var2, ExpiryOption var4);

    public long expireTime(String var1);

    public long pexpireTime(String var1);

    public long expireAt(String var1, long var2);

    public long expireAt(String var1, long var2, ExpiryOption var4);

    public long pexpireAt(String var1, long var2);

    public long pexpireAt(String var1, long var2, ExpiryOption var4);

    public long ttl(String var1);

    public long pttl(String var1);

    public long touch(String var1);

    public long touch(String ... var1);

    public List<String> sort(String var1);

    public long sort(String var1, String var2);

    public List<String> sort(String var1, SortingParams var2);

    public long sort(String var1, SortingParams var2, String var3);

    public List<String> sortReadonly(String var1, SortingParams var2);

    public long del(String var1);

    public long del(String ... var1);

    @Experimental
    public long delex(String var1, CompareCondition var2);

    @Experimental
    public String digestKey(String var1);

    public long unlink(String var1);

    public long unlink(String ... var1);

    public boolean copy(String var1, String var2, boolean var3);

    public String rename(String var1, String var2);

    public long renamenx(String var1, String var2);

    public Long memoryUsage(String var1);

    public Long memoryUsage(String var1, int var2);

    public Long objectRefcount(String var1);

    public String objectEncoding(String var1);

    public Long objectIdletime(String var1);

    public Long objectFreq(String var1);

    public String migrate(String var1, int var2, String var3, int var4);

    public String migrate(String var1, int var2, int var3, MigrateParams var4, String ... var5);

    public Set<String> keys(String var1);

    public ScanResult<String> scan(String var1);

    public ScanResult<String> scan(String var1, ScanParams var2);

    public ScanResult<String> scan(String var1, ScanParams var2, String var3);

    public String randomKey();
}

