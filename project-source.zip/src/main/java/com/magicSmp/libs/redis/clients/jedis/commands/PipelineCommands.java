/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.commands.FunctionPipelineCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.GeoPipelineCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.HashPipelineCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.HyperLogLogPipelineCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.KeyPipelineCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.ListPipelineCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.SampleKeyedPipelineCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.ScriptingKeyPipelineCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.SetPipelineCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.SortedSetPipelineCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.StreamPipelineCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.StringPipelineCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.VectorSetPipelineCommands;

public interface PipelineCommands
extends KeyPipelineCommands,
StringPipelineCommands,
ListPipelineCommands,
HashPipelineCommands,
SetPipelineCommands,
SortedSetPipelineCommands,
GeoPipelineCommands,
HyperLogLogPipelineCommands,
StreamPipelineCommands,
ScriptingKeyPipelineCommands,
SampleKeyedPipelineCommands,
FunctionPipelineCommands,
VectorSetPipelineCommands {
}

