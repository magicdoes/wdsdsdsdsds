/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.annots.Experimental;
import com.bx.magicSmp.libs.redis.clients.jedis.params.VAddParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.VSimParams;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.RawVector;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.VSimScoreAttribs;
import java.util.List;
import java.util.Map;

public interface VectorSetBinaryCommands {
    @Experimental
    public boolean vadd(byte[] var1, float[] var2, byte[] var3);

    @Experimental
    public boolean vadd(byte[] var1, float[] var2, byte[] var3, VAddParams var4);

    @Experimental
    public boolean vaddFP32(byte[] var1, byte[] var2, byte[] var3);

    @Experimental
    public boolean vaddFP32(byte[] var1, byte[] var2, byte[] var3, VAddParams var4);

    @Experimental
    public boolean vadd(byte[] var1, float[] var2, byte[] var3, int var4, VAddParams var5);

    @Experimental
    public boolean vaddFP32(byte[] var1, byte[] var2, byte[] var3, int var4, VAddParams var5);

    @Experimental
    public List<byte[]> vsim(byte[] var1, float[] var2);

    @Experimental
    public List<byte[]> vsim(byte[] var1, float[] var2, VSimParams var3);

    @Experimental
    public Map<byte[], Double> vsimWithScores(byte[] var1, float[] var2, VSimParams var3);

    @Experimental
    public Map<byte[], VSimScoreAttribs> vsimWithScoresAndAttribs(byte[] var1, float[] var2, VSimParams var3);

    @Experimental
    public List<byte[]> vsimByElement(byte[] var1, byte[] var2);

    @Experimental
    public List<byte[]> vsimByElement(byte[] var1, byte[] var2, VSimParams var3);

    @Experimental
    public Map<byte[], Double> vsimByElementWithScores(byte[] var1, byte[] var2, VSimParams var3);

    @Experimental
    public Map<byte[], VSimScoreAttribs> vsimByElementWithScoresAndAttribs(byte[] var1, byte[] var2, VSimParams var3);

    @Experimental
    public long vdim(byte[] var1);

    @Experimental
    public long vcard(byte[] var1);

    @Experimental
    public List<Double> vemb(byte[] var1, byte[] var2);

    public RawVector vembRaw(byte[] var1, byte[] var2);

    @Experimental
    public boolean vrem(byte[] var1, byte[] var2);

    @Experimental
    public List<List<byte[]>> vlinks(byte[] var1, byte[] var2);

    @Experimental
    public List<Map<byte[], Double>> vlinksWithScores(byte[] var1, byte[] var2);

    @Experimental
    public byte[] vrandmember(byte[] var1);

    @Experimental
    public List<byte[]> vrandmember(byte[] var1, int var2);

    @Experimental
    public byte[] vgetattr(byte[] var1, byte[] var2);

    @Experimental
    public boolean vsetattr(byte[] var1, byte[] var2, byte[] var3);
}

