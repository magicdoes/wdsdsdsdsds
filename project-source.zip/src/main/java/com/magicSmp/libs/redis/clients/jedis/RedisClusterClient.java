/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis;

import com.bx.magicSmp.libs.redis.clients.jedis.AbstractTransaction;
import com.bx.magicSmp.libs.redis.clients.jedis.BinaryJedisShardedPubSub;
import com.bx.magicSmp.libs.redis.clients.jedis.ClusterCommandObjects;
import com.bx.magicSmp.libs.redis.clients.jedis.ClusterPipeline;
import com.bx.magicSmp.libs.redis.clients.jedis.CommandObject;
import com.bx.magicSmp.libs.redis.clients.jedis.CommandObjects;
import com.bx.magicSmp.libs.redis.clients.jedis.Connection;
import com.bx.magicSmp.libs.redis.clients.jedis.ConnectionPool;
import com.bx.magicSmp.libs.redis.clients.jedis.DefaultJedisClientConfig;
import com.bx.magicSmp.libs.redis.clients.jedis.HostAndPort;
import com.bx.magicSmp.libs.redis.clients.jedis.JedisShardedPubSub;
import com.bx.magicSmp.libs.redis.clients.jedis.RedisProtocol;
import com.bx.magicSmp.libs.redis.clients.jedis.UnifiedJedis;
import com.bx.magicSmp.libs.redis.clients.jedis.builders.ClusterClientBuilder;
import com.bx.magicSmp.libs.redis.clients.jedis.csc.Cache;
import com.bx.magicSmp.libs.redis.clients.jedis.executors.ClusterCommandExecutor;
import com.bx.magicSmp.libs.redis.clients.jedis.executors.CommandExecutor;
import com.bx.magicSmp.libs.redis.clients.jedis.providers.ClusterConnectionProvider;
import com.bx.magicSmp.libs.redis.clients.jedis.providers.ConnectionProvider;
import com.bx.magicSmp.libs.redis.clients.jedis.util.JedisClusterCRC16;
import java.time.Duration;
import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;

public class RedisClusterClient
extends UnifiedJedis {
    public static final String INIT_NO_ERROR_PROPERTY = "jedis.cluster.initNoError";
    public static final int DEFAULT_TIMEOUT = 2000;
    public static final int DEFAULT_MAX_ATTEMPTS = 5;

    private RedisClusterClient(CommandExecutor commandExecutor, ConnectionProvider connectionProvider, CommandObjects commandObjects, RedisProtocol redisProtocol, Cache cache) {
        super(commandExecutor, connectionProvider, commandObjects, redisProtocol, cache);
    }

    public static RedisClusterClient create(HostAndPort node) {
        return (RedisClusterClient)((ClusterClientBuilder)RedisClusterClient.builder().nodes(Collections.singleton(node)).clientConfig(DefaultJedisClientConfig.builder().timeoutMillis(2000).build())).maxAttempts(5).maxTotalRetriesDuration(Duration.ofMillis(10000L)).build();
    }

    public static RedisClusterClient create(Set<HostAndPort> nodes) {
        return (RedisClusterClient)((ClusterClientBuilder)RedisClusterClient.builder().nodes(nodes).clientConfig(DefaultJedisClientConfig.builder().timeoutMillis(2000).build())).maxAttempts(5).maxTotalRetriesDuration(Duration.ofMillis(10000L)).build();
    }

    public static RedisClusterClient create(Set<HostAndPort> nodes, String user, String password) {
        return (RedisClusterClient)((ClusterClientBuilder)RedisClusterClient.builder().nodes(nodes).clientConfig(DefaultJedisClientConfig.builder().user(user).password(password).build())).maxAttempts(5).maxTotalRetriesDuration(Duration.ofMillis(10000L)).build();
    }

    public static Builder builder() {
        return new Builder();
    }

    public Map<String, ConnectionPool> getClusterNodes() {
        return ((ClusterConnectionProvider)this.provider).getNodes();
    }

    public Connection getConnectionFromSlot(int slot) {
        return ((ClusterConnectionProvider)this.provider).getConnectionFromSlot(slot);
    }

    public long spublish(String channel, String message) {
        return this.executeCommand(this.commandObjects.spublish(channel, message));
    }

    public long spublish(byte[] channel, byte[] message) {
        return this.executeCommand(this.commandObjects.spublish(channel, message));
    }

    public void ssubscribe(JedisShardedPubSub jedisPubSub, String ... channels) {
        try (Connection connection = this.getConnectionFromSlot(JedisClusterCRC16.getSlot(channels[0]));){
            jedisPubSub.proceed(connection, channels);
        }
    }

    public void ssubscribe(BinaryJedisShardedPubSub jedisPubSub, byte[] ... channels) {
        try (Connection connection = this.getConnectionFromSlot(JedisClusterCRC16.getSlot(channels[0]));){
            jedisPubSub.proceed(connection, (T[])channels);
        }
    }

    @Override
    public ClusterPipeline pipelined() {
        return this.pipelined(null);
    }

    public ClusterPipeline pipelined(ExecutorService executorService) {
        return new ClusterPipeline((ClusterConnectionProvider)this.provider, (ClusterCommandObjects)this.commandObjects, executorService);
    }

    @Override
    public AbstractTransaction transaction(boolean doMulti) {
        throw new UnsupportedOperationException();
    }

    public final <T> T executeCommandToReplica(CommandObject<T> commandObject) {
        if (!(this.executor instanceof ClusterCommandExecutor)) {
            throw new UnsupportedOperationException("Support only execute to replica in ClusterCommandExecutor");
        }
        return ((ClusterCommandExecutor)this.executor).executeCommandToReplica(commandObject);
    }

    public static class Builder
    extends ClusterClientBuilder<RedisClusterClient> {
        @Override
        protected RedisClusterClient createClient() {
            return new RedisClusterClient(this.commandExecutor, this.connectionProvider, this.commandObjects, this.clientConfig.getRedisProtocol(), this.cache);
        }
    }
}

