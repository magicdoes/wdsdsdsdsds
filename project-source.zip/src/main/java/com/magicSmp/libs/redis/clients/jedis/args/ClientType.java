/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.args;

import com.bx.magicSmp.libs.redis.clients.jedis.args.Rawable;
import com.bx.magicSmp.libs.redis.clients.jedis.util.SafeEncoder;

public enum ClientType implements Rawable
{
    NORMAL,
    MASTER,
    SLAVE,
    REPLICA,
    PUBSUB;

    private final byte[] raw = SafeEncoder.encode(this.name().toLowerCase());

    @Override
    public byte[] getRaw() {
        return this.raw;
    }
}

