/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.commands.FunctionPipelineBinaryCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.GeoPipelineBinaryCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.HashPipelineBinaryCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.HyperLogLogPipelineBinaryCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.KeyPipelineBinaryCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.ListPipelineBinaryCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.SampleBinaryKeyedPipelineCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.ScriptingKeyPipelineBinaryCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.SetPipelineBinaryCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.SortedSetPipelineBinaryCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.StreamPipelineBinaryCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.StringPipelineBinaryCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.VectorSetPipelineBinaryCommands;

public interface PipelineBinaryCommands
extends KeyPipelineBinaryCommands,
StringPipelineBinaryCommands,
ListPipelineBinaryCommands,
HashPipelineBinaryCommands,
SetPipelineBinaryCommands,
SortedSetPipelineBinaryCommands,
GeoPipelineBinaryCommands,
HyperLogLogPipelineBinaryCommands,
StreamPipelineBinaryCommands,
ScriptingKeyPipelineBinaryCommands,
SampleBinaryKeyedPipelineCommands,
FunctionPipelineBinaryCommands,
VectorSetPipelineBinaryCommands {
}

