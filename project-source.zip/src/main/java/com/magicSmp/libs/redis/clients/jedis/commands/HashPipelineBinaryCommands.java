/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.Response;
import com.bx.magicSmp.libs.redis.clients.jedis.args.ExpiryOption;
import com.bx.magicSmp.libs.redis.clients.jedis.params.HGetExParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.HSetExParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.ScanParams;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.ScanResult;
import java.util.List;
import java.util.Map;
import java.util.Set;

public interface HashPipelineBinaryCommands {
    public Response<Long> hset(byte[] var1, byte[] var2, byte[] var3);

    public Response<Long> hset(byte[] var1, Map<byte[], byte[]> var2);

    public Response<Long> hsetex(byte[] var1, HSetExParams var2, byte[] var3, byte[] var4);

    public Response<Long> hsetex(byte[] var1, HSetExParams var2, Map<byte[], byte[]> var3);

    public Response<byte[]> hget(byte[] var1, byte[] var2);

    public Response<List<byte[]>> hgetex(byte[] var1, HGetExParams var2, byte[] ... var3);

    public Response<List<byte[]>> hgetdel(byte[] var1, byte[] ... var2);

    public Response<Long> hsetnx(byte[] var1, byte[] var2, byte[] var3);

    public Response<String> hmset(byte[] var1, Map<byte[], byte[]> var2);

    public Response<List<byte[]>> hmget(byte[] var1, byte[] ... var2);

    public Response<Long> hincrBy(byte[] var1, byte[] var2, long var3);

    public Response<Double> hincrByFloat(byte[] var1, byte[] var2, double var3);

    public Response<Boolean> hexists(byte[] var1, byte[] var2);

    public Response<Long> hdel(byte[] var1, byte[] ... var2);

    public Response<Long> hlen(byte[] var1);

    public Response<Set<byte[]>> hkeys(byte[] var1);

    public Response<List<byte[]>> hvals(byte[] var1);

    public Response<Map<byte[], byte[]>> hgetAll(byte[] var1);

    public Response<byte[]> hrandfield(byte[] var1);

    public Response<List<byte[]>> hrandfield(byte[] var1, long var2);

    public Response<List<Map.Entry<byte[], byte[]>>> hrandfieldWithValues(byte[] var1, long var2);

    default public Response<ScanResult<Map.Entry<byte[], byte[]>>> hscan(byte[] key, byte[] cursor) {
        return this.hscan(key, cursor, new ScanParams());
    }

    public Response<ScanResult<Map.Entry<byte[], byte[]>>> hscan(byte[] var1, byte[] var2, ScanParams var3);

    default public Response<ScanResult<byte[]>> hscanNoValues(byte[] key, byte[] cursor) {
        return this.hscanNoValues(key, cursor, new ScanParams());
    }

    public Response<ScanResult<byte[]>> hscanNoValues(byte[] var1, byte[] var2, ScanParams var3);

    public Response<Long> hstrlen(byte[] var1, byte[] var2);

    public Response<List<Long>> hexpire(byte[] var1, long var2, byte[] ... var4);

    public Response<List<Long>> hexpire(byte[] var1, long var2, ExpiryOption var4, byte[] ... var5);

    public Response<List<Long>> hpexpire(byte[] var1, long var2, byte[] ... var4);

    public Response<List<Long>> hpexpire(byte[] var1, long var2, ExpiryOption var4, byte[] ... var5);

    public Response<List<Long>> hexpireAt(byte[] var1, long var2, byte[] ... var4);

    public Response<List<Long>> hexpireAt(byte[] var1, long var2, ExpiryOption var4, byte[] ... var5);

    public Response<List<Long>> hpexpireAt(byte[] var1, long var2, byte[] ... var4);

    public Response<List<Long>> hpexpireAt(byte[] var1, long var2, ExpiryOption var4, byte[] ... var5);

    public Response<List<Long>> hexpireTime(byte[] var1, byte[] ... var2);

    public Response<List<Long>> hpexpireTime(byte[] var1, byte[] ... var2);

    public Response<List<Long>> httl(byte[] var1, byte[] ... var2);

    public Response<List<Long>> hpttl(byte[] var1, byte[] ... var2);

    public Response<List<Long>> hpersist(byte[] var1, byte[] ... var2);
}

