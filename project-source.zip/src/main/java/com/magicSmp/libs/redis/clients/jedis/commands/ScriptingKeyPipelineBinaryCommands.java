/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.Response;
import java.util.List;

public interface ScriptingKeyPipelineBinaryCommands {
    public Response<Object> eval(byte[] var1);

    public Response<Object> eval(byte[] var1, int var2, byte[] ... var3);

    public Response<Object> eval(byte[] var1, List<byte[]> var2, List<byte[]> var3);

    public Response<Object> evalReadonly(byte[] var1, List<byte[]> var2, List<byte[]> var3);

    public Response<Object> evalsha(byte[] var1);

    public Response<Object> evalsha(byte[] var1, int var2, byte[] ... var3);

    public Response<Object> evalsha(byte[] var1, List<byte[]> var2, List<byte[]> var3);

    public Response<Object> evalshaReadonly(byte[] var1, List<byte[]> var2, List<byte[]> var3);
}

