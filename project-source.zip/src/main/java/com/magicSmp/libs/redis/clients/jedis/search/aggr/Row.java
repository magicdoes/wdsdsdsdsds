/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.search.aggr;

import com.bx.magicSmp.libs.redis.clients.jedis.util.DoublePrecision;
import java.util.Map;

public class Row {
    private final Map<String, Object> fields;

    public Row(Map<String, Object> fields) {
        this.fields = fields;
    }

    public boolean containsKey(String key) {
        return this.fields.containsKey(key);
    }

    public Object get(String key) {
        return this.fields.get(key);
    }

    public String getString(String key) {
        if (!this.containsKey(key)) {
            return "";
        }
        return (String)this.fields.get(key);
    }

    public long getLong(String key) {
        if (!this.containsKey(key)) {
            return 0L;
        }
        return Long.parseLong((String)this.fields.get(key));
    }

    public double getDouble(String key) {
        if (!this.containsKey(key)) {
            return 0.0;
        }
        return DoublePrecision.parseFloatingPointNumber((String)this.fields.get(key));
    }

    public String toString() {
        return String.valueOf(this.fields);
    }
}

