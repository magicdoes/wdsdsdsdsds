/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.commands.AccessControlLogBinaryCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.ClientBinaryCommands;
import java.util.List;

public interface ControlBinaryCommands
extends AccessControlLogBinaryCommands,
ClientBinaryCommands {
    public List<Object> roleBinary();

    public Long objectRefcount(byte[] var1);

    public byte[] objectEncoding(byte[] var1);

    public Long objectIdletime(byte[] var1);

    public List<byte[]> objectHelpBinary();

    public Long objectFreq(byte[] var1);

    public byte[] memoryDoctorBinary();

    public Long memoryUsage(byte[] var1);

    public Long memoryUsage(byte[] var1, int var2);
}

