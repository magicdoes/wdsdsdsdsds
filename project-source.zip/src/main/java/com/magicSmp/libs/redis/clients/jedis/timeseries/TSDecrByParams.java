/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.timeseries;

import com.bx.magicSmp.libs.redis.clients.jedis.timeseries.TSArithByParams;

public class TSDecrByParams
extends TSArithByParams<TSDecrByParams> {
    public static TSDecrByParams decrByParams() {
        return new TSDecrByParams();
    }
}

