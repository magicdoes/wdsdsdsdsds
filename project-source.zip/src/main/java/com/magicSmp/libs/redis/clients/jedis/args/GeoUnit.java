/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.args;

import com.bx.magicSmp.libs.redis.clients.jedis.args.Rawable;
import com.bx.magicSmp.libs.redis.clients.jedis.util.SafeEncoder;
import java.util.Locale;

public enum GeoUnit implements Rawable
{
    M,
    KM,
    MI,
    FT;

    private final byte[] raw = SafeEncoder.encode(this.name().toLowerCase(Locale.ENGLISH));

    @Override
    public byte[] getRaw() {
        return this.raw;
    }
}

