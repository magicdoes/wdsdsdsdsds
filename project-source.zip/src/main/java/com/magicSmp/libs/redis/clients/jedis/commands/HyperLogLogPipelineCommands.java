/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.Response;

public interface HyperLogLogPipelineCommands {
    public Response<Long> pfadd(String var1, String ... var2);

    public Response<String> pfmerge(String var1, String ... var2);

    public Response<Long> pfcount(String var1);

    public Response<Long> pfcount(String ... var1);
}

