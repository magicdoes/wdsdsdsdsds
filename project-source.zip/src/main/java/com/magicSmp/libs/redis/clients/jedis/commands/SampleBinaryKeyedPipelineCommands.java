/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.Response;
import com.bx.magicSmp.libs.redis.clients.jedis.args.FlushMode;
import com.bx.magicSmp.libs.redis.clients.jedis.util.KeyValue;
import java.util.List;

public interface SampleBinaryKeyedPipelineCommands {
    public Response<Long> waitReplicas(byte[] var1, int var2, long var3);

    public Response<KeyValue<Long, Long>> waitAOF(byte[] var1, long var2, long var4, long var6);

    public Response<Object> eval(byte[] var1, byte[] var2);

    public Response<Object> evalsha(byte[] var1, byte[] var2);

    public Response<List<Boolean>> scriptExists(byte[] var1, byte[] ... var2);

    public Response<byte[]> scriptLoad(byte[] var1, byte[] var2);

    public Response<String> scriptFlush(byte[] var1);

    public Response<String> scriptFlush(byte[] var1, FlushMode var2);

    public Response<String> scriptKill(byte[] var1);
}

