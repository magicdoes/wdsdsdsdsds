/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.util;

import com.bx.magicSmp.libs.redis.clients.jedis.util.MurmurHash;
import com.bx.magicSmp.libs.redis.clients.jedis.util.SafeEncoder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@Deprecated
public interface Hashing {
    public static final Hashing MURMUR_HASH = new MurmurHash();
    public static final ThreadLocal<MessageDigest> md5Holder = new ThreadLocal();
    public static final Hashing MD5 = new Hashing(){

        @Override
        public long hash(String key) {
            return this.hash(SafeEncoder.encode(key));
        }

        @Override
        public long hash(byte[] key) {
            try {
                if (md5Holder.get() == null) {
                    md5Holder.set(MessageDigest.getInstance("MD5"));
                }
            }
            catch (NoSuchAlgorithmException e) {
                throw new IllegalStateException("++++ no md5 algorithm found");
            }
            MessageDigest md5 = (MessageDigest)md5Holder.get();
            md5.reset();
            md5.update(key);
            byte[] bKey = md5.digest();
            return (long)(bKey[3] & 0xFF) << 24 | (long)(bKey[2] & 0xFF) << 16 | (long)(bKey[1] & 0xFF) << 8 | (long)(bKey[0] & 0xFF);
        }
    };

    public long hash(String var1);

    public long hash(byte[] var1);
}

