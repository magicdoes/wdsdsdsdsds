/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.bloom.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.bloom.TDigestMergeParams;
import java.util.List;
import java.util.Map;

public interface TDigestSketchCommands {
    public String tdigestCreate(String var1);

    public String tdigestCreate(String var1, int var2);

    public String tdigestReset(String var1);

    public String tdigestMerge(String var1, String ... var2);

    public String tdigestMerge(TDigestMergeParams var1, String var2, String ... var3);

    public Map<String, Object> tdigestInfo(String var1);

    public String tdigestAdd(String var1, double ... var2);

    public List<Double> tdigestCDF(String var1, double ... var2);

    public List<Double> tdigestQuantile(String var1, double ... var2);

    public double tdigestMin(String var1);

    public double tdigestMax(String var1);

    public double tdigestTrimmedMean(String var1, double var2, double var4);

    public List<Long> tdigestRank(String var1, double ... var2);

    public List<Long> tdigestRevRank(String var1, double ... var2);

    public List<Double> tdigestByRank(String var1, long ... var2);

    public List<Double> tdigestByRevRank(String var1, long ... var2);
}

