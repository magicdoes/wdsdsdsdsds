/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.args;

import com.bx.magicSmp.libs.redis.clients.jedis.args.Rawable;
import com.bx.magicSmp.libs.redis.clients.jedis.util.SafeEncoder;

public enum ClientAttributeOption implements Rawable
{
    LIB_NAME("LIB-NAME"),
    LIB_VER("LIB-VER");

    private final byte[] raw;

    private ClientAttributeOption(String str) {
        this.raw = SafeEncoder.encode(str);
    }

    @Override
    public byte[] getRaw() {
        return this.raw;
    }
}

