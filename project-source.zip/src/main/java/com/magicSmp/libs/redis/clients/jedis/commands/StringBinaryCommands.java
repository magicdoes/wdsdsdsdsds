/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.commands.BitBinaryCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.params.GetExParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.LCSParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.MSetExParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.SetParams;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.LCSMatchResult;
import java.util.List;

public interface StringBinaryCommands
extends BitBinaryCommands {
    public String set(byte[] var1, byte[] var2);

    public String set(byte[] var1, byte[] var2, SetParams var3);

    public byte[] get(byte[] var1);

    public byte[] setGet(byte[] var1, byte[] var2);

    public byte[] setGet(byte[] var1, byte[] var2, SetParams var3);

    public byte[] getDel(byte[] var1);

    public byte[] getEx(byte[] var1, GetExParams var2);

    public long setrange(byte[] var1, long var2, byte[] var4);

    public byte[] getrange(byte[] var1, long var2, long var4);

    @Deprecated
    public byte[] getSet(byte[] var1, byte[] var2);

    @Deprecated
    public long setnx(byte[] var1, byte[] var2);

    @Deprecated
    public String setex(byte[] var1, long var2, byte[] var4);

    @Deprecated
    public String psetex(byte[] var1, long var2, byte[] var4);

    public List<byte[]> mget(byte[] ... var1);

    public String mset(byte[] ... var1);

    public long msetnx(byte[] ... var1);

    public boolean msetex(MSetExParams var1, byte[] ... var2);

    public long incr(byte[] var1);

    public long incrBy(byte[] var1, long var2);

    public double incrByFloat(byte[] var1, double var2);

    public long decr(byte[] var1);

    public long decrBy(byte[] var1, long var2);

    public long append(byte[] var1, byte[] var2);

    @Deprecated
    public byte[] substr(byte[] var1, int var2, int var3);

    public long strlen(byte[] var1);

    public LCSMatchResult lcs(byte[] var1, byte[] var2, LCSParams var3);
}

