/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.resps.Slowlog;
import java.util.List;

public interface SlowlogCommands {
    public String slowlogReset();

    public long slowlogLen();

    public List<Slowlog> slowlogGet();

    public List<Object> slowlogGetBinary();

    public List<Slowlog> slowlogGet(long var1);

    public List<Object> slowlogGetBinary(long var1);
}

