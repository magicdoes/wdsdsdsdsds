/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.Response;
import com.bx.magicSmp.libs.redis.clients.jedis.args.SortedSetOption;
import com.bx.magicSmp.libs.redis.clients.jedis.params.ScanParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.ZAddParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.ZIncrByParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.ZParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.ZRangeParams;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.ScanResult;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.Tuple;
import com.bx.magicSmp.libs.redis.clients.jedis.util.KeyValue;
import java.util.List;
import java.util.Map;

public interface SortedSetPipelineCommands {
    public Response<Long> zadd(String var1, double var2, String var4);

    public Response<Long> zadd(String var1, double var2, String var4, ZAddParams var5);

    public Response<Long> zadd(String var1, Map<String, Double> var2);

    public Response<Long> zadd(String var1, Map<String, Double> var2, ZAddParams var3);

    public Response<Double> zaddIncr(String var1, double var2, String var4, ZAddParams var5);

    public Response<Long> zrem(String var1, String ... var2);

    public Response<Double> zincrby(String var1, double var2, String var4);

    public Response<Double> zincrby(String var1, double var2, String var4, ZIncrByParams var5);

    public Response<Long> zrank(String var1, String var2);

    public Response<Long> zrevrank(String var1, String var2);

    public Response<KeyValue<Long, Double>> zrankWithScore(String var1, String var2);

    public Response<KeyValue<Long, Double>> zrevrankWithScore(String var1, String var2);

    public Response<List<String>> zrange(String var1, long var2, long var4);

    public Response<List<String>> zrevrange(String var1, long var2, long var4);

    public Response<List<Tuple>> zrangeWithScores(String var1, long var2, long var4);

    public Response<List<Tuple>> zrevrangeWithScores(String var1, long var2, long var4);

    public Response<String> zrandmember(String var1);

    public Response<List<String>> zrandmember(String var1, long var2);

    public Response<List<Tuple>> zrandmemberWithScores(String var1, long var2);

    public Response<Long> zcard(String var1);

    public Response<Double> zscore(String var1, String var2);

    public Response<List<Double>> zmscore(String var1, String ... var2);

    public Response<Tuple> zpopmax(String var1);

    public Response<List<Tuple>> zpopmax(String var1, int var2);

    public Response<Tuple> zpopmin(String var1);

    public Response<List<Tuple>> zpopmin(String var1, int var2);

    public Response<Long> zcount(String var1, double var2, double var4);

    public Response<Long> zcount(String var1, String var2, String var3);

    public Response<List<String>> zrangeByScore(String var1, double var2, double var4);

    public Response<List<String>> zrangeByScore(String var1, String var2, String var3);

    public Response<List<String>> zrevrangeByScore(String var1, double var2, double var4);

    public Response<List<String>> zrangeByScore(String var1, double var2, double var4, int var6, int var7);

    public Response<List<String>> zrevrangeByScore(String var1, String var2, String var3);

    public Response<List<String>> zrangeByScore(String var1, String var2, String var3, int var4, int var5);

    public Response<List<String>> zrevrangeByScore(String var1, double var2, double var4, int var6, int var7);

    public Response<List<Tuple>> zrangeByScoreWithScores(String var1, double var2, double var4);

    public Response<List<Tuple>> zrevrangeByScoreWithScores(String var1, double var2, double var4);

    public Response<List<Tuple>> zrangeByScoreWithScores(String var1, double var2, double var4, int var6, int var7);

    public Response<List<String>> zrevrangeByScore(String var1, String var2, String var3, int var4, int var5);

    public Response<List<Tuple>> zrangeByScoreWithScores(String var1, String var2, String var3);

    public Response<List<Tuple>> zrevrangeByScoreWithScores(String var1, String var2, String var3);

    public Response<List<Tuple>> zrangeByScoreWithScores(String var1, String var2, String var3, int var4, int var5);

    public Response<List<Tuple>> zrevrangeByScoreWithScores(String var1, double var2, double var4, int var6, int var7);

    public Response<List<Tuple>> zrevrangeByScoreWithScores(String var1, String var2, String var3, int var4, int var5);

    public Response<List<String>> zrange(String var1, ZRangeParams var2);

    public Response<List<Tuple>> zrangeWithScores(String var1, ZRangeParams var2);

    public Response<Long> zrangestore(String var1, String var2, ZRangeParams var3);

    public Response<Long> zremrangeByRank(String var1, long var2, long var4);

    public Response<Long> zremrangeByScore(String var1, double var2, double var4);

    public Response<Long> zremrangeByScore(String var1, String var2, String var3);

    public Response<Long> zlexcount(String var1, String var2, String var3);

    public Response<List<String>> zrangeByLex(String var1, String var2, String var3);

    public Response<List<String>> zrangeByLex(String var1, String var2, String var3, int var4, int var5);

    public Response<List<String>> zrevrangeByLex(String var1, String var2, String var3);

    public Response<List<String>> zrevrangeByLex(String var1, String var2, String var3, int var4, int var5);

    public Response<Long> zremrangeByLex(String var1, String var2, String var3);

    default public Response<ScanResult<Tuple>> zscan(String key, String cursor) {
        return this.zscan(key, cursor, new ScanParams());
    }

    public Response<ScanResult<Tuple>> zscan(String var1, String var2, ScanParams var3);

    public Response<KeyValue<String, Tuple>> bzpopmax(double var1, String ... var3);

    public Response<KeyValue<String, Tuple>> bzpopmin(double var1, String ... var3);

    public Response<List<String>> zdiff(String ... var1);

    public Response<List<Tuple>> zdiffWithScores(String ... var1);

    @Deprecated
    public Response<Long> zdiffStore(String var1, String ... var2);

    public Response<Long> zdiffstore(String var1, String ... var2);

    public Response<Long> zinterstore(String var1, String ... var2);

    public Response<Long> zinterstore(String var1, ZParams var2, String ... var3);

    public Response<List<String>> zinter(ZParams var1, String ... var2);

    public Response<List<Tuple>> zinterWithScores(ZParams var1, String ... var2);

    public Response<Long> zintercard(String ... var1);

    public Response<Long> zintercard(long var1, String ... var3);

    public Response<List<String>> zunion(ZParams var1, String ... var2);

    public Response<List<Tuple>> zunionWithScores(ZParams var1, String ... var2);

    public Response<Long> zunionstore(String var1, String ... var2);

    public Response<Long> zunionstore(String var1, ZParams var2, String ... var3);

    public Response<KeyValue<String, List<Tuple>>> zmpop(SortedSetOption var1, String ... var2);

    public Response<KeyValue<String, List<Tuple>>> zmpop(SortedSetOption var1, int var2, String ... var3);

    public Response<KeyValue<String, List<Tuple>>> bzmpop(double var1, SortedSetOption var3, String ... var4);

    public Response<KeyValue<String, List<Tuple>>> bzmpop(double var1, SortedSetOption var3, int var4, String ... var5);
}

