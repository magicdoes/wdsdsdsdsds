/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.timeseries;

import com.bx.magicSmp.libs.redis.clients.jedis.CommandArguments;
import com.bx.magicSmp.libs.redis.clients.jedis.params.IParams;
import com.bx.magicSmp.libs.redis.clients.jedis.timeseries.TimeSeriesProtocol;

public class TSGetParams
implements IParams {
    private boolean latest;

    public static TSGetParams getParams() {
        return new TSGetParams();
    }

    public TSGetParams latest() {
        this.latest = true;
        return this;
    }

    @Override
    public void addParams(CommandArguments args) {
        if (this.latest) {
            args.add(TimeSeriesProtocol.TimeSeriesKeyword.LATEST);
        }
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        TSGetParams that = (TSGetParams)o;
        return this.latest == that.latest;
    }

    public int hashCode() {
        return Boolean.hashCode(this.latest);
    }
}

