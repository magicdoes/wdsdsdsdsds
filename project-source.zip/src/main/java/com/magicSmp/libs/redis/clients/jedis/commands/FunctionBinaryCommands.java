/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.args.FlushMode;
import com.bx.magicSmp.libs.redis.clients.jedis.args.FunctionRestorePolicy;
import java.util.List;

public interface FunctionBinaryCommands {
    public Object fcall(byte[] var1, List<byte[]> var2, List<byte[]> var3);

    public Object fcallReadonly(byte[] var1, List<byte[]> var2, List<byte[]> var3);

    public String functionDelete(byte[] var1);

    public byte[] functionDump();

    public String functionFlush();

    public String functionFlush(FlushMode var1);

    public String functionKill();

    public List<Object> functionListBinary();

    public List<Object> functionList(byte[] var1);

    public List<Object> functionListWithCodeBinary();

    public List<Object> functionListWithCode(byte[] var1);

    public String functionLoad(byte[] var1);

    public String functionLoadReplace(byte[] var1);

    public String functionRestore(byte[] var1);

    public String functionRestore(byte[] var1, FunctionRestorePolicy var2);

    public Object functionStatsBinary();
}

