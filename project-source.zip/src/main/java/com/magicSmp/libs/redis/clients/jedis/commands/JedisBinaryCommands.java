/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.commands.FunctionBinaryCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.GeoBinaryCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.HashBinaryCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.HyperLogLogBinaryCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.KeyBinaryCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.ListBinaryCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.ScriptingKeyBinaryCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.SetBinaryCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.SortedSetBinaryCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.StreamBinaryCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.StringBinaryCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.VectorSetBinaryCommands;

public interface JedisBinaryCommands
extends KeyBinaryCommands,
StringBinaryCommands,
ListBinaryCommands,
HashBinaryCommands,
SetBinaryCommands,
SortedSetBinaryCommands,
GeoBinaryCommands,
HyperLogLogBinaryCommands,
StreamBinaryCommands,
ScriptingKeyBinaryCommands,
FunctionBinaryCommands,
VectorSetBinaryCommands {
}

