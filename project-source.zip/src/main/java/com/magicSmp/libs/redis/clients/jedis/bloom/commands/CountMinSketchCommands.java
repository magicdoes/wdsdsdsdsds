/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.bloom.commands;

import java.util.Collections;
import java.util.List;
import java.util.Map;

public interface CountMinSketchCommands {
    public String cmsInitByDim(String var1, long var2, long var4);

    public String cmsInitByProb(String var1, double var2, double var4);

    default public long cmsIncrBy(String key, String item, long increment) {
        return this.cmsIncrBy(key, Collections.singletonMap(item, increment)).get(0);
    }

    public List<Long> cmsIncrBy(String var1, Map<String, Long> var2);

    public List<Long> cmsQuery(String var1, String ... var2);

    public String cmsMerge(String var1, String ... var2);

    public String cmsMerge(String var1, Map<String, Long> var2);

    public Map<String, Object> cmsInfo(String var1);
}

