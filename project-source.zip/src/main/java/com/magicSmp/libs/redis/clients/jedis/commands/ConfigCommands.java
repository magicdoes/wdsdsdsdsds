/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import java.util.Map;

public interface ConfigCommands {
    public Map<String, String> configGet(String var1);

    public Map<String, String> configGet(String ... var1);

    public Map<byte[], byte[]> configGet(byte[] var1);

    public Map<byte[], byte[]> configGet(byte[] ... var1);

    public String configSet(String var1, String var2);

    public String configSet(String ... var1);

    public String configSet(Map<String, String> var1);

    public String configSet(byte[] var1, byte[] var2);

    public String configSet(byte[] ... var1);

    public String configSetBinary(Map<byte[], byte[]> var1);

    public String configResetStat();

    public String configRewrite();
}

