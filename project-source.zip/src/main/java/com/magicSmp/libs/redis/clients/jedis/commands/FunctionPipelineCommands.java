/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.Response;
import com.bx.magicSmp.libs.redis.clients.jedis.args.FlushMode;
import com.bx.magicSmp.libs.redis.clients.jedis.args.FunctionRestorePolicy;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.FunctionStats;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.LibraryInfo;
import java.util.List;

public interface FunctionPipelineCommands {
    public Response<Object> fcall(String var1, List<String> var2, List<String> var3);

    public Response<Object> fcallReadonly(String var1, List<String> var2, List<String> var3);

    public Response<String> functionDelete(String var1);

    public Response<byte[]> functionDump();

    public Response<String> functionFlush();

    public Response<String> functionFlush(FlushMode var1);

    public Response<String> functionKill();

    public Response<List<LibraryInfo>> functionList();

    public Response<List<LibraryInfo>> functionList(String var1);

    public Response<List<LibraryInfo>> functionListWithCode();

    public Response<List<LibraryInfo>> functionListWithCode(String var1);

    public Response<String> functionLoad(String var1);

    public Response<String> functionLoadReplace(String var1);

    public Response<String> functionRestore(byte[] var1);

    public Response<String> functionRestore(byte[] var1, FunctionRestorePolicy var2);

    public Response<FunctionStats> functionStats();
}

