/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.args.SortedSetOption;
import com.bx.magicSmp.libs.redis.clients.jedis.params.ScanParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.ZAddParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.ZIncrByParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.ZParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.ZRangeParams;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.ScanResult;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.Tuple;
import com.bx.magicSmp.libs.redis.clients.jedis.util.KeyValue;
import java.util.List;
import java.util.Map;

public interface SortedSetCommands {
    public long zadd(String var1, double var2, String var4);

    public long zadd(String var1, double var2, String var4, ZAddParams var5);

    public long zadd(String var1, Map<String, Double> var2);

    public long zadd(String var1, Map<String, Double> var2, ZAddParams var3);

    public Double zaddIncr(String var1, double var2, String var4, ZAddParams var5);

    public long zrem(String var1, String ... var2);

    public double zincrby(String var1, double var2, String var4);

    public Double zincrby(String var1, double var2, String var4, ZIncrByParams var5);

    public Long zrank(String var1, String var2);

    public Long zrevrank(String var1, String var2);

    public KeyValue<Long, Double> zrankWithScore(String var1, String var2);

    public KeyValue<Long, Double> zrevrankWithScore(String var1, String var2);

    public List<String> zrange(String var1, long var2, long var4);

    @Deprecated
    public List<String> zrevrange(String var1, long var2, long var4);

    public List<Tuple> zrangeWithScores(String var1, long var2, long var4);

    @Deprecated
    public List<Tuple> zrevrangeWithScores(String var1, long var2, long var4);

    public List<String> zrange(String var1, ZRangeParams var2);

    public List<Tuple> zrangeWithScores(String var1, ZRangeParams var2);

    public long zrangestore(String var1, String var2, ZRangeParams var3);

    public String zrandmember(String var1);

    public List<String> zrandmember(String var1, long var2);

    public List<Tuple> zrandmemberWithScores(String var1, long var2);

    public long zcard(String var1);

    public Double zscore(String var1, String var2);

    public List<Double> zmscore(String var1, String ... var2);

    public Tuple zpopmax(String var1);

    public List<Tuple> zpopmax(String var1, int var2);

    public Tuple zpopmin(String var1);

    public List<Tuple> zpopmin(String var1, int var2);

    public long zcount(String var1, double var2, double var4);

    public long zcount(String var1, String var2, String var3);

    @Deprecated
    public List<String> zrangeByScore(String var1, double var2, double var4);

    @Deprecated
    public List<String> zrangeByScore(String var1, String var2, String var3);

    @Deprecated
    public List<String> zrevrangeByScore(String var1, double var2, double var4);

    @Deprecated
    public List<String> zrangeByScore(String var1, double var2, double var4, int var6, int var7);

    @Deprecated
    public List<String> zrevrangeByScore(String var1, String var2, String var3);

    @Deprecated
    public List<String> zrangeByScore(String var1, String var2, String var3, int var4, int var5);

    @Deprecated
    public List<String> zrevrangeByScore(String var1, double var2, double var4, int var6, int var7);

    @Deprecated
    public List<Tuple> zrangeByScoreWithScores(String var1, double var2, double var4);

    @Deprecated
    public List<Tuple> zrevrangeByScoreWithScores(String var1, double var2, double var4);

    @Deprecated
    public List<Tuple> zrangeByScoreWithScores(String var1, double var2, double var4, int var6, int var7);

    @Deprecated
    public List<String> zrevrangeByScore(String var1, String var2, String var3, int var4, int var5);

    @Deprecated
    public List<Tuple> zrangeByScoreWithScores(String var1, String var2, String var3);

    @Deprecated
    public List<Tuple> zrevrangeByScoreWithScores(String var1, String var2, String var3);

    @Deprecated
    public List<Tuple> zrangeByScoreWithScores(String var1, String var2, String var3, int var4, int var5);

    @Deprecated
    public List<Tuple> zrevrangeByScoreWithScores(String var1, double var2, double var4, int var6, int var7);

    @Deprecated
    public List<Tuple> zrevrangeByScoreWithScores(String var1, String var2, String var3, int var4, int var5);

    public long zremrangeByRank(String var1, long var2, long var4);

    public long zremrangeByScore(String var1, double var2, double var4);

    public long zremrangeByScore(String var1, String var2, String var3);

    public long zlexcount(String var1, String var2, String var3);

    @Deprecated
    public List<String> zrangeByLex(String var1, String var2, String var3);

    @Deprecated
    public List<String> zrangeByLex(String var1, String var2, String var3, int var4, int var5);

    @Deprecated
    public List<String> zrevrangeByLex(String var1, String var2, String var3);

    @Deprecated
    public List<String> zrevrangeByLex(String var1, String var2, String var3, int var4, int var5);

    public long zremrangeByLex(String var1, String var2, String var3);

    default public ScanResult<Tuple> zscan(String key, String cursor) {
        return this.zscan(key, cursor, new ScanParams());
    }

    public ScanResult<Tuple> zscan(String var1, String var2, ScanParams var3);

    public KeyValue<String, Tuple> bzpopmax(double var1, String ... var3);

    public KeyValue<String, Tuple> bzpopmin(double var1, String ... var3);

    public List<String> zdiff(String ... var1);

    public List<Tuple> zdiffWithScores(String ... var1);

    @Deprecated
    public long zdiffStore(String var1, String ... var2);

    public long zdiffstore(String var1, String ... var2);

    public List<String> zinter(ZParams var1, String ... var2);

    public List<Tuple> zinterWithScores(ZParams var1, String ... var2);

    public long zinterstore(String var1, String ... var2);

    public long zinterstore(String var1, ZParams var2, String ... var3);

    public long zintercard(String ... var1);

    public long zintercard(long var1, String ... var3);

    public List<String> zunion(ZParams var1, String ... var2);

    public List<Tuple> zunionWithScores(ZParams var1, String ... var2);

    public long zunionstore(String var1, String ... var2);

    public long zunionstore(String var1, ZParams var2, String ... var3);

    public KeyValue<String, List<Tuple>> zmpop(SortedSetOption var1, String ... var2);

    public KeyValue<String, List<Tuple>> zmpop(SortedSetOption var1, int var2, String ... var3);

    public KeyValue<String, List<Tuple>> bzmpop(double var1, SortedSetOption var3, String ... var4);

    public KeyValue<String, List<Tuple>> bzmpop(double var1, SortedSetOption var3, int var4, String ... var5);
}

