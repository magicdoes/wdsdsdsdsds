/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.args.BitCountOption;
import com.bx.magicSmp.libs.redis.clients.jedis.args.BitOP;
import com.bx.magicSmp.libs.redis.clients.jedis.params.BitPosParams;
import java.util.List;

public interface BitBinaryCommands {
    public boolean setbit(byte[] var1, long var2, boolean var4);

    public boolean getbit(byte[] var1, long var2);

    public long bitcount(byte[] var1);

    public long bitcount(byte[] var1, long var2, long var4);

    public long bitcount(byte[] var1, long var2, long var4, BitCountOption var6);

    public long bitpos(byte[] var1, boolean var2);

    public long bitpos(byte[] var1, boolean var2, BitPosParams var3);

    public List<Long> bitfield(byte[] var1, byte[] ... var2);

    public List<Long> bitfieldReadonly(byte[] var1, byte[] ... var2);

    public long bitop(BitOP var1, byte[] var2, byte[] ... var3);
}

