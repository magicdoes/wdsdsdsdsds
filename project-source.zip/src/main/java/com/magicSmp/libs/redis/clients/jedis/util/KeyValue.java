/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.util;

import java.util.AbstractMap;

public class KeyValue<K, V>
extends AbstractMap.SimpleImmutableEntry<K, V> {
    public KeyValue(K key, V value) {
        super(key, value);
    }

    public static <K, V> KeyValue<K, V> of(K key, V value) {
        return new KeyValue<K, V>(key, value);
    }
}

