/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.Response;
import com.bx.magicSmp.libs.redis.clients.jedis.annots.Experimental;
import com.bx.magicSmp.libs.redis.clients.jedis.params.VAddParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.VSimParams;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.RawVector;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.VectorInfo;
import java.util.List;
import java.util.Map;

public interface VectorSetPipelineCommands {
    @Experimental
    public Response<Boolean> vadd(String var1, float[] var2, String var3);

    @Experimental
    public Response<Boolean> vadd(String var1, float[] var2, String var3, VAddParams var4);

    @Experimental
    public Response<Boolean> vaddFP32(String var1, byte[] var2, String var3);

    @Experimental
    public Response<Boolean> vaddFP32(String var1, byte[] var2, String var3, VAddParams var4);

    @Experimental
    public Response<Boolean> vadd(String var1, float[] var2, String var3, int var4, VAddParams var5);

    @Experimental
    public Response<Boolean> vaddFP32(String var1, byte[] var2, String var3, int var4, VAddParams var5);

    @Experimental
    public Response<List<String>> vsim(String var1, float[] var2);

    @Experimental
    public Response<List<String>> vsim(String var1, float[] var2, VSimParams var3);

    @Experimental
    public Response<Map<String, Double>> vsimWithScores(String var1, float[] var2, VSimParams var3);

    @Experimental
    public Response<List<String>> vsimByElement(String var1, String var2);

    @Experimental
    public Response<List<String>> vsimByElement(String var1, String var2, VSimParams var3);

    @Experimental
    public Response<Map<String, Double>> vsimByElementWithScores(String var1, String var2, VSimParams var3);

    @Experimental
    public Response<Long> vdim(String var1);

    @Experimental
    public Response<Long> vcard(String var1);

    @Experimental
    public Response<List<Double>> vemb(String var1, String var2);

    @Experimental
    public Response<RawVector> vembRaw(String var1, String var2);

    @Experimental
    public Response<Boolean> vrem(String var1, String var2);

    @Experimental
    public Response<List<List<String>>> vlinks(String var1, String var2);

    @Experimental
    public Response<List<Map<String, Double>>> vlinksWithScores(String var1, String var2);

    @Experimental
    public Response<String> vrandmember(String var1);

    @Experimental
    public Response<List<String>> vrandmember(String var1, int var2);

    @Experimental
    public Response<String> vgetattr(String var1, String var2);

    @Experimental
    public Response<Boolean> vsetattr(String var1, String var2, String var3);

    @Experimental
    public Response<VectorInfo> vinfo(String var1);
}

