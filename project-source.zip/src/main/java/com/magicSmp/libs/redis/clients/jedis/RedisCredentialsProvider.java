/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis;

import com.bx.magicSmp.libs.redis.clients.jedis.RedisCredentials;
import java.util.function.Supplier;

public interface RedisCredentialsProvider
extends Supplier<RedisCredentials> {
    default public void prepare() {
    }

    default public void cleanUp() {
    }
}

