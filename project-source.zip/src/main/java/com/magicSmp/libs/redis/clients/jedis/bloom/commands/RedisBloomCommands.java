/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.bloom.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.bloom.commands.BloomFilterCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.bloom.commands.CountMinSketchCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.bloom.commands.CuckooFilterCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.bloom.commands.TDigestSketchCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.bloom.commands.TopKFilterCommands;

public interface RedisBloomCommands
extends BloomFilterCommands,
CuckooFilterCommands,
CountMinSketchCommands,
TopKFilterCommands,
TDigestSketchCommands {
}

