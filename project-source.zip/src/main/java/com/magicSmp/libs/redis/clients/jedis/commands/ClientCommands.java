/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.args.ClientAttributeOption;
import com.bx.magicSmp.libs.redis.clients.jedis.args.ClientPauseMode;
import com.bx.magicSmp.libs.redis.clients.jedis.args.ClientType;
import com.bx.magicSmp.libs.redis.clients.jedis.args.UnblockType;
import com.bx.magicSmp.libs.redis.clients.jedis.params.ClientKillParams;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.TrackingInfo;

public interface ClientCommands {
    public String clientKill(String var1);

    public String clientKill(String var1, int var2);

    public long clientKill(ClientKillParams var1);

    public String clientGetname();

    public String clientList();

    public String clientList(ClientType var1);

    public String clientList(long ... var1);

    public String clientInfo();

    public String clientSetInfo(ClientAttributeOption var1, String var2);

    public String clientSetname(String var1);

    public long clientId();

    public long clientUnblock(long var1);

    public long clientUnblock(long var1, UnblockType var3);

    public String clientPause(long var1);

    public String clientPause(long var1, ClientPauseMode var3);

    public String clientUnpause();

    public String clientNoEvictOn();

    public String clientNoEvictOff();

    public String clientNoTouchOn();

    public String clientNoTouchOff();

    public TrackingInfo clientTrackingInfo();
}

