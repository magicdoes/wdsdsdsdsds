/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.annots.Experimental;
import com.bx.magicSmp.libs.redis.clients.jedis.params.VAddParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.VSimParams;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.RawVector;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.VSimScoreAttribs;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.VectorInfo;
import java.util.List;
import java.util.Map;

public interface VectorSetCommands {
    @Experimental
    public boolean vadd(String var1, float[] var2, String var3);

    @Experimental
    public boolean vadd(String var1, float[] var2, String var3, VAddParams var4);

    @Experimental
    public boolean vaddFP32(String var1, byte[] var2, String var3);

    @Experimental
    public boolean vaddFP32(String var1, byte[] var2, String var3, VAddParams var4);

    @Experimental
    public boolean vadd(String var1, float[] var2, String var3, int var4, VAddParams var5);

    @Experimental
    public boolean vaddFP32(String var1, byte[] var2, String var3, int var4, VAddParams var5);

    @Experimental
    public List<String> vsim(String var1, float[] var2);

    @Experimental
    public List<String> vsim(String var1, float[] var2, VSimParams var3);

    @Experimental
    public Map<String, Double> vsimWithScores(String var1, float[] var2, VSimParams var3);

    @Experimental
    public Map<String, VSimScoreAttribs> vsimWithScoresAndAttribs(String var1, float[] var2, VSimParams var3);

    @Experimental
    public List<String> vsimByElement(String var1, String var2);

    @Experimental
    public List<String> vsimByElement(String var1, String var2, VSimParams var3);

    @Experimental
    public Map<String, Double> vsimByElementWithScores(String var1, String var2, VSimParams var3);

    @Experimental
    public Map<String, VSimScoreAttribs> vsimByElementWithScoresAndAttribs(String var1, String var2, VSimParams var3);

    @Experimental
    public long vdim(String var1);

    @Experimental
    public long vcard(String var1);

    @Experimental
    public List<Double> vemb(String var1, String var2);

    @Experimental
    public RawVector vembRaw(String var1, String var2);

    @Experimental
    public boolean vrem(String var1, String var2);

    @Experimental
    public List<List<String>> vlinks(String var1, String var2);

    @Experimental
    public List<Map<String, Double>> vlinksWithScores(String var1, String var2);

    @Experimental
    public String vrandmember(String var1);

    @Experimental
    public List<String> vrandmember(String var1, int var2);

    @Experimental
    public String vgetattr(String var1, String var2);

    @Experimental
    public boolean vsetattr(String var1, String var2, String var3);

    @Experimental
    public VectorInfo vinfo(String var1);
}

