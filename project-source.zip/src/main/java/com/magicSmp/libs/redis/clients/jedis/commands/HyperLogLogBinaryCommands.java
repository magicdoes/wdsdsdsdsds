/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

public interface HyperLogLogBinaryCommands {
    public long pfadd(byte[] var1, byte[] ... var2);

    public String pfmerge(byte[] var1, byte[] ... var2);

    public long pfcount(byte[] var1);

    public long pfcount(byte[] ... var1);
}

