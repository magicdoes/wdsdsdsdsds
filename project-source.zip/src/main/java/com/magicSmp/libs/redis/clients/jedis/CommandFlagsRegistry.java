/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis;

import com.bx.magicSmp.libs.redis.clients.jedis.CommandArguments;
import java.util.EnumSet;

public interface CommandFlagsRegistry {
    public EnumSet<CommandFlag> getFlags(CommandArguments var1);

    public static enum CommandFlag {
        READONLY,
        WRITE,
        DENYOOM,
        ADMIN,
        PUBSUB,
        NOSCRIPT,
        SORT_FOR_SCRIPT,
        LOADING,
        STALE,
        SKIP_MONITOR,
        SKIP_SLOWLOG,
        ASKING,
        FAST,
        MOVABLEKEYS,
        MODULE,
        BLOCKING,
        NO_AUTH,
        NO_ASYNC_LOADING,
        NO_MULTI,
        NO_MANDATORY_KEYS,
        ALLOW_BUSY;

    }
}

