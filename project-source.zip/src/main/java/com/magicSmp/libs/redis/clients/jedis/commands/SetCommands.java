/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.params.ScanParams;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.ScanResult;
import java.util.List;
import java.util.Set;

public interface SetCommands {
    public long sadd(String var1, String ... var2);

    public Set<String> smembers(String var1);

    public long srem(String var1, String ... var2);

    public String spop(String var1);

    public Set<String> spop(String var1, long var2);

    public long scard(String var1);

    public boolean sismember(String var1, String var2);

    public List<Boolean> smismember(String var1, String ... var2);

    public String srandmember(String var1);

    public List<String> srandmember(String var1, int var2);

    default public ScanResult<String> sscan(String key, String cursor) {
        return this.sscan(key, cursor, new ScanParams());
    }

    public ScanResult<String> sscan(String var1, String var2, ScanParams var3);

    public Set<String> sdiff(String ... var1);

    public long sdiffstore(String var1, String ... var2);

    public Set<String> sinter(String ... var1);

    public long sinterstore(String var1, String ... var2);

    public long sintercard(String ... var1);

    public long sintercard(int var1, String ... var2);

    public Set<String> sunion(String ... var1);

    public long sunionstore(String var1, String ... var2);

    public long smove(String var1, String var2, String var3);
}

