/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.Module;
import com.bx.magicSmp.libs.redis.clients.jedis.params.ModuleLoadExParams;
import java.util.List;

public interface ModuleCommands {
    public String moduleLoad(String var1);

    public String moduleLoad(String var1, String ... var2);

    public String moduleLoadEx(String var1, ModuleLoadExParams var2);

    public String moduleUnload(String var1);

    public List<Module> moduleList();
}

