/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.executors;

import com.bx.magicSmp.libs.redis.clients.jedis.CommandObject;
import com.bx.magicSmp.libs.redis.clients.jedis.Connection;
import com.bx.magicSmp.libs.redis.clients.jedis.executors.CommandExecutor;
import com.bx.magicSmp.libs.redis.clients.jedis.util.IOUtils;

public class SimpleCommandExecutor
implements CommandExecutor {
    protected final Connection connection;

    public SimpleCommandExecutor(Connection connection) {
        this.connection = connection;
    }

    @Override
    public void close() {
        IOUtils.closeQuietly(this.connection);
    }

    @Override
    public final <T> T executeCommand(CommandObject<T> commandObject) {
        return this.connection.executeCommand(commandObject);
    }
}

