/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.args.ClusterFailoverOption;
import com.bx.magicSmp.libs.redis.clients.jedis.args.ClusterResetType;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.ClusterShardInfo;
import java.util.List;
import java.util.Map;

public interface ClusterCommands {
    public String asking();

    public String readonly();

    public String readwrite();

    public String clusterNodes();

    public String clusterMeet(String var1, int var2);

    public String clusterAddSlots(int ... var1);

    public String clusterDelSlots(int ... var1);

    public String clusterInfo();

    public List<String> clusterGetKeysInSlot(int var1, int var2);

    public List<byte[]> clusterGetKeysInSlotBinary(int var1, int var2);

    public String clusterSetSlotNode(int var1, String var2);

    public String clusterSetSlotMigrating(int var1, String var2);

    public String clusterSetSlotImporting(int var1, String var2);

    public String clusterSetSlotStable(int var1);

    public String clusterForget(String var1);

    public String clusterFlushSlots();

    public long clusterKeySlot(String var1);

    public long clusterCountFailureReports(String var1);

    public long clusterCountKeysInSlot(int var1);

    public String clusterSaveConfig();

    public String clusterSetConfigEpoch(long var1);

    public String clusterBumpEpoch();

    public String clusterReplicate(String var1);

    @Deprecated
    public List<String> clusterSlaves(String var1);

    public List<String> clusterReplicas(String var1);

    public String clusterFailover();

    public String clusterFailover(ClusterFailoverOption var1);

    @Deprecated
    public List<Object> clusterSlots();

    public List<ClusterShardInfo> clusterShards();

    public String clusterReset();

    public String clusterReset(ClusterResetType var1);

    public String clusterMyId();

    public String clusterMyShardId();

    public List<Map<String, Object>> clusterLinks();

    public String clusterAddSlotsRange(int ... var1);

    public String clusterDelSlotsRange(int ... var1);
}

