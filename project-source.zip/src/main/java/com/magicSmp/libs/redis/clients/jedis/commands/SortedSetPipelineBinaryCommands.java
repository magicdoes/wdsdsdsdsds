/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.Response;
import com.bx.magicSmp.libs.redis.clients.jedis.args.SortedSetOption;
import com.bx.magicSmp.libs.redis.clients.jedis.params.ScanParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.ZAddParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.ZIncrByParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.ZParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.ZRangeParams;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.ScanResult;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.Tuple;
import com.bx.magicSmp.libs.redis.clients.jedis.util.KeyValue;
import java.util.List;
import java.util.Map;

public interface SortedSetPipelineBinaryCommands {
    public Response<Long> zadd(byte[] var1, double var2, byte[] var4);

    public Response<Long> zadd(byte[] var1, double var2, byte[] var4, ZAddParams var5);

    public Response<Long> zadd(byte[] var1, Map<byte[], Double> var2);

    public Response<Long> zadd(byte[] var1, Map<byte[], Double> var2, ZAddParams var3);

    public Response<Double> zaddIncr(byte[] var1, double var2, byte[] var4, ZAddParams var5);

    public Response<Long> zrem(byte[] var1, byte[] ... var2);

    public Response<Double> zincrby(byte[] var1, double var2, byte[] var4);

    public Response<Double> zincrby(byte[] var1, double var2, byte[] var4, ZIncrByParams var5);

    public Response<Long> zrank(byte[] var1, byte[] var2);

    public Response<Long> zrevrank(byte[] var1, byte[] var2);

    public Response<KeyValue<Long, Double>> zrankWithScore(byte[] var1, byte[] var2);

    public Response<KeyValue<Long, Double>> zrevrankWithScore(byte[] var1, byte[] var2);

    public Response<List<byte[]>> zrange(byte[] var1, long var2, long var4);

    public Response<List<byte[]>> zrevrange(byte[] var1, long var2, long var4);

    public Response<List<Tuple>> zrangeWithScores(byte[] var1, long var2, long var4);

    public Response<List<Tuple>> zrevrangeWithScores(byte[] var1, long var2, long var4);

    public Response<byte[]> zrandmember(byte[] var1);

    public Response<List<byte[]>> zrandmember(byte[] var1, long var2);

    public Response<List<Tuple>> zrandmemberWithScores(byte[] var1, long var2);

    public Response<Long> zcard(byte[] var1);

    public Response<Double> zscore(byte[] var1, byte[] var2);

    public Response<List<Double>> zmscore(byte[] var1, byte[] ... var2);

    public Response<Tuple> zpopmax(byte[] var1);

    public Response<List<Tuple>> zpopmax(byte[] var1, int var2);

    public Response<Tuple> zpopmin(byte[] var1);

    public Response<List<Tuple>> zpopmin(byte[] var1, int var2);

    public Response<Long> zcount(byte[] var1, double var2, double var4);

    public Response<Long> zcount(byte[] var1, byte[] var2, byte[] var3);

    public Response<List<byte[]>> zrangeByScore(byte[] var1, double var2, double var4);

    public Response<List<byte[]>> zrangeByScore(byte[] var1, byte[] var2, byte[] var3);

    public Response<List<byte[]>> zrevrangeByScore(byte[] var1, double var2, double var4);

    public Response<List<byte[]>> zrangeByScore(byte[] var1, double var2, double var4, int var6, int var7);

    public Response<List<byte[]>> zrevrangeByScore(byte[] var1, byte[] var2, byte[] var3);

    public Response<List<byte[]>> zrangeByScore(byte[] var1, byte[] var2, byte[] var3, int var4, int var5);

    public Response<List<byte[]>> zrevrangeByScore(byte[] var1, double var2, double var4, int var6, int var7);

    public Response<List<Tuple>> zrangeByScoreWithScores(byte[] var1, double var2, double var4);

    public Response<List<Tuple>> zrevrangeByScoreWithScores(byte[] var1, double var2, double var4);

    public Response<List<Tuple>> zrangeByScoreWithScores(byte[] var1, double var2, double var4, int var6, int var7);

    public Response<List<byte[]>> zrevrangeByScore(byte[] var1, byte[] var2, byte[] var3, int var4, int var5);

    public Response<List<Tuple>> zrangeByScoreWithScores(byte[] var1, byte[] var2, byte[] var3);

    public Response<List<Tuple>> zrevrangeByScoreWithScores(byte[] var1, byte[] var2, byte[] var3);

    public Response<List<Tuple>> zrangeByScoreWithScores(byte[] var1, byte[] var2, byte[] var3, int var4, int var5);

    public Response<List<Tuple>> zrevrangeByScoreWithScores(byte[] var1, double var2, double var4, int var6, int var7);

    public Response<List<Tuple>> zrevrangeByScoreWithScores(byte[] var1, byte[] var2, byte[] var3, int var4, int var5);

    public Response<Long> zremrangeByRank(byte[] var1, long var2, long var4);

    public Response<Long> zremrangeByScore(byte[] var1, double var2, double var4);

    public Response<Long> zremrangeByScore(byte[] var1, byte[] var2, byte[] var3);

    public Response<Long> zlexcount(byte[] var1, byte[] var2, byte[] var3);

    public Response<List<byte[]>> zrangeByLex(byte[] var1, byte[] var2, byte[] var3);

    public Response<List<byte[]>> zrangeByLex(byte[] var1, byte[] var2, byte[] var3, int var4, int var5);

    public Response<List<byte[]>> zrevrangeByLex(byte[] var1, byte[] var2, byte[] var3);

    public Response<List<byte[]>> zrevrangeByLex(byte[] var1, byte[] var2, byte[] var3, int var4, int var5);

    public Response<List<byte[]>> zrange(byte[] var1, ZRangeParams var2);

    public Response<List<Tuple>> zrangeWithScores(byte[] var1, ZRangeParams var2);

    public Response<Long> zrangestore(byte[] var1, byte[] var2, ZRangeParams var3);

    public Response<Long> zremrangeByLex(byte[] var1, byte[] var2, byte[] var3);

    default public Response<ScanResult<Tuple>> zscan(byte[] key, byte[] cursor) {
        return this.zscan(key, cursor, new ScanParams());
    }

    public Response<ScanResult<Tuple>> zscan(byte[] var1, byte[] var2, ScanParams var3);

    public Response<KeyValue<byte[], Tuple>> bzpopmax(double var1, byte[] ... var3);

    public Response<KeyValue<byte[], Tuple>> bzpopmin(double var1, byte[] ... var3);

    public Response<List<byte[]>> zdiff(byte[] ... var1);

    public Response<List<Tuple>> zdiffWithScores(byte[] ... var1);

    @Deprecated
    public Response<Long> zdiffStore(byte[] var1, byte[] ... var2);

    public Response<Long> zdiffstore(byte[] var1, byte[] ... var2);

    public Response<List<byte[]>> zinter(ZParams var1, byte[] ... var2);

    public Response<List<Tuple>> zinterWithScores(ZParams var1, byte[] ... var2);

    public Response<Long> zinterstore(byte[] var1, byte[] ... var2);

    public Response<Long> zinterstore(byte[] var1, ZParams var2, byte[] ... var3);

    public Response<Long> zintercard(byte[] ... var1);

    public Response<Long> zintercard(long var1, byte[] ... var3);

    public Response<List<byte[]>> zunion(ZParams var1, byte[] ... var2);

    public Response<List<Tuple>> zunionWithScores(ZParams var1, byte[] ... var2);

    public Response<Long> zunionstore(byte[] var1, byte[] ... var2);

    public Response<Long> zunionstore(byte[] var1, ZParams var2, byte[] ... var3);

    public Response<KeyValue<byte[], List<Tuple>>> zmpop(SortedSetOption var1, byte[] ... var2);

    public Response<KeyValue<byte[], List<Tuple>>> zmpop(SortedSetOption var1, int var2, byte[] ... var3);

    public Response<KeyValue<byte[], List<Tuple>>> bzmpop(double var1, SortedSetOption var3, byte[] ... var4);

    public Response<KeyValue<byte[], List<Tuple>>> bzmpop(double var1, SortedSetOption var3, int var4, byte[] ... var5);
}

