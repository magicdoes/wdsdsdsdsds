/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis;

public enum SslVerifyMode {
    INSECURE,
    CA,
    FULL;

}

