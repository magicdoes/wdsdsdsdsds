/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.bloom.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.bloom.BFInsertParams;
import com.bx.magicSmp.libs.redis.clients.jedis.bloom.BFReserveParams;
import java.util.List;
import java.util.Map;

public interface BloomFilterCommands {
    public String bfReserve(String var1, double var2, long var4);

    public String bfReserve(String var1, double var2, long var4, BFReserveParams var6);

    public boolean bfAdd(String var1, String var2);

    public List<Boolean> bfMAdd(String var1, String ... var2);

    public List<Boolean> bfInsert(String var1, String ... var2);

    public List<Boolean> bfInsert(String var1, BFInsertParams var2, String ... var3);

    public boolean bfExists(String var1, String var2);

    public List<Boolean> bfMExists(String var1, String ... var2);

    public Map.Entry<Long, byte[]> bfScanDump(String var1, long var2);

    public String bfLoadChunk(String var1, long var2, byte[] var4);

    public long bfCard(String var1);

    public Map<String, Object> bfInfo(String var1);
}

