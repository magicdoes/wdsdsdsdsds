/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.timeseries;

import com.bx.magicSmp.libs.redis.clients.jedis.args.Rawable;
import com.bx.magicSmp.libs.redis.clients.jedis.util.SafeEncoder;
import java.util.Locale;

public enum AggregationType implements Rawable
{
    AVG,
    SUM,
    MIN,
    MAX,
    RANGE,
    COUNT,
    FIRST,
    LAST,
    STD_P("STD.P"),
    STD_S("STD.S"),
    VAR_P("VAR.P"),
    VAR_S("VAR.S"),
    TWA,
    COUNTNAN,
    COUNTALL;

    private final byte[] raw;

    private AggregationType() {
        this.raw = SafeEncoder.encode(this.name());
    }

    private AggregationType(String alt) {
        this.raw = SafeEncoder.encode(alt);
    }

    @Override
    public byte[] getRaw() {
        return this.raw;
    }

    public static AggregationType safeValueOf(String str) {
        try {
            return AggregationType.valueOf(str.replace('.', '_').toUpperCase(Locale.ENGLISH));
        }
        catch (IllegalArgumentException iae) {
            return null;
        }
    }
}

