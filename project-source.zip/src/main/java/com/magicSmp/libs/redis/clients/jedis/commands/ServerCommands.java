/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.args.FlushMode;
import com.bx.magicSmp.libs.redis.clients.jedis.args.LatencyEvent;
import com.bx.magicSmp.libs.redis.clients.jedis.args.SaveMode;
import com.bx.magicSmp.libs.redis.clients.jedis.exceptions.JedisException;
import com.bx.magicSmp.libs.redis.clients.jedis.params.HotkeysParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.LolwutParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.ShutdownParams;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.HotkeysInfo;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.LatencyHistoryInfo;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.LatencyLatestInfo;
import com.bx.magicSmp.libs.redis.clients.jedis.util.KeyValue;
import java.util.List;
import java.util.Map;

public interface ServerCommands {
    public String ping();

    public String ping(String var1);

    public String echo(String var1);

    public byte[] echo(byte[] var1);

    public String flushDB();

    public String flushDB(FlushMode var1);

    public String flushAll();

    public String flushAll(FlushMode var1);

    public String auth(String var1);

    public String auth(String var1, String var2);

    public String save();

    public String bgsave();

    public String bgsaveSchedule();

    public String bgrewriteaof();

    public long lastsave();

    public void shutdown() throws JedisException;

    default public void shutdown(SaveMode saveMode) throws JedisException {
        this.shutdown(ShutdownParams.shutdownParams().saveMode(saveMode));
    }

    public void shutdown(ShutdownParams var1) throws JedisException;

    public String shutdownAbort();

    public String info();

    public String info(String var1);

    @Deprecated
    public String slaveof(String var1, int var2);

    @Deprecated
    public String slaveofNoOne();

    public String replicaof(String var1, int var2);

    public String replicaofNoOne();

    public long waitReplicas(int var1, long var2);

    public KeyValue<Long, Long> waitAOF(long var1, long var3, long var5);

    public String lolwut();

    public String lolwut(LolwutParams var1);

    public String reset();

    public String latencyDoctor();

    public Map<String, LatencyLatestInfo> latencyLatest();

    public List<LatencyHistoryInfo> latencyHistory(LatencyEvent var1);

    public long latencyReset(LatencyEvent ... var1);

    public String hotkeysStart(HotkeysParams var1);

    public String hotkeysStop();

    public String hotkeysReset();

    public HotkeysInfo hotkeysGet();
}

