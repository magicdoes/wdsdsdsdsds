/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.commands.FunctionCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.GeoCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.HashCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.HyperLogLogCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.KeyCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.ListCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.ScriptingKeyCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.SetCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.SortedSetCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.StreamCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.StringCommands;
import com.bx.magicSmp.libs.redis.clients.jedis.commands.VectorSetCommands;

public interface JedisCommands
extends KeyCommands,
StringCommands,
ListCommands,
HashCommands,
SetCommands,
SortedSetCommands,
GeoCommands,
HyperLogLogCommands,
StreamCommands,
ScriptingKeyCommands,
FunctionCommands,
VectorSetCommands {
}

