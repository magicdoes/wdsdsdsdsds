/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.bloom.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.bloom.CFInsertParams;
import com.bx.magicSmp.libs.redis.clients.jedis.bloom.CFReserveParams;
import java.util.List;
import java.util.Map;

public interface CuckooFilterCommands {
    public String cfReserve(String var1, long var2);

    public String cfReserve(String var1, long var2, CFReserveParams var4);

    public boolean cfAdd(String var1, String var2);

    public boolean cfAddNx(String var1, String var2);

    public List<Boolean> cfInsert(String var1, String ... var2);

    public List<Boolean> cfInsert(String var1, CFInsertParams var2, String ... var3);

    public List<Boolean> cfInsertNx(String var1, String ... var2);

    public List<Boolean> cfInsertNx(String var1, CFInsertParams var2, String ... var3);

    public boolean cfExists(String var1, String var2);

    public List<Boolean> cfMExists(String var1, String ... var2);

    public boolean cfDel(String var1, String var2);

    public long cfCount(String var1, String var2);

    public Map.Entry<Long, byte[]> cfScanDump(String var1, long var2);

    public String cfLoadChunk(String var1, long var2, byte[] var4);

    public Map<String, Object> cfInfo(String var1);
}

