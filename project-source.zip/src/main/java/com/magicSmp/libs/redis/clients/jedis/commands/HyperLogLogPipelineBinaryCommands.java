/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.Response;

public interface HyperLogLogPipelineBinaryCommands {
    public Response<Long> pfadd(byte[] var1, byte[] ... var2);

    public Response<String> pfmerge(byte[] var1, byte[] ... var2);

    public Response<Long> pfcount(byte[] var1);

    public Response<Long> pfcount(byte[] ... var1);
}

