/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import java.util.List;
import java.util.Map;

public interface SentinelCommands {
    public String sentinelMyId();

    public List<Map<String, String>> sentinelMasters();

    public Map<String, String> sentinelMaster(String var1);

    public List<Map<String, String>> sentinelSentinels(String var1);

    public List<String> sentinelGetMasterAddrByName(String var1);

    public Long sentinelReset(String var1);

    @Deprecated
    public List<Map<String, String>> sentinelSlaves(String var1);

    public List<Map<String, String>> sentinelReplicas(String var1);

    public String sentinelFailover(String var1);

    public String sentinelMonitor(String var1, String var2, int var3, int var4);

    public String sentinelRemove(String var1);

    public String sentinelSet(String var1, Map<String, String> var2);
}

