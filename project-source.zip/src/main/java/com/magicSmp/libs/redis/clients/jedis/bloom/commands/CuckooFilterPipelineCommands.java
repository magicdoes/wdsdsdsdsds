/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.bloom.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.Response;
import com.bx.magicSmp.libs.redis.clients.jedis.bloom.CFInsertParams;
import com.bx.magicSmp.libs.redis.clients.jedis.bloom.CFReserveParams;
import java.util.List;
import java.util.Map;

public interface CuckooFilterPipelineCommands {
    public Response<String> cfReserve(String var1, long var2);

    public Response<String> cfReserve(String var1, long var2, CFReserveParams var4);

    public Response<Boolean> cfAdd(String var1, String var2);

    public Response<Boolean> cfAddNx(String var1, String var2);

    public Response<List<Boolean>> cfInsert(String var1, String ... var2);

    public Response<List<Boolean>> cfInsert(String var1, CFInsertParams var2, String ... var3);

    public Response<List<Boolean>> cfInsertNx(String var1, String ... var2);

    public Response<List<Boolean>> cfInsertNx(String var1, CFInsertParams var2, String ... var3);

    public Response<Boolean> cfExists(String var1, String var2);

    public Response<List<Boolean>> cfMExists(String var1, String ... var2);

    public Response<Boolean> cfDel(String var1, String var2);

    public Response<Long> cfCount(String var1, String var2);

    public Response<Map.Entry<Long, byte[]>> cfScanDump(String var1, long var2);

    public Response<String> cfLoadChunk(String var1, long var2, byte[] var4);

    public Response<Map<String, Object>> cfInfo(String var1);
}

