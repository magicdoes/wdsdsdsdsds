/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.CommandArguments;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.AccessControlLogEntry;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.AccessControlUser;
import java.util.List;

public interface AccessControlLogCommands {
    public String aclWhoAmI();

    public String aclGenPass();

    public String aclGenPass(int var1);

    public List<String> aclList();

    public List<String> aclUsers();

    public AccessControlUser aclGetUser(String var1);

    public String aclSetUser(String var1);

    public String aclSetUser(String var1, String ... var2);

    public long aclDelUser(String ... var1);

    public List<String> aclCat();

    public List<String> aclCat(String var1);

    public List<AccessControlLogEntry> aclLog();

    public List<AccessControlLogEntry> aclLog(int var1);

    public String aclLogReset();

    public String aclLoad();

    public String aclSave();

    public String aclDryRun(String var1, String var2, String ... var3);

    public String aclDryRun(String var1, CommandArguments var2);
}

