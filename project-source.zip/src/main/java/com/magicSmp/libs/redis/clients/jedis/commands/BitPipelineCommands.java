/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.Response;
import com.bx.magicSmp.libs.redis.clients.jedis.args.BitCountOption;
import com.bx.magicSmp.libs.redis.clients.jedis.args.BitOP;
import com.bx.magicSmp.libs.redis.clients.jedis.params.BitPosParams;
import java.util.List;

public interface BitPipelineCommands {
    public Response<Boolean> setbit(String var1, long var2, boolean var4);

    public Response<Boolean> getbit(String var1, long var2);

    public Response<Long> bitcount(String var1);

    public Response<Long> bitcount(String var1, long var2, long var4);

    public Response<Long> bitcount(String var1, long var2, long var4, BitCountOption var6);

    public Response<Long> bitpos(String var1, boolean var2);

    public Response<Long> bitpos(String var1, boolean var2, BitPosParams var3);

    public Response<List<Long>> bitfield(String var1, String ... var2);

    public Response<List<Long>> bitfieldReadonly(String var1, String ... var2);

    public Response<Long> bitop(BitOP var1, String var2, String ... var3);
}

