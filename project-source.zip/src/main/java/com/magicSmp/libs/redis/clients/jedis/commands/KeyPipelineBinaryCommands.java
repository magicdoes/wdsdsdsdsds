/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.Response;
import com.bx.magicSmp.libs.redis.clients.jedis.args.ExpiryOption;
import com.bx.magicSmp.libs.redis.clients.jedis.params.MigrateParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.RestoreParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.ScanParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.SortingParams;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.ScanResult;
import com.bx.magicSmp.libs.redis.clients.jedis.util.CompareCondition;
import java.util.List;
import java.util.Set;

public interface KeyPipelineBinaryCommands {
    public Response<Boolean> exists(byte[] var1);

    public Response<Long> exists(byte[] ... var1);

    public Response<Long> persist(byte[] var1);

    public Response<String> type(byte[] var1);

    public Response<byte[]> dump(byte[] var1);

    public Response<String> restore(byte[] var1, long var2, byte[] var4);

    public Response<String> restore(byte[] var1, long var2, byte[] var4, RestoreParams var5);

    public Response<Long> expire(byte[] var1, long var2);

    public Response<Long> expire(byte[] var1, long var2, ExpiryOption var4);

    public Response<Long> pexpire(byte[] var1, long var2);

    public Response<Long> pexpire(byte[] var1, long var2, ExpiryOption var4);

    public Response<Long> expireTime(byte[] var1);

    public Response<Long> pexpireTime(byte[] var1);

    public Response<Long> expireAt(byte[] var1, long var2);

    public Response<Long> expireAt(byte[] var1, long var2, ExpiryOption var4);

    public Response<Long> pexpireAt(byte[] var1, long var2);

    public Response<Long> pexpireAt(byte[] var1, long var2, ExpiryOption var4);

    public Response<Long> ttl(byte[] var1);

    public Response<Long> pttl(byte[] var1);

    public Response<Long> touch(byte[] var1);

    public Response<Long> touch(byte[] ... var1);

    public Response<List<byte[]>> sort(byte[] var1);

    public Response<List<byte[]>> sort(byte[] var1, SortingParams var2);

    public Response<List<byte[]>> sortReadonly(byte[] var1, SortingParams var2);

    public Response<Long> del(byte[] var1);

    public Response<Long> del(byte[] ... var1);

    public Response<Long> delex(byte[] var1, CompareCondition var2);

    public Response<byte[]> digestKey(byte[] var1);

    public Response<Long> unlink(byte[] var1);

    public Response<Long> unlink(byte[] ... var1);

    public Response<Boolean> copy(byte[] var1, byte[] var2, boolean var3);

    public Response<String> rename(byte[] var1, byte[] var2);

    public Response<Long> renamenx(byte[] var1, byte[] var2);

    public Response<Long> sort(byte[] var1, SortingParams var2, byte[] var3);

    public Response<Long> sort(byte[] var1, byte[] var2);

    public Response<Long> memoryUsage(byte[] var1);

    public Response<Long> memoryUsage(byte[] var1, int var2);

    public Response<Long> objectRefcount(byte[] var1);

    public Response<byte[]> objectEncoding(byte[] var1);

    public Response<Long> objectIdletime(byte[] var1);

    public Response<Long> objectFreq(byte[] var1);

    public Response<String> migrate(String var1, int var2, byte[] var3, int var4);

    public Response<String> migrate(String var1, int var2, int var3, MigrateParams var4, byte[] ... var5);

    public Response<Set<byte[]>> keys(byte[] var1);

    public Response<ScanResult<byte[]>> scan(byte[] var1);

    public Response<ScanResult<byte[]>> scan(byte[] var1, ScanParams var2);

    public Response<ScanResult<byte[]>> scan(byte[] var1, ScanParams var2, byte[] var3);

    public Response<byte[]> randomBinaryKey();
}

