/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.params.CommandListFilterByParams;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.CommandDocument;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.CommandInfo;
import com.bx.magicSmp.libs.redis.clients.jedis.util.KeyValue;
import java.util.List;
import java.util.Map;

public interface CommandCommands {
    public long commandCount();

    public Map<String, CommandDocument> commandDocs(String ... var1);

    public List<String> commandGetKeys(String ... var1);

    public List<KeyValue<String, List<String>>> commandGetKeysAndFlags(String ... var1);

    public Map<String, CommandInfo> commandInfo(String ... var1);

    public Map<String, CommandInfo> command();

    public List<String> commandList();

    public List<String> commandListFilterBy(CommandListFilterByParams var1);
}

