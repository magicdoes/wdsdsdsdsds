/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.Response;
import com.bx.magicSmp.libs.redis.clients.jedis.params.MigrateParams;

public interface DatabasePipelineCommands {
    public Response<String> select(int var1);

    public Response<Long> dbSize();

    public Response<String> swapDB(int var1, int var2);

    public Response<Long> move(String var1, int var2);

    public Response<Long> move(byte[] var1, int var2);

    public Response<Boolean> copy(String var1, String var2, int var3, boolean var4);

    public Response<Boolean> copy(byte[] var1, byte[] var2, int var3, boolean var4);

    public Response<String> migrate(String var1, int var2, byte[] var3, int var4, int var5);

    public Response<String> migrate(String var1, int var2, int var3, int var4, MigrateParams var5, byte[] ... var6);

    public Response<String> migrate(String var1, int var2, String var3, int var4, int var5);

    public Response<String> migrate(String var1, int var2, int var3, int var4, MigrateParams var5, String ... var6);
}

