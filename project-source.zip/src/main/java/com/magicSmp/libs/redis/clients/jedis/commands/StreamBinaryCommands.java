/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import com.bx.magicSmp.libs.redis.clients.jedis.StreamEntryID;
import com.bx.magicSmp.libs.redis.clients.jedis.args.StreamDeletionPolicy;
import com.bx.magicSmp.libs.redis.clients.jedis.params.XAddParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.XAutoClaimParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.XCfgSetParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.XClaimParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.XPendingParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.XReadGroupParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.XReadParams;
import com.bx.magicSmp.libs.redis.clients.jedis.params.XTrimParams;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.StreamEntryBinary;
import com.bx.magicSmp.libs.redis.clients.jedis.resps.StreamEntryDeletionResult;
import java.util.List;
import java.util.Map;

public interface StreamBinaryCommands {
    default public byte[] xadd(byte[] key, Map<byte[], byte[]> hash, XAddParams params) {
        return this.xadd(key, params, hash);
    }

    public byte[] xadd(byte[] var1, XAddParams var2, Map<byte[], byte[]> var3);

    public long xlen(byte[] var1);

    public List<Object> xrange(byte[] var1, byte[] var2, byte[] var3);

    public List<Object> xrange(byte[] var1, byte[] var2, byte[] var3, int var4);

    public List<Object> xrevrange(byte[] var1, byte[] var2, byte[] var3);

    public List<Object> xrevrange(byte[] var1, byte[] var2, byte[] var3, int var4);

    public long xack(byte[] var1, byte[] var2, byte[] ... var3);

    public List<StreamEntryDeletionResult> xackdel(byte[] var1, byte[] var2, byte[] ... var3);

    public List<StreamEntryDeletionResult> xackdel(byte[] var1, byte[] var2, StreamDeletionPolicy var3, byte[] ... var4);

    public String xgroupCreate(byte[] var1, byte[] var2, byte[] var3, boolean var4);

    public String xgroupSetID(byte[] var1, byte[] var2, byte[] var3);

    public long xgroupDestroy(byte[] var1, byte[] var2);

    public boolean xgroupCreateConsumer(byte[] var1, byte[] var2, byte[] var3);

    public long xgroupDelConsumer(byte[] var1, byte[] var2, byte[] var3);

    public long xdel(byte[] var1, byte[] ... var2);

    public List<StreamEntryDeletionResult> xdelex(byte[] var1, byte[] ... var2);

    public List<StreamEntryDeletionResult> xdelex(byte[] var1, StreamDeletionPolicy var2, byte[] ... var3);

    public long xtrim(byte[] var1, long var2, boolean var4);

    public long xtrim(byte[] var1, XTrimParams var2);

    public Object xpending(byte[] var1, byte[] var2);

    public List<Object> xpending(byte[] var1, byte[] var2, XPendingParams var3);

    public List<byte[]> xclaim(byte[] var1, byte[] var2, byte[] var3, long var4, XClaimParams var6, byte[] ... var7);

    public List<byte[]> xclaimJustId(byte[] var1, byte[] var2, byte[] var3, long var4, XClaimParams var6, byte[] ... var7);

    public List<Object> xautoclaim(byte[] var1, byte[] var2, byte[] var3, long var4, byte[] var6, XAutoClaimParams var7);

    public List<Object> xautoclaimJustId(byte[] var1, byte[] var2, byte[] var3, long var4, byte[] var6, XAutoClaimParams var7);

    public Object xinfoStream(byte[] var1);

    public Object xinfoStreamFull(byte[] var1);

    public Object xinfoStreamFull(byte[] var1, int var2);

    public List<Object> xinfoGroups(byte[] var1);

    public List<Object> xinfoConsumers(byte[] var1, byte[] var2);

    @Deprecated
    public List<Object> xread(XReadParams var1, Map.Entry<byte[], byte[]> ... var2);

    @Deprecated
    public List<Object> xreadGroup(byte[] var1, byte[] var2, XReadGroupParams var3, Map.Entry<byte[], byte[]> ... var4);

    public List<Map.Entry<byte[], List<StreamEntryBinary>>> xreadBinary(XReadParams var1, Map<byte[], StreamEntryID> var2);

    public Map<byte[], List<StreamEntryBinary>> xreadBinaryAsMap(XReadParams var1, Map<byte[], StreamEntryID> var2);

    public List<Map.Entry<byte[], List<StreamEntryBinary>>> xreadGroupBinary(byte[] var1, byte[] var2, XReadGroupParams var3, Map<byte[], StreamEntryID> var4);

    public Map<byte[], List<StreamEntryBinary>> xreadGroupBinaryAsMap(byte[] var1, byte[] var2, XReadGroupParams var3, Map<byte[], StreamEntryID> var4);

    public byte[] xcfgset(byte[] var1, XCfgSetParams var2);
}

