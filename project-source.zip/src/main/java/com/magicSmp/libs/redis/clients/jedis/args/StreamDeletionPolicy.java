/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.args;

import com.bx.magicSmp.libs.redis.clients.jedis.args.Rawable;
import com.bx.magicSmp.libs.redis.clients.jedis.util.SafeEncoder;

public enum StreamDeletionPolicy implements Rawable
{
    KEEP_REFERENCES("KEEPREF"),
    DELETE_REFERENCES("DELREF"),
    ACKNOWLEDGED("ACKED");

    private final byte[] raw;

    private StreamDeletionPolicy(String redisParamName) {
        this.raw = SafeEncoder.encode(redisParamName);
    }

    @Override
    public byte[] getRaw() {
        return this.raw;
    }
}

