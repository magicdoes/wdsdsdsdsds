/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis;

import com.bx.magicSmp.libs.commons.pool2.impl.GenericObjectPoolConfig;
import com.bx.magicSmp.libs.redis.clients.jedis.Jedis;
import java.time.Duration;

@Deprecated
public class JedisPoolConfig
extends GenericObjectPoolConfig<Jedis> {
    public JedisPoolConfig() {
        this.setTestWhileIdle(true);
        this.setMinEvictableIdleTime(Duration.ofMillis(60000L));
        this.setTimeBetweenEvictionRuns(Duration.ofMillis(30000L));
        this.setNumTestsPerEvictionRun(-1);
    }
}

