/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

import java.util.List;

public interface ScriptingKeyCommands {
    public Object eval(String var1);

    public Object eval(String var1, int var2, String ... var3);

    public Object eval(String var1, List<String> var2, List<String> var3);

    public Object evalReadonly(String var1, List<String> var2, List<String> var3);

    public Object evalsha(String var1);

    public Object evalsha(String var1, int var2, String ... var3);

    public Object evalsha(String var1, List<String> var2, List<String> var3);

    public Object evalshaReadonly(String var1, List<String> var2, List<String> var3);
}

