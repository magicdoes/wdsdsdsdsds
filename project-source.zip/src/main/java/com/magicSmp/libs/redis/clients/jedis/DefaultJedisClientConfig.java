/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis;

import com.bx.magicSmp.libs.redis.clients.jedis.ClientSetInfoConfig;
import com.bx.magicSmp.libs.redis.clients.jedis.DefaultRedisCredentials;
import com.bx.magicSmp.libs.redis.clients.jedis.DefaultRedisCredentialsProvider;
import com.bx.magicSmp.libs.redis.clients.jedis.HostAndPortMapper;
import com.bx.magicSmp.libs.redis.clients.jedis.JedisClientConfig;
import com.bx.magicSmp.libs.redis.clients.jedis.RedisCredentials;
import com.bx.magicSmp.libs.redis.clients.jedis.RedisProtocol;
import com.bx.magicSmp.libs.redis.clients.jedis.SslOptions;
import com.bx.magicSmp.libs.redis.clients.jedis.authentication.AuthXManager;
import com.bx.magicSmp.libs.redis.clients.jedis.util.JedisAsserts;
import com.bx.magicSmp.libs.redis.clients.jedis.util.JedisURIHelper;
import java.net.URI;
import java.util.function.Supplier;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.SSLSocketFactory;

public final class DefaultJedisClientConfig
implements JedisClientConfig {
    private final RedisProtocol redisProtocol;
    private final int connectionTimeoutMillis;
    private final int socketTimeoutMillis;
    private final int blockingSocketTimeoutMillis;
    private volatile Supplier<RedisCredentials> credentialsProvider;
    private final int database;
    private final String clientName;
    private final boolean ssl;
    private final SSLSocketFactory sslSocketFactory;
    private final SSLParameters sslParameters;
    private final SslOptions sslOptions;
    private final HostnameVerifier hostnameVerifier;
    private final HostAndPortMapper hostAndPortMapper;
    private final ClientSetInfoConfig clientSetInfoConfig;
    private final boolean readOnlyForRedisClusterReplicas;
    private final AuthXManager authXManager;

    private DefaultJedisClientConfig(Builder builder) {
        this.redisProtocol = builder.redisProtocol;
        this.connectionTimeoutMillis = builder.connectionTimeoutMillis;
        this.socketTimeoutMillis = builder.socketTimeoutMillis;
        this.blockingSocketTimeoutMillis = builder.blockingSocketTimeoutMillis;
        this.credentialsProvider = builder.credentialsProvider;
        this.database = builder.database;
        this.clientName = builder.clientName;
        this.ssl = builder.ssl;
        this.sslSocketFactory = builder.sslSocketFactory;
        this.sslParameters = builder.sslParameters;
        this.sslOptions = builder.sslOptions;
        this.hostnameVerifier = builder.hostnameVerifier;
        this.hostAndPortMapper = builder.hostAndPortMapper;
        this.clientSetInfoConfig = builder.clientSetInfoConfig;
        this.readOnlyForRedisClusterReplicas = builder.readOnlyForRedisClusterReplicas;
        this.authXManager = builder.authXManager;
    }

    @Override
    public RedisProtocol getRedisProtocol() {
        return this.redisProtocol;
    }

    @Override
    public int getConnectionTimeoutMillis() {
        return this.connectionTimeoutMillis;
    }

    @Override
    public int getSocketTimeoutMillis() {
        return this.socketTimeoutMillis;
    }

    @Override
    public int getBlockingSocketTimeoutMillis() {
        return this.blockingSocketTimeoutMillis;
    }

    @Override
    public String getUser() {
        return this.credentialsProvider.get().getUser();
    }

    @Override
    public String getPassword() {
        char[] password = this.credentialsProvider.get().getPassword();
        return password == null ? null : new String(password);
    }

    @Override
    public Supplier<RedisCredentials> getCredentialsProvider() {
        return this.credentialsProvider;
    }

    @Override
    public AuthXManager getAuthXManager() {
        return this.authXManager;
    }

    @Override
    public int getDatabase() {
        return this.database;
    }

    @Override
    public String getClientName() {
        return this.clientName;
    }

    @Override
    public boolean isSsl() {
        return this.ssl;
    }

    @Override
    @Deprecated
    public SSLSocketFactory getSslSocketFactory() {
        return this.sslSocketFactory;
    }

    @Override
    @Deprecated
    public SSLParameters getSslParameters() {
        return this.sslParameters;
    }

    @Override
    public SslOptions getSslOptions() {
        return this.sslOptions;
    }

    @Override
    public HostnameVerifier getHostnameVerifier() {
        return this.hostnameVerifier;
    }

    @Override
    public HostAndPortMapper getHostAndPortMapper() {
        return this.hostAndPortMapper;
    }

    @Override
    public ClientSetInfoConfig getClientSetInfoConfig() {
        return this.clientSetInfoConfig;
    }

    @Override
    public boolean isReadOnlyForRedisClusterReplicas() {
        return this.readOnlyForRedisClusterReplicas;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static Builder builder(URI redisUri) {
        RedisProtocol uriProtocol;
        JedisAsserts.notNull(redisUri, "Redis URI must not be null");
        JedisAsserts.isTrue(JedisURIHelper.isValid(redisUri), "Invalid Redis URI");
        Builder builder = new Builder();
        String uriUser = JedisURIHelper.getUser(redisUri);
        String uriPassword = JedisURIHelper.getPassword(redisUri);
        if (uriUser != null || uriPassword != null) {
            builder.credentials(new DefaultRedisCredentials(uriUser, uriPassword));
        }
        if (JedisURIHelper.hasDbIndex(redisUri)) {
            builder.database(JedisURIHelper.getDBIndex(redisUri));
        }
        if ((uriProtocol = JedisURIHelper.getRedisProtocol(redisUri)) != null) {
            builder.protocol(uriProtocol);
        }
        if (JedisURIHelper.isRedisSSLScheme(redisUri)) {
            builder.ssl(true);
        } else if (JedisURIHelper.isRedisScheme(redisUri)) {
            builder.ssl(false);
        }
        return builder;
    }

    @Deprecated
    public static DefaultJedisClientConfig create(int connectionTimeoutMillis, int soTimeoutMillis, int blockingSocketTimeoutMillis, String user, String password, int database, String clientName, boolean ssl, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier, HostAndPortMapper hostAndPortMapper) {
        Builder builder = DefaultJedisClientConfig.builder();
        builder.connectionTimeoutMillis(connectionTimeoutMillis).socketTimeoutMillis(soTimeoutMillis).blockingSocketTimeoutMillis(blockingSocketTimeoutMillis);
        if (user != null || password != null) {
            builder.credentials(new DefaultRedisCredentials(user, password));
        }
        builder.database(database).clientName(clientName);
        builder.ssl(ssl).sslSocketFactory(sslSocketFactory).sslParameters(sslParameters).hostnameVerifier(hostnameVerifier);
        builder.hostAndPortMapper(hostAndPortMapper);
        return builder.build();
    }

    @Deprecated
    public static DefaultJedisClientConfig copyConfig(JedisClientConfig copy) {
        Builder builder = DefaultJedisClientConfig.builder();
        builder.protocol(copy.getRedisProtocol());
        builder.connectionTimeoutMillis(copy.getConnectionTimeoutMillis());
        builder.socketTimeoutMillis(copy.getSocketTimeoutMillis());
        builder.blockingSocketTimeoutMillis(copy.getBlockingSocketTimeoutMillis());
        Supplier<RedisCredentials> credentialsProvider = copy.getCredentialsProvider();
        if (credentialsProvider != null) {
            builder.credentialsProvider(credentialsProvider);
        } else {
            builder.user(copy.getUser());
            builder.password(copy.getPassword());
        }
        builder.database(copy.getDatabase());
        builder.clientName(copy.getClientName());
        builder.ssl(copy.isSsl());
        builder.sslSocketFactory(copy.getSslSocketFactory());
        builder.sslParameters(copy.getSslParameters());
        builder.hostnameVerifier(copy.getHostnameVerifier());
        builder.sslOptions(copy.getSslOptions());
        builder.hostAndPortMapper(copy.getHostAndPortMapper());
        builder.clientSetInfoConfig(copy.getClientSetInfoConfig());
        if (copy.isReadOnlyForRedisClusterReplicas()) {
            builder.readOnlyForRedisClusterReplicas();
        }
        builder.authXManager(copy.getAuthXManager());
        return builder.build();
    }

    public static class Builder {
        private RedisProtocol redisProtocol = null;
        private int connectionTimeoutMillis = 2000;
        private int socketTimeoutMillis = 2000;
        private int blockingSocketTimeoutMillis = 0;
        private String user = null;
        private String password = null;
        private Supplier<RedisCredentials> credentialsProvider;
        private int database = 0;
        private String clientName = null;
        private boolean ssl = false;
        private SSLSocketFactory sslSocketFactory = null;
        private SSLParameters sslParameters = null;
        private SslOptions sslOptions = null;
        private HostnameVerifier hostnameVerifier = null;
        private HostAndPortMapper hostAndPortMapper = null;
        private ClientSetInfoConfig clientSetInfoConfig = ClientSetInfoConfig.DEFAULT;
        private boolean readOnlyForRedisClusterReplicas = false;
        private AuthXManager authXManager = null;

        private Builder() {
        }

        public DefaultJedisClientConfig build() {
            if (this.credentialsProvider == null) {
                this.credentialsProvider = new DefaultRedisCredentialsProvider(new DefaultRedisCredentials(this.user, this.password));
            }
            return new DefaultJedisClientConfig(this);
        }

        public Builder resp3() {
            return this.protocol(RedisProtocol.RESP3);
        }

        public Builder protocol(RedisProtocol protocol) {
            this.redisProtocol = protocol;
            return this;
        }

        public Builder timeoutMillis(int timeoutMillis) {
            this.connectionTimeoutMillis = timeoutMillis;
            this.socketTimeoutMillis = timeoutMillis;
            return this;
        }

        public Builder connectionTimeoutMillis(int connectionTimeoutMillis) {
            this.connectionTimeoutMillis = connectionTimeoutMillis;
            return this;
        }

        public Builder socketTimeoutMillis(int socketTimeoutMillis) {
            this.socketTimeoutMillis = socketTimeoutMillis;
            return this;
        }

        public Builder blockingSocketTimeoutMillis(int blockingSocketTimeoutMillis) {
            this.blockingSocketTimeoutMillis = blockingSocketTimeoutMillis;
            return this;
        }

        public Builder user(String user) {
            this.user = user;
            return this;
        }

        public Builder password(String password) {
            this.password = password;
            return this;
        }

        public Builder credentials(RedisCredentials credentials) {
            this.credentialsProvider = new DefaultRedisCredentialsProvider(credentials);
            return this;
        }

        public Builder credentialsProvider(Supplier<RedisCredentials> credentials) {
            this.credentialsProvider = credentials;
            return this;
        }

        public Builder database(int database) {
            this.database = database;
            return this;
        }

        public Builder clientName(String clientName) {
            this.clientName = clientName;
            return this;
        }

        @Deprecated
        public Builder ssl(boolean ssl) {
            this.ssl = ssl;
            return this;
        }

        @Deprecated
        public Builder sslSocketFactory(SSLSocketFactory sslSocketFactory) {
            this.sslSocketFactory = sslSocketFactory;
            return this;
        }

        @Deprecated
        public Builder sslParameters(SSLParameters sslParameters) {
            this.sslParameters = sslParameters;
            return this;
        }

        public Builder sslOptions(SslOptions sslOptions) {
            this.sslOptions = sslOptions;
            return this;
        }

        public Builder hostnameVerifier(HostnameVerifier hostnameVerifier) {
            this.hostnameVerifier = hostnameVerifier;
            return this;
        }

        public Builder hostAndPortMapper(HostAndPortMapper hostAndPortMapper) {
            this.hostAndPortMapper = hostAndPortMapper;
            return this;
        }

        public Builder clientSetInfoConfig(ClientSetInfoConfig setInfoConfig) {
            this.clientSetInfoConfig = setInfoConfig;
            return this;
        }

        public Builder readOnlyForRedisClusterReplicas() {
            this.readOnlyForRedisClusterReplicas = true;
            return this;
        }

        public Builder authXManager(AuthXManager authXManager) {
            this.authXManager = authXManager;
            return this;
        }

        public Builder from(JedisClientConfig instance) {
            this.redisProtocol = instance.getRedisProtocol();
            this.connectionTimeoutMillis = instance.getConnectionTimeoutMillis();
            this.socketTimeoutMillis = instance.getSocketTimeoutMillis();
            this.blockingSocketTimeoutMillis = instance.getBlockingSocketTimeoutMillis();
            this.credentialsProvider = instance.getCredentialsProvider();
            this.database = instance.getDatabase();
            this.clientName = instance.getClientName();
            this.ssl = instance.isSsl();
            this.sslSocketFactory = instance.getSslSocketFactory();
            this.sslParameters = instance.getSslParameters();
            this.sslOptions = instance.getSslOptions();
            this.hostnameVerifier = instance.getHostnameVerifier();
            this.hostAndPortMapper = instance.getHostAndPortMapper();
            this.clientSetInfoConfig = instance.getClientSetInfoConfig();
            this.readOnlyForRedisClusterReplicas = instance.isReadOnlyForRedisClusterReplicas();
            this.authXManager = instance.getAuthXManager();
            return this;
        }
    }
}

