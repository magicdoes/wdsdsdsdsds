/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis;

public interface Endpoint {
    public String getHost();

    public int getPort();
}

