/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis;

import com.bx.magicSmp.libs.redis.clients.jedis.AbstractPipeline;
import com.bx.magicSmp.libs.redis.clients.jedis.CommandArguments;
import com.bx.magicSmp.libs.redis.clients.jedis.CommandObject;
import com.bx.magicSmp.libs.redis.clients.jedis.CommandObjects;
import com.bx.magicSmp.libs.redis.clients.jedis.Connection;
import com.bx.magicSmp.libs.redis.clients.jedis.HostAndPort;
import com.bx.magicSmp.libs.redis.clients.jedis.Response;
import com.bx.magicSmp.libs.redis.clients.jedis.exceptions.JedisConnectionException;
import com.bx.magicSmp.libs.redis.clients.jedis.util.IOUtils;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class MultiNodePipelineBase
extends AbstractPipeline {
    private final Logger log = LoggerFactory.getLogger(this.getClass());
    public static volatile int MULTI_NODE_PIPELINE_SYNC_WORKERS = 3;
    private final Map<HostAndPort, Queue<Response<?>>> pipelinedResponses = new LinkedHashMap();
    private final Map<HostAndPort, Connection> connections = new LinkedHashMap<HostAndPort, Connection>();
    private volatile boolean syncing = false;
    private final ExecutorService sharedExecutorService;

    public MultiNodePipelineBase(CommandObjects commandObjects) {
        this(commandObjects, null);
    }

    MultiNodePipelineBase(CommandObjects commandObjects, ExecutorService executorService) {
        super(commandObjects);
        this.sharedExecutorService = executorService;
    }

    protected abstract HostAndPort getNodeKey(CommandArguments var1);

    protected abstract Connection getConnection(HostAndPort var1);

    @Override
    protected final <T> Response<T> appendCommand(CommandObject<T> commandObject) {
        Connection connection;
        Queue<Response<?>> queue;
        HostAndPort nodeKey = this.getNodeKey(commandObject.getArguments());
        if (this.pipelinedResponses.containsKey(nodeKey)) {
            queue = this.pipelinedResponses.get(nodeKey);
            connection = this.connections.get(nodeKey);
        } else {
            Connection newOne = this.getConnection(nodeKey);
            this.connections.putIfAbsent(nodeKey, newOne);
            connection = this.connections.get(nodeKey);
            if (connection != newOne) {
                this.log.debug("Duplicate connection to {}, closing it.", (Object)nodeKey);
                IOUtils.closeQuietly(newOne);
            }
            this.pipelinedResponses.putIfAbsent(nodeKey, new LinkedList());
            queue = this.pipelinedResponses.get(nodeKey);
        }
        connection.sendCommand(commandObject.getArguments());
        Response<T> response = new Response<T>(commandObject.getBuilder());
        queue.add(response);
        return response;
    }

    @Override
    public void close() {
        try {
            this.sync();
        }
        finally {
            this.connections.values().forEach(IOUtils::closeQuietly);
        }
    }

    @Override
    public final void sync() {
        Executor executor;
        if (this.syncing) {
            return;
        }
        this.syncing = true;
        boolean multiNode = this.pipelinedResponses.size() > 1;
        ExecutorService executorService = null;
        if (multiNode) {
            executorService = this.getPipelineExecutor();
            executor = executorService;
        } else {
            executor = Runnable::run;
        }
        CountDownLatch countDownLatch = multiNode ? new CountDownLatch(this.pipelinedResponses.size()) : null;
        Iterator<Map.Entry<HostAndPort, Queue<Response<?>>>> pipelinedResponsesIterator = this.pipelinedResponses.entrySet().iterator();
        while (pipelinedResponsesIterator.hasNext()) {
            Map.Entry<HostAndPort, Queue<Response<?>>> entry = pipelinedResponsesIterator.next();
            HostAndPort nodeKey = entry.getKey();
            Queue<Response<?>> queue = entry.getValue();
            Connection connection = this.connections.get(nodeKey);
            executor.execute(() -> {
                try {
                    List<Object> unformatted = connection.getMany(queue.size());
                    for (Object o : unformatted) {
                        ((Response)queue.poll()).set(o);
                    }
                }
                catch (JedisConnectionException jce) {
                    this.log.error("Error with connection to " + nodeKey, jce);
                    pipelinedResponsesIterator.remove();
                    this.connections.remove(nodeKey);
                    IOUtils.closeQuietly(connection);
                }
                finally {
                    if (multiNode) {
                        countDownLatch.countDown();
                    }
                }
            });
        }
        if (multiNode) {
            try {
                countDownLatch.await();
            }
            catch (InterruptedException e) {
                this.log.error("Thread is interrupted during sync.", e);
            }
            this.releasePipelineExecutor(executorService);
        }
        this.syncing = false;
    }

    private ExecutorService getPipelineExecutor() {
        return this.isUsingSharedExecutor() ? this.sharedExecutorService : this.createDedicatedPipelineExecutor();
    }

    private void releasePipelineExecutor(ExecutorService executorService) {
        if (!this.isUsingSharedExecutor()) {
            executorService.shutdownNow();
        }
    }

    private boolean isUsingSharedExecutor() {
        return this.sharedExecutorService != null;
    }

    private ExecutorService createDedicatedPipelineExecutor() {
        return Executors.newFixedThreadPool(MULTI_NODE_PIPELINE_SYNC_WORKERS);
    }

    @Deprecated
    public Response<Long> waitReplicas(int replicas, long timeout) {
        return this.appendCommand(this.commandObjects.waitReplicas(replicas, timeout));
    }
}

