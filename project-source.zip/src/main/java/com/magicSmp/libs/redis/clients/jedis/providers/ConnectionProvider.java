/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.providers;

import com.bx.magicSmp.libs.redis.clients.jedis.CommandArguments;
import com.bx.magicSmp.libs.redis.clients.jedis.Connection;
import java.util.Collections;
import java.util.Map;

public interface ConnectionProvider
extends AutoCloseable {
    public Connection getConnection();

    public Connection getConnection(CommandArguments var1);

    default public Map<?, ?> getConnectionMap() {
        Connection c = this.getConnection();
        return Collections.singletonMap(c.toString(), c);
    }

    default public Map<?, ?> getPrimaryNodesConnectionMap() {
        Connection c = this.getConnection();
        return Collections.singletonMap(c.toString(), c);
    }
}

