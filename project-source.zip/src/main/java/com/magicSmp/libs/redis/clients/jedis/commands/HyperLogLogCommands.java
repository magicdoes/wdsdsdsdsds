/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.commands;

public interface HyperLogLogCommands {
    public long pfadd(String var1, String ... var2);

    public String pfmerge(String var1, String ... var2);

    public long pfcount(String var1);

    public long pfcount(String ... var1);
}

