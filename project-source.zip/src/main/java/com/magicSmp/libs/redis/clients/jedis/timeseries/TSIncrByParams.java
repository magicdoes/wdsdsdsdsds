/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.timeseries;

import com.bx.magicSmp.libs.redis.clients.jedis.timeseries.TSArithByParams;

public class TSIncrByParams
extends TSArithByParams<TSIncrByParams> {
    public static TSIncrByParams incrByParams() {
        return new TSIncrByParams();
    }
}

