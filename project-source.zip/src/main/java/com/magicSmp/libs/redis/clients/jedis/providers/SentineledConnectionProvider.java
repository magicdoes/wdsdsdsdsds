/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.redis.clients.jedis.providers;

import com.bx.magicSmp.libs.commons.pool2.impl.GenericObjectPoolConfig;
import com.bx.magicSmp.libs.redis.clients.jedis.CommandArguments;
import com.bx.magicSmp.libs.redis.clients.jedis.Connection;
import com.bx.magicSmp.libs.redis.clients.jedis.ConnectionPool;
import com.bx.magicSmp.libs.redis.clients.jedis.HostAndPort;
import com.bx.magicSmp.libs.redis.clients.jedis.Jedis;
import com.bx.magicSmp.libs.redis.clients.jedis.JedisClientConfig;
import com.bx.magicSmp.libs.redis.clients.jedis.JedisPubSub;
import com.bx.magicSmp.libs.redis.clients.jedis.annots.Experimental;
import com.bx.magicSmp.libs.redis.clients.jedis.csc.Cache;
import com.bx.magicSmp.libs.redis.clients.jedis.exceptions.JedisConnectionException;
import com.bx.magicSmp.libs.redis.clients.jedis.exceptions.JedisException;
import com.bx.magicSmp.libs.redis.clients.jedis.providers.ConnectionProvider;
import com.bx.magicSmp.libs.redis.clients.jedis.util.Delay;
import com.bx.magicSmp.libs.redis.clients.jedis.util.IOUtils;
import com.bx.magicSmp.libs.redis.clients.jedis.util.Pool;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SentineledConnectionProvider
implements ConnectionProvider {
    private static final Logger LOG = LoggerFactory.getLogger(SentineledConnectionProvider.class);
    protected static final long DEFAULT_SUBSCRIBE_RETRY_WAIT_TIME_MILLIS = 5000L;
    public static final Delay DEFAULT_RESUBSCRIBE_DELAY = Delay.constant(Duration.ofMillis(5000L));
    private static final Sleeper DEFAULT_SLEEPER = Thread::sleep;
    private volatile HostAndPort currentMaster;
    private volatile ConnectionPool pool;
    private final String masterName;
    private final JedisClientConfig masterClientConfig;
    private final Cache clientSideCache;
    private final GenericObjectPoolConfig<Connection> masterPoolConfig;
    protected final Collection<SentinelListener> sentinelListeners = new ArrayList<SentinelListener>();
    private final JedisClientConfig sentinelClientConfig;
    private final Delay resubscribeDelay;
    private final Lock initPoolLock = new ReentrantLock(true);
    private final SentinelConnectionFactory sentinelConnectionFactory;
    private final Sleeper sleeper;

    public SentineledConnectionProvider(String masterName, JedisClientConfig masterClientConfig, Set<HostAndPort> sentinels, JedisClientConfig sentinelClientConfig) {
        this(masterName, masterClientConfig, null, null, sentinels, sentinelClientConfig);
    }

    @Experimental
    public SentineledConnectionProvider(String masterName, JedisClientConfig masterClientConfig, Cache clientSideCache, Set<HostAndPort> sentinels, JedisClientConfig sentinelClientConfig) {
        this(masterName, masterClientConfig, clientSideCache, null, sentinels, sentinelClientConfig);
    }

    public SentineledConnectionProvider(String masterName, JedisClientConfig masterClientConfig, GenericObjectPoolConfig<Connection> poolConfig, Set<HostAndPort> sentinels, JedisClientConfig sentinelClientConfig) {
        this(masterName, masterClientConfig, poolConfig, sentinels, sentinelClientConfig, DEFAULT_RESUBSCRIBE_DELAY);
    }

    @Experimental
    public SentineledConnectionProvider(String masterName, JedisClientConfig masterClientConfig, Cache clientSideCache, GenericObjectPoolConfig<Connection> poolConfig, Set<HostAndPort> sentinels, JedisClientConfig sentinelClientConfig) {
        this(masterName, masterClientConfig, clientSideCache, poolConfig, sentinels, sentinelClientConfig, DEFAULT_RESUBSCRIBE_DELAY);
    }

    @Deprecated
    public SentineledConnectionProvider(String masterName, JedisClientConfig masterClientConfig, GenericObjectPoolConfig<Connection> poolConfig, Set<HostAndPort> sentinels, JedisClientConfig sentinelClientConfig, long subscribeRetryWaitTimeMillis) {
        this(masterName, masterClientConfig, null, poolConfig, sentinels, sentinelClientConfig, Delay.constant(Duration.ofMillis(subscribeRetryWaitTimeMillis)));
    }

    public SentineledConnectionProvider(String masterName, JedisClientConfig masterClientConfig, GenericObjectPoolConfig<Connection> poolConfig, Set<HostAndPort> sentinels, JedisClientConfig sentinelClientConfig, Delay subscribeRetryWaitTimeMillis) {
        this(masterName, masterClientConfig, null, poolConfig, sentinels, sentinelClientConfig, subscribeRetryWaitTimeMillis);
    }

    @Deprecated
    @Experimental
    public SentineledConnectionProvider(String masterName, JedisClientConfig masterClientConfig, Cache clientSideCache, GenericObjectPoolConfig<Connection> poolConfig, Set<HostAndPort> sentinels, JedisClientConfig sentinelClientConfig, long subscribeRetryWaitTimeMillis) {
        this(masterName, masterClientConfig, clientSideCache, poolConfig, sentinels, sentinelClientConfig, Delay.constant(Duration.ofMillis(subscribeRetryWaitTimeMillis)));
    }

    @Experimental
    public SentineledConnectionProvider(String masterName, JedisClientConfig masterClientConfig, Cache clientSideCache, GenericObjectPoolConfig<Connection> poolConfig, Set<HostAndPort> sentinels, JedisClientConfig sentinelClientConfig, Delay resubscribeDelay) {
        this(masterName, masterClientConfig, clientSideCache, poolConfig, sentinels, sentinelClientConfig, resubscribeDelay, null, null);
    }

    SentineledConnectionProvider(String masterName, JedisClientConfig masterClientConfig, Cache clientSideCache, GenericObjectPoolConfig<Connection> poolConfig, Set<HostAndPort> sentinels, JedisClientConfig sentinelClientConfig, Delay resubscribeDelay, SentinelConnectionFactory sentinelConnectionFactory, Sleeper sleeper) {
        this.masterName = masterName;
        this.masterClientConfig = masterClientConfig;
        this.clientSideCache = clientSideCache;
        this.masterPoolConfig = poolConfig;
        this.sentinelClientConfig = sentinelClientConfig;
        this.resubscribeDelay = resubscribeDelay;
        this.sentinelConnectionFactory = sentinelConnectionFactory != null ? sentinelConnectionFactory : this.defaultSentinelConnectionFactory();
        this.sleeper = sleeper != null ? sleeper : DEFAULT_SLEEPER;
        HostAndPort master = this.initSentinels(sentinels);
        this.initMaster(master);
    }

    @Override
    public Connection getConnection() {
        return this.pool.getResource();
    }

    @Override
    public Connection getConnection(CommandArguments args) {
        return this.pool.getResource();
    }

    public Map<?, Pool<Connection>> getConnectionMap() {
        return Collections.singletonMap(this.currentMaster, this.pool);
    }

    public Map<?, Pool<Connection>> getPrimaryNodesConnectionMap() {
        return Collections.singletonMap(this.currentMaster, this.pool);
    }

    @Override
    public void close() {
        this.sentinelListeners.forEach(SentinelListener::shutdown);
        this.pool.close();
    }

    public HostAndPort getCurrentMaster() {
        return this.currentMaster;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void initMaster(HostAndPort master) {
        this.initPoolLock.lock();
        try {
            if (!master.equals(this.currentMaster)) {
                this.currentMaster = master;
                ConnectionPool newPool = this.createNodePool(this.currentMaster);
                ConnectionPool existingPool = this.pool;
                this.pool = newPool;
                LOG.info("Created connection pool to master at {}.", (Object)master);
                if (this.clientSideCache != null) {
                    this.clientSideCache.flush();
                }
                if (existingPool != null) {
                    existingPool.close();
                }
            }
        }
        finally {
            this.initPoolLock.unlock();
        }
    }

    private ConnectionPool createNodePool(HostAndPort master) {
        if (this.masterPoolConfig == null) {
            if (this.clientSideCache == null) {
                return new ConnectionPool(master, this.masterClientConfig);
            }
            return new ConnectionPool(master, this.masterClientConfig, this.clientSideCache);
        }
        if (this.clientSideCache == null) {
            return new ConnectionPool(master, this.masterClientConfig, this.masterPoolConfig);
        }
        return new ConnectionPool(master, this.masterClientConfig, this.clientSideCache, this.masterPoolConfig);
    }

    private HostAndPort initSentinels(Set<HostAndPort> sentinels) {
        HostAndPort master = null;
        boolean sentinelAvailable = false;
        LOG.debug("Trying to find master from available sentinels...");
        for (HostAndPort sentinel : sentinels) {
            LOG.debug("Connecting to Sentinel {}...", (Object)sentinel);
            try {
                Jedis jedis = this.sentinelConnectionFactory.createConnection(sentinel, this.sentinelClientConfig);
                Throwable throwable = null;
                try {
                    List<String> masterAddr = jedis.sentinelGetMasterAddrByName(this.masterName);
                    sentinelAvailable = true;
                    if (masterAddr == null || masterAddr.size() != 2) {
                        LOG.warn("Sentinel {} is not monitoring master {}.", (Object)sentinel, (Object)this.masterName);
                        continue;
                    }
                    master = SentineledConnectionProvider.toHostAndPort(masterAddr);
                    LOG.debug("Redis master reported at {}.", (Object)master);
                    break;
                }
                catch (Throwable throwable2) {
                    throwable = throwable2;
                    throw throwable2;
                }
                finally {
                    if (jedis == null) continue;
                    if (throwable != null) {
                        try {
                            jedis.close();
                        }
                        catch (Throwable throwable3) {
                            throwable.addSuppressed(throwable3);
                        }
                        continue;
                    }
                    jedis.close();
                }
            }
            catch (JedisException e) {
                LOG.warn("Could not get master address from {}.", (Object)sentinel, (Object)e);
            }
        }
        if (master == null) {
            if (sentinelAvailable) {
                throw new JedisException("Can connect to sentinel, but " + this.masterName + " seems to be not monitored.");
            }
            throw new JedisConnectionException("All sentinels down, cannot determine where " + this.masterName + " is running.");
        }
        LOG.info("Redis master running at {}. Starting sentinel listeners...", (Object)master);
        for (HostAndPort sentinel : sentinels) {
            SentinelListener listener = new SentinelListener(sentinel);
            listener.setDaemon(true);
            this.sentinelListeners.add(listener);
            listener.start();
        }
        return master;
    }

    private static HostAndPort toHostAndPort(List<String> masterAddr) {
        return SentineledConnectionProvider.toHostAndPort(masterAddr.get(0), masterAddr.get(1));
    }

    private static HostAndPort toHostAndPort(String hostStr, String portStr) {
        return new HostAndPort(hostStr, Integer.parseInt(portStr));
    }

    protected SentinelConnectionFactory defaultSentinelConnectionFactory() {
        return (node, config) -> new Jedis(node, config);
    }

    @FunctionalInterface
    protected static interface SentinelConnectionFactory {
        public Jedis createConnection(HostAndPort var1, JedisClientConfig var2);
    }

    @FunctionalInterface
    static interface Sleeper {
        public void sleep(long var1) throws InterruptedException;
    }

    protected class SentinelListener
    extends Thread {
        protected final HostAndPort node;
        protected volatile Jedis sentinelJedis;
        protected AtomicBoolean running;
        protected long subscribeAttempt;

        public SentinelListener(HostAndPort node) {
            super(String.format("%s-SentinelListener-[%s]", SentineledConnectionProvider.this.masterName, node.toString()));
            this.running = new AtomicBoolean(false);
            this.subscribeAttempt = 0L;
            this.node = node;
        }

        /*
         * WARNING - Removed try catching itself - possible behaviour change.
         */
        @Override
        public void run() {
            this.running.set(true);
            while (this.running.get()) {
                try {
                    if (!this.running.get()) break;
                    this.sentinelJedis = SentineledConnectionProvider.this.sentinelConnectionFactory.createConnection(this.node, SentineledConnectionProvider.this.sentinelClientConfig);
                    List<String> masterAddr = this.sentinelJedis.sentinelGetMasterAddrByName(SentineledConnectionProvider.this.masterName);
                    if (masterAddr == null || masterAddr.size() != 2) {
                        LOG.warn("Can not get master {} address. Sentinel: {}.", (Object)SentineledConnectionProvider.this.masterName, (Object)this.node);
                    } else {
                        SentineledConnectionProvider.this.initMaster(SentineledConnectionProvider.toHostAndPort(masterAddr));
                    }
                    this.sentinelJedis.subscribe(new JedisPubSub(){

                        @Override
                        public void onSubscribe(String channel, int subscribedChannels) {
                            SentinelListener.this.subscribeAttempt = 0L;
                            LOG.debug("Successfully subscribed to {} on Sentinel {}. Reset attempt counter.", (Object)channel, (Object)SentinelListener.this.node);
                        }

                        @Override
                        public void onMessage(String channel, String message) {
                            LOG.debug("Sentinel {} published: {}.", (Object)SentinelListener.this.node, (Object)message);
                            String[] switchMasterMsg = message.split(" ");
                            if (switchMasterMsg.length > 3) {
                                if (SentineledConnectionProvider.this.masterName.equals(switchMasterMsg[0])) {
                                    SentineledConnectionProvider.this.initMaster(SentineledConnectionProvider.toHostAndPort(switchMasterMsg[3], switchMasterMsg[4]));
                                } else {
                                    LOG.debug("Ignoring message on +switch-master for master {}. Our master is {}.", (Object)switchMasterMsg[0], (Object)SentineledConnectionProvider.this.masterName);
                                }
                            } else {
                                LOG.error("Invalid message received on sentinel {} on channel +switch-master: {}.", (Object)SentinelListener.this.node, (Object)message);
                            }
                        }
                    }, "+switch-master");
                }
                catch (JedisException e) {
                    if (this.running.get()) {
                        long subscribeRetryWaitTimeMillis = SentineledConnectionProvider.this.resubscribeDelay.delay(this.subscribeAttempt).toMillis();
                        ++this.subscribeAttempt;
                        LOG.warn("Lost connection to Sentinel {}. Sleeping {}ms and retrying.", this.node, subscribeRetryWaitTimeMillis, e);
                        try {
                            SentineledConnectionProvider.this.sleeper.sleep(subscribeRetryWaitTimeMillis);
                        }
                        catch (InterruptedException se) {
                            LOG.error("Sleep interrupted.", se);
                        }
                        continue;
                    }
                    LOG.debug("Unsubscribing from sentinel {}.", (Object)this.node);
                }
                finally {
                    IOUtils.closeQuietly(this.sentinelJedis);
                }
            }
        }

        public void shutdown() {
            try {
                LOG.debug("Shutting down listener on {}.", (Object)this.node);
                this.running.set(false);
                if (this.sentinelJedis != null) {
                    this.sentinelJedis.close();
                }
            }
            catch (RuntimeException e) {
                LOG.error("Error while shutting down.", e);
            }
        }
    }
}

