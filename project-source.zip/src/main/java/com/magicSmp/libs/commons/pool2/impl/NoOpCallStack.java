/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.commons.pool2.impl;

import com.bx.magicSmp.libs.commons.pool2.impl.CallStack;
import java.io.PrintWriter;

public class NoOpCallStack
implements CallStack {
    public static final CallStack INSTANCE = new NoOpCallStack();

    private NoOpCallStack() {
    }

    @Override
    public void clear() {
    }

    @Override
    public void fillInStackTrace() {
    }

    @Override
    public boolean printStackTrace(PrintWriter writer) {
        return false;
    }
}

