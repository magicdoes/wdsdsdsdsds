/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.commons.pool2;

import com.bx.magicSmp.libs.commons.pool2.DestroyMode;
import com.bx.magicSmp.libs.commons.pool2.PooledObject;

public interface PooledObjectFactory<T> {
    public void activateObject(PooledObject<T> var1) throws Exception;

    public void destroyObject(PooledObject<T> var1) throws Exception;

    default public void destroyObject(PooledObject<T> p, DestroyMode destroyMode) throws Exception {
        this.destroyObject(p);
    }

    public PooledObject<T> makeObject() throws Exception;

    public void passivateObject(PooledObject<T> var1) throws Exception;

    public boolean validateObject(PooledObject<T> var1);
}

