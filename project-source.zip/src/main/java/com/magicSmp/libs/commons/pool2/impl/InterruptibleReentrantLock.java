/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.commons.pool2.impl;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

final class InterruptibleReentrantLock
extends ReentrantLock {
    private static final long serialVersionUID = 1L;

    public InterruptibleReentrantLock(boolean fairness) {
        super(fairness);
    }

    public void interruptWaiters(Condition condition) {
        this.getWaitingThreads(condition).forEach(Thread::interrupt);
    }
}

