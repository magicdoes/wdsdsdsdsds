/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.sf.cglib.proxy.Enhancer
 *  net.sf.cglib.proxy.Factory
 */
package com.bx.magicSmp.libs.commons.pool2.proxy;

import com.bx.magicSmp.libs.commons.pool2.UsageTracking;
import com.bx.magicSmp.libs.commons.pool2.proxy.CglibProxyHandler;
import com.bx.magicSmp.libs.commons.pool2.proxy.ProxySource;
import net.sf.cglib.proxy.Enhancer;
import net.sf.cglib.proxy.Factory;

public class CglibProxySource<T>
implements ProxySource<T> {
    private final Class<? extends T> superclass;

    public CglibProxySource(Class<? extends T> superclass) {
        this.superclass = superclass;
    }

    @Override
    public T createProxy(T pooledObject, UsageTracking<T> usageTracking) {
        Enhancer enhancer = new Enhancer();
        enhancer.setSuperclass(this.superclass);
        CglibProxyHandler<T> proxyInterceptor = new CglibProxyHandler<T>(pooledObject, usageTracking);
        enhancer.setCallback(proxyInterceptor);
        return (T)enhancer.create();
    }

    @Override
    public T resolveProxy(T proxy) {
        CglibProxyHandler cglibProxyHandler = (CglibProxyHandler)((Factory)proxy).getCallback(0);
        return cglibProxyHandler.disableProxy();
    }

    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("CglibProxySource [superclass=");
        builder.append(this.superclass);
        builder.append("]");
        return builder.toString();
    }
}

