/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.commons.pool2.proxy;

import com.bx.magicSmp.libs.commons.pool2.UsageTracking;
import com.bx.magicSmp.libs.commons.pool2.proxy.BaseProxyHandler;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

final class JdkProxyHandler<T>
extends BaseProxyHandler<T>
implements InvocationHandler {
    JdkProxyHandler(T pooledObject, UsageTracking<T> usageTracking) {
        super(pooledObject, usageTracking);
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        return this.doInvoke(method, args);
    }
}

