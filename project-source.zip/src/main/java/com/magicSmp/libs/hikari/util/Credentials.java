/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.hikari.util;

import javax.management.ConstructorParameters;

public final class Credentials {
    private final String username;
    private final String password;

    public static Credentials of(String username, String password) {
        return new Credentials(username, password);
    }

    @ConstructorParameters(value={"username", "password"})
    public Credentials(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public String getUsername() {
        return this.username;
    }

    public String getPassword() {
        return this.password;
    }
}

