/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.hikari.metrics;

import com.bx.magicSmp.libs.hikari.metrics.IMetricsTracker;
import com.bx.magicSmp.libs.hikari.metrics.PoolStats;

public interface MetricsTrackerFactory {
    public IMetricsTracker create(String var1, PoolStats var2);
}

