/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.codahale.metrics.Gauge
 *  com.codahale.metrics.Histogram
 *  com.codahale.metrics.Meter
 *  com.codahale.metrics.Metric
 *  com.codahale.metrics.MetricRegistry
 *  com.codahale.metrics.Timer
 */
package com.bx.magicSmp.libs.hikari.metrics.dropwizard;

import com.bx.magicSmp.libs.hikari.metrics.IMetricsTracker;
import com.bx.magicSmp.libs.hikari.metrics.PoolStats;
import com.codahale.metrics.Gauge;
import com.codahale.metrics.Histogram;
import com.codahale.metrics.Meter;
import com.codahale.metrics.Metric;
import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.Timer;
import java.util.concurrent.TimeUnit;

public final class CodaHaleMetricsTracker
implements IMetricsTracker {
    private final String poolName;
    private final Timer connectionObtainTimer;
    private final Histogram connectionUsage;
    private final Histogram connectionCreation;
    private final Meter connectionTimeoutMeter;
    private final MetricRegistry registry;

    CodaHaleMetricsTracker(String poolName, PoolStats poolStats, MetricRegistry registry) {
        this.poolName = poolName;
        this.registry = registry;
        this.connectionObtainTimer = registry.timer(MetricRegistry.name((String)poolName, (String[])new String[]{"pool", "Wait"}));
        this.connectionUsage = registry.histogram(MetricRegistry.name((String)poolName, (String[])new String[]{"pool", "Usage"}));
        this.connectionCreation = registry.histogram(MetricRegistry.name((String)poolName, (String[])new String[]{"pool", "ConnectionCreation"}));
        this.connectionTimeoutMeter = registry.meter(MetricRegistry.name((String)poolName, (String[])new String[]{"pool", "ConnectionTimeoutRate"}));
        registry.register(MetricRegistry.name((String)poolName, (String[])new String[]{"pool", "TotalConnections"}), (Metric)((Gauge)poolStats::getTotalConnections));
        registry.register(MetricRegistry.name((String)poolName, (String[])new String[]{"pool", "IdleConnections"}), (Metric)((Gauge)poolStats::getIdleConnections));
        registry.register(MetricRegistry.name((String)poolName, (String[])new String[]{"pool", "ActiveConnections"}), (Metric)((Gauge)poolStats::getActiveConnections));
        registry.register(MetricRegistry.name((String)poolName, (String[])new String[]{"pool", "PendingConnections"}), (Metric)((Gauge)poolStats::getPendingThreads));
        registry.register(MetricRegistry.name((String)poolName, (String[])new String[]{"pool", "MaxConnections"}), (Metric)((Gauge)poolStats::getMaxConnections));
        registry.register(MetricRegistry.name((String)poolName, (String[])new String[]{"pool", "MinConnections"}), (Metric)((Gauge)poolStats::getMinConnections));
    }

    @Override
    public void close() {
        this.registry.remove(MetricRegistry.name((String)this.poolName, (String[])new String[]{"pool", "Wait"}));
        this.registry.remove(MetricRegistry.name((String)this.poolName, (String[])new String[]{"pool", "Usage"}));
        this.registry.remove(MetricRegistry.name((String)this.poolName, (String[])new String[]{"pool", "ConnectionCreation"}));
        this.registry.remove(MetricRegistry.name((String)this.poolName, (String[])new String[]{"pool", "ConnectionTimeoutRate"}));
        this.registry.remove(MetricRegistry.name((String)this.poolName, (String[])new String[]{"pool", "TotalConnections"}));
        this.registry.remove(MetricRegistry.name((String)this.poolName, (String[])new String[]{"pool", "IdleConnections"}));
        this.registry.remove(MetricRegistry.name((String)this.poolName, (String[])new String[]{"pool", "ActiveConnections"}));
        this.registry.remove(MetricRegistry.name((String)this.poolName, (String[])new String[]{"pool", "PendingConnections"}));
        this.registry.remove(MetricRegistry.name((String)this.poolName, (String[])new String[]{"pool", "MaxConnections"}));
        this.registry.remove(MetricRegistry.name((String)this.poolName, (String[])new String[]{"pool", "MinConnections"}));
    }

    @Override
    public void recordConnectionAcquiredNanos(long elapsedAcquiredNanos) {
        this.connectionObtainTimer.update(elapsedAcquiredNanos, TimeUnit.NANOSECONDS);
    }

    @Override
    public void recordConnectionUsageMillis(long elapsedBorrowedMillis) {
        this.connectionUsage.update(elapsedBorrowedMillis);
    }

    @Override
    public void recordConnectionTimeout() {
        this.connectionTimeoutMeter.mark();
    }

    @Override
    public void recordConnectionCreatedMillis(long connectionCreatedMillis) {
        this.connectionCreation.update(connectionCreatedMillis);
    }

    public Timer getConnectionAcquisitionTimer() {
        return this.connectionObtainTimer;
    }

    public Histogram getConnectionDurationHistogram() {
        return this.connectionUsage;
    }

    public Histogram getConnectionCreationHistogram() {
        return this.connectionCreation;
    }
}

