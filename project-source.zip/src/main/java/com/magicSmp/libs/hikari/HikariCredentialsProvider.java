/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.hikari;

import com.bx.magicSmp.libs.hikari.util.Credentials;

public interface HikariCredentialsProvider {
    public Credentials getCredentials();
}

