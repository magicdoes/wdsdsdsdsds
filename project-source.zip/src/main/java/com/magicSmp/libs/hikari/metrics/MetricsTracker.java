/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.libs.hikari.metrics;

import com.bx.magicSmp.libs.hikari.metrics.IMetricsTracker;

@Deprecated
public class MetricsTracker
implements IMetricsTracker {
}

