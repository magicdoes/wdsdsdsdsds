/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.codahale.metrics.MetricRegistry
 */
package com.bx.magicSmp.libs.hikari.metrics.dropwizard;

import com.bx.magicSmp.libs.hikari.metrics.IMetricsTracker;
import com.bx.magicSmp.libs.hikari.metrics.MetricsTrackerFactory;
import com.bx.magicSmp.libs.hikari.metrics.PoolStats;
import com.bx.magicSmp.libs.hikari.metrics.dropwizard.CodaHaleMetricsTracker;
import com.codahale.metrics.MetricRegistry;

public final class CodahaleMetricsTrackerFactory
implements MetricsTrackerFactory {
    private final MetricRegistry registry;

    public CodahaleMetricsTrackerFactory(MetricRegistry registry) {
        this.registry = registry;
    }

    public MetricRegistry getRegistry() {
        return this.registry;
    }

    @Override
    public IMetricsTracker create(String poolName, PoolStats poolStats) {
        return new CodaHaleMetricsTracker(poolName, poolStats, this.registry);
    }
}

