/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.dropwizard.metrics5.MetricRegistry
 */
package com.bx.magicSmp.libs.hikari.metrics.dropwizard;

import com.bx.magicSmp.libs.hikari.metrics.IMetricsTracker;
import com.bx.magicSmp.libs.hikari.metrics.MetricsTrackerFactory;
import com.bx.magicSmp.libs.hikari.metrics.PoolStats;
import com.bx.magicSmp.libs.hikari.metrics.dropwizard.Dropwizard5MetricsTracker;
import io.dropwizard.metrics5.MetricRegistry;

public class Dropwizard5MetricsTrackerFactory
implements MetricsTrackerFactory {
    private final MetricRegistry registry;

    public Dropwizard5MetricsTrackerFactory(MetricRegistry registry) {
        this.registry = registry;
    }

    public MetricRegistry getRegistry() {
        return this.registry;
    }

    @Override
    public IMetricsTracker create(String poolName, PoolStats poolStats) {
        return new Dropwizard5MetricsTracker(poolName, poolStats, this.registry);
    }
}

