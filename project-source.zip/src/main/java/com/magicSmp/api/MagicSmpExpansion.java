/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.api;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.api.EconomyExpansion;
import org.jetbrains.annotations.NotNull;

public class MagicSmpExpansion
extends EconomyExpansion {
    public MagicSmpExpansion(MagicSmp plugin) {
        super(plugin);
    }

    @Override
    @NotNull
    public String getIdentifier() {
        return "uds";
    }
}

