/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  me.clip.placeholderapi.expansion.PlaceholderExpansion
 *  org.bukkit.OfflinePlayer
 */
package com.bx.magicSmp.api;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.managers.LeaderboardManager;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class EconomyRankExpansion
extends PlaceholderExpansion {
    private final MagicSmp plugin;

    public EconomyRankExpansion(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @NotNull
    public String getIdentifier() {
        return "economyrank";
    }

    @NotNull
    public String getAuthor() {
        return "MagicSmp";
    }

    @NotNull
    public String getVersion() {
        return this.plugin.getDescription().getVersion();
    }

    public boolean persist() {
        return true;
    }

    @Nullable
    public String onRequest(OfflinePlayer player, @NotNull String params) {
        LeaderboardManager.LeaderboardType type;
        if (player == null || params.isBlank()) {
            return "0";
        }
        String typeKey = params;
        if (typeKey.startsWith("_")) {
            typeKey = typeKey.substring(1);
        }
        if ((type = (LeaderboardManager.LeaderboardType)this.plugin.getLeaderboardManager().parseType(typeKey).orElse(null)) == null) {
            return "0";
        }
        LeaderboardManager.LeaderboardEntry entry = this.plugin.getLeaderboardManager().getPlayerEntry(player.getUniqueId(), type);
        return entry == null ? "0" : String.valueOf(entry.position());
    }
}

