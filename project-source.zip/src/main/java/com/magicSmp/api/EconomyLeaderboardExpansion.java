/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  me.clip.placeholderapi.expansion.PlaceholderExpansion
 *  org.bukkit.OfflinePlayer
 */
package com.bx.magicSmp.api;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.managers.LeaderboardManager;
import java.util.Arrays;
import java.util.Locale;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class EconomyLeaderboardExpansion
extends PlaceholderExpansion {
    private final MagicSmp plugin;

    public EconomyLeaderboardExpansion(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @NotNull
    public String getIdentifier() {
        return "economylb";
    }

    @NotNull
    public String getAuthor() {
        return "MagicSmp";
    }

    @NotNull
    public String getVersion() {
        return this.plugin.getDescription().getVersion();
    }

    public boolean persist() {
        return true;
    }

    @Nullable
    public String onRequest(OfflinePlayer offlinePlayer, @NotNull String params) {
        if (params.isBlank()) {
            return null;
        }
        String[] parts = params.split("_");
        if (parts.length < 3) {
            return null;
        }
        int positionIndex = -1;
        for (int i = 1; i < parts.length - 1; ++i) {
            if (!this.isPositiveInteger(parts[i])) continue;
            positionIndex = i;
            break;
        }
        if (positionIndex < 1 || positionIndex >= parts.length - 1) {
            return null;
        }
        int position = Integer.parseInt(parts[positionIndex]);
        String typeKey = String.join((CharSequence)"_", Arrays.copyOfRange(parts, 0, positionIndex));
        String outputKey = String.join((CharSequence)"_", Arrays.copyOfRange(parts, positionIndex + 1, parts.length)).toLowerCase(Locale.US);
        LeaderboardManager.LeaderboardType type = this.plugin.getLeaderboardManager().parseType(typeKey).orElse(null);
        if (type == null) {
            return null;
        }
        LeaderboardManager.LeaderboardEntry entry = this.plugin.getLeaderboardManager().getEntryAt(type, position);
        String entryName = this.resolveEntryName(entry);
        String fullValue = entry == null ? "0" : this.plugin.getLeaderboardManager().formatValue(type, entry.playerData(), false, false);
        String shortValue = entry == null ? "0" : this.plugin.getLeaderboardManager().formatValue(type, entry.playerData(), true, false);
        return switch (outputKey) {
            case "name" -> entryName;
            case "value" -> fullValue;
            case "value_short", "value-short", "short" -> shortValue;
            case "rank" -> String.valueOf(position);
            case "display" -> "#" + position + " " + entryName + ": " + shortValue;
            default -> null;
        };
    }

    private String resolveEntryName(LeaderboardManager.LeaderboardEntry entry) {
        if (entry == null || entry.playerData() == null) {
            return "none";
        }
        String username = entry.playerData().getUsername();
        return username == null || username.isBlank() ? "unknown" : username;
    }

    private boolean isPositiveInteger(String input) {
        if (input == null || input.isBlank()) {
            return false;
        }
        for (int i = 0; i < input.length(); ++i) {
            if (Character.isDigit(input.charAt(i))) continue;
            return false;
        }
        return !input.equals("0");
    }
}

