/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  me.clip.placeholderapi.expansion.PlaceholderExpansion
 *  org.bukkit.OfflinePlayer
 */
package com.bx.magicSmp.api;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.api.LeaderboardPlaceholderResolver;
import com.bx.magicSmp.managers.CurrencyManager;
import com.bx.magicSmp.models.PlayerData;
import com.bx.magicSmp.stars.MagicStars;
import com.bx.magicSmp.utils.NumberUtils;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class EconomyExpansion
extends PlaceholderExpansion {
    private final MagicSmp plugin;
    private final LeaderboardPlaceholderResolver leaderboardPlaceholderResolver;

    public EconomyExpansion(MagicSmp plugin) {
        this.plugin = plugin;
        this.leaderboardPlaceholderResolver = new LeaderboardPlaceholderResolver(plugin);
    }

    @NotNull
    public String getIdentifier() {
        return "economy";
    }

    @NotNull
    public String getAuthor() {
        return "MagicSmp";
    }

    @NotNull
    public String getVersion() {
        return "1.1";
    }

    public boolean persist() {
        return true;
    }

    /*
     * WARNING - void declaration
     */
    @Nullable
    public String onRequest(OfflinePlayer offlinePlayer, @NotNull String string) {
        String params = string;
        OfflinePlayer offlinePlayer2 = offlinePlayer;
        if (string.equalsIgnoreCase("stars")) {
            if (offlinePlayer == null) {
                return "0";
            }
            return MagicStars.format(MagicStars.getBalance(offlinePlayer.getUniqueId()));
        }
        String leaderboardValue = this.leaderboardPlaceholderResolver.resolve((OfflinePlayer)offlinePlayer2, (String)params);
        if (leaderboardValue != null) {
            return leaderboardValue;
        }
        if (params.equalsIgnoreCase("ping")) {
            if (offlinePlayer2 == null || !offlinePlayer2.isOnline()) {
                return "0";
            }
            return String.valueOf(this.plugin.getPingManager().getPing(offlinePlayer2.getPlayer()));
        }
        if (params.equalsIgnoreCase("username")) {
            if (offlinePlayer2 == null) {
                return "unknown";
            }
            return offlinePlayer2.getName() != null ? offlinePlayer2.getName() : "unknown";
        }
        if (params.equalsIgnoreCase("online_staff") || params.equalsIgnoreCase("staff") || params.equalsIgnoreCase("is_staff")) {
            int staffCount = 0;
            for (Player player : this.plugin.getServer().getOnlinePlayers()) {
                if (!player.isOp() && !player.hasPermission("tab.staff")) continue;
                ++staffCount;
            }
            return String.valueOf(staffCount);
        }
        if (params.equalsIgnoreCase("sell_event_active")) {
            return this.plugin.getSellEventManager().isEventActive() ? "true" : "false";
        }
        if (params.equalsIgnoreCase("sell_event_multiplier")) {
            return String.valueOf(this.plugin.getSellEventManager().getMultiplier());
        }
        if (params.equalsIgnoreCase("sell_event_remaining")) {
            return String.valueOf(this.plugin.getSellEventManager().getRemainingSeconds());
        }
        CurrencyManager currencyManager = this.plugin.getCurrencyManager();
        if (params.equalsIgnoreCase("money_symbol")) {
            return currencyManager.symbol(CurrencyManager.CurrencyType.MONEY);
        }
        if (params.equalsIgnoreCase("money_symbol_color")) {
            return currencyManager.symbolColor(CurrencyManager.CurrencyType.MONEY);
        }
        if (params.equalsIgnoreCase("money_symbol_colored")) {
            return currencyManager.coloredSymbol(CurrencyManager.CurrencyType.MONEY);
        }
        if (params.equalsIgnoreCase("money_color")) {
            return currencyManager.color(CurrencyManager.CurrencyType.MONEY);
        }
        if (params.equalsIgnoreCase("money_name")) {
            return currencyManager.singular(CurrencyManager.CurrencyType.MONEY);
        }
        if (params.equalsIgnoreCase("money_name_plural")) {
            return currencyManager.plural(CurrencyManager.CurrencyType.MONEY);
        }
        if (params.equalsIgnoreCase("team")) {
            if (offlinePlayer2 == null) {
                return "none";
            }
            String team = offlinePlayer2.isOnline() ? this.plugin.getTeamManager().getTeamName(offlinePlayer2.getPlayer()) : null;
            return team != null ? team.toUpperCase() : "none";
        }
        if (offlinePlayer2 == null) {
            return "";
        }
        PlayerData data = this.plugin.getPlayerDataManager().get(offlinePlayer2.getUniqueId());
        if (data == null && offlinePlayer2.isOnline()) {
            data = this.plugin.getPlayerDataManager().get(offlinePlayer2.getPlayer());
        }
        if (data == null && offlinePlayer2.getUniqueId() != null) {
            data = this.plugin.getDatabaseManager().loadPlayer(offlinePlayer2.getUniqueId());
        }
        if (data == null) {
            return switch (params) {
                case "nicestMoney", "money_short", "money_amount_short", "nicestmoney" -> currencyManager.formatCompactAmount(CurrencyManager.CurrencyType.MONEY, 0.0);
                case "money_formatted", "money-formatted" -> currencyManager.formatMoney(0.0);
                case "money_short_formatted", "nicestMoney_formatted", "nicestmoney_formatted" -> currencyManager.formatMoneyCompact(0.0);
                default -> "0";
            };
        }
        return switch (params) {
            case "donutplus", "display_donutplus" -> {
                if (offlinePlayer2 == null || !offlinePlayer2.isOnline()) {
                    yield "";
                }
                Player p = offlinePlayer2.getPlayer();
                if (p != null && data.isDisplayDonutPlusEnabled() && (p.hasPermission("MagicSmp.donutplus") || p.hasPermission("donutplus"))) {
                    yield "&d&lDonut+ &r";
                }
                yield "";
            }
            case "money" -> NumberUtils.format(data.getMoney());
            case "nicestMoney", "money_short", "money_amount_short", "nicestmoney" -> currencyManager.formatCompactAmount(CurrencyManager.CurrencyType.MONEY, data.getMoney());
            case "money_formatted", "money-formatted" -> currencyManager.formatMoney(data.getMoney());
            case "money_short_formatted", "nicestMoney_formatted", "nicestmoney_formatted" -> currencyManager.formatMoneyCompact(data.getMoney());
            case "kills" -> String.valueOf(data.getKills());
            case "deaths" -> String.valueOf(data.getDeaths());
            case "playtime" -> NumberUtils.formatTimeLong(data.getTotalPlaytimeSeconds());
            case "killStreak", "killstreak" -> String.valueOf(data.getKillStreak());
            case "highestKillStreak", "highestkillstreak" -> String.valueOf(data.getHighestKillStreak());
            case "blocksPlaced", "blocksplaced" -> String.valueOf(data.getBlocksPlaced());
            case "blocksBroken", "blocksbroken" -> String.valueOf(data.getBlocksBroken());
            case "mobsKilled", "mobskilled" -> String.valueOf(data.getMobsKilled());
            case "moneySpent", "moneyspent" -> NumberUtils.format(data.getMoneySpent());
            case "moneyMade", "moneymade" -> NumberUtils.format(data.getMoneyMade());
            case "x", "coord_x", "coords_x" -> {
                if (offlinePlayer2 == null || !offlinePlayer2.isOnline() || offlinePlayer2.getPlayer() == null) {
                    yield "0";
                }
                yield String.valueOf(data.getDisplayX(offlinePlayer2.getPlayer().getLocation().getBlockX()));
            }
            case "y", "coord_y", "coords_y" -> {
                if (offlinePlayer2 == null || !offlinePlayer2.isOnline() || offlinePlayer2.getPlayer() == null) {
                    yield "0";
                }
                yield String.valueOf(data.getDisplayY(offlinePlayer2.getPlayer().getLocation().getBlockY()));
            }
            case "z", "coord_z", "coords_z" -> {
                if (offlinePlayer2 == null || !offlinePlayer2.isOnline() || offlinePlayer2.getPlayer() == null) {
                    yield "0";
                }
                yield String.valueOf(data.getDisplayZ(offlinePlayer2.getPlayer().getLocation().getBlockZ()));
            }
            case "coords", "location", "formatted_coords" -> {
                if (offlinePlayer2 == null || !offlinePlayer2.isOnline() || offlinePlayer2.getPlayer() == null) {
                    yield "0, 0, 0";
                }
                yield data.getDisplayCoords(offlinePlayer2.getPlayer().getLocation());
            }
            case "randomized_coords", "randomized_coords_enabled" -> String.valueOf(data.isRandomizedCoords());
            default -> null;
        };
    }
}

