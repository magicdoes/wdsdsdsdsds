/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.permissions.Permissible
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.managers.DatabaseManager;
import com.bx.magicSmp.models.ProfileSnapshot;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.PermissionUtils;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.permissions.Permissible;

public class AltsCommand
implements CommandExecutor {
    private static final String PERMISSION = "MagicSmp.staff.alts";
    private final MagicSmp plugin;

    public AltsCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Player player;
        if (sender instanceof Player && !PermissionUtils.has((Permissible)(player = (Player)sender), PERMISSION)) {
            player.sendMessage(ColorUtils.toComponent("&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274."));
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("ALTS.USAGE", "&c\u1d1c\u0455\u1d00\u0262\u1d07: /alts <player>")));
            return true;
        }
        ProfileSnapshot snapshot = this.plugin.getProfileViewerManager().resolveProfile(args[0]).orElse(null);
        if (snapshot == null) {
            sender.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("ALTS.NOT_FOUND", "&c\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u0274\u1d0f\u1d1b \ua730\u1d0f\u1d1c\u0274\u1d05.")));
            return true;
        }
        List<String> knownIps = this.plugin.getDatabaseManager().loadKnownIpAddresses(snapshot.getUuid());
        if (knownIps.isEmpty()) {
            sender.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("ALTS.NO_DATA", "&c\u0274\u1d0f \u026a\u1d18 \u029c\u026a\u0455\u1d1b\u1d0f\u0280\u028f \ua730\u1d0f\u1d1c\u0274\u1d05 \ua730\u1d0f\u0280 \u1d1b\u029c\u1d00\u1d1b \u1d18\u029f\u1d00\u028f\u1d07\u0280.")));
            return true;
        }
        List<DatabaseManager.AltAccountMatch> matches = this.plugin.getDatabaseManager().loadAltAccounts(snapshot.getUuid());
        sender.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("ALTS.HEADER", "&8[&6\u1d00\u029f\u1d1b\u0455&8] &e%player%").replace("%player%", snapshot.getUsername())));
        sender.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("ALTS.KNOWN_IPS", "&7\u1d0b\u0274\u1d0f\u1d21\u0274 \u026a\u1d18\u0455: &f%ips%").replace("%ips%", String.join((CharSequence)", ", knownIps))));
        if (matches.isEmpty()) {
            sender.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("ALTS.NONE", "&7\u0274\u1d0f \u1d00\u029f\u1d1b\u1d07\u0280\u0274\u1d00\u1d1b\u1d07 \u1d00\u1d04\u1d04\u1d0f\u1d1c\u0274\u1d1b\u0455 \ua730\u1d0f\u1d1c\u0274\u1d05.")));
            return true;
        }
        for (DatabaseManager.AltAccountMatch match : matches) {
            boolean online = Bukkit.getPlayer(match.uuid()) != null;
            sender.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("ALTS.ENTRY", "&8- &e%player% &7[%status%&7] &f\u0455\u029c\u1d00\u0280\u1d07\u1d05: %ips%").replace("%player%", match.username()).replace("%status%", online ? "&a\u1d0f\u0274\u029f\u026a\u0274\u1d07" : "&c\u1d0f\ua730\ua730\u029f\u026a\u0274\u1d07").replace("%ips%", String.join((CharSequence)", ", match.sharedIps()))));
        }
        return true;
    }
}

