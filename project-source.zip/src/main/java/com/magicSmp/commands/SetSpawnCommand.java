/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.permissions.Permissible
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.managers.SpawnManager;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.PermissionUtils;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.permissions.Permissible;

public class SetSpawnCommand
implements CommandExecutor {
    private static final String PERMISSION = "MagicSMP.command.setspawn";
    private static final String SETUP_PERMISSION = "MagicSMP.admin.setup";
    private final MagicSmp plugin;

    public SetSpawnCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Only players can save spawn locations.");
            return true;
        }
        Player player = (Player)sender;
        if (!PermissionUtils.has((Permissible)player, PERMISSION) && !PermissionUtils.has((Permissible)player, SETUP_PERMISSION)) {
            player.sendMessage(ColorUtils.toComponent("&cYou do not have permission to set spawn."));
            return true;
        }
        Location location = player.getLocation();
        SpawnManager.SetupLocationResult result = this.plugin.getSpawnManager().setSpawnLocation(location);
        if (!result.success()) {
            player.sendMessage(ColorUtils.toComponent("&cSpawn location could not be saved: &f" + result.message()));
            return true;
        }
        player.sendMessage(ColorUtils.toComponent("&aSpawn location saved. &7(World: &f" + (location.getWorld() == null ? "unknown" : location.getWorld().getName()) + "&7, X: &f" + String.format("%.1f", location.getX()) + "&7, Y: &f" + String.format("%.1f", location.getY()) + "&7, Z: &f" + String.format("%.1f", location.getZ()) + "&7)"));
        return true;
    }
}

