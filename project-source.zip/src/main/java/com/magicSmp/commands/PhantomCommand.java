/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.models.PlayerData;
import com.bx.magicSmp.utils.ColorUtils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class PhantomCommand
implements CommandExecutor {
    private final MagicSmp plugin;

    public PhantomCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u1d0f\u0274\u029f\u028f.");
            return true;
        }
        Player player = (Player)sender;
        PlayerData data = this.plugin.getPlayerDataManager().get(player);
        if (data == null) {
            return true;
        }
        data.setPhantomEnabled(!data.isPhantomEnabled());
        String msg = data.isPhantomEnabled() ? this.plugin.getConfigManager().getMessage("PHANTOM.DISABLED") : this.plugin.getConfigManager().getMessage("PHANTOM.ENABLED");
        player.sendMessage(ColorUtils.toComponent(msg));
        return true;
    }
}

