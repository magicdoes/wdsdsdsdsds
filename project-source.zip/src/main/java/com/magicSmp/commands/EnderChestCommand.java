/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.permissions.Permissible
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.PermissionUtils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.permissions.Permissible;

public class EnderChestCommand
implements CommandExecutor {
    private static final String ADMIN_PERMISSION = "MagicSmp.admin.enderchest";
    private final MagicSmp plugin;

    public EnderChestCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            if (!PermissionUtils.has((Permissible)sender, ADMIN_PERMISSION)) {
                sender.sendMessage(ColorUtils.toComponent(this.plugin.getEnderChestManager().getMessage("NO-PERMISSION", "&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274.")));
                return true;
            }
            this.plugin.getConfigManager().reloadEnderChest();
            this.plugin.getEnderChestManager().reload();
            sender.sendMessage(ColorUtils.toComponent(this.plugin.getEnderChestManager().getMessage("RELOAD-SUCCESS", "&a\u1d07\u0274\u1d05\u1d07\u0280 \u1d04\u029c\u1d07\u0455\u1d1b \u1d04\u1d0f\u0274\ua730\u026a\u0262 \u0280\u1d07\u029f\u1d0f\u1d00\u1d05\u1d07\u1d05.")));
            return true;
        }
        if (!(sender instanceof Player)) {
            sender.sendMessage("\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u1d0f\u0274\u029f\u028f.");
            return true;
        }
        Player player = (Player)sender;
        if (!this.plugin.getEnderChestManager().isEnabled()) {
            player.sendMessage(ColorUtils.toComponent(this.plugin.getEnderChestManager().getMessage("FEATURE-DISABLED", "&c\u1d1b\u029c\u1d07 \u1d07\u0274\u1d05\u1d07\u0280 \u1d04\u029c\u1d07\u0455\u1d1b 6 \u0280\u1d0f\u1d21\u0455 \u0455\u028f\u0455\u1d1b\u1d07\u1d0d \u026a\u0455 \u1d05\u026a\u0455\u1d00\u0299\u029f\u1d07\u1d05.")));
            return true;
        }
        if (!this.plugin.getEnderChestManager().isCommandAllowed()) {
            player.sendMessage(ColorUtils.toComponent(this.plugin.getEnderChestManager().getMessage("COMMAND-DISABLED", "&c\u1d1b\u029c\u1d07 /enderchest \u1d04\u1d0f\u1d0d\u1d0d\u1d00\u0274\u1d05 \u026a\u0455 \u1d05\u026a\u0455\u1d00\u0299\u029f\u1d07\u1d05.")));
            return true;
        }
        if (this.plugin.getEnderChestManager().commandRequiresPermission() && !PermissionUtils.has((Permissible)player, this.plugin.getEnderChestManager().getCommandPermission())) {
            player.sendMessage(ColorUtils.toComponent(this.plugin.getEnderChestManager().getMessage("NO-PERMISSION", "&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274.")));
            return true;
        }
        this.plugin.getEnderChestManager().open(player);
        return true;
    }
}

