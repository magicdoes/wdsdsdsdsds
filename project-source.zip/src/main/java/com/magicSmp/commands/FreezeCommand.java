/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.managers.FreezeManager;
import com.bx.magicSmp.models.FreezeState;
import com.bx.magicSmp.utils.ColorUtils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class FreezeCommand
implements CommandExecutor {
    private final MagicSmp plugin;

    public FreezeCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        FreezeManager freezeManager = this.plugin.getFreezeManager();
        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            if (!freezeManager.canAdmin(sender)) {
                sender.sendMessage(ColorUtils.toComponent(freezeManager.getMessage("NO-PERMISSION", "&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274.")));
                return true;
            }
            this.plugin.getConfigManager().reloadFreeze();
            freezeManager.reload();
            sender.sendMessage(ColorUtils.toComponent(freezeManager.getMessage("RELOAD-SUCCESS", "&a\ua730\u0280\u1d07\u1d07\u1d22\u1d07 \u1d04\u1d0f\u0274\ua730\u026a\u0262 \u0280\u1d07\u029f\u1d0f\u1d00\u1d05\u1d07\u1d05.")));
            return true;
        }
        if (!freezeManager.isEnabled()) {
            sender.sendMessage(ColorUtils.toComponent(freezeManager.getMessage("FEATURE-DISABLED", "&c\u1d1b\u029c\u1d07 \ua730\u0280\u1d07\u1d07\u1d22\u1d07 \u0455\u028f\u0455\u1d1b\u1d07\u1d0d \u026a\u0455 \u1d05\u026a\u0455\u1d00\u0299\u029f\u1d07\u1d05.")));
            return true;
        }
        if (!freezeManager.canUse(sender)) {
            sender.sendMessage(ColorUtils.toComponent(freezeManager.getMessage("NO-PERMISSION", "&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274.")));
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage(ColorUtils.toComponent("&c\u1d1c\u0455\u1d00\u0262\u1d07: /" + label + " <player>"));
            return true;
        }
        Player target = freezeManager.findOnlineTarget(args[0]);
        if (target != null) {
            if (freezeManager.hasActiveFreeze(target.getUniqueId())) {
                FreezeManager.FreezeToggleResult result = freezeManager.unfreeze(sender, target.getUniqueId());
                if (result != null) {
                    sender.sendMessage(ColorUtils.toComponent(freezeManager.buildToggleMessage(result)));
                }
                return true;
            }
            if (freezeManager.isSelfTarget(sender, target)) {
                sender.sendMessage(ColorUtils.toComponent(freezeManager.getMessage("SELF-TARGET", "&c\u028f\u1d0f\u1d1c \u1d04\u1d00\u0274\u0274\u1d0f\u1d1b \ua730\u0280\u1d07\u1d07\u1d22\u1d07 \u028f\u1d0f\u1d1c\u0280\u0455\u1d07\u029f\ua730.")));
                return true;
            }
            if (!freezeManager.canFreeze(sender, target)) {
                sender.sendMessage(ColorUtils.toComponent(freezeManager.getMessage("TARGET-EXEMPT", "&c\u028f\u1d0f\u1d1c \u1d04\u1d00\u0274\u0274\u1d0f\u1d1b \ua730\u0280\u1d07\u1d07\u1d22\u1d07 \u1d1b\u029c\u1d00\u1d1b \u1d18\u029f\u1d00\u028f\u1d07\u0280.")));
                return true;
            }
            FreezeManager.FreezeToggleResult result = freezeManager.freeze(sender, target);
            if (result != null) {
                sender.sendMessage(ColorUtils.toComponent(freezeManager.buildToggleMessage(result)));
            }
            return true;
        }
        FreezeState frozenState = freezeManager.findActiveState(args[0]);
        if (frozenState != null) {
            FreezeManager.FreezeToggleResult result = freezeManager.unfreeze(sender, frozenState.getTargetUuid());
            if (result != null) {
                sender.sendMessage(ColorUtils.toComponent(freezeManager.buildToggleMessage(result)));
            }
            return true;
        }
        String path = freezeManager.hasKnownPlayer(args[0]) ? "TARGET-OFFLINE" : "PLAYER-NOT-FOUND";
        String fallback = freezeManager.hasKnownPlayer(args[0]) ? "&cthat player must be online." : "&cplayer not found.";
        sender.sendMessage(ColorUtils.toComponent(freezeManager.getMessage(path, fallback)));
        return true;
    }
}

