/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.permissions.Permissible
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.PermissionUtils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.permissions.Permissible;

public class ClearLagCommand
implements CommandExecutor {
    private final MagicSmp plugin;

    public ClearLagCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!PermissionUtils.has((Permissible)sender, "MagicSmp.admin.clearlag")) {
            sender.sendMessage(ColorUtils.toComponent("&c\u0274\u1d0f \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274."));
            return true;
        }
        this.plugin.getClearLagManager().clearEntities();
        return true;
    }
}

