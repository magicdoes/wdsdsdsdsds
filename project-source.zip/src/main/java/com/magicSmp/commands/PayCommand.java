/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.menus.PayConfirmMenu;
import com.bx.magicSmp.models.PlayerData;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.NumberUtils;
import com.bx.magicSmp.utils.PaymentUtils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class PayCommand
implements CommandExecutor {
    private final MagicSmp plugin;

    public PayCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        double amount;
        if (!(sender instanceof Player)) {
            sender.sendMessage("\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u1d0f\u0274\u029f\u028f.");
            return true;
        }
        Player player = (Player)sender;
        if (args.length < 2) {
            player.sendMessage(ColorUtils.toComponent("&c\u1d1c\u0455\u1d00\u0262\u1d07: /pay <player> <amount>"));
            return true;
        }
        if (args[0].equalsIgnoreCase(player.getName())) {
            player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessage("BALANCE.PAY.CANT-PAY-SELF")));
            return true;
        }
        try {
            amount = NumberUtils.parse(args[1]);
        }
        catch (NumberFormatException e) {
            player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessage("BALANCE.PAY.INVALID-AMOUNT")));
            return true;
        }
        if (amount <= 0.0) {
            player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessage("BALANCE.PAY.MUST-BE-POSITIVE")));
            return true;
        }
        PlayerData senderData = this.plugin.getPlayerDataManager().get(player);
        if (senderData != null && senderData.isPayConfirmMenuEnabled()) {
            new PayConfirmMenu(this.plugin, args[0], amount).open(player);
            return true;
        }
        PaymentUtils.transferMoney(this.plugin, player, args[0], amount);
        return true;
    }
}

