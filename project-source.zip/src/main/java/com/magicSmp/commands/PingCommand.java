/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.PlayerLookup;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class PingCommand
implements CommandExecutor {
    private final MagicSmp plugin;

    public PingCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length > 1) {
            sender.sendMessage(ColorUtils.toComponent("&c\u1d1c\u0455\u1d00\u0262\u1d07: /" + label + " [\u1d18\u029f\u1d00\u028f\u1d07\u0280]"));
            return true;
        }
        if (args.length == 0) {
            if (!(sender instanceof Player)) {
                sender.sendMessage(ColorUtils.toComponent("&c\u1d1c\u0455\u1d00\u0262\u1d07: /" + label + " <player>"));
                return true;
            }
            Player player = (Player)sender;
            player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("PING.SELF", "&7\u028f\u1d0f\u1d1c\u0280 \u1d18\u026a\u0274\u0262 \u026a\u0455 &b%ping%\u1d0d\u0455", "%ping%", String.valueOf(this.plugin.getPingManager().getPing(player))), player));
            return true;
        }
        Player target = PlayerLookup.findOnlinePlayer(args[0]);
        if (target == null) {
            sender.sendMessage(ColorUtils.toComponent("&c\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u0274\u1d0f\u1d1b \u1d0f\u0274\u029f\u026a\u0274\u1d07."));
            return true;
        }
        sender.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("PING.OTHER", "&e%player%'\u0455 &7\u1d18\u026a\u0274\u0262 \u026a\u0455 &b%ping%\u1d0d\u0455", "%player%", target.getName(), "%ping%", String.valueOf(this.plugin.getPingManager().getPing(target)))));
        return true;
    }
}

