/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.md_5.bungee.api.chat.BaseComponent
 *  net.md_5.bungee.api.chat.ClickEvent
 *  net.md_5.bungee.api.chat.ClickEvent$Action
 *  net.md_5.bungee.api.chat.HoverEvent
 *  net.md_5.bungee.api.chat.HoverEvent$Action
 *  net.md_5.bungee.api.chat.TextComponent
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.menus.TeamDisbandConfirmMenu;
import com.bx.magicSmp.menus.TeamMenu;
import com.bx.magicSmp.models.PlayerData;
import com.bx.magicSmp.models.Team;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.PlayerLookup;
import java.util.UUID;
import net.md_5.bungee.api.chat.BaseComponent;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class TeamCommand
implements CommandExecutor {
    private final MagicSmp plugin;

    public TeamCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u1d0f\u0274\u029f\u028f.");
            return true;
        }
        Player player = (Player)sender;
        if (args.length == 0) {
            new TeamMenu(this.plugin).open(player);
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "create": {
                this.handleCreate(player, args);
                break;
            }
            case "disband": {
                this.handleDisband(player);
                break;
            }
            case "invite": {
                this.handleInvite(player, args);
                break;
            }
            case "join": {
                this.handleJoin(player, args);
                break;
            }
            case "leave": {
                this.handleLeave(player);
                break;
            }
            case "kick": {
                this.handleKick(player, args);
                break;
            }
            case "home": {
                this.handleHome(player);
                break;
            }
            case "sethome": {
                this.handleSetHome(player);
                break;
            }
            case "delhome": {
                this.handleDeleteHome(player);
                break;
            }
            case "chat": {
                this.handleChat(player);
                break;
            }
            case "pvp": {
                this.handlePvp(player);
                break;
            }
            default: {
                new TeamMenu(this.plugin).open(player);
            }
        }
        return true;
    }

    private void handleCreate(Player player, String[] args) {
        if (args.length < 2) {
            this.send(player, "&c\u1d1c\u0455\u1d00\u0262\u1d07: /team \u1d04\u0280\u1d07\u1d00\u1d1b\u1d07 <name>");
            return;
        }
        String name = args[1];
        if (!this.plugin.getTeamManager().isValidName(name)) {
            this.send(player, "&c\u1d1b\u1d07\u1d00\u1d0d \u0274\u1d00\u1d0d\u1d07 \u1d0d\u1d1c\u0455\u1d1b \u0299\u1d07 3-5 \u1d00\u029f\u1d18\u029c\u1d00\u0274\u1d1c\u1d0d\u1d07\u0280\u026a\u1d04 \u1d04\u029c\u1d00\u0280\u1d00\u1d04\u1d1b\u1d07\u0280\u0455.");
            return;
        }
        if (this.plugin.getTeamManager().isInTeam(player)) {
            this.send(player, this.plugin.getConfigManager().getMessage("TEAM.ALREADY-IN-TEAM"));
            return;
        }
        if (this.plugin.getTeamManager().teamExists(name)) {
            this.send(player, this.plugin.getConfigManager().getMessage("TEAM.ALREADY-EXISTS"));
            return;
        }
        this.plugin.getTeamManager().createTeam(player, name);
        this.send(player, this.plugin.getConfigManager().getMessage("TEAM.TEAM-CREATED"));
    }

    private void handleDisband(Player player) {
        Team team = this.plugin.getTeamManager().getTeam(player);
        if (team == null) {
            this.send(player, this.plugin.getConfigManager().getMessage("TEAM.NO-TEAM"));
            return;
        }
        if (!team.isLeader(player.getUniqueId())) {
            this.send(player, this.plugin.getConfigManager().getMessage("TEAM.NOT-LEADER"));
            return;
        }
        new TeamDisbandConfirmMenu(this.plugin).open(player);
    }

    private void handleInvite(Player player, String[] args) {
        if (args.length < 2) {
            this.send(player, "&c\u1d1c\u0455\u1d00\u0262\u1d07: /team \u026a\u0274\u1d20\u026a\u1d1b\u1d07 <player>");
            return;
        }
        Team team = this.plugin.getTeamManager().getTeam(player);
        if (team == null) {
            this.send(player, this.plugin.getConfigManager().getMessage("TEAM.NO-TEAM"));
            return;
        }
        if (!this.plugin.getTeamManager().canManageTeammates(team, player.getUniqueId())) {
            this.send(player, this.plugin.getConfigManager().getMessage("TEAM.NO-MANAGE-PERMISSION"));
            return;
        }
        if (args[1].equalsIgnoreCase(player.getName())) {
            this.send(player, "&c\u028f\u1d0f\u1d1c \u1d04\u1d00\u0274\u0274\u1d0f\u1d1b \u026a\u0274\u1d20\u026a\u1d1b\u1d07 \u028f\u1d0f\u1d1c\u0280\u0455\u1d07\u029f\ua730!");
            return;
        }
        int maxMembers = this.plugin.getConfigManager().getConfig().getInt("TEAM.LIMIT-MEMBERS", 10);
        if (team.getMemberCount() >= maxMembers) {
            this.send(player, this.plugin.getConfigManager().getMessage("TEAM.TEAM-FULL"));
            return;
        }
        Player target = PlayerLookup.findOnlinePlayer(args[1]);
        if (target == null) {
            this.send(player, "&c\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u0274\u1d0f\u1d1b \u1d0f\u0274\u029f\u026a\u0274\u1d07.");
            return;
        }
        if (target.getUniqueId().equals(player.getUniqueId())) {
            this.send(player, this.plugin.getConfigManager().getMessage("TEAM.CANNOT-INVITE-YOURSELF"));
            return;
        }
        PlayerData targetData = this.plugin.getPlayerDataManager().get(target);
        if (targetData != null && !targetData.isTeamInvitesEnabled()) {
            this.send(player, this.plugin.getConfigManager().getMessage("TEAM.PLAYER-NO-INVITES"));
            return;
        }
        if (this.plugin.getTeamManager().isInTeam(target)) {
            this.send(player, this.plugin.getConfigManager().getMessage("TEAM.PLAYER-IN-TEAM", "{player}", this.publicName(target)));
            return;
        }
        this.plugin.getTeamManager().sendInvite(player, target);
        this.send(player, this.plugin.getConfigManager().getMessage("TEAM.INVITE-SENT", "{player}", this.publicName(target)));
        String joinCommand = "/team join " + team.getName();
        TextComponent inviteMessage = ColorUtils.toBaseComponent(this.plugin.getConfigManager().getMessage("TEAM.INVITED-TO-JOIN", "{team}", team.getName()));
        inviteMessage.addExtra(" ");
        TextComponent joinPart = ColorUtils.toBaseComponent(this.plugin.getConfigManager().getMessage("TEAM.CLICK-TO-JOIN"));
        joinPart.setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, joinCommand));
        joinPart.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, ColorUtils.toBaseComponents(this.plugin.getConfigManager().getMessage("TEAM.HOVER-JOIN", "{team}", team.getName()))));
        inviteMessage.addExtra((BaseComponent)joinPart);
        target.spigot().sendMessage((BaseComponent)inviteMessage);
    }

    private void handleJoin(Player player, String[] args) {
        if (args.length < 2) {
            this.send(player, "&c\u1d1c\u0455\u1d00\u0262\u1d07: /team \u1d0a\u1d0f\u026a\u0274 <team>");
            return;
        }
        if (this.plugin.getTeamManager().isInTeam(player)) {
            this.send(player, this.plugin.getConfigManager().getMessage("TEAM.ALREADY-IN-TEAM"));
            return;
        }
        String teamName = args[1];
        if (!this.plugin.getTeamManager().hasInviteFrom(player, teamName)) {
            this.send(player, this.plugin.getConfigManager().getMessage("TEAM.NO-PENDING-INVITES", "{team}", teamName));
            return;
        }
        boolean joined = this.plugin.getTeamManager().joinTeam(player, teamName);
        if (!joined) {
            this.send(player, this.plugin.getConfigManager().getMessage("TEAM.TEAM-FULL"));
            return;
        }
        Team team = this.plugin.getTeamManager().getTeam(player);
        String resolvedTeamName = team != null ? team.getName() : teamName;
        this.send(player, this.plugin.getConfigManager().getMessage("TEAM.JOIN-SUCCESS", "{team}", resolvedTeamName));
        if (team != null) {
            String broadcast = this.plugin.getConfigManager().getMessage("TEAM.JOINED-BROADCAST", "{player}", this.publicName(player));
            for (UUID memberUuid : team.getMemberUuids()) {
                Player member = Bukkit.getPlayer(memberUuid);
                if (member == null || member.getUniqueId().equals(player.getUniqueId())) continue;
                member.sendMessage(ColorUtils.toComponent(broadcast));
            }
        }
    }

    private void handleLeave(Player player) {
        if (!this.plugin.getTeamManager().isInTeam(player)) {
            this.send(player, this.plugin.getConfigManager().getMessage("TEAM.NO-TEAM"));
            return;
        }
        Team team = this.plugin.getTeamManager().getTeam(player);
        if (team != null && team.isLeader(player.getUniqueId())) {
            new TeamDisbandConfirmMenu(this.plugin).open(player);
            return;
        }
        this.plugin.getTeamManager().leaveTeam(player);
        this.send(player, "&7\u028f\u1d0f\u1d1c \u029f\u1d07\ua730\u1d1b \u1d1b\u029c\u1d07 \u1d1b\u1d07\u1d00\u1d0d.");
    }

    private void handleKick(Player player, String[] args) {
        if (args.length < 2) {
            this.send(player, "&c\u1d1c\u0455\u1d00\u0262\u1d07: /team \u1d0b\u026a\u1d04\u1d0b <player>");
            return;
        }
        Team team = this.plugin.getTeamManager().getTeam(player);
        if (team == null) {
            this.send(player, this.plugin.getConfigManager().getMessage("TEAM.NO-TEAM"));
            return;
        }
        if (!this.plugin.getTeamManager().canManageTeammates(team, player.getUniqueId())) {
            this.send(player, this.plugin.getConfigManager().getMessage("TEAM.NO-MANAGE-PERMISSION"));
            return;
        }
        if (args[1].equalsIgnoreCase(player.getName())) {
            this.send(player, this.plugin.getConfigManager().getMessage("TEAM.CANT-KICK-SELF"));
            return;
        }
        UUID targetUuid = this.resolvePlayerUuid(player, args[1]);
        if (targetUuid == null) {
            this.send(player, this.plugin.getConfigManager().getMessage("TEAM.TEAM-NOT-EXIST"));
            return;
        }
        boolean kicked = this.plugin.getTeamManager().kickMember(team, targetUuid);
        this.send(player, kicked ? this.plugin.getConfigManager().getMessage("TEAM.KICK-SUCCESS", "{player}", args[1]) : this.plugin.getConfigManager().getMessage("TEAM.PLAYER-NOT-IN-TEAM", "{player}", args[1]));
    }

    private void handleHome(Player player) {
        Team team = this.plugin.getTeamManager().getTeam(player);
        if (team == null) {
            this.send(player, this.plugin.getConfigManager().getMessage("TEAM.NO-TEAM"));
            return;
        }
        if (!this.plugin.getTeamManager().canVisitHome(team, player.getUniqueId())) {
            this.send(player, this.plugin.getConfigManager().getMessage("TEAM.NO-VISIT-HOME-PERMISSION"));
            return;
        }
        if (!team.hasHome()) {
            this.send(player, this.plugin.getConfigManager().getMessage("TEAM.NO-TEAM-HOME"));
            return;
        }
        this.plugin.getTeleportManager().queue(player, team.getHome(), "TEAM-HOME", null);
    }

    private void handleSetHome(Player player) {
        Team team = this.plugin.getTeamManager().getTeam(player);
        if (team == null) {
            this.send(player, this.plugin.getConfigManager().getMessage("TEAM.NO-TEAM"));
            return;
        }
        if (!this.plugin.getTeamManager().canEditHome(team, player.getUniqueId())) {
            this.send(player, this.plugin.getConfigManager().getMessage("TEAM.NO-EDIT-HOME-PERMISSION"));
            return;
        }
        team.setHome(player.getLocation());
        this.plugin.getTeamManager().save(team);
        this.send(player, this.plugin.getConfigManager().getMessage("TEAM.TEAM-HOME-SET"));
    }

    private void handleDeleteHome(Player player) {
        Team team = this.plugin.getTeamManager().getTeam(player);
        if (team == null) {
            this.send(player, this.plugin.getConfigManager().getMessage("TEAM.NO-TEAM"));
            return;
        }
        if (!this.plugin.getTeamManager().canEditHome(team, player.getUniqueId())) {
            this.send(player, this.plugin.getConfigManager().getMessage("TEAM.NO-EDIT-HOME-PERMISSION"));
            return;
        }
        if (!team.hasHome()) {
            this.send(player, this.plugin.getConfigManager().getMessage("TEAM.NO-TEAM-HOME"));
            return;
        }
        team.setHome(null);
        this.plugin.getTeamManager().save(team);
        this.send(player, this.plugin.getConfigManager().getMessage("TEAM.TEAM-HOME-DELETED"));
    }

    private void handleChat(Player player) {
        Team team = this.plugin.getTeamManager().getTeam(player);
        if (team == null) {
            this.send(player, this.plugin.getConfigManager().getMessage("TEAM.NO-TEAM"));
            return;
        }
        if (!this.plugin.getTeamManager().canUseTeamChat(team, player.getUniqueId())) {
            this.send(player, this.plugin.getConfigManager().getMessage("TEAM.NO-TEAM-CHAT-PERMISSION"));
            return;
        }
        this.plugin.getTeamManager().toggleTeamChat(player.getUniqueId());
        boolean enabled = this.plugin.getTeamManager().isTeamChatEnabled(player.getUniqueId());
        this.send(player, enabled ? this.plugin.getConfigManager().getMessage("TEAM.TEAM-CHAT-ENABLED") : this.plugin.getConfigManager().getMessage("TEAM.TEAM-CHAT-DISABLED"));
    }

    private void handlePvp(Player player) {
        Team team = this.plugin.getTeamManager().getTeam(player);
        if (team == null) {
            this.send(player, this.plugin.getConfigManager().getMessage("TEAM.NO-TEAM"));
            return;
        }
        if (!this.plugin.getTeamManager().toggleFriendlyFire(team, player.getUniqueId())) {
            this.send(player, this.plugin.getConfigManager().getMessage("TEAM.NO-PVP-PERMISSION"));
            return;
        }
        this.send(player, team.isFriendlyFireEnabled() ? this.plugin.getConfigManager().getMessage("TEAM.TEAM-PVP-ENABLED") : this.plugin.getConfigManager().getMessage("TEAM.TEAM-PVP-DISABLED"));
    }

    private UUID resolvePlayerUuid(Player viewer, String name) {
        Player online = PlayerLookup.findOnlinePlayer(name);
        if (online != null) {
            return online.getUniqueId();
        }
        UUID storedUuid = this.plugin.getDatabaseManager().findPlayerUuidByUsername(name);
        if (storedUuid != null) {
            return storedUuid;
        }
        return Bukkit.getOfflinePlayer((String)name).hasPlayedBefore() ? Bukkit.getOfflinePlayer((String)name).getUniqueId() : null;
    }

    private void send(Player player, String message) {
        player.sendMessage(ColorUtils.toComponent(message));
    }

    private String publicName(Player player) {
        return player.getName();
    }
}

