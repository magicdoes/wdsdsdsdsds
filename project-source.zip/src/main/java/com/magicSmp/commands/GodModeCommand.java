/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.CommandMap
 *  org.bukkit.permissions.Permissible
 *  org.bukkit.permissions.Permission
 *  org.bukkit.permissions.PermissionDefault
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.PermissionUtils;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Locale;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandMap;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.permissions.Permissible;
import org.bukkit.permissions.Permission;
import org.bukkit.permissions.PermissionDefault;

public class GodModeCommand
extends Command
implements CommandExecutor {
    private static final String PERMISSION = "MagicSMP.staff.god";
    private final MagicSmp plugin;

    public GodModeCommand(MagicSmp plugin) {
        super("god", "toggle god mode for yourself or another online player", "/god [player]", List.of("godmode"));
        this.plugin = plugin;
        this.setPermission(PERMISSION);
        this.registerPermission();
    }

    public boolean execute(CommandSender sender, String label, String[] args) {
        return this.handle(sender, label, args);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        return this.handle(sender, label, args);
    }

    public boolean registerDynamically() {
        CommandMap commandMap = this.resolveCommandMap();
        return commandMap != null && commandMap.register(this.plugin.getDescription().getName().toLowerCase(Locale.ROOT), (Command)this);
    }

    private void registerPermission() {
        if (this.plugin.getServer().getPluginManager().getPermission(PERMISSION) != null) {
            return;
        }
        this.plugin.getServer().getPluginManager().addPermission(new Permission(PERMISSION, PermissionDefault.OP));
    }

    private boolean handle(CommandSender sender, String label, String[] args) {
        Player target;
        Player player;
        if (args.length > 1) {
            this.send(sender, "GOD.USAGE", "&c\u1d1c\u0455\u1d00\u0262\u1d07: /%label% [\u1d18\u029f\u1d00\u028f\u1d07\u0280]", "%label%", label);
            return true;
        }
        if (sender instanceof Player && !PermissionUtils.has((Permissible)(player = (Player)sender), PERMISSION)) {
            this.send(player, "GOD.NO_PERMISSION", "&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274.", new String[0]);
            return true;
        }
        if (args.length == 0) {
            if (!(sender instanceof Player)) {
                this.send(sender, "GOD.CONSOLE_USAGE", "&c\u1d1c\u0455\u1d00\u0262\u1d07: /%label% <player>", "%label%", label);
                return true;
            }
            Player player2 = (Player)sender;
            target = player2;
        } else {
            target = this.findOnlinePlayer(args[0]);
            if (target == null) {
                this.send(sender, "GOD.PLAYER_NOT_ONLINE", "&c\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u0274\u1d0f\u1d1b \u1d0f\u0274\u029f\u026a\u0274\u1d07.", new String[0]);
                return true;
            }
        }
        boolean enabled = this.plugin.getGodModeManager().toggle(target.getUniqueId());
        this.notifyTarget(sender, target, enabled);
        return true;
    }

    private void notifyTarget(CommandSender sender, Player target, boolean enabled) {
        Player player;
        String status = this.plugin.getConfigManager().getMessageOrDefault(enabled ? "GOD.STATUS_ENABLED" : "GOD.STATUS_DISABLED", enabled ? "&a\u1d07\u0274\u1d00\u0299\u029f\u1d07\u1d05" : "&c\u1d05\u026a\u0455\u1d00\u0299\u029f\u1d07\u1d05");
        if (sender instanceof Player && (player = (Player)sender).getUniqueId().equals(target.getUniqueId())) {
            this.send(target, enabled ? "GOD.ENABLED" : "GOD.DISABLED", enabled ? "&a\u0262\u1d0f\u1d05 \u1d0d\u1d0f\u1d05\u1d07 \u1d07\u0274\u1d00\u0299\u029f\u1d07\u1d05." : "&c\u0262\u1d0f\u1d05 \u1d0d\u1d0f\u1d05\u1d07 \u1d05\u026a\u0455\u1d00\u0299\u029f\u1d07\u1d05.", new String[0]);
            return;
        }
        this.send(sender, "GOD.OTHER", "&7\u0262\u1d0f\u1d05 \u1d0d\u1d0f\u1d05\u1d07 \ua730\u1d0f\u0280 &e%player% &7\u1d21\u1d00\u0455 %status%&7.", "%player%", target.getName(), "%status%", status);
        this.send(target, "GOD.NOTIFY", "&e%sender% &7\u0455\u1d07\u1d1b \u028f\u1d0f\u1d1c\u0280 \u0262\u1d0f\u1d05 \u1d0d\u1d0f\u1d05\u1d07 \u1d1b\u1d0f %status%&7.", "%sender%", this.senderName(sender), "%status%", status);
    }

    private void send(CommandSender sender, String path, String fallback, String ... placeholders) {
        sender.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault(path, fallback, placeholders)));
    }

    private String senderName(CommandSender sender) {
        String string;
        if (sender instanceof Player) {
            Player player = (Player)sender;
            string = player.getName();
        } else {
            string = sender.getName();
        }
        return string;
    }

    private Player findOnlinePlayer(String input) {
        if (input == null || input.isBlank()) {
            return null;
        }
        Player exact = Bukkit.getPlayerExact((String)input);
        if (exact != null) {
            return exact;
        }
        String expected = input.toLowerCase(Locale.ROOT);
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (!player.getName().toLowerCase(Locale.ROOT).equals(expected)) continue;
            return player;
        }
        return null;
    }

    private CommandMap resolveCommandMap() {
        try {
            CommandMap map;
            Method method = Bukkit.getServer().getClass().getMethod("getCommandMap", new Class[0]);
            Object commandMap = method.invoke((Object)Bukkit.getServer(), new Object[0]);
            return commandMap instanceof CommandMap ? (map = (CommandMap)commandMap) : null;
        }
        catch (ReflectiveOperationException ignored) {
            try {
                CommandMap map;
                Field field = Bukkit.getServer().getClass().getDeclaredField("commandMap");
                field.setAccessible(true);
                Object commandMap = field.get(Bukkit.getServer());
                return commandMap instanceof CommandMap ? (map = (CommandMap)commandMap) : null;
            }
            catch (ReflectiveOperationException ignoredAgain) {
                return null;
            }
        }
    }
}

