/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.menus.PunishmentHistoryMenu;
import com.bx.magicSmp.utils.ColorUtils;
import java.util.UUID;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class PunishmentHistoryCommand
implements CommandExecutor {
    private final MagicSmp plugin;

    public PunishmentHistoryCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(this.plugin.getConfigManager().getMessageOrDefault("PUNISHMENTS.PLAYER-ONLY", "&c\u1d0f\u0274\u029f\u028f \u1d18\u029f\u1d00\u028f\u1d07\u0280\u0455 \u1d04\u1d00\u0274 \u1d1c\u0455\u1d07 \u1d1b\u029c\u026a\u0455 \u1d04\u1d0f\u1d0d\u1d0d\u1d00\u0274\u1d05."));
            return true;
        }
        Player player = (Player)sender;
        if (!this.plugin.getPunishmentManager().canView(player)) {
            player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("PUNISHMENTS.NO-PERMISSION", "&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274 \u1d1b\u1d0f \u1d20\u026a\u1d07\u1d21 \u1d18\u1d1c\u0274\u026a\u0455\u029c\u1d0d\u1d07\u0274\u1d1b \u029c\u026a\u0455\u1d1b\u1d0f\u0280\u028f.")));
            return true;
        }
        if (args.length == 0) {
            player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("PUNISHMENTS.USAGE", "&c\u1d1c\u0455\u1d00\u0262\u1d07: /" + label + " <player>")));
            return true;
        }
        UUID targetUuid = this.plugin.getPunishmentManager().resolveTargetUuid(args[0], true).orElse(null);
        if (targetUuid == null) {
            player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("PUNISHMENTS.NOT-FOUND", "&c\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u0274\u1d0f\u1d1b \ua730\u1d0f\u1d1c\u0274\u1d05.")));
            return true;
        }
        new PunishmentHistoryMenu(this.plugin, targetUuid, false).open(player);
        return true;
    }
}

