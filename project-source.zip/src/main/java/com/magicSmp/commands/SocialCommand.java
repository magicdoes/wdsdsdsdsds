/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.utils.ColorUtils;
import java.util.List;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SocialCommand
implements CommandExecutor {
    private final MagicSmp plugin;

    public SocialCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        String key;
        if (!(sender instanceof Player)) {
            sender.sendMessage("\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u1d0f\u0274\u029f\u028f.");
            return true;
        }
        Player player = (Player)sender;
        if (!this.plugin.getConfigManager().isCommandEnabled("SOCIAL")) {
            player.sendMessage(ColorUtils.toComponent("&c\u0455\u1d0f\u1d04\u026a\u1d00\u029f \u1d04\u1d0f\u1d0d\u1d0d\u1d00\u0274\u1d05\u0455 \u1d00\u0280\u1d07 \u1d04\u1d1c\u0280\u0280\u1d07\u0274\u1d1b\u029f\u028f \u1d05\u026a\u0455\u1d00\u0299\u029f\u1d07\u1d05."));
            return true;
        }
        String normalizedLabel = label.toLowerCase();
        switch (normalizedLabel) {
            case "discord": {
                String string = "SOCIAL.DISCORD";
                break;
            }
            case "supportus": {
                String string = "SOCIAL.SUPPORTUS";
                break;
            }
            default: {
                String string = key = null;
            }
        }
        if (key != null) {
            List lines = this.plugin.getConfigManager().getMessages().getStringList(key);
            for (String line : lines) {
                player.sendMessage(ColorUtils.toComponent(line));
            }
        } else {
            for (String section : List.of("SOCIAL.DISCORD", "SOCIAL.SUPPORTUS")) {
                List lines = this.plugin.getConfigManager().getMessages().getStringList(section);
                for (String line : lines) {
                    player.sendMessage(ColorUtils.toComponent(line));
                }
            }
        }
        return true;
    }
}

