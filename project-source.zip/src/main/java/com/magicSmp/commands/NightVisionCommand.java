/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.NightVisionUtils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class NightVisionCommand
implements CommandExecutor {
    private final MagicSmp plugin;

    public NightVisionCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u1d0f\u0274\u029f\u028f.");
            return true;
        }
        Player player = (Player)sender;
        boolean enabled = NightVisionUtils.toggle(this.plugin, player);
        if (!enabled) {
            player.sendMessage(ColorUtils.toComponent("&7\u0274\u026a\u0262\u029c\u1d1b \u1d20\u026a\u0455\u026a\u1d0f\u0274 &c\u1d05\u026a\u0455\u1d00\u0299\u029f\u1d07\u1d05&7."));
        } else {
            player.sendMessage(ColorUtils.toComponent("&7\u0274\u026a\u0262\u029c\u1d1b \u1d20\u026a\u0455\u026a\u1d0f\u0274 &a\u1d07\u0274\u1d00\u0299\u029f\u1d07\u1d05&7."));
        }
        return true;
    }
}

