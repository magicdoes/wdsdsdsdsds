/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.attribute.AttributeInstance
 *  org.bukkit.permissions.Permissible
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.utils.AttributeUtils;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.PermissionUtils;
import java.util.Locale;
import org.bukkit.Bukkit;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.permissions.Permissible;

public class HealCommand
implements CommandExecutor {
    private static final String PERMISSION = "MagicSMP.staff.heal";
    private final MagicSmp plugin;

    public HealCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String string;
        Player target;
        Player player;
        Player player2;
        if (sender instanceof Player && !PermissionUtils.has((Permissible)(player2 = (Player)sender), PERMISSION)) {
            player2.sendMessage(ColorUtils.toComponent("&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274."));
            return true;
        }
        if (args.length > 1) {
            sender.sendMessage(ColorUtils.toComponent("&c\u1d1c\u0455\u1d00\u0262\u1d07: /" + label + " [\u1d18\u029f\u1d00\u028f\u1d07\u0280]"));
            return true;
        }
        if (args.length == 0) {
            if (!(sender instanceof Player)) {
                sender.sendMessage(ColorUtils.toComponent("&c\u1d1c\u0455\u1d00\u0262\u1d07: /" + label + " <player>"));
                return true;
            }
            player = (Player)sender;
            target = player;
        } else {
            target = this.findOnlinePlayer(args[0]);
            if (target == null) {
                sender.sendMessage(ColorUtils.toComponent("&c\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u0274\u1d0f\u1d1b \u1d0f\u0274\u029f\u026a\u0274\u1d07."));
                return true;
            }
        }
        this.heal(target);
        if (sender instanceof Player && (player = (Player)sender).getUniqueId().equals(target.getUniqueId())) {
            player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("HEAL.SELF", "&a\u028f\u1d0f\u1d1c\u0280 \u029c\u1d07\u1d00\u029f\u1d1b\u029c \u029c\u1d00\u0455 \u0299\u1d07\u1d07\u0274 \u0280\u1d07\u0455\u1d1b\u1d0f\u0280\u1d07\u1d05!")));
            return true;
        }
        if (sender instanceof Player) {
            Player player3 = (Player)sender;
            string = player3.getName();
        } else {
            string = sender.getName();
        }
        String senderName = string;
        sender.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("HEAL.OTHER", "&7\u028f\u1d0f\u1d1c \u029c\u1d07\u1d00\u029f\u1d07\u1d05 &d%player%", "%player%", target.getName())));
        target.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("HEAL.NOTIFY", "&d%sender% &7\u0280\u1d07\u0455\u1d1b\u1d0f\u0280\u1d07\u1d05 \u028f\u1d0f\u1d1c\u0280 \u029c\u1d07\u1d00\u029f\u1d1b\u029c", "%sender%", senderName)));
        return true;
    }

    private void heal(Player target) {
        AttributeInstance maxHealth = AttributeUtils.getMaxHealthAttribute(target);
        target.setHealth(maxHealth == null ? 20.0 : maxHealth.getValue());
        target.setFireTicks(0);
        target.setFallDistance(0.0f);
    }

    private Player findOnlinePlayer(String input) {
        if (input == null || input.isBlank()) {
            return null;
        }
        Player exact = Bukkit.getPlayerExact((String)input);
        if (exact != null) {
            return exact;
        }
        String expected = input.toLowerCase(Locale.ROOT);
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (!player.getName().toLowerCase(Locale.ROOT).equals(expected)) continue;
            return player;
        }
        return null;
    }
}

