/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.permissions.Permissible
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.managers.DatabaseManager;
import com.bx.magicSmp.managers.SellStatsExporter;
import com.bx.magicSmp.managers.StatsWipeManager;
import com.bx.magicSmp.menus.SellStatsAdminMenu;
import com.bx.magicSmp.menus.StatsWipeConfirmMenu;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.NumberUtils;
import com.bx.magicSmp.utils.PermissionUtils;
import java.util.List;
import java.util.Locale;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.permissions.Permissible;

public class SellStatsCommand
implements CommandExecutor,
TabCompleter {
    private static final String PERMISSION = "MagicSMP.admin.sellstats";
    private final MagicSmp plugin;

    public SellStatsCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String sub;
        if (!PermissionUtils.has((Permissible)sender, PERMISSION) && !sender.hasPermission("MagicSMP.admin")) {
            sender.sendMessage(ColorUtils.toComponent("&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274 \u1d1b\u1d0f \u1d20\u026a\u1d07\u1d21 \u1d00\u1d05\u1d0d\u026a\u0274 \u0455\u1d07\u029f\u029f \u0455\u1d1b\u1d00\u1d1b\u026a\u0455\u1d1b\u026a\u1d04\u0455."));
            return true;
        }
        if (args.length == 0 || args[0].equalsIgnoreCase("gui") || args[0].equalsIgnoreCase("menu")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage(ColorUtils.toComponent("&cOnly players can open the Sell Stats GUI. Use /" + label + " export or /" + label + " items."));
                return true;
            }
            Player player = (Player)sender;
            new SellStatsAdminMenu(this.plugin).open(player);
            return true;
        }
        switch (sub = args[0].toLowerCase(Locale.ROOT)) {
            case "items": 
            case "revenue": 
            case "topitems": {
                this.handleTopItems(sender, args);
                break;
            }
            case "volume": 
            case "topvolume": {
                this.handleTopVolume(sender, args);
                break;
            }
            case "sellers": 
            case "topsellers": 
            case "players": {
                this.handleTopSellers(sender, args);
                break;
            }
            case "export": 
            case "report": {
                this.handleExport(sender);
                break;
            }
            case "web": 
            case "site": 
            case "url": 
            case "paste": {
                new SellStatsExporter(this.plugin).uploadToWebPaste(sender);
                break;
            }
            case "html": {
                new SellStatsExporter(this.plugin).exportHtml(sender);
                break;
            }
            case "reset": 
            case "wipe": 
            case "clear": {
                this.handleReset(sender, args);
                break;
            }
            default: {
                this.sendUsage(sender, label);
            }
        }
        return true;
    }

    private void handleReset(CommandSender sender, String[] args) {
        if (args.length >= 2 && args[1].equalsIgnoreCase("confirm")) {
            this.plugin.getDatabaseManager().clearShopAnalyticsData();
            sender.sendMessage(ColorUtils.toComponent("&a[Shop Analytics] All shop analytics, purchases, and sales data have been reset!"));
            return;
        }
        if (sender instanceof Player) {
            Player player = (Player)sender;
            new StatsWipeConfirmMenu(this.plugin, StatsWipeManager.WipeTarget.SELL_DOCUMENTS).open(player);
        } else {
            sender.sendMessage(ColorUtils.toComponent("&cUse '/topsell reset confirm' to wipe all shop analytics data from console."));
        }
    }

    private void handleTopItems(CommandSender sender, String[] args) {
        int limit = args.length >= 2 ? this.parseLimit(args[1], 10) : 10;
        double totalRevenue = this.plugin.getDatabaseManager().getTotalSellRevenue();
        List<DatabaseManager.TopSoldItemEntry> items = this.plugin.getDatabaseManager().getTopSoldItemsByRevenue(limit);
        sender.sendMessage(ColorUtils.toComponent("&8&m---------- &b&lTOP REVENUE SOLD ITEMS &8&m----------"));
        if (items.isEmpty()) {
            sender.sendMessage(ColorUtils.toComponent("&7No sell transaction history recorded yet."));
            return;
        }
        for (int i = 0; i < items.size(); ++i) {
            DatabaseManager.TopSoldItemEntry entry = items.get(i);
            double pct = totalRevenue > 0.0 ? entry.totalRevenue() / totalRevenue * 100.0 : 0.0;
            String hint = pct >= 10.0 ? " &c[NERF RECOMMENDED]" : "";
            sender.sendMessage(ColorUtils.toComponent("&e#" + (i + 1) + " &f" + this.prettifyMaterial(entry.itemName()) + " &8- &a" + this.plugin.getCurrencyManager().formatMoney(entry.totalRevenue()) + " &7(" + String.format(Locale.US, "%.1f%%", pct) + ") &8| &e" + NumberUtils.format(entry.totalAmount()) + " sold" + hint));
        }
        sender.sendMessage(ColorUtils.toComponent("&7Total Server Revenue: &a" + this.plugin.getCurrencyManager().formatMoney(totalRevenue)));
    }

    private void handleTopVolume(CommandSender sender, String[] args) {
        int limit = args.length >= 2 ? this.parseLimit(args[1], 10) : 10;
        long totalVolume = this.plugin.getDatabaseManager().getTotalItemsSold();
        List<DatabaseManager.TopSoldItemEntry> items = this.plugin.getDatabaseManager().getTopSoldItemsByVolume(limit);
        sender.sendMessage(ColorUtils.toComponent("&8&m---------- &b&lTOP VOLUME SOLD ITEMS &8&m----------"));
        if (items.isEmpty()) {
            sender.sendMessage(ColorUtils.toComponent("&7No sell transaction history recorded yet."));
            return;
        }
        for (int i = 0; i < items.size(); ++i) {
            DatabaseManager.TopSoldItemEntry entry = items.get(i);
            sender.sendMessage(ColorUtils.toComponent("&e#" + (i + 1) + " &f" + this.prettifyMaterial(entry.itemName()) + " &8- &e" + NumberUtils.format(entry.totalAmount()) + " sold &8| &a" + this.plugin.getCurrencyManager().formatMoney(entry.totalRevenue())));
        }
    }

    private void handleTopSellers(CommandSender sender, String[] args) {
        int limit = args.length >= 2 ? this.parseLimit(args[1], 10) : 10;
        double totalRevenue = this.plugin.getDatabaseManager().getTotalSellRevenue();
        List<DatabaseManager.TopSellerEntry> sellers = this.plugin.getDatabaseManager().getTopSellers(limit);
        sender.sendMessage(ColorUtils.toComponent("&8&m---------- &b&lTOP SELLING PLAYERS &8&m----------"));
        if (sellers.isEmpty()) {
            sender.sendMessage(ColorUtils.toComponent("&7No sell transaction history recorded yet."));
            return;
        }
        for (int i = 0; i < sellers.size(); ++i) {
            DatabaseManager.TopSellerEntry entry = sellers.get(i);
            double pct = totalRevenue > 0.0 ? entry.totalEarned() / totalRevenue * 100.0 : 0.0;
            sender.sendMessage(ColorUtils.toComponent("&e#" + (i + 1) + " &f" + entry.playerName() + " &8- &a" + this.plugin.getCurrencyManager().formatMoney(entry.totalEarned()) + " &7(" + String.format(Locale.US, "%.1f%%", pct) + ") &8| &e" + NumberUtils.format(entry.totalAmountSold()) + " items"));
        }
    }

    private void handleExport(CommandSender sender) {
        Player p;
        sender.sendMessage(ColorUtils.toComponent("&7Exporting sell statistics report..."));
        Player player = sender instanceof Player ? (p = (Player)sender) : null;
        new SellStatsAdminMenu(this.plugin).exportReport(player);
    }

    private void sendUsage(CommandSender sender, String label) {
        sender.sendMessage(ColorUtils.toComponent("&cUsage: /" + label + " [gui|items|volume|sellers|export|web|html]"));
    }

    private int parseLimit(String input, int def) {
        try {
            return Math.max(1, Math.min(100, Integer.parseInt(input)));
        }
        catch (NumberFormatException ignored) {
            return def;
        }
    }

    private String prettifyMaterial(String raw) {
        String[] words = raw.toLowerCase(Locale.US).split("_");
        StringBuilder sb = new StringBuilder();
        for (String w : words) {
            if (w.isEmpty()) continue;
            if (!sb.isEmpty()) {
                sb.append(' ');
            }
            sb.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1));
        }
        return sb.toString();
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        String sub;
        if (args.length == 1) {
            List<String> options = List.of("gui", "items", "volume", "sellers", "export", "web", "site", "html", "reset", "wipe");
            String filter = args[0].toLowerCase(Locale.ROOT);
            return options.stream().filter(o -> o.startsWith(filter)).toList();
        }
        if (args.length == 2 && ("reset".equals(sub = args[0].toLowerCase(Locale.ROOT)) || "wipe".equals(sub)) && "confirm".startsWith(args[1].toLowerCase(Locale.ROOT))) {
            return List.of("confirm");
        }
        return List.of();
    }
}

