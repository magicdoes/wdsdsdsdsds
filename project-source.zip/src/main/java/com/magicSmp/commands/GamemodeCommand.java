/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.GameMode
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.permissions.Permissible
 *  org.bukkit.util.StringUtil
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.PermissionUtils;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.permissions.Permissible;
import org.bukkit.util.StringUtil;

public class GamemodeCommand
implements CommandExecutor,
TabCompleter {
    private static final String PERMISSION = "MagicSMP.staff.gamemode";
    private static final String OTHERS_PERMISSION = "MagicSMP.staff.gamemode.others";
    private static final List<String> MODE_COMPLETIONS = List.of("survival", "creative", "adventure", "spectator");
    private final MagicSmp plugin;

    public GamemodeCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!this.plugin.getConfigManager().isCommandEnabled("GAMEMODE")) {
            this.send(sender, "GAMEMODE.DISABLED", "&c\u0262\u1d00\u1d0d\u1d07\u1d0d\u1d0f\u1d05\u1d07 \u1d04\u1d0f\u1d0d\u1d0d\u1d00\u0274\u1d05\u0455 \u1d00\u0280\u1d07 \u1d04\u1d1c\u0280\u0280\u1d07\u0274\u1d1b\u029f\u028f \u1d05\u026a\u0455\u1d00\u0299\u029f\u1d07\u1d05.", new String[0]);
            return true;
        }
        if (!this.hasBasePermission(sender)) {
            return true;
        }
        GameMode fixedMode = this.modeFromLabel(label);
        if (fixedMode != null) {
            return this.handleFixedModeCommand(sender, label, args, fixedMode);
        }
        return this.handleMainCommand(sender, label, args);
    }

    private boolean handleFixedModeCommand(CommandSender sender, String label, String[] args, GameMode mode) {
        if (args.length > 1) {
            this.send(sender, "GAMEMODE.USAGE_SHORT", "&c\u1d1c\u0455\u1d00\u0262\u1d07: /%label% [\u1d18\u029f\u1d00\u028f\u1d07\u0280]", "%label%", label);
            return true;
        }
        Player target = this.resolveTarget(sender, args.length == 0 ? null : args[0], label, true);
        if (target == null) {
            return true;
        }
        if (!this.hasRequiredPermission(sender, target)) {
            return true;
        }
        this.applyGamemode(sender, target, mode);
        return true;
    }

    private boolean handleMainCommand(CommandSender sender, String label, String[] args) {
        if (args.length < 1 || args.length > 2) {
            this.send(sender, "GAMEMODE.USAGE", "&c\u1d1c\u0455\u1d00\u0262\u1d07: /%label% <survival|creative|adventure|spectator> [\u1d18\u029f\u1d00\u028f\u1d07\u0280]", "%label%", label);
            return true;
        }
        GameMode mode = this.parseMode(args[0]);
        if (mode == null) {
            this.send(sender, "GAMEMODE.INVALID_MODE", "&c\u026a\u0274\u1d20\u1d00\u029f\u026a\u1d05 \u0262\u1d00\u1d0d\u1d07\u1d0d\u1d0f\u1d05\u1d07. \u1d1c\u0455\u1d07 \u0455\u1d1c\u0280\u1d20\u026a\u1d20\u1d00\u029f, \u1d04\u0280\u1d07\u1d00\u1d1b\u026a\u1d20\u1d07, \u1d00\u1d05\u1d20\u1d07\u0274\u1d1b\u1d1c\u0280\u1d07, \u1d0f\u0280 \u0455\u1d18\u1d07\u1d04\u1d1b\u1d00\u1d1b\u1d0f\u0280.", new String[0]);
            return true;
        }
        Player target = this.resolveTarget(sender, args.length == 1 ? null : args[1], label, false);
        if (target == null) {
            return true;
        }
        if (!this.hasRequiredPermission(sender, target)) {
            return true;
        }
        this.applyGamemode(sender, target, mode);
        return true;
    }

    private Player resolveTarget(CommandSender sender, String input, String label, boolean fixedModeCommand) {
        if (input == null || input.isBlank()) {
            if (sender instanceof Player) {
                Player player = (Player)sender;
                return player;
            }
            String fallback = fixedModeCommand ? "&cusage: /%label% <player>" : "&cusage: /%label% <survival|creative|adventure|spectator> <player>";
            this.send(sender, "GAMEMODE.PLAYER_ONLY", fallback, "%label%", label);
            return null;
        }
        Player target = this.findOnlinePlayer(input);
        if (target == null) {
            this.send(sender, "GAMEMODE.PLAYER_NOT_ONLINE", "&c\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u0274\u1d0f\u1d1b \u1d0f\u0274\u029f\u026a\u0274\u1d07.", new String[0]);
            return null;
        }
        return target;
    }

    private boolean hasRequiredPermission(CommandSender sender, Player target) {
        if (!(sender instanceof Player)) {
            return true;
        }
        Player player = (Player)sender;
        if (!PermissionUtils.has((Permissible)player, PERMISSION)) {
            this.send(player, "GAMEMODE.NO_PERMISSION", "&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274.", new String[0]);
            return false;
        }
        if (!player.getUniqueId().equals(target.getUniqueId()) && !PermissionUtils.has((Permissible)player, OTHERS_PERMISSION)) {
            this.send(player, "GAMEMODE.NO_PERMISSION_OTHERS", "&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274 \u1d1b\u1d0f \u1d04\u029c\u1d00\u0274\u0262\u1d07 \u1d0f\u1d1b\u029c\u1d07\u0280 \u1d18\u029f\u1d00\u028f\u1d07\u0280\u0455' \u0262\u1d00\u1d0d\u1d07\u1d0d\u1d0f\u1d05\u1d07.", new String[0]);
            return false;
        }
        return true;
    }

    private void applyGamemode(CommandSender sender, Player target, GameMode mode) {
        Player player;
        target.setGameMode(mode);
        String modeName = this.displayName(mode);
        this.send(sender, "GAMEMODE.MESSAGE", "&d%player% &7\u026a\u0455 \u0274\u1d0f\u1d21 \u026a\u0274 &e%mode% \u1d0d\u1d0f\u1d05\u1d07", "%player%", target.getName(), "%mode%", modeName, "%sender%", this.senderName(sender));
        if (sender instanceof Player && (player = (Player)sender).getUniqueId().equals(target.getUniqueId())) {
            return;
        }
        this.send(target, "GAMEMODE.TARGET_MESSAGE", "&7\u028f\u1d0f\u1d1c\u0280 \u0262\u1d00\u1d0d\u1d07\u1d0d\u1d0f\u1d05\u1d07 \u029c\u1d00\u0455 \u0299\u1d07\u1d07\u0274 \u1d04\u029c\u1d00\u0274\u0262\u1d07\u1d05 \u1d1b\u1d0f &e%mode% &7\u0299\u028f &d%sender%", "%player%", target.getName(), "%mode%", modeName, "%sender%", this.senderName(sender));
    }

    private GameMode modeFromLabel(String label) {
        return switch (this.normalizeLabel(label)) {
            case "gms" -> GameMode.SURVIVAL;
            case "gmc" -> GameMode.CREATIVE;
            case "gma" -> GameMode.ADVENTURE;
            case "gmsp" -> GameMode.SPECTATOR;
            default -> null;
        };
    }

    private GameMode parseMode(String input) {
        if (input == null || input.isBlank()) {
            return null;
        }
        return switch (input.toLowerCase(Locale.ROOT)) {
            case "survival", "s", "0" -> GameMode.SURVIVAL;
            case "creative", "c", "1" -> GameMode.CREATIVE;
            case "adventure", "a", "2" -> GameMode.ADVENTURE;
            case "spectator", "spec", "sp", "3" -> GameMode.SPECTATOR;
            default -> null;
        };
    }

    private Player findOnlinePlayer(String input) {
        Player exact = Bukkit.getPlayerExact((String)input);
        if (exact != null) {
            return exact;
        }
        String expected = input.toLowerCase(Locale.ROOT);
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (!player.getName().toLowerCase(Locale.ROOT).equals(expected)) continue;
            return player;
        }
        return null;
    }

    private String displayName(GameMode mode) {
        return mode.name().toLowerCase(Locale.ROOT);
    }

    private String senderName(CommandSender sender) {
        String string;
        if (sender instanceof Player) {
            Player player = (Player)sender;
            string = player.getName();
        } else {
            string = "console";
        }
        return string;
    }

    private String normalizeLabel(String label) {
        if (label == null) {
            return "";
        }
        String normalized = label.toLowerCase(Locale.ROOT);
        int namespaceSeparator = normalized.indexOf(58);
        if (namespaceSeparator >= 0 && namespaceSeparator + 1 < normalized.length()) {
            normalized = normalized.substring(namespaceSeparator + 1);
        }
        return normalized;
    }

    private void send(CommandSender sender, String path, String fallback, String ... placeholders) {
        sender.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault(path, fallback, placeholders)));
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!this.canUseBaseCommand(sender)) {
            return Collections.emptyList();
        }
        if (this.modeFromLabel(alias) != null) {
            if (args.length == 1 && this.canTargetOthers(sender)) {
                return this.partialMatches(args[0], this.onlinePlayerNames());
            }
            return Collections.emptyList();
        }
        if (args.length == 1) {
            return this.partialMatches(args[0], MODE_COMPLETIONS);
        }
        if (args.length == 2 && this.canTargetOthers(sender)) {
            return this.partialMatches(args[1], this.onlinePlayerNames());
        }
        return Collections.emptyList();
    }

    private boolean canUseBaseCommand(CommandSender sender) {
        Player player;
        return !(sender instanceof Player) || PermissionUtils.has((Permissible)(player = (Player)sender), PERMISSION);
    }

    private boolean hasBasePermission(CommandSender sender) {
        Player player;
        if (sender instanceof Player && !PermissionUtils.has((Permissible)(player = (Player)sender), PERMISSION)) {
            this.send(player, "GAMEMODE.NO_PERMISSION", "&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274.", new String[0]);
            return false;
        }
        return true;
    }

    private boolean canTargetOthers(CommandSender sender) {
        Player player;
        return !(sender instanceof Player) || PermissionUtils.has((Permissible)(player = (Player)sender), OTHERS_PERMISSION);
    }

    private List<String> onlinePlayerNames() {
        ArrayList<String> names = new ArrayList<String>();
        for (Player player : Bukkit.getOnlinePlayers()) {
            names.add(player.getName());
        }
        names.sort(String.CASE_INSENSITIVE_ORDER);
        return names;
    }

    private List<String> partialMatches(String token, List<String> completions) {
        ArrayList<String> matches = new ArrayList<String>();
        StringUtil.copyPartialMatches((String)token, completions, matches);
        matches.sort(String.CASE_INSENSITIVE_ORDER);
        return matches;
    }
}

