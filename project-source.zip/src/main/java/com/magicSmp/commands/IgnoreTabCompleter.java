/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.util.StringUtil
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.models.IgnoreEntry;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.util.StringUtil;

public class IgnoreTabCompleter
implements TabCompleter {
    private final MagicSmp plugin;

    public IgnoreTabCompleter(MagicSmp plugin) {
        this.plugin = plugin;
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        Player player;
        block7: {
            block6: {
                if (!(sender instanceof Player)) break block6;
                player = (Player)sender;
                if (args.length == 1) break block7;
            }
            return Collections.emptyList();
        }
        ArrayList<String> completions = new ArrayList<String>();
        if (alias.equalsIgnoreCase("unignore")) {
            for (IgnoreEntry entry : this.plugin.getIgnoreManager().getIgnoredPlayers(player.getUniqueId())) {
                completions.add(entry.ignoredNameSnapshot());
            }
            return this.partialMatches(args[0], completions);
        }
        completions.add("list");
        for (Player onlinePlayer : Bukkit.getOnlinePlayers()) {
            if (onlinePlayer.getUniqueId().equals(player.getUniqueId())) continue;
            completions.add(onlinePlayer.getName());
        }
        return this.partialMatches(args[0], completions);
    }

    private List<String> partialMatches(String token, List<String> completions) {
        ArrayList<String> matches = new ArrayList<String>();
        StringUtil.copyPartialMatches((String)token, completions, matches);
        matches.sort(String.CASE_INSENSITIVE_ORDER);
        return matches;
    }
}

