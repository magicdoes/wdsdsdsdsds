/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.managers.CurrencyManager;
import com.bx.magicSmp.managers.EconomyManager;
import com.bx.magicSmp.utils.ColorUtils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class BalanceCommand
implements CommandExecutor {
    private final MagicSmp plugin;

    public BalanceCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u1d0f\u0274\u029f\u028f.");
            return true;
        }
        Player player = (Player)sender;
        if (args.length == 0) {
            double balance = this.plugin.getEconomyManager().getBalance(player);
            String msg = this.plugin.getConfigManager().getMessage("BALANCE.YOUR-BALANCE", "{amount}", this.compactAmount(balance), "{amount_full}", this.fullAmount(balance), "{money}", this.plugin.getCurrencyManager().formatMoneyCompact(balance), "{money_full}", this.fullMoney(balance));
            player.sendMessage(ColorUtils.toComponent(msg));
        } else {
            EconomyManager.AccountReference account = this.plugin.getEconomyManager().resolveAccount(args[0]);
            if (account == null) {
                player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessage("BALANCE.ADMIN.PLAYER-NOT-FOUND")));
                return true;
            }
            double balance = this.plugin.getEconomyManager().getBalance(account.uuid());
            String msg = this.plugin.getConfigManager().getMessage("BALANCE.OTHER-BALANCE", "{player}", account.displayName(), "{amount}", this.compactAmount(balance), "{amount_full}", this.fullAmount(balance), "{money}", this.plugin.getCurrencyManager().formatMoneyCompact(balance), "{money_full}", this.fullMoney(balance));
            player.sendMessage(ColorUtils.toComponent(msg));
        }
        return true;
    }

    private String compactAmount(double amount) {
        return this.plugin.getCurrencyManager().formatCompactAmount(CurrencyManager.CurrencyType.MONEY, amount);
    }

    private String fullAmount(double amount) {
        return this.plugin.getCurrencyManager().formatAmount(CurrencyManager.CurrencyType.MONEY, amount);
    }

    private String fullMoney(double amount) {
        return this.plugin.getCurrencyManager().format(CurrencyManager.CurrencyType.MONEY, amount, false);
    }
}

