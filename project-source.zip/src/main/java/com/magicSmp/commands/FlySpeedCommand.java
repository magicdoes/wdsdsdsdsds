/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.permissions.Permissible
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.managers.FeatureManager;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.PermissionUtils;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.permissions.Permissible;

public class FlySpeedCommand
implements CommandExecutor,
TabCompleter {
    private static final String PERMISSION = "MagicSMP.staff.fly";
    private static final float MAX_SPEED = 10.0f;
    private final MagicSmp plugin;

    public FlySpeedCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ColorUtils.toComponent("&c\u1d0f\u0274\u029f\u028f \u1d18\u029f\u1d00\u028f\u1d07\u0280\u0455 \u1d04\u1d00\u0274 \u1d1c\u0455\u1d07 \u1d1b\u029c\u026a\u0455 \u1d04\u1d0f\u1d0d\u1d0d\u1d00\u0274\u1d05."));
            return true;
        }
        Player player = (Player)sender;
        if (!PermissionUtils.has((Permissible)player, PERMISSION)) {
            player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("STAFF.NO_PERMISSION_OTHERS", "&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274.")));
            return true;
        }
        if (!player.getAllowFlight() && !player.isFlying()) {
            player.sendMessage(ColorUtils.toComponent("&c\u028f\u1d0f\u1d1c \u1d0d\u1d1c\u0455\u1d1b \u0299\u1d07 \ua730\u029f\u028f\u026a\u0274\u0262 \u1d1b\u1d0f \u0455\u1d07\u1d1b \ua730\u029f\u028f \u0455\u1d18\u1d07\u1d07\u1d05."));
            return true;
        }
        if (args.length == 0) {
            player.sendMessage(ColorUtils.toComponent("&c\u1d1c\u0455\u1d00\u0262\u1d07: /" + label + " <\u0455\u1d18\u1d07\u1d07\u1d05 (1-10)>"));
            player.sendMessage(ColorUtils.toComponent("&7\u1d04\u1d1c\u0280\u0280\u1d07\u0274\u1d1b \u0455\u1d18\u1d07\u1d07\u1d05: &f" + this.getCurrentSpeedDisplay(player.getFlySpeed())));
            return true;
        }
        if (args.length == 1) {
            try {
                float speed = Float.parseFloat(args[0]);
                if (speed < 1.0f || speed > 10.0f) {
                    player.sendMessage(ColorUtils.toComponent("&c\u0455\u1d1c\u1d07\u1d07\u1d05 \u1d0d\u1d1c\u0455\u1d1b \u0299\u1d07 \u0299\u1d07\u1d1b\u1d21\u1d07\u1d07\u0274 &f1&7- &f10.0"));
                    return true;
                }
                float minecraftSpeed = speed / 10.0f;
                player.setFlySpeed(minecraftSpeed);
                player.sendMessage(ColorUtils.toComponent("&a\ua730\u029f\u028f \u0455\u1d18\u1d07\u1d07\u1d05 \u0455\u1d07\u1d1b \u1d1b\u1d0f &f" + speed));
                return true;
            }
            catch (NumberFormatException e) {
                player.sendMessage(ColorUtils.toComponent("&c\u026a\u0274\u1d20\u1d00\u029f\u026a\u1d05 \u0274\u1d1c\u1d0d\u0299\u1d07\u0280. \u1d1c\u0455\u1d07 \u1d00 \u0274\u1d1c\u1d0d\u0299\u1d07\u0280 \u0299\u1d07\u1d1b\u1d21\u1d07\u1d07\u0274 &f1&7- &f10.0"));
                return true;
            }
        }
        player.sendMessage(ColorUtils.toComponent("&c\u1d1c\u0455\u1d00\u0262\u1d07: /" + label + " <\u0455\u1d18\u1d07\u1d07\u1d05 (1-10)>"));
        return true;
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<String>();
        if (!this.plugin.getFeatureManager().isEnabled(FeatureManager.Feature.FLY)) {
            return completions;
        }
        if (args.length == 1) {
            completions.add("1");
            completions.add("2");
            completions.add("3");
            completions.add("5");
            completions.add("10");
        }
        return completions;
    }

    private String getCurrentSpeedDisplay(float minecraftSpeed) {
        int displaySpeed = Math.round(minecraftSpeed * 10.0f);
        return String.valueOf(displaySpeed);
    }
}

