/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.permissions.Permissible
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.managers.PunishmentManager;
import com.bx.magicSmp.models.PunishmentRecord;
import com.bx.magicSmp.models.PunishmentScope;
import com.bx.magicSmp.models.PunishmentType;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.NumberUtils;
import com.bx.magicSmp.utils.PermissionUtils;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.permissions.Permissible;

public class PunishmentCommand
implements CommandExecutor {
    private static final String CREATE_PERMISSION = "MagicSMP.staff.punishments.create";
    private static final String BAN_PERMISSION = "MagicSMP.staff.punishments.ban";
    private static final String UNBAN_PERMISSION = "MagicSMP.staff.punishments.unban";
    private static final String MUTE_PERMISSION = "MagicSMP.staff.punishments.mute";
    private static final String UNMUTE_PERMISSION = "MagicSMP.staff.punishments.unmute";
    private static final String BLACKLIST_PERMISSION = "MagicSMP.staff.punishments.blacklist";
    private static final String UNBLACKLIST_PERMISSION = "MagicSMP.staff.punishments.unblacklist";
    private static final Pattern DURATION_TOKEN = Pattern.compile("(\\d+)([smhdw])", 2);
    private static final Map<String, String> USAGE_MESSAGES = Map.ofEntries(Map.entry("ban", "&cusage: /ban <player> [reason]"), Map.entry("tempban", "&cusage: /tempban <player> <time> [reason] &7(time: 30s, 15m, 2h, 5d, or 5d 15m 30s)"), Map.entry("mute", "&cusage: /mute <player> [reason]"), Map.entry("tempmute", "&cusage: /tempmute <player> <time> [reason] &7(time: 30s, 15m, 2h, 5d, or 5d 15m 30s)"), Map.entry("warn", "&cusage: /warn <player> [reason]"), Map.entry("kick", "&cusage: /kick <player> [reason]"), Map.entry("blacklist", "&cusage: /blacklist <player> [reason]"), Map.entry("unban", "&cusage: /unban <player> [reason]"), Map.entry("pardon", "&cusage: /pardon <player> [reason]"), Map.entry("unmute", "&cusage: /unmute <player> [reason]"), Map.entry("unblacklist", "&cusage: /unblacklist <player> [reason]"));
    private final MagicSmp plugin;

    public PunishmentCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String action;
        return switch (action = this.normalizeLabel(label, command)) {
            case "ban" -> this.handleCreate(sender, PunishmentType.BAN, args, false, false, action);
            case "tempban" -> this.handleCreate(sender, PunishmentType.BAN, args, true, false, action);
            case "mute" -> this.handleCreate(sender, PunishmentType.MUTE, args, false, false, action);
            case "tempmute" -> this.handleCreate(sender, PunishmentType.MUTE, args, true, false, action);
            case "warn" -> this.handleCreate(sender, PunishmentType.WARN, args, false, false, action);
            case "kick" -> this.handleCreate(sender, PunishmentType.KICK, args, false, true, action);
            case "blacklist" -> this.handleCreate(sender, PunishmentType.BLACKLIST, args, false, false, action);
            case "unban", "pardon" -> this.handleRemove(sender, PunishmentType.BAN, args, action);
            case "unmute" -> this.handleRemove(sender, PunishmentType.MUTE, args, action);
            case "unblacklist" -> this.handleRemove(sender, PunishmentType.BLACKLIST, args, action);
            default -> false;
        };
    }

    private String normalizeLabel(String label, Command command) {
        String normalized = label == null || label.isBlank() ? command.getName() : label;
        int namespaceSeparator = normalized.indexOf(58);
        if (namespaceSeparator >= 0 && namespaceSeparator + 1 < normalized.length()) {
            normalized = normalized.substring(namespaceSeparator + 1);
        }
        return normalized.toLowerCase(Locale.ROOT);
    }

    static String permissionForAction(String action) {
        if (action == null || action.isBlank()) {
            return null;
        }
        return switch (action.toLowerCase(Locale.ROOT)) {
            case "ban", "tempban" -> BAN_PERMISSION;
            case "unban", "pardon" -> UNBAN_PERMISSION;
            case "mute", "tempmute" -> MUTE_PERMISSION;
            case "unmute" -> UNMUTE_PERMISSION;
            case "blacklist" -> BLACKLIST_PERMISSION;
            case "unblacklist" -> UNBLACKLIST_PERMISSION;
            case "warn", "kick" -> CREATE_PERMISSION;
            default -> null;
        };
    }

    static boolean hasPermissionForAction(Permissible permissible, String action) {
        String permission = PunishmentCommand.permissionForAction(action);
        return permission != null && PermissionUtils.has(permissible, permission);
    }

    private boolean handleCreate(CommandSender sender, PunishmentType type, String[] args, boolean temporary, boolean onlineOnly, String usageLabel) {
        int minimumArgs;
        if (!this.hasPermission(sender, usageLabel)) {
            this.send(sender, this.plugin.getConfigManager().getMessageOrDefault("PUNISHMENTS.NO-CREATE-PERMISSION", "&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274 \u1d1b\u1d0f \u1d04\u0280\u1d07\u1d00\u1d1b\u1d07 \u1d18\u1d1c\u0274\u026a\u0455\u029c\u1d0d\u1d07\u0274\u1d1b\u0455."));
            return true;
        }
        int n = minimumArgs = temporary ? 2 : 1;
        if (args.length < minimumArgs) {
            this.sendUsage(sender, usageLabel);
            return true;
        }
        ResolvedTarget target = this.resolveTarget(args[0]);
        if (target == null || target.uuid() == null) {
            this.send(sender, this.plugin.getConfigManager().getMessageOrDefault("PUNISHMENTS.NOT-FOUND", "&c\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u0274\u1d0f\u1d1b \ua730\u1d0f\u1d1c\u0274\u1d05."));
            return true;
        }
        Player onlineTarget = Bukkit.getPlayer(target.uuid());
        if (onlineOnly && onlineTarget == null) {
            this.send(sender, this.plugin.getConfigManager().getMessageOrDefault("PUNISHMENTS.TARGET-OFFLINE", "&c\u1d1b\u029c\u1d00\u1d1b \u1d18\u029f\u1d00\u028f\u1d07\u0280 \u026a\u0455 \u0274\u1d0f\u1d1b \u1d0f\u0274\u029f\u026a\u0274\u1d07."));
            return true;
        }
        Long expiresAt = null;
        int reasonStart = 1;
        if (temporary) {
            DurationParseResult duration = this.parseDuration(args, 1);
            if (duration.millis() <= 0L) {
                this.send(sender, this.plugin.getConfigManager().getMessageOrDefault("PUNISHMENTS.INVALID-DURATION", "&c\u026a\u0274\u1d20\u1d00\u029f\u026a\u1d05 \u1d1b\u026a\u1d0d\u1d07. \u1d1c\u0455\u1d07 \u1d20\u1d00\u029f\u1d1c\u1d07\u0455 \u029f\u026a\u1d0b\u1d07 30\u0455, 15\u1d0d, 2\u029c, 5\u1d05, \u1d0f\u0280 \u1d04\u1d0f\u1d0d\u0299\u026a\u0274\u1d07: 5\u1d05 15\u1d0d 30\u0455."));
                return true;
            }
            expiresAt = System.currentTimeMillis() + duration.millis();
            reasonStart = duration.nextArgIndex();
        }
        String reason = this.joinReason(args, reasonStart);
        Actor actor = this.resolveActor(sender);
        PunishmentRecord record = this.plugin.getPunishmentManager().createRecord(new PunishmentManager.PunishmentCreateRequest(target.uuid(), target.name(), type, reason, actor.uuid(), actor.name(), System.currentTimeMillis(), expiresAt, "local", PunishmentScope.SERVER));
        if (record == null) {
            this.send(sender, this.plugin.getConfigManager().getMessageOrDefault("PUNISHMENTS.CREATE-FAILED", "&c\ua730\u1d00\u026a\u029f\u1d07\u1d05 \u1d1b\u1d0f \u1d04\u0280\u1d07\u1d00\u1d1b\u1d07 \u1d18\u1d1c\u0274\u026a\u0455\u029c\u1d0d\u1d07\u0274\u1d1b \u0280\u1d07\u1d04\u1d0f\u0280\u1d05."));
            return true;
        }
        this.applyRuntimeEffect(type, onlineTarget, record);
        this.plugin.getDiscordWebhookManager().sendPunishment(record);
        this.send(sender, this.plugin.getConfigManager().getMessageOrDefault("PUNISHMENTS.CREATED", "&a\u1d04\u0280\u1d07\u1d00\u1d1b\u1d07\u1d05 &f{type} &a\u1d18\u1d1c\u0274\u026a\u0455\u029c\u1d0d\u1d07\u0274\u1d1b \ua730\u1d0f\u0280 &b{player}&a. \u026a\u1d05: &f#{id}", "{type}", this.plugin.getPunishmentManager().getDisplayType(record), "{player}", target.name(), "{id}", String.valueOf(record.getId())));
        return true;
    }

    private boolean handleRemove(CommandSender sender, PunishmentType type, String[] args, String label) {
        String targetName;
        if (!this.hasPermission(sender, label)) {
            this.send(sender, this.plugin.getConfigManager().getMessageOrDefault("PUNISHMENTS.NO-REMOVE-PERMISSION", "&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274 \u1d1b\u1d0f \u0280\u1d07\u1d0d\u1d0f\u1d20\u1d07 \u1d18\u1d1c\u0274\u026a\u0455\u029c\u1d0d\u1d07\u0274\u1d1b\u0455."));
            return true;
        }
        if (args.length < 1) {
            this.sendUsage(sender, label);
            return true;
        }
        ResolvedTarget target = this.resolveTarget(args[0]);
        UUID targetUuid = target != null ? target.uuid() : null;
        String string = targetName = target != null ? target.name() : args[0];
        if (targetUuid == null && (targetName == null || targetName.isBlank())) {
            this.send(sender, this.plugin.getConfigManager().getMessageOrDefault("PUNISHMENTS.NOT-FOUND", "&c\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u0274\u1d0f\u1d1b \ua730\u1d0f\u1d1c\u0274\u1d05."));
            return true;
        }
        String reason = this.joinReason(args, 1);
        if (reason.equals("no reason specified")) {
            reason = "removed by staff";
        }
        Actor actor = this.resolveActor(sender);
        boolean removed = this.plugin.getPunishmentManager().markActiveRecordsRemoved(targetUuid, targetName, type, new PunishmentManager.PunishmentRemovalRequest(actor.uuid(), actor.name(), System.currentTimeMillis(), reason));
        if (!removed) {
            this.send(sender, this.plugin.getConfigManager().getMessageOrDefault("PUNISHMENTS.NO-ACTIVE", "&c\u0274\u1d0f \u1d00\u1d04\u1d1b\u026a\u1d20\u1d07 {type} \u1d18\u1d1c\u0274\u026a\u0455\u029c\u1d0d\u1d07\u0274\u1d1b \ua730\u1d0f\u1d1c\u0274\u1d05 \ua730\u1d0f\u0280 {player}.", "{type}", type.name(), "{player}", target.name()));
            return true;
        }
        this.send(sender, this.plugin.getConfigManager().getMessageOrDefault("PUNISHMENTS.REMOVED", "&a\u0280\u1d07\u1d0d\u1d0f\u1d20\u1d07\u1d05 \u1d00\u1d04\u1d1b\u026a\u1d20\u1d07 &f{type} &a\u1d18\u1d1c\u0274\u026a\u0455\u029c\u1d0d\u1d07\u0274\u1d1b(\u0455) \ua730\u1d0f\u0280 &b{player}&a.", "{type}", type.name(), "{player}", target.name()));
        return true;
    }

    private void applyRuntimeEffect(PunishmentType type, Player onlineTarget, PunishmentRecord record) {
        if (onlineTarget == null) {
            return;
        }
        switch (type) {
            case BAN: 
            case BLACKLIST: 
            case KICK: {
                onlineTarget.kickPlayer(ColorUtils.toComponent(this.buildPunishmentMessage(record)));
                break;
            }
            case WARN: {
                onlineTarget.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("PUNISHMENTS.WARN-RECEIVED", "&c\u1d21\u1d00\u0280\u0274\u026a\u0274\u0262: &f{reason}", "{reason}", record.getReason())));
                break;
            }
            case MUTE: {
                onlineTarget.sendMessage(ColorUtils.toComponent(this.buildPunishmentMessage(record)));
            }
        }
    }

    private String buildPunishmentMessage(PunishmentRecord record) {
        return this.plugin.getConfigManager().getMessageOrDefault(this.punishmentMessagePath(record.getType()), this.defaultPunishmentMessage(record.getType()), this.punishmentPlaceholders(record));
    }

    private String punishmentMessagePath(PunishmentType type) {
        return switch (type) {
            default -> throw new MatchException(null, null);
            case PunishmentType.BAN -> "PUNISHMENTS.BAN";
            case PunishmentType.KICK -> "PUNISHMENTS.KICK";
            case PunishmentType.MUTE -> "PUNISHMENTS.MUTE";
            case PunishmentType.BLACKLIST -> "PUNISHMENTS.BLACKLIST";
            case PunishmentType.WARN -> "PUNISHMENTS.WARN-RECEIVED";
        };
    }

    private String defaultPunishmentMessage(PunishmentType type) {
        return switch (type) {
            default -> throw new MatchException(null, null);
            case PunishmentType.BAN -> "&c&lyou have been banned!\n&8&m----------------------------\n&7reason: &f%reason%\n&7expires: &f%nicest_expiration%\n&7banned by: &f%issuer%\n&8&m----------------------------\n&7appeal at: &fdiscord.example.space";
            case PunishmentType.KICK -> "&c&lyou have been kicked!\n&8&m----------------------------\n&7reason: &f%reason%\n&7kicked by: &f%issuer%\n&8&m----------------------------\n&7you may reconnect";
            case PunishmentType.MUTE -> "&c&lyou have been muted!\n&8&m----------------------------\n&7reason: &f%reason%\n&7expires: &f%nicest_expiration%\n&7muted by: &f%issuer%\n&8&m----------------------------\n&7you cannot speak in chat";
            case PunishmentType.BLACKLIST -> "&4&lyou have been blacklisted!\n&8&m----------------------------\n&7reason: &f%reason%\n&7blacklisted by: &f%issuer%\n&8&m----------------------------\n&4you cannot join the server";
            case PunishmentType.WARN -> "&cwarning: &f{reason}";
        };
    }

    private String[] punishmentPlaceholders(PunishmentRecord record) {
        String expires = this.formatExpires(record);
        String issuer = this.formatIssuer(record);
        String reason = record == null || record.getReason() == null ? "" : record.getReason();
        String player = record == null || record.getTargetNameSnapshot() == null ? "" : record.getTargetNameSnapshot();
        String id = record == null ? "" : String.valueOf(record.getId());
        String type = record == null || record.getType() == null ? "" : record.getType().name();
        return new String[]{"%reason%", reason, "{reason}", reason, "%nicest_expiration%", expires, "{nicest_expiration}", expires, "%expires%", expires, "{expires}", expires, "%expires_at%", expires, "{expires_at}", expires, "%expiration%", expires, "{expiration}", expires, "%expiry%", expires, "{expiry}", expires, "%duration%", expires, "{duration}", expires, "%issuer%", issuer, "{issuer}", issuer, "%staff%", issuer, "{staff}", issuer, "%by%", issuer, "{by}", issuer, "%player%", player, "{player}", player, "%target%", player, "{target}", player, "%id%", id, "{id}", id, "%type%", type, "{type}", type};
    }

    private String formatExpires(PunishmentRecord record) {
        if (record == null || record.getExpiresAt() == null) {
            return "Permanent";
        }
        long remainingSeconds = Math.max(0L, (record.getExpiresAt() - System.currentTimeMillis()) / 1000L);
        if (remainingSeconds <= 0L) {
            return "Expired";
        }
        if (this.plugin != null && this.plugin.getLanguageManager() != null) {
            return this.plugin.getLanguageManager().formatDuration(remainingSeconds, true);
        }
        return NumberUtils.formatCountdown(remainingSeconds);
    }

    private String formatIssuer(PunishmentRecord record) {
        if (record == null) {
            return "unknown";
        }
        String issuer = record.getIssuerNameSnapshot();
        return issuer == null || issuer.isBlank() ? "unknown" : issuer;
    }

    private ResolvedTarget resolveTarget(String input) {
        Player online = Bukkit.getPlayerExact((String)input);
        if (online == null) {
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (!player.getName().equalsIgnoreCase(input)) continue;
                online = player;
                break;
            }
        }
        if (online != null) {
            return new ResolvedTarget(online.getUniqueId(), online.getName());
        }
        UUID knownUuid = this.plugin.getPunishmentManager().resolveTargetUuid(input, true).orElse(null);
        if (knownUuid != null) {
            return new ResolvedTarget(knownUuid, this.plugin.getPunishmentManager().resolveTargetName(knownUuid, input));
        }
        return null;
    }

    private Actor resolveActor(CommandSender sender) {
        if (sender instanceof Player) {
            Player player = (Player)sender;
            return new Actor(player.getUniqueId(), player.getName());
        }
        return new Actor(null, "console");
    }

    private boolean hasPermission(CommandSender sender, String action) {
        return !(sender instanceof Player) || PunishmentCommand.hasPermissionForAction((Permissible)sender, action);
    }

    private void sendUsage(CommandSender sender, String label) {
        String normalizedLabel = label.toLowerCase(Locale.ROOT);
        String fallback = USAGE_MESSAGES.getOrDefault(normalizedLabel, "&c\u1d1c\u0455\u1d00\u0262\u1d07: /" + normalizedLabel + " <player> [reason]");
        this.send(sender, this.plugin.getConfigManager().getMessageOrDefault("PUNISHMENTS.USAGE-" + normalizedLabel.toUpperCase(Locale.ROOT), fallback));
    }

    private long parseDurationMillis(String input) {
        if (input == null || input.isBlank()) {
            return -1L;
        }
        Matcher matcher = DURATION_TOKEN.matcher(input.trim());
        long totalMillis = 0L;
        int matchedCharacters = 0;
        while (matcher.find()) {
            long multiplier;
            long amount;
            try {
                amount = Long.parseLong(matcher.group(1));
            }
            catch (NumberFormatException e) {
                return -1L;
            }
            switch (matcher.group(2).toLowerCase(Locale.ROOT)) {
                case "s": {
                    long l = 1000L;
                    break;
                }
                case "m": {
                    long l = 60000L;
                    break;
                }
                case "h": {
                    long l = 3600000L;
                    break;
                }
                case "d": {
                    long l = 86400000L;
                    break;
                }
                case "w": {
                    long l = 604800000L;
                    break;
                }
                default: {
                    long l = multiplier = -1L;
                }
            }
            if (multiplier <= 0L) {
                return -1L;
            }
            totalMillis += amount * multiplier;
            matchedCharacters += matcher.group(0).length();
        }
        return matchedCharacters == input.trim().length() ? totalMillis : -1L;
    }

    private DurationParseResult parseDuration(String[] args, int startIndex) {
        long tokenMillis;
        int index;
        long totalMillis = 0L;
        for (index = startIndex; index < args.length && (tokenMillis = this.parseDurationMillis(args[index])) > 0L; ++index) {
            totalMillis += tokenMillis;
        }
        return new DurationParseResult(totalMillis, index);
    }

    private String joinReason(String[] args, int startIndex) {
        if (args.length <= startIndex) {
            return "no reason specified";
        }
        StringBuilder builder = new StringBuilder();
        for (int index = startIndex; index < args.length; ++index) {
            if (!builder.isEmpty()) {
                builder.append(' ');
            }
            builder.append(args[index]);
        }
        return builder.isEmpty() ? "no reason specified" : builder.toString();
    }

    private void send(CommandSender sender, String message) {
        sender.sendMessage(ColorUtils.toComponent(message));
    }

    private record ResolvedTarget(UUID uuid, String name) {
    }

    private record DurationParseResult(long millis, int nextArgIndex) {
    }

    private record Actor(UUID uuid, String name) {
    }
}

