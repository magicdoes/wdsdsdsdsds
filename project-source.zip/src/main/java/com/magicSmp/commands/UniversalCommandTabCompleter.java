/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.generator.WorldInfo
 *  org.bukkit.permissions.Permissible
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.managers.FeatureManager;
import com.bx.magicSmp.managers.WorthManager;
import com.bx.magicSmp.models.AuctionListing;
import com.bx.magicSmp.models.Home;
import com.bx.magicSmp.models.PlayerData;
import com.bx.magicSmp.models.Team;
import com.bx.magicSmp.utils.PermissionUtils;
import com.bx.magicSmp.utils.PlayerLookup;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.generator.WorldInfo;
import org.bukkit.permissions.Permissible;

public class UniversalCommandTabCompleter
implements TabCompleter {
    private static final List<String> AMOUNTS = List.of("1", "10", "100", "1K", "10K", "100K", "1M", "10M", "100M", "1B");
    private static final List<String> DURATIONS = List.of("30s", "15m", "1h", "2h", "1d", "7d");
    private static final List<String> TOGGLES = List.of("true", "false", "on", "off");
    private static final List<String> TEAM_SUBCOMMANDS = List.of("create", "disband", "invite", "join", "leave", "kick", "home", "sethome", "delhome", "chat", "pvp");
    private static final List<String> ARENA_SUBCOMMANDS = List.of("create", "delete", "setpos1", "setpos2", "setreturn", "setdisplay", "enable", "disable", "queue", "list", "reload");
    private static final List<String> TELEPORT_ROOTS = List.of("here", "all", "top");
    private final MagicSmp plugin;

    public UniversalCommandTabCompleter(MagicSmp plugin) {
        this.plugin = plugin;
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!command.testPermissionSilent(sender) || !this.isFeatureEnabled(command.getName())) {
            return List.of();
        }
        String commandName = this.normalize(command.getName());
        String label = this.normalize(alias);
        return switch (commandName) {
            case "team" -> this.completeTeam(sender, args);
            case "home", "homes", "sethome", "delhome", "renamehome" -> this.completeHome(sender, commandName, args);
            case "rtp", "randomteleport" -> this.singleArg(args, this.plugin.getRtpManager().getWorldSelectorSuggestions());
            case "shop" -> this.completeShop(sender, args);
            case "safety" -> this.completeSafety(sender, args);
            case "orders" -> this.completeOrders(sender, args);
            case "auctionhouse" -> this.completeAuctionHouse(sender, args);
            case "enderchest" -> this.completeReloadOnly(sender, args, "MagicSMP.admin.enderchest");
            case "ecsee" -> this.completeEcsee(sender, args);
            case "sellhand" -> this.singleArg(args, AMOUNTS);
            case "worth" -> this.completeWorth(sender, args);
            case "balance", "stats", "playtime", "alts", "profileviewer", "punishments", "punishmenthistory" -> this.completeOnlinePlayer(args, sender, true);
            case "ping", "findplayer" -> this.completeOnlinePlayer(args, sender, true);
            case "pay" -> this.completePayment(sender, args);
            case "addmoney", "removemoney", "setmoney" -> this.completeMoneyAdmin(sender, args);
            case "freeze" -> this.completePlayerOrReload(sender, args, "MagicSMP.admin.freeze", false);
            case "fly", "heal", "feed", "godmode", "god", "nightvision", "phantom", "vanish" -> this.completeOnlinePlayer(args, sender, true);
            case "staffmode" -> this.completePlayerOrReload(sender, args, "MagicSMP.admin.staffmode", true);
            case "helpop", "staffchat" -> List.of();
            case "rename" -> this.singleArg(args, List.of("reset", "clear", "remove"));
            case "leave", "draw", "pm", "spawn", "sell", "sellall", "sellhistory", "stafflist", "tpauto", "tpahereauto", "discord", "supportus", "rules", "servers", "clearlag" -> List.of();
            case "teleport" -> this.completeTeleport(sender, label, args);
            case "invsee" -> this.completePlayerOrReload(sender, args, "MagicSMP.admin.invsee", false);
            case "ban", "tempban", "mute", "tempmute", "warn", "kick", "blacklist", "unban", "unmute", "unblacklist" -> this.completePunishment(sender, commandName, args);
            case "bounty" -> this.completeBounty(sender, args);
            case "tpa", "tpahere" -> this.completeOnlinePlayer(args, sender, false);
            case "tpaccept", "tpadeny" -> this.completeOnlinePlayer(args, sender, true);
            case "leaderboard" -> this.singleArg(args, this.leaderboardTypes());
            case "hide" -> this.completeOnlinePlayer(args, sender, true);
            case "kill" -> this.completeOnlinePlayer(args, sender, false);
            case "gamemode", "gm" -> this.completeGamemode(sender, args);
            case "maintenance" -> this.completeMaintenance(sender, args);
            case "ignore" -> this.completeIgnore(sender, args);
            case "message", "msg", "tell", "whisper" -> this.completeMessage(sender, args);
            case "friends", "friend" -> this.completeFriends(sender, args);
            case "setspawn" -> this.singleArg(args, this.worldNames());
            case "crate", "crates", "keys" -> this.completeCrate(sender, args);
            case "report" -> this.completeReport(sender, args);
            case "logs" -> this.completeLogs(sender, args);
            case "amethysttool" -> this.completeAmethystTool(sender, args);
            case "offend" -> this.completeOffend(sender, args);
            case "anvilmoderation" -> this.completeAnvilModeration(sender, args);
            case "social" -> this.completeSocial(sender, args);
            case "help" -> this.completeHelp(sender, args);
            default -> List.of();
        };
    }

    private List<String> completeTeam(CommandSender sender, String[] args) {
        if (!(sender instanceof Player)) {
            return List.of();
        }
        Player player = (Player)sender;
        if (args.length == 1) {
            return this.partial(args[0], TEAM_SUBCOMMANDS);
        }
        if (args.length != 2) {
            return List.of();
        }
        return switch (this.normalize(args[0])) {
            case "invite" -> this.partial(args[1], this.onlinePlayerNames(sender, false));
            case "join" -> this.partial(args[1], this.plugin.getTeamManager().getPendingInvites(player.getUniqueId()));
            case "kick" -> this.partial(args[1], this.teamMemberNames(player, false));
            default -> List.of();
        };
    }

    private List<String> completeHome(CommandSender sender, String commandName, String[] args) {
        if (!(sender instanceof Player)) {
            return List.of();
        }
        Player player = (Player)sender;
        if (args.length != 1) {
            return List.of();
        }
        return switch (commandName) {
            case "home", "delhome", "renamehome" -> this.partial(args[0], this.homeNames(player));
            default -> List.of();
        };
    }

    private List<String> completeOrders(CommandSender sender, String[] args) {
        if (args.length != 1) {
            return List.of();
        }
        ArrayList<String> options = new ArrayList<String>(List.of("browse", "my", "collect"));
        if (this.has(sender, "MagicSMP.admin.orders")) {
            options.add("reload");
        }
        return this.partial(args[0], options);
    }

    private List<String> completeAuctionHouse(CommandSender sender, String[] args) {
        if (args.length == 1) {
            ArrayList<String> options = new ArrayList<String>(List.of("sell", "my", "claims", "cancel"));
            if (this.has(sender, "MagicSMP.admin.auctionhouse")) {
                options.add("reload");
            }
            return this.partial(args[0], options);
        }
        if (args.length == 2 && this.normalize(args[0]).equals("sell")) {
            return this.partial(args[1], AMOUNTS);
        }
        if (args.length == 2 && this.normalize(args[0]).equals("cancel") && sender instanceof Player) {
            Player player = (Player)sender;
            return this.partial(args[1], this.ownAuctionListingIds(player));
        }
        return List.of();
    }

    private List<String> completeWorth(CommandSender sender, String[] args) {
        int itemStartIndex;
        if (args == null || args.length == 0) {
            return List.of();
        }
        List<WorthManager.WorthBrowserEntry> entries = this.plugin.getWorthManager().getBrowserEntries();
        List<String> prettifiedNames = entries.stream().map(WorthManager.WorthBrowserEntry::material).filter(mat -> mat != null && !mat.isAir()).map(mat -> this.plugin.getWorthManager().prettifyMaterial((Material)((Object)mat))).distinct().toList();
        if (args.length == 1) {
            ArrayList<String> options = new ArrayList<String>();
            options.addAll(List.of("hand", "held", "item", "check", "browse", "prices"));
            if (this.has(sender, "MagicSMP.admin.worth")) {
                options.add("reload");
            }
            options.addAll(prettifiedNames);
            return this.partial(args[0], options);
        }
        boolean isFirstArgAmount = false;
        try {
            int amount = Integer.parseInt(args[0]);
            if (amount > 0) {
                isFirstArgAmount = true;
            }
        }
        catch (NumberFormatException amount) {
            // empty catch block
        }
        int n = itemStartIndex = isFirstArgAmount ? 1 : 0;
        if (args.length <= itemStartIndex) {
            return List.of();
        }
        if (isFirstArgAmount && args.length == 2) {
            return this.partial(args[1], prettifiedNames);
        }
        String itemTypedSoFar = String.join((CharSequence)" ", Arrays.copyOfRange(args, itemStartIndex, args.length)).toLowerCase(Locale.ROOT);
        String itemTypedPrefixBeforeLast = String.join((CharSequence)" ", Arrays.copyOfRange(args, itemStartIndex, args.length - 1)).toLowerCase(Locale.ROOT);
        String lastArg = args[args.length - 1];
        ArrayList<String> suggestions = new ArrayList<String>();
        for (String fullName : prettifiedNames) {
            String lowerFull = fullName.toLowerCase(Locale.ROOT);
            if (lowerFull.startsWith(itemTypedSoFar)) {
                suggestions.add(fullName);
            }
            if (itemTypedPrefixBeforeLast.isEmpty() || !lowerFull.startsWith(itemTypedPrefixBeforeLast + " ")) continue;
            String remainder = fullName.substring(itemTypedPrefixBeforeLast.length() + 1);
            suggestions.add(remainder);
        }
        return this.partial(lastArg, suggestions);
    }

    private List<String> completePayment(CommandSender sender, String[] args) {
        if (args.length == 1) {
            return this.partial(args[0], this.onlinePlayerNames(sender, false));
        }
        if (args.length == 2) {
            return this.partial(args[1], AMOUNTS);
        }
        return List.of();
    }

    private List<String> completeMoneyAdmin(CommandSender sender, String[] args) {
        if (args.length == 1) {
            return this.partial(args[0], this.onlinePlayerNames(sender, true));
        }
        if (args.length == 2) {
            return this.partial(args[1], AMOUNTS);
        }
        return List.of();
    }

    private List<String> completePlayerOrReload(CommandSender sender, String[] args, String adminPermission, boolean includeSelf) {
        if (args.length != 1) {
            return List.of();
        }
        ArrayList<String> options = new ArrayList<String>(this.onlinePlayerNames(sender, includeSelf));
        if (this.has(sender, adminPermission)) {
            options.add("reload");
        }
        return this.partial(args[0], options);
    }

    private List<String> completeEcsee(CommandSender sender, String[] args) {
        if (args.length != 1 || !this.plugin.getEnderChestManager().isInspectionEnabled() || !this.plugin.getEnderChestManager().canInspect(sender)) {
            return List.of();
        }
        return this.partial(args[0], this.plugin.getEnderChestManager().getInspectionTargetSuggestions());
    }

    private List<String> completeTeleport(CommandSender sender, String label, String[] args) {
        if (label.equals("tphere")) {
            return this.completeOnlinePlayer(args, sender, false);
        }
        if (label.equals("tpall")) {
            return List.of();
        }
        if (args.length == 1) {
            ArrayList<String> options = new ArrayList<String>(this.onlinePlayerNames(sender, true));
            options.addAll(TELEPORT_ROOTS);
            return this.partial(args[0], options);
        }
        if (args.length == 2 && this.normalize(args[0]).equals("here")) {
            return this.partial(args[1], this.onlinePlayerNames(sender, false));
        }
        if (args.length == 4 && !this.normalize(args[0]).equals("here")) {
            return this.partial(args[3], this.worldNames());
        }
        return List.of();
    }

    private List<String> completePunishment(CommandSender sender, String commandName, String[] args) {
        if (args.length == 1) {
            boolean onlineOnly = commandName.equals("kick");
            return onlineOnly ? this.partial(args[0], this.onlinePlayerNames(sender, true)) : this.partial(args[0], this.onlinePlayerNames(sender, true));
        }
        if (args.length == 2 && (commandName.equals("tempban") || commandName.equals("tempmute"))) {
            return this.partial(args[1], DURATIONS);
        }
        return List.of();
    }

    private List<String> completeBounty(CommandSender sender, String[] args) {
        if (args.length == 1) {
            return this.partial(args[0], List.of("add", "set", "info", "list"));
        }
        if (args.length == 2 && Set.of("add", "set", "info").contains(this.normalize(args[0]))) {
            return this.partial(args[1], this.onlinePlayerNames(sender, false));
        }
        if (args.length == 3 && Set.of("add", "set").contains(this.normalize(args[0]))) {
            return this.partial(args[2], AMOUNTS);
        }
        return List.of();
    }

    private List<String> completeReloadOnly(CommandSender sender, String[] args, String permission) {
        return args.length == 1 && this.has(sender, permission) ? this.partial(args[0], List.of("reload")) : List.of();
    }

    private List<String> completeShop(CommandSender sender, String[] args) {
        return this.completeReloadOnly(sender, args, "MagicSMP.admin.shop");
    }

    private List<String> completeOnlinePlayer(String[] args, CommandSender sender, boolean includeSelf) {
        return args.length == 1 ? this.partial(args[0], this.onlinePlayerNames(sender, includeSelf)) : List.of();
    }

    private List<String> completeKnownPlayer(String[] args, CommandSender sender, boolean includeSelf) {
        return args.length == 1 ? this.partial(args[0], this.knownPlayerNames(sender, includeSelf)) : List.of();
    }

    private List<String> singleArg(String[] args, Collection<String> options) {
        return args.length == 1 ? this.partial(args[0], options) : List.of();
    }

    private List<String> onlinePlayerNames(CommandSender sender, boolean includeSelf) {
        UUID uUID;
        if (sender instanceof Player) {
            Player player = (Player)sender;
            uUID = player.getUniqueId();
        } else {
            uUID = null;
        }
        UUID senderUuid = uUID;
        ArrayList<String> names = new ArrayList<String>();
        for (String name : PlayerLookup.onlineNames()) {
            Player player = PlayerLookup.findOnlinePlayer(name);
            if (player == null || !includeSelf && senderUuid != null && senderUuid.equals(player.getUniqueId())) continue;
            names.add(name);
        }
        return names;
    }

    private List<String> knownPlayerNames(CommandSender sender, boolean includeSelf) {
        UUID uUID;
        if (sender instanceof Player) {
            Player player = (Player)sender;
            uUID = player.getUniqueId();
        } else {
            uUID = null;
        }
        UUID senderUuid = uUID;
        LinkedHashSet<String> names = new LinkedHashSet<String>(this.onlinePlayerNames(sender, includeSelf));
        if (this.plugin.getPlayerDataManager() == null) {
            return new ArrayList<String>(names);
        }
        for (PlayerData data : this.plugin.getPlayerDataManager().getAll()) {
            if (data == null || data.getUsername() == null || data.getUsername().isBlank() || !includeSelf && senderUuid != null && senderUuid.equals(data.getUuid())) continue;
            names.add(data.getUsername());
        }
        return new ArrayList<String>(names);
    }

    private List<String> homeNames(Player player) {
        if (this.plugin.getHomeManager() == null) {
            return List.of();
        }
        return this.plugin.getHomeManager().getHomes(player.getUniqueId()).stream().map(Home::getName).toList();
    }

    private List<String> teamMemberNames(Player player, boolean includeSelf) {
        Team team = this.plugin.getTeamManager().getTeam(player);
        if (team == null) {
            return List.of();
        }
        ArrayList<String> names = new ArrayList<String>();
        for (UUID uuid : team.getMemberUuids()) {
            if (!includeSelf && player.getUniqueId().equals(uuid)) continue;
            Player online = Bukkit.getPlayer(uuid);
            if (online != null) {
                names.add(online.getName());
                continue;
            }
            String knownName = this.plugin.getDatabaseManager().getLastKnownUsername(uuid);
            if (knownName == null || knownName.isBlank()) continue;
            names.add(knownName);
        }
        return names;
    }

    private List<String> ownAuctionListingIds(Player player) {
        return this.plugin.getAuctionHouseManager().getActiveListingsForSeller(player.getUniqueId(), this.plugin.getAuctionHouseManager().getDefaultSort()).stream().map(AuctionListing::id).map(String::valueOf).toList();
    }

    private List<String> leaderboardTypes() {
        return this.plugin.getLeaderboardManager().getTypes().stream().map(type -> type.getConfigKey().toLowerCase(Locale.ROOT)).toList();
    }

    private List<String> worldNames() {
        return Bukkit.getWorlds().stream().map(WorldInfo::getName).toList();
    }

    private boolean isFeatureEnabled(String commandName) {
        if (this.plugin.getFeatureManager() == null) {
            return true;
        }
        for (FeatureManager.Feature feature : FeatureManager.featuresForCommand(commandName)) {
            if (feature == null || this.plugin.getFeatureManager().isEnabled(feature)) continue;
            return false;
        }
        return true;
    }

    private List<String> completeSafety(CommandSender sender, String[] args) {
        if (args.length == 1) {
            ArrayList<String> options = new ArrayList<String>();
            if (this.has(sender, "safety.reload")) {
                options.add("reload");
            }
            if (this.has(sender, "safety.add")) {
                options.add("add");
                options.add("give");
            }
            return this.partial(args[0], options);
        }
        if (args.length == 2 && (args[0].equalsIgnoreCase("add") || args[0].equalsIgnoreCase("give")) && this.has(sender, "safety.add")) {
            return this.partial(args[1], this.onlinePlayerNames(sender, true));
        }
        return List.of();
    }

    private List<String> completeGamemode(CommandSender sender, String[] args) {
        if (args.length == 1) {
            ArrayList<String> options = new ArrayList<String>(List.of("survival", "creative", "adventure", "spectator"));
            if (sender instanceof Player) {
                options.addAll(this.onlinePlayerNames(sender, true));
            }
            return this.partial(args[0], options);
        }
        if (args.length == 2 && sender instanceof Player) {
            return this.partial(args[1], this.onlinePlayerNames(sender, true));
        }
        return List.of();
    }

    private List<String> completeMaintenance(CommandSender sender, String[] args) {
        if (!this.has(sender, "MagicSMP.admin.maintenance")) {
            return List.of();
        }
        if (args.length == 1) {
            return this.partial(args[0], List.of("on", "off", "status", "bypass"));
        }
        if (args.length == 2 && this.normalize(args[0]).equals("bypass")) {
            return this.partial(args[1], this.onlinePlayerNames(sender, true));
        }
        return List.of();
    }

    private List<String> completeIgnore(CommandSender sender, String[] args) {
        if (!(sender instanceof Player)) {
            return List.of();
        }
        if (args.length == 1) {
            ArrayList<String> options = new ArrayList<String>(List.of("add", "remove", "list"));
            options.addAll(this.onlinePlayerNames(sender, false));
            return this.partial(args[0], options);
        }
        if (args.length == 2 && Set.of("add", "remove").contains(this.normalize(args[0]))) {
            return this.partial(args[1], this.onlinePlayerNames(sender, false));
        }
        return List.of();
    }

    private List<String> completeMessage(CommandSender sender, String[] args) {
        if (args.length == 1) {
            return this.partial(args[0], this.onlinePlayerNames(sender, false));
        }
        return List.of();
    }

    private List<String> completeFriends(CommandSender sender, String[] args) {
        if (!(sender instanceof Player)) {
            return List.of();
        }
        Player player = (Player)sender;
        if (args.length == 1) {
            ArrayList<String> options = new ArrayList<String>(List.of("add", "remove", "accept", "deny", "list", "toggle"));
            options.addAll(this.onlinePlayerNames(sender, false));
            return this.partial(args[0], options);
        }
        if (args.length == 2 && Set.of("add", "remove", "accept", "deny").contains(this.normalize(args[0]))) {
            return this.partial(args[1], this.onlinePlayerNames(sender, false));
        }
        return List.of();
    }

    private List<String> completeCrate(CommandSender sender, String[] args) {
        if (!(sender instanceof Player)) {
            return List.of();
        }
        if (args.length == 1) {
            ArrayList<String> options = new ArrayList<String>(List.of("open", "give", "reload"));
            if (this.has(sender, "MagicSMP.admin.crates")) {
                options.add("key");
            }
            return this.partial(args[0], options);
        }
        if (args.length == 2 && this.normalize(args[0]).equals("give") && this.has(sender, "MagicSMP.admin.crates")) {
            return this.partial(args[1], this.onlinePlayerNames(sender, true));
        }
        return List.of();
    }

    private List<String> completeReport(CommandSender sender, String[] args) {
        if (!(sender instanceof Player)) {
            return List.of();
        }
        if (args.length == 1) {
            return this.partial(args[0], this.onlinePlayerNames(sender, false));
        }
        return List.of();
    }

    private List<String> completeLogs(CommandSender sender, String[] args) {
        if (!this.has(sender, "MagicSMP.admin.logs")) {
            return List.of();
        }
        if (args.length == 1) {
            return this.partial(args[0], List.of("punishments", "economy", "chat"));
        }
        if (args.length == 2) {
            return this.partial(args[1], this.onlinePlayerNames(sender, true));
        }
        return List.of();
    }

    private List<String> completeAmethystTool(CommandSender sender, String[] args) {
        if (!this.has(sender, "MagicSMP.admin.amethysttools")) {
            return List.of();
        }
        if (args.length == 1) {
            return this.partial(args[0], List.of("give", "reload"));
        }
        if (args.length == 2 && this.normalize(args[0]).equals("give")) {
            return this.partial(args[1], this.onlinePlayerNames(sender, true));
        }
        return List.of();
    }

    private List<String> completeOffend(CommandSender sender, String[] args) {
        if (!this.has(sender, "MagicSMP.admin.offend")) {
            return List.of();
        }
        if (args.length == 1) {
            return this.partial(args[0], this.onlinePlayerNames(sender, true));
        }
        return List.of();
    }

    private List<String> completeAnvilModeration(CommandSender sender, String[] args) {
        if (!this.has(sender, "MagicSMP.admin.anvilmoderation")) {
            return List.of();
        }
        if (args.length == 1) {
            return this.partial(args[0], List.of("on", "off", "status"));
        }
        return List.of();
    }

    private List<String> completeDraw(CommandSender sender, String[] args) {
        if (!(sender instanceof Player)) {
            return List.of();
        }
        if (args.length == 1) {
            return this.partial(args[0], List.of("help", "cancel"));
        }
        return List.of();
    }

    private List<String> completeHelp(CommandSender sender, String[] args) {
        if (args.length == 1) {
            return this.partial(args[0], List.of("1", "2", "3", "4", "5", "6", "7", "8", "9", "10"));
        }
        return List.of();
    }

    private List<String> completeSocial(CommandSender sender, String[] args) {
        if (args.length == 1) {
            return this.partial(args[0], List.of("discord", "supportus", "website"));
        }
        return List.of();
    }

    private boolean has(CommandSender sender, String permission) {
        return permission == null || permission.isBlank() || PermissionUtils.has((Permissible)sender, permission);
    }

    private String normalize(String value) {
        return value == null ? "" : value.toLowerCase(Locale.ROOT);
    }

    private List<String> partial(String input, Collection<String> options) {
        if (options == null || options.isEmpty()) {
            return List.of();
        }
        String prefix = input == null ? "" : input.toLowerCase(Locale.ROOT);
        return options.stream().filter(option -> option != null && !option.isBlank()).distinct().filter(option -> option.toLowerCase(Locale.ROOT).startsWith(prefix)).sorted(String.CASE_INSENSITIVE_ORDER).toList();
    }
}

