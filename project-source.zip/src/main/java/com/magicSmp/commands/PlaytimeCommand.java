/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.models.PlayerData;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.NumberUtils;
import com.bx.magicSmp.utils.PlayerLookup;
import java.util.UUID;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class PlaytimeCommand
implements CommandExecutor {
    private final MagicSmp plugin;

    public PlaytimeCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length > 1) {
            sender.sendMessage(ColorUtils.toComponent("&cᴜѕᴀɢᴇ: /" + label + " [ᴘʟᴀʏᴇʀ]"));
            return true;
        }

        Player target = null;
        String requestedName;
        if (args.length == 0) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage(ColorUtils.toComponent("&cᴜѕᴀɢᴇ: /" + label + " <player>"));
                return true;
            }
            target = player;
            requestedName = player.getName();
        } else {
            requestedName = args[0];
            target = PlayerLookup.findOnlinePlayer(requestedName);
        }

        PlayerData data = this.resolvePlayerData(sender, target, requestedName);
        if (data == null) {
            sender.sendMessage(ColorUtils.toComponent("&cᴘʟᴀʏᴇʀ ɴᴏᴛ ꜰᴏᴜɴᴅ."));
            return true;
        }

        String targetName = target != null ? target.getName() : this.resolveStoredName(data, requestedName);
        long seconds = target != null ? data.getTotalPlaytimeSeconds() : data.getPlaytimeSeconds();
        String time = NumberUtils.formatTimeLong(seconds);
        String server = this.resolveServerName();
        boolean selfRequest = args.length == 0 || (sender instanceof Player player && target != null && player.getUniqueId().equals(target.getUniqueId()));
        String path = selfRequest ? "PLAYTIME.MESSAGE" : "PLAYTIME.OTHER";
        String fallback = selfRequest ? "&a%time% &eplaying on &a%server%" : "&e%player% &7has played for &a%time% &7on &a%server%";
        sender.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault(path, fallback, new String[]{"%player%", targetName, "%time%", time, "%server%", server})));
        return true;
    }

    private PlayerData resolvePlayerData(CommandSender viewer, Player target, String requestedName) {
        if (target != null) {
            PlayerData cached = this.plugin.getPlayerDataManager().get(target);
            return cached != null ? cached : this.plugin.getDatabaseManager().loadPlayer(target.getUniqueId());
        }
        UUID uuid = PlayerLookup.findKnownPlayerUuid(this.plugin, requestedName);
        return uuid == null ? null : this.plugin.getDatabaseManager().loadPlayer(uuid);
    }

    private String resolveStoredName(PlayerData data, String requestedName) {
        String username = data.getUsername();
        if (username != null && !username.isBlank()) {
            return username;
        }
        return requestedName == null || requestedName.isBlank() ? "unknown" : requestedName;
    }

    private String resolveServerName() {
        String displayName = this.plugin.getConfigManager().getConfig().getString("NETWORK-STATUS.LOCAL-DISPLAY-NAME", "");
        if (displayName != null && !displayName.isBlank()) {
            return displayName;
        }
        String serverId = this.plugin.getConfigManager().getConfig().getString("NETWORK-STATUS.LOCAL-SERVER-ID", "");
        if (serverId != null && !serverId.isBlank()) {
            return serverId;
        }
        return "server";
    }
}

