/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.models.PlayerData;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.NumberUtils;
import com.bx.magicSmp.utils.PlayerLookup;
import java.util.UUID;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class PlaytimeCommand
implements CommandExecutor {
    private final MagicSmp plugin;

    public PlaytimeCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length > 1) {
            sender.sendMessage(ColorUtils.toComponent("&c\u1d1c\u0455\u1d00\u0262\u1d07: /" + label + " [\u1d18\u029f\u1d00\u028f\u1d07\u0280]"));
            return true;
        }
        target = null;
        requestedName = null;
        if (args.length == 0) {
            if (!(sender instanceof Player)) {
                sender.sendMessage(ColorUtils.toComponent("&c\u1d1c\u0455\u1d00\u0262\u1d07: /" + label + " <player>"));
                return true;
            }
            player = (Player)sender;
            target = player;
            requestedName = player.getName();
        } else {
            requestedName = args[0];
            target = PlayerLookup.findOnlinePlayer(requestedName);
        }
        data = this.resolvePlayerData(sender, target, requestedName);
        if (data == null) {
            sender.sendMessage(ColorUtils.toComponent("&c\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u0274\u1d0f\u1d1b \ua730\u1d0f\u1d1c\u0274\u1d05."));
            return true;
        }
        targetName = target != null ? target.getName() : this.resolveStoredName(data, requestedName);
        seconds = target != null ? data.getTotalPlaytimeSeconds() : data.getPlaytimeSeconds();
        time = NumberUtils.formatTimeLong(seconds);
        server = this.resolveServerName();
        if (args.length == 0) ** GOTO lbl-1000
        if (sender instanceof Player) {
            player = (Player)sender;
            ** if (target == null || !player.getUniqueId().equals((Object)target.getUniqueId())) goto lbl-1000
        }
        ** GOTO lbl-1000
lbl-1000:
        // 2 sources

        {
            v0 = true;
            ** GOTO lbl32
        }
lbl-1000:
        // 2 sources

        {
            v0 = false;
        }
lbl32:
        // 2 sources

        selfRequest = v0;
        path = selfRequest != false ? "PLAYTIME.MESSAGE" : "PLAYTIME.OTHER";
        fallback = selfRequest != false ? "&a%time% &eplaying on &a%server%" : "&e%player% &7has played for &a%time% &7on &a%server%";
        sender.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault(path, fallback, new String[]{"%player%", targetName, "%time%", time, "%server%", server})));
        return true;
    }

    private PlayerData resolvePlayerData(CommandSender viewer, Player target, String requestedName) {
        if (target != null) {
            PlayerData cached = this.plugin.getPlayerDataManager().get(target);
            return cached != null ? cached : this.plugin.getDatabaseManager().loadPlayer(target.getUniqueId());
        }
        UUID uuid = PlayerLookup.findKnownPlayerUuid(this.plugin, requestedName);
        return uuid == null ? null : this.plugin.getDatabaseManager().loadPlayer(uuid);
    }

    private String resolveStoredName(PlayerData data, String requestedName) {
        String username = data.getUsername();
        if (username != null && !username.isBlank()) {
            return username;
        }
        return requestedName == null || requestedName.isBlank() ? "unknown" : requestedName;
    }

    private String resolveServerName() {
        String displayName = this.plugin.getConfigManager().getConfig().getString("NETWORK-STATUS.LOCAL-DISPLAY-NAME", "");
        if (displayName != null && !displayName.isBlank()) {
            return displayName;
        }
        String serverId = this.plugin.getConfigManager().getConfig().getString("NETWORK-STATUS.LOCAL-SERVER-ID", "");
        if (serverId != null && !serverId.isBlank()) {
            return serverId;
        }
        return "server";
    }
}

