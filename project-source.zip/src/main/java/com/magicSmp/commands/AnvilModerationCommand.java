/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.permissions.Permissible
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.PermissionUtils;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.permissions.Permissible;

public class AnvilModerationCommand
implements CommandExecutor,
TabCompleter {
    private final MagicSmp plugin;

    public AnvilModerationCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!PermissionUtils.has((Permissible)sender, "anvilmod.admin")) {
            sender.sendMessage(ColorUtils.toComponent(this.plugin.getLanguageManager().text("MESSAGES.ANVILMOD.NO-PERMISSION", "&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274.")));
            return true;
        }
        if (args.length == 0) {
            this.sendUsage(sender);
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        if (sub.equals("add")) {
            if (args.length < 2) {
                this.sendUsage(sender);
                return true;
            }
            String word = args[1];
            boolean success = this.plugin.getAnvilModerationManager().addBannedWord(word);
            if (success) {
                sender.sendMessage(ColorUtils.toComponent(this.plugin.getLanguageManager().text("MESSAGES.ANVILMOD.ADDED", "&a\u0455\u1d1c\u1d04\u1d04\u1d07\u0455\u0455\ua730\u1d1c\u029f\u029f\u028f \u1d00\u1d05\u1d05\u1d07\u1d05 '&e{word}&a' \u1d1b\u1d0f \u0299\u1d00\u0274\u0274\u1d07\u1d05 \u1d21\u1d0f\u0280\u1d05\u0455.", "{word}", word)));
            } else {
                sender.sendMessage(ColorUtils.toComponent(this.plugin.getLanguageManager().text("MESSAGES.ANVILMOD.ALREADY-EXISTS", "&c\u1d1b\u029c\u1d00\u1d1b \u1d21\u1d0f\u0280\u1d05 \u026a\u0455 \u1d00\u029f\u0280\u1d07\u1d00\u1d05\u028f \u026a\u0274 \u1d1b\u029c\u1d07 \u0299\u1d00\u0274\u0274\u1d07\u1d05 \u029f\u026a\u0455\u1d1b.")));
            }
            return true;
        }
        if (sub.equals("reload")) {
            this.plugin.getAnvilModerationManager().load();
            sender.sendMessage(ColorUtils.toComponent(this.plugin.getLanguageManager().text("MESSAGES.ANVILMOD.RELOADED", "&a\u1d00\u0274\u1d20\u026a\u029f \u1d0d\u1d0f\u1d05\u1d07\u0280\u1d00\u1d1b\u026a\u1d0f\u0274 \u1d04\u1d0f\u0274\ua730\u026a\u0262 \u0280\u1d07\u029f\u1d0f\u1d00\u1d05\u1d07\u1d05.")));
            return true;
        }
        this.sendUsage(sender);
        return true;
    }

    private void sendUsage(CommandSender sender) {
        sender.sendMessage(ColorUtils.toComponent(this.plugin.getLanguageManager().text("MESSAGES.ANVILMOD.USAGE", "&c\u1d1c\u0455\u1d00\u0262\u1d07: /amod <add|reload> [\u1d21\u1d0f\u0280\u1d05]")));
    }

    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        if (!PermissionUtils.has((Permissible)sender, "anvilmod.admin")) {
            return Collections.emptyList();
        }
        if (args.length == 1) {
            ArrayList<String> suggestions = new ArrayList<String>();
            String input = args[0].toLowerCase(Locale.ROOT);
            if ("add".startsWith(input)) {
                suggestions.add("add");
            }
            if ("reload".startsWith(input)) {
                suggestions.add("reload");
            }
            return suggestions;
        }
        return Collections.emptyList();
    }
}

