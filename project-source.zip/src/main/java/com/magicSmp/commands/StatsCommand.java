/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.OfflinePlayer
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.menus.StatsMenu;
import com.bx.magicSmp.models.PlayerData;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.PlayerLookup;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class StatsCommand
implements CommandExecutor {
    private final MagicSmp plugin;

    public StatsCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        String targetName;
        UUID targetUuid;
        Player player;
        if (args.length > 1) {
            sender.sendMessage(ColorUtils.toComponent("&cUsage: /" + label + " [player]"));
            return true;
        }
        if (args.length == 0) {
            if (!(sender instanceof Player)) {
                sender.sendMessage(ColorUtils.toComponent("&cUsage: /" + label + " <player>"));
                return true;
            }
            player = (Player)sender;
            targetUuid = player.getUniqueId();
            targetName = player.getName();
        } else {
            Player online = PlayerLookup.findOnlinePlayer(args[0]);
            if (online != null) {
                targetUuid = online.getUniqueId();
                targetName = online.getName();
            } else {
                String fallback;
                targetUuid = PlayerLookup.findKnownPlayerUuid(this.plugin, args[0]);
                if (targetUuid == null) {
                    sender.sendMessage(ColorUtils.toComponent("&cPlayer not found."));
                    return true;
                }
                OfflinePlayer offline = Bukkit.getOfflinePlayer((UUID)targetUuid);
                String lastKnown = this.plugin.getDatabaseManager().getLastKnownUsername(targetUuid);
                targetName = fallback = lastKnown == null || lastKnown.isBlank() ? (offline.getName() == null ? args[0] : offline.getName()) : lastKnown;
            }
        }
        if (sender instanceof Player) {
            player = (Player)sender;
            new StatsMenu(this.plugin, targetUuid, targetName).open(player);
        } else {
            PlayerData data = this.plugin.getPlayerDataManager().get(targetUuid);
            if (data == null) {
                data = this.plugin.getDatabaseManager().loadPlayer(targetUuid);
            }
            if (data == null) {
                sender.sendMessage(ColorUtils.toComponent("&cPlayer not found."));
                return true;
            }
            sender.sendMessage(ColorUtils.toComponent("&7&m------------------"));
            sender.sendMessage(ColorUtils.toComponent("&b" + targetName + "&7's Stats:"));
            sender.sendMessage(ColorUtils.toComponent("Money: " + this.plugin.getCurrencyManager().formatMoneyCompact(data.getMoney())));
            sender.sendMessage(ColorUtils.toComponent("Kills: " + data.getKills()));
            sender.sendMessage(ColorUtils.toComponent("Deaths: " + data.getDeaths()));
            sender.sendMessage(ColorUtils.toComponent("&7&m------------------"));
        }
        return true;
    }
}

