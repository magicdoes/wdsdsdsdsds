/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.menus.RulesMenu;
import com.bx.magicSmp.utils.ColorUtils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class RulesCommand
implements CommandExecutor {
    private final MagicSmp plugin;

    public RulesCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u1d0f\u0274\u029f\u028f.");
            return true;
        }
        Player player = (Player)sender;
        if (!this.plugin.getConfigManager().isCommandEnabled("RULES")) {
            player.sendMessage(ColorUtils.toComponent("&c\u0280\u1d1c\u029f\u1d07\u0455 \u1d04\u1d0f\u1d0d\u1d0d\u1d00\u0274\u1d05 \u026a\u0455 \u1d04\u1d1c\u0280\u0280\u1d07\u0274\u1d1b\u029f\u028f \u1d05\u026a\u0455\u1d00\u0299\u029f\u1d07\u1d05."));
            return true;
        }
        RulesMenu menu = new RulesMenu(this.plugin);
        if (menu.hasValidButtons()) {
            menu.open(player);
            return true;
        }
        this.sendLegacyRules(player);
        return true;
    }

    private void sendLegacyRules(Player player) {
        player.sendMessage(ColorUtils.toComponent("&7&m---------- &b\u0455\u1d07\u0280\u1d20\u1d07\u0280 \u0280\u1d1c\u029f\u1d07\u0455 &7&m----------"));
        player.sendMessage(ColorUtils.toComponent("&71. &f\u0274\u1d0f \u1d04\u029c\u1d07\u1d00\u1d1b\u026a\u0274\u0262 \u1d0f\u0280 \u029c\u1d00\u1d04\u1d0b\u026a\u0274\u0262"));
        player.sendMessage(ColorUtils.toComponent("&72. &f\u0299\u1d07 \u0280\u1d07\u0455\u1d18\u1d07\u1d04\u1d1b\ua730\u1d1c\u029f \u1d1b\u1d0f \u1d0f\u1d1b\u029c\u1d07\u0280 \u1d18\u029f\u1d00\u028f\u1d07\u0280\u0455"));
        player.sendMessage(ColorUtils.toComponent("&73. &f\u0274\u1d0f \u0262\u0280\u026a\u1d07\ua730\u026a\u0274\u0262 \u1d00\u1d1b \u0455\u1d18\u1d00\u1d21\u0274"));
        player.sendMessage(ColorUtils.toComponent("&74. &f\u0274\u1d0f \u1d1c\u0455\u1d07 \u1d0f\ua730 \u1d07x\u1d18\u029f\u1d0f\u026a\u1d1b\u0455 \u1d0f\u0280 \u1d05\u1d1c\u1d18\u029f\u026a\u1d04\u1d00\u1d1b\u026a\u1d0f\u0274"));
        player.sendMessage(ColorUtils.toComponent("&75. &f\u029c\u1d00\u1d20\u1d07 \ua730\u1d1c\u0274!"));
        player.sendMessage(ColorUtils.toComponent("&7&m-----------------------------------"));
    }
}

