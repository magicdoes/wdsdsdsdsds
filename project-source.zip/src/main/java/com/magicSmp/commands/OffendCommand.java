/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.permissions.Permissible
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.managers.OffenseManager;
import com.bx.magicSmp.managers.PunishmentManager;
import com.bx.magicSmp.models.PunishmentQuery;
import com.bx.magicSmp.models.PunishmentRecord;
import com.bx.magicSmp.models.PunishmentScope;
import com.bx.magicSmp.models.PunishmentType;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.NumberUtils;
import com.bx.magicSmp.utils.PermissionUtils;
import java.lang.invoke.LambdaMetafactory;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.permissions.Permissible;

public class OffendCommand
implements CommandExecutor,
TabCompleter {
    private static final String OFFEND_PERMISSION = "MagicSMP.staff.punishments.offend";
    private static final String CREATE_PERMISSION = "MagicSMP.staff.punishments.create";
    private final MagicSmp plugin;

    public OffendCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Long durationMillis;
        Long expiresAt;
        if (!PermissionUtils.has((Permissible)sender, OFFEND_PERMISSION) && !PermissionUtils.has((Permissible)sender, CREATE_PERMISSION)) {
            this.sendMessage(sender, this.plugin.getConfigManager().getMessageOrDefault("PUNISHMENTS.NO-CREATE-PERMISSION", "&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274 \u1d1b\u1d0f \u1d04\u0280\u1d07\u1d00\u1d1b\u1d07 \u1d18\u1d1c\u0274\u026a\u0455\u029c\u1d0d\u1d07\u0274\u1d1b\u0455."));
            return true;
        }
        if (args.length < 2) {
            this.sendMessage(sender, "&cUsage: /offend <player> <reason> [time]");
            return true;
        }
        String targetInput = args[0];
        String reasonKeyInput = args[1].toLowerCase(Locale.ROOT);
        ResolvedTarget target = this.resolveTarget(targetInput);
        if (target == null || target.uuid() == null) {
            this.sendMessage(sender, this.plugin.getConfigManager().getMessageOrDefault("PUNISHMENTS.NOT-FOUND", "&c\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u0274\u1d0f\u1d1b \ua730\u1d0f\u1d1c\u0274\u1d05."));
            return true;
        }
        Player onlineTarget = Bukkit.getPlayer(target.uuid());
        OffenseManager offenseManager = this.plugin.getOffenseManager();
        Optional<OffenseManager.OffenseRule> ruleOpt = offenseManager.getOffenseRule(reasonKeyInput);
        PunishmentType type = PunishmentType.BAN;
        Object reasonDisplay = args[1];
        String durationStr = null;
        if (args.length >= 3) {
            durationStr = args[2];
        }
        if (ruleOpt.isPresent()) {
            OffenseManager.OffenseRule rule = ruleOpt.get();
            type = rule.type();
            reasonDisplay = rule.name() + " (" + rule.key() + ")";
            if (durationStr == null) {
                int previousInfractions = this.plugin.getPunishmentManager().countHistory(target.uuid(), target.name(), new PunishmentQuery(null, null, null));
                durationStr = rule.getDurationForTier(previousInfractions);
            }
        }
        Long l = expiresAt = (durationMillis = OffenseManager.parseDurationToMillis(durationStr)) != null && durationMillis > 0L ? Long.valueOf(System.currentTimeMillis() + durationMillis) : null;
        if (durationMillis != null && durationMillis == 0L && type != PunishmentType.WARN) {
            type = PunishmentType.WARN;
        }
        Actor actor = this.resolveActor(sender);
        PunishmentRecord record = this.plugin.getPunishmentManager().createRecord(new PunishmentManager.PunishmentCreateRequest(target.uuid(), target.name(), type, (String)reasonDisplay, actor.uuid(), actor.name(), System.currentTimeMillis(), expiresAt, "local", PunishmentScope.SERVER));
        if (record == null) {
            this.sendMessage(sender, this.plugin.getConfigManager().getMessageOrDefault("PUNISHMENTS.CREATE-FAILED", "&c\ua730\u1d00\u026a\u029f\u1d07\u1d05 \u1d1b\u1d0f \u1d04\u0280\u1d07\u1d00\u1d1b\u1d07 \u1d18\u1d1c\u0274\u026a\u0455\u029c\u1d0d\u1d07\u0274\u1d1b \u0280\u1d07\u1d04\u1d0f\u0280\u1d05."));
            return true;
        }
        this.applyRuntimeEffect(type, onlineTarget, record);
        if (this.plugin.getDiscordWebhookManager() != null) {
            this.plugin.getDiscordWebhookManager().sendPunishment(record);
        }
        String durationDisplay = expiresAt == null ? "Permanent" : NumberUtils.formatCountdown(Math.max(0L, (expiresAt - System.currentTimeMillis()) / 1000L));
        this.sendMessage(sender, "&aSuccessfully issued &f" + type.name() + " &apunishment to &b" + target.name() + "&a! [Duration: &f" + durationDisplay + "&a, Reason: &f" + (String)reasonDisplay + "&a]");
        return true;
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            String partial = args[0].toLowerCase(Locale.ROOT);
            return Bukkit.getOnlinePlayers().stream().map(Player::getName).filter(name -> name.toLowerCase(Locale.ROOT).startsWith(partial)).collect(Collectors.toList());
        }
        if (args.length == 2) {
            String partial = args[1].toLowerCase(Locale.ROOT);
            return this.plugin.getOffenseManager().getOffenseKeys().stream().filter(key -> key.toLowerCase(Locale.ROOT).startsWith(partial)).sorted().collect(Collectors.toList());
        }
        if (args.length == 3) {
            String partial = args[2].toLowerCase(Locale.ROOT);
            List<String> durations = List.of("24h", "3d", "7d", "14d", "30d", "60d", "180d", "360d", "perm");
            return durations.stream().filter(d -> d.startsWith(partial)).collect(Collectors.toList());
        }
        return Collections.emptyList();
    }

    private void applyRuntimeEffect(PunishmentType type, Player onlineTarget, PunishmentRecord record) {
        if (onlineTarget == null) {
            return;
        }
        switch (type) {
            case BAN: 
            case BLACKLIST: 
            case KICK: {
                onlineTarget.kickPlayer(ColorUtils.toComponent(this.buildPunishmentMessage(record)));
                break;
            }
            case WARN: {
                onlineTarget.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("PUNISHMENTS.WARN-RECEIVED", "&c\u1d21\u1d00\u0280\u0274\u026a\u0274\u0262: &f{reason}", "{reason}", record.getReason())));
                break;
            }
            case MUTE: {
                onlineTarget.sendMessage(ColorUtils.toComponent(this.buildPunishmentMessage(record)));
            }
        }
    }

    private String buildPunishmentMessage(PunishmentRecord record) {
        return this.plugin.getConfigManager().getMessageOrDefault(this.punishmentMessagePath(record.getType()), this.defaultPunishmentMessage(record.getType()), this.punishmentPlaceholders(record));
    }

    private String punishmentMessagePath(PunishmentType type) {
        return switch (type) {
            default -> throw new MatchException(null, null);
            case PunishmentType.BAN -> "PUNISHMENTS.BAN";
            case PunishmentType.KICK -> "PUNISHMENTS.KICK";
            case PunishmentType.MUTE -> "PUNISHMENTS.MUTE";
            case PunishmentType.BLACKLIST -> "PUNISHMENTS.BLACKLIST";
            case PunishmentType.WARN -> "PUNISHMENTS.WARN-RECEIVED";
        };
    }

    private String defaultPunishmentMessage(PunishmentType type) {
        return switch (type) {
            default -> throw new MatchException(null, null);
            case PunishmentType.BAN -> "&c&lyou have been banned!\n&8&m----------------------------\n&7reason: &f%reason%\n&7expires: &f%nicest_expiration%\n&7banned by: &f%issuer%\n&8&m----------------------------";
            case PunishmentType.KICK -> "&c&lyou have been kicked!\n&8&m----------------------------\n&7reason: &f%reason%\n&7kicked by: &f%issuer%\n&8&m----------------------------";
            case PunishmentType.MUTE -> "&c&lyou have been muted!\n&8&m----------------------------\n&7reason: &f%reason%\n&7expires: &f%nicest_expiration%\n&7muted by: &f%issuer%\n&8&m----------------------------";
            case PunishmentType.BLACKLIST -> "&4&lyou have been blacklisted!\n&8&m----------------------------\n&7reason: &f%reason%\n&7blacklisted by: &f%issuer%\n&8&m----------------------------";
            case PunishmentType.WARN -> "&cwarning: &f{reason}";
        };
    }

    private String[] punishmentPlaceholders(PunishmentRecord record) {
        String expires = this.formatExpires(record);
        String issuer = this.formatIssuer(record);
        String reason = record == null || record.getReason() == null ? "" : record.getReason();
        String player = record == null || record.getTargetNameSnapshot() == null ? "" : record.getTargetNameSnapshot();
        String id = record == null ? "" : String.valueOf(record.getId());
        String type = record == null || record.getType() == null ? "" : record.getType().name();
        return new String[]{"%reason%", reason, "{reason}", reason, "%nicest_expiration%", expires, "{nicest_expiration}", expires, "%expires%", expires, "{expires}", expires, "%expires_at%", expires, "{expires_at}", expires, "%expiration%", expires, "{expiration}", expires, "%expiry%", expires, "{expiry}", expires, "%duration%", expires, "{duration}", expires, "%issuer%", issuer, "{issuer}", issuer, "%staff%", issuer, "{staff}", issuer, "%by%", issuer, "{by}", issuer, "%player%", player, "{player}", player, "%target%", player, "{target}", player, "%id%", id, "{id}", id, "%type%", type, "{type}", type};
    }

    private String formatExpires(PunishmentRecord record) {
        if (record == null || record.getExpiresAt() == null) {
            return "Permanent";
        }
        long remainingSeconds = Math.max(0L, (record.getExpiresAt() - System.currentTimeMillis()) / 1000L);
        if (remainingSeconds <= 0L) {
            return "Expired";
        }
        if (this.plugin != null && this.plugin.getLanguageManager() != null) {
            return this.plugin.getLanguageManager().formatDuration(remainingSeconds, true);
        }
        return NumberUtils.formatCountdown(remainingSeconds);
    }

    private String formatIssuer(PunishmentRecord record) {
        if (record == null) {
            return "unknown";
        }
        String issuer = record.getIssuerNameSnapshot();
        return issuer == null || issuer.isBlank() ? "unknown" : issuer;
    }

    private ResolvedTarget resolveTarget(String input) {
        Player online = Bukkit.getPlayerExact((String)input);
        if (online == null) {
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (!player.getName().equalsIgnoreCase(input)) continue;
                online = player;
                break;
            }
        }
        if (online != null) {
            return new ResolvedTarget(online.getUniqueId(), online.getName());
        }
        UUID knownUuid = this.plugin.getPunishmentManager().resolveTargetUuid(input, true).orElse(null);
        if (knownUuid != null) {
            return new ResolvedTarget(knownUuid, this.plugin.getPunishmentManager().resolveTargetName(knownUuid, input));
        }
        return null;
    }

    private Actor resolveActor(CommandSender sender) {
        if (sender instanceof Player) {
            Player player = (Player)sender;
            return new Actor(player.getUniqueId(), player.getName());
        }
        return new Actor(null, "console");
    }

    private void sendMessage(CommandSender sender, String message) {
        if (sender != null && message != null && !message.isBlank()) {
            sender.sendMessage(ColorUtils.toComponent(message));
        }
    }

    private record ResolvedTarget(UUID uuid, String name) {
    }

    private record Actor(UUID uuid, String name) {
    }
}

