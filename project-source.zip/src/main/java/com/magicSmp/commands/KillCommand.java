/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.menus.ConfirmKillMenu;
import com.bx.magicSmp.utils.ColorUtils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class KillCommand
implements CommandExecutor {
    private final MagicSmp plugin;

    public KillCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u1d0f\u0274\u029f\u028f.");
            return true;
        }
        Player player = (Player)sender;
        if (this.plugin.getCombatManager().isInCombat(player.getUniqueId())) {
            player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getConfig().getString("COMBAT-MANAGER.BLOCK-MESSAGE", "&c\u028f\u1d0f\u1d1c \u1d04\u1d00\u0274'\u1d1b \u1d1c\u0455\u1d07 \u1d1b\u029c\u026a\u0455 \u1d04\u1d0f\u1d0d\u1d0d\u1d00\u0274\u1d05 \u026a\u0274 \u1d04\u1d0f\u1d0d\u0299\u1d00\u1d1b.")));
            return true;
        }
        new ConfirmKillMenu(this.plugin).open(player);
        return true;
    }
}

