/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.TabCompleter
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.managers.FeatureManager;
import com.bx.magicSmp.utils.ColorUtils;
import java.util.Collections;
import java.util.List;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

public class FeatureCommandExecutor
implements CommandExecutor,
TabCompleter {
    private final MagicSmp plugin;
    private final CommandExecutor delegate;
    private final FeatureManager.Feature[] requiredFeatures;

    public FeatureCommandExecutor(MagicSmp plugin, CommandExecutor delegate, FeatureManager.Feature ... requiredFeatures) {
        this.plugin = plugin;
        this.delegate = delegate;
        this.requiredFeatures = requiredFeatures == null ? new FeatureManager.Feature[]{} : requiredFeatures;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        for (FeatureManager.Feature feature : this.requiredFeatures) {
            if (feature == null || this.plugin.getFeatureManager().isEnabled(feature)) continue;
            FeatureManager.DisabledCommandAction action = this.plugin.getFeatureManager().getDisabledCommandAction();
            if (action == FeatureManager.DisabledCommandAction.UNREGISTER) {
                return false;
            }
            if (action == FeatureManager.DisabledCommandAction.UNKNOWN) {
                sender.sendMessage(ColorUtils.toComponent("&cUnknown command. Type \"/help\" for help."));
            } else {
                this.plugin.getFeatureManager().sendDisabledMessage(sender, feature, label);
            }
            return true;
        }
        return this.delegate.onCommand(sender, command, label, args);
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        for (FeatureManager.Feature feature : this.requiredFeatures) {
            if (feature == null || this.plugin.getFeatureManager().isEnabled(feature)) continue;
            return Collections.emptyList();
        }
        CommandExecutor commandExecutor = this.delegate;
        if (commandExecutor instanceof TabCompleter) {
            TabCompleter tabCompleter = (TabCompleter)commandExecutor;
            return tabCompleter.onTabComplete(sender, command, alias, args);
        }
        return Collections.emptyList();
    }
}

