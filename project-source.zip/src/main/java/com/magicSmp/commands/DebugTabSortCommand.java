/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.CommandMap
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import java.lang.reflect.Field;
import java.util.Collections;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandMap;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class DebugTabSortCommand
extends Command
implements CommandExecutor {
    private final MagicSmp plugin;

    public DebugTabSortCommand(MagicSmp plugin) {
        super("debugtabsort", "Manually trigger tab list sorting by weight", "/debugtabsort", Collections.emptyList());
        this.plugin = plugin;
        this.setPermission("MagicSMP.admin.debug");
    }

    public boolean execute(CommandSender sender, String label, String[] args) {
        Player player;
        if (sender instanceof Player && !(player = (Player)sender).hasPermission("MagicSMP.admin.debug")) {
            player.sendMessage("\u00a7cYou don't have permission.");
            return true;
        }
        sender.sendMessage("\u00a7cTab list sorting has been removed. Please use the TAB plugin instead.");
        return true;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        return this.execute(sender, label, args);
    }

    public boolean registerDynamically() {
        try {
            Field commandMapField = Bukkit.getServer().getClass().getDeclaredField("commandMap");
            commandMapField.setAccessible(true);
            Object commandMap = commandMapField.get(Bukkit.getServer());
            return ((CommandMap)commandMap).register(this.plugin.getName().toLowerCase(), (Command)this);
        }
        catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}

