/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.menus.HomeMenu;
import com.bx.magicSmp.models.Home;
import com.bx.magicSmp.utils.ColorUtils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class HomeCommand
implements CommandExecutor {
    private final MagicSmp plugin;

    public HomeCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Player only.");
            return true;
        }
        Player player = (Player)sender;
        if (this.plugin.getCombatManager().isInCombat(player.getUniqueId())) {
            player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getConfig().getString("COMBAT-MANAGER.BLOCK-MESSAGE", "&cYou can't use this in combat.")));
            return true;
        }
        String sub = label.toLowerCase();
        if (sub.equals("homes")) {
            if (this.plugin.getHomeBedrockManager() != null && this.plugin.getHomeBedrockManager().isBedrockPlayer(player)) {
                this.plugin.getHomeBedrockManager().openMain(player);
            } else {
                new HomeMenu(this.plugin).open(player);
            }
            return true;
        }
        if (sub.equals("sethome")) {
            String name = args.length > 0 ? args[0] : "home";
            boolean success = this.plugin.getHomeManager().setHome(player, name);
            if (success) {
                player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessage("HOME.SET")));
            } else {
                player.sendMessage(ColorUtils.toComponent("&cYou've reached your home limit or the home already exists at this name."));
            }
            return true;
        }
        if (sub.equals("delhome")) {
            if (args.length == 0) {
                if (this.plugin.getHomeBedrockManager() != null && this.plugin.getHomeBedrockManager().isBedrockPlayer(player)) {
                    this.plugin.getHomeBedrockManager().openDeleteSelect(player);
                } else {
                    player.sendMessage(ColorUtils.toComponent("&cUsage: /delhome <name>"));
                }
                return true;
            }
            boolean removed = this.plugin.getHomeManager().deleteHome(player.getUniqueId(), args[0]);
            player.sendMessage(ColorUtils.toComponent(removed ? this.plugin.getConfigManager().getMessage("HOME.DELETED") : "&cHome not found."));
            return true;
        }
        if (sub.equals("renamehome")) {
            if (args.length < 2) {
                player.sendMessage(ColorUtils.toComponent("&cUsage: /renamehome <old> <new>"));
                return true;
            }
            boolean ok = this.plugin.getHomeManager().renameHome(player.getUniqueId(), args[0], args[1]);
            player.sendMessage(ColorUtils.toComponent(ok ? this.plugin.getConfigManager().getMessage("HOME.RENAME-SUCCESS", "{name}", args[1]) : "&cFailed to rename home."));
            return true;
        }
        String homeName = args.length > 0 ? args[0] : "home";
        Home home = this.plugin.getHomeManager().getHome(player.getUniqueId(), homeName);
        if (home == null) {
            if (this.plugin.getHomeManager().getHomeCount(player.getUniqueId()) == 0) {
                if (this.plugin.getHomeBedrockManager() != null && this.plugin.getHomeBedrockManager().isBedrockPlayer(player)) {
                    this.plugin.getHomeBedrockManager().openMain(player);
                } else {
                    new HomeMenu(this.plugin).open(player);
                }
            } else {
                player.sendMessage(ColorUtils.toComponent("&cHome '&e" + homeName + "&c' not found."));
            }
            return true;
        }
        this.plugin.getTeleportManager().queue(player, home.getLocation(), "HOME", null);
        return true;
    }
}

