/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.permissions.Permissible
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.models.PlayerData;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.PermissionUtils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.permissions.Permissible;

public class PrivateMessageToggleCommand
implements CommandExecutor {
    private static final String PERMISSION = "MagicSMP.message.toggle";
    private final MagicSmp plugin;

    public PrivateMessageToggleCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!this.plugin.getConfigManager().isCommandEnabled("MESSAGE")) {
            this.send(sender, this.message("MESSAGES.DISABLED", "PRIVATE-MESSAGE.DISABLED", "&c\u1d18\u0280\u026a\u1d20\u1d00\u1d1b\u1d07 \u1d0d\u1d07\u0455\u0455\u1d00\u0262\u1d07\u0455 \u1d00\u0280\u1d07 \u1d04\u1d1c\u0280\u0280\u1d07\u0274\u1d1b\u029f\u028f \u1d05\u026a\u0455\u1d00\u0299\u029f\u1d07\u1d05."));
            return true;
        }
        if (!(sender instanceof Player)) {
            this.send(sender, this.message("MESSAGES.PLAYER_ONLY", null, "&c\u1d0f\u0274\u029f\u028f \u1d18\u029f\u1d00\u028f\u1d07\u0280\u0455 \u1d04\u1d00\u0274 \u1d1c\u0455\u1d07 \u1d1b\u029c\u026a\u0455 \u1d04\u1d0f\u1d0d\u1d0d\u1d00\u0274\u1d05."));
            return true;
        }
        Player player = (Player)sender;
        if (!PermissionUtils.has((Permissible)player, PERMISSION)) {
            this.send(player, this.message("MESSAGES.NO_PERMISSION", "PRIVATE-MESSAGE.NO-PERMISSION", "&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274."));
            return true;
        }
        PlayerData data = this.plugin.getPlayerDataManager().get(player);
        if (data == null) {
            data = this.plugin.getPlayerDataManager().loadOrCreate(player);
        }
        boolean enabled = !data.isPrivateMessagesEnabled();
        data.setPrivateMessagesEnabled(enabled);
        this.plugin.getDatabaseManager().savePlayer(data);
        this.send(player, this.message(enabled ? "PRIVATE_MESSAGES.PM_ENABLED" : "PRIVATE_MESSAGES.PM_DISABLED", enabled ? "PRIVATE-MESSAGE.PM-ENABLED" : "PRIVATE-MESSAGE.PM-DISABLED", enabled ? "&a\u1d18\u0280\u026a\u1d20\u1d00\u1d1b\u1d07 \u1d0d\u1d07\u0455\u0455\u1d00\u0262\u1d07\u0455 \u1d00\u0280\u1d07 \u0274\u1d0f\u1d21 \u1d07\u0274\u1d00\u0299\u029f\u1d07\u1d05" : "&c\u1d18\u0280\u026a\u1d20\u1d00\u1d1b\u1d07 \u1d0d\u1d07\u0455\u0455\u1d00\u0262\u1d07\u0455 \u1d00\u0280\u1d07 \u0274\u1d0f\u1d21 \u1d05\u026a\u0455\u1d00\u0299\u029f\u1d07\u1d05"));
        return true;
    }

    private void send(CommandSender sender, String message) {
        if (sender instanceof Player) {
            Player player = (Player)sender;
            player.sendMessage(ColorUtils.toComponent(message, player));
            return;
        }
        sender.sendMessage(ColorUtils.colorize(message));
    }

    private String message(String path, String fallbackPath, String fallback) {
        String value = this.plugin.getConfigManager().getMessages().getString(path);
        if (value != null) {
            return value;
        }
        if (fallbackPath != null && (value = this.plugin.getConfigManager().getMessages().getString(fallbackPath)) != null) {
            return value;
        }
        return fallback;
    }
}

