/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.permissions.Permissible
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.managers.SpawnManager;
import com.bx.magicSmp.menus.SpawnMenu;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.PermissionUtils;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.permissions.Permissible;

public class SpawnCommand
implements CommandExecutor {
    private final MagicSmp plugin;

    public SpawnCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Player only.");
            return true;
        }
        Player player = (Player)sender;
        if (args.length > 0 && (args[0].equalsIgnoreCase("set") || args[0].equalsIgnoreCase("setspawn") || args[0].equalsIgnoreCase("setup"))) {
            if (!PermissionUtils.has((Permissible)player, "MagicSMP.command.setspawn") && !PermissionUtils.has((Permissible)player, "MagicSMP.admin.setup")) {
                player.sendMessage(ColorUtils.toComponent("&cYou do not have permission to set spawn."));
                return true;
            }
            Location location = player.getLocation();
            SpawnManager.SetupLocationResult result = this.plugin.getSpawnManager().setSpawnLocation(location);
            if (!result.success()) {
                player.sendMessage(ColorUtils.toComponent("&cSpawn location could not be saved: &f" + result.message()));
                return true;
            }
            player.sendMessage(ColorUtils.toComponent("&aSpawn location saved. &7(World: &f" + (location.getWorld() == null ? "unknown" : location.getWorld().getName()) + "&7, X: &f" + String.format("%.1f", location.getX()) + "&7, Y: &f" + String.format("%.1f", location.getY()) + "&7, Z: &f" + String.format("%.1f", location.getZ()) + "&7)"));
            return true;
        }
        if (this.plugin.getCombatManager().isInCombat(player.getUniqueId())) {
            player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getConfig().getString("COMBAT-MANAGER.BLOCK-MESSAGE", "&c\u028f\u1d0f\u1d1c \u1d04\u1d00\u0274'\u1d1b \u1d1c\u0455\u1d07 \u1d1b\u029c\u026a\u0455 \u1d04\u1d0f\u1d0d\u1d0d\u1d00\u0274\u1d05 \u026a\u0274 \u1d04\u1d0f\u1d0d\u0299\u1d00\u1d1b.")));
            return true;
        }
        if (this.plugin.getSpawnManager().shouldOpenMenu(SpawnManager.AreaType.SPAWN)) {
            new SpawnMenu(this.plugin).open(player);
            return true;
        }
        Location destination = this.plugin.getSpawnManager().resolveCommandDestination(SpawnManager.AreaType.SPAWN);
        if (destination == null) {
            player.sendMessage(ColorUtils.toComponent("&c\u0455\u1d18\u1d00\u1d21\u0274 \u029f\u1d0f\u1d04\u1d00\u1d1b\u026a\u1d0f\u0274 \u026a\u0455 \u0274\u1d0f\u1d1b \u0455\u1d07\u1d1b."));
            return true;
        }
        this.plugin.getTeleportManager().queue(player, destination, "SPAWN", null);
        return true;
    }
}

