/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.util.StringUtil
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.managers.MaintenanceManager;
import com.bx.magicSmp.utils.ColorUtils;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.util.StringUtil;

public class MaintenanceCommand
implements CommandExecutor,
TabCompleter {
    private final MagicSmp plugin;

    public MaintenanceCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("MagicSMP.admin.maintenance")) {
            sender.sendMessage(ColorUtils.toComponent("&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274 \u1d1b\u1d0f \u1d0d\u1d00\u0274\u1d00\u0262\u1d07 \u1d0d\u1d00\u026a\u0274\u1d1b\u1d07\u0274\u1d00\u0274\u1d04\u1d07 \u1d0d\u1d0f\u1d05\u1d07."));
            return true;
        }
        if (args.length < 1) {
            sender.sendMessage(ColorUtils.toComponent("&c\u1d1c\u0455\u1d00\u0262\u1d07: /" + label + " <on|off|status|setlobby [server]>"));
            return true;
        }
        MaintenanceManager mm = this.plugin.getMaintenanceManager();
        if (mm == null) {
            sender.sendMessage(ColorUtils.toComponent("&c\u1d0d\u1d00\u026a\u0274\u1d1b\u1d07\u0274\u1d00\u0274\u1d04\u1d07 \u1d0d\u1d00\u0274\u1d00\u0262\u1d07\u0280 \u026a\u0455 \u0274\u1d0f\u1d1b \u1d00\u1d20\u1d00\u026a\u029f\u1d00\u0299\u029f\u1d07."));
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "on": 
            case "start": 
            case "enable": {
                if (mm.isMaintenanceActive()) {
                    sender.sendMessage(ColorUtils.toComponent("&e\u1d0d\u1d00\u026a\u0274\u1d1b\u1d07\u0274\u1d00\u0274\u1d04\u1d07 \u1d0d\u1d0f\u1d05\u1d07 \u026a\u0455 \u1d00\u029f\u0280\u1d07\u1d00\u1d05\u028f \u1d00\u1d04\u1d1b\u026a\u1d20\u1d07."));
                    return true;
                }
                mm.startMaintenance();
                sender.sendMessage(ColorUtils.toComponent("&a\u1d0d\u1d00\u026a\u0274\u1d1b\u1d07\u0274\u1d00\u0274\u1d04\u1d07 \u1d0d\u1d0f\u1d05\u1d07 \u029c\u1d00\u0455 \u0299\u1d07\u1d07\u0274 \u1d07\u0274\u1d00\u0299\u029f\u1d07\u1d05. \u1d18\u029f\u1d00\u028f\u1d07\u0280\u0455 \u1d00\u0280\u1d07 \u0299\u1d07\u026a\u0274\u0262 \u0280\u1d07\u1d05\u026a\u0280\u1d07\u1d04\u1d1b\u1d07\u1d05."));
                break;
            }
            case "off": 
            case "stop": 
            case "disable": {
                if (!mm.isMaintenanceActive()) {
                    sender.sendMessage(ColorUtils.toComponent("&e\u1d0d\u1d00\u026a\u0274\u1d1b\u1d07\u0274\u1d00\u0274\u1d04\u1d07 \u1d0d\u1d0f\u1d05\u1d07 \u026a\u0455 \u0274\u1d0f\u1d1b \u1d00\u1d04\u1d1b\u026a\u1d20\u1d07."));
                    return true;
                }
                mm.stopMaintenance();
                sender.sendMessage(ColorUtils.toComponent("&a\u1d0d\u1d00\u026a\u0274\u1d1b\u1d07\u0274\u1d00\u0274\u1d04\u1d07 \u1d0d\u1d0f\u1d05\u1d07 \u029c\u1d00\u0455 \u0299\u1d07\u1d07\u0274 \u1d05\u026a\u0455\u1d00\u0299\u029f\u1d07\u1d05. \u0280\u1d07\u1d04\u1d0f\u0274\u0274\u1d07\u1d04\u1d1b \u0455\u026a\u0262\u0274\u1d00\u029f \u0455\u1d07\u0274\u1d1b."));
                break;
            }
            case "status": {
                boolean active = mm.isMaintenanceActive();
                String lobby = mm.getLobbyServer();
                sender.sendMessage(ColorUtils.toComponent("&d&l\u1d0d\u1d00\u026a\u0274\u1d1b\u1d07\u0274\u1d00\u0274\u1d04\u1d07 \u0455\u1d1b\u1d00\u1d1b\u1d1c\u0455:"));
                sender.sendMessage(ColorUtils.toComponent("  &f\u1d00\u1d04\u1d1b\u026a\u1d20\u1d07: " + (active ? "&a\u028f\u1d07\u0455" : "&c\u0274\u1d0f")));
                sender.sendMessage(ColorUtils.toComponent("  &f\u029f\u1d0f\u0299\u0299\u028f \u0455\u1d07\u0280\u1d20\u1d07\u0280: &b" + lobby));
                break;
            }
            case "setlobby": {
                if (args.length < 2) {
                    sender.sendMessage(ColorUtils.toComponent("&c\u1d1c\u0455\u1d00\u0262\u1d07: /" + label + " \u0455\u1d07\u1d1b\u029f\u1d0f\u0299\u0299\u028f <server>"));
                    return true;
                }
                String lobby = args[1];
                mm.setLobbyServer(lobby);
                sender.sendMessage(ColorUtils.toComponent("&a\u029f\u1d0f\u0299\u0299\u028f \u0455\u1d07\u0280\u1d20\u1d07\u0280 \u0455\u1d07\u1d1b \u1d1b\u1d0f &b" + lobby + "&a."));
                break;
            }
            default: {
                sender.sendMessage(ColorUtils.toComponent("&c\u1d1c\u0455\u1d00\u0262\u1d07: /" + label + " <on|off|status|setlobby [server]>"));
            }
        }
        return true;
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!sender.hasPermission("MagicSMP.admin.maintenance")) {
            return List.of();
        }
        if (args.length == 1) {
            return (List)StringUtil.copyPartialMatches((String)args[0], List.of("on", "off", "status", "setlobby"), new ArrayList());
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("setlobby")) {
            ArrayList servers = new ArrayList();
            ConfigurationSection sec = this.plugin.getConfigManager().getConfig().getConfigurationSection("NETWORK-STATUS.SERVERS");
            if (sec != null) {
                servers.addAll(sec.getKeys(false));
            }
            return (List)StringUtil.copyPartialMatches((String)args[1], servers, new ArrayList());
        }
        return List.of();
    }
}

