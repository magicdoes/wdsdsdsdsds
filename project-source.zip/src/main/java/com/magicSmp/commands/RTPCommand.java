/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.menus.RTPMenu;
import com.bx.magicSmp.utils.ColorUtils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class RTPCommand
implements CommandExecutor {
    private final MagicSmp plugin;

    public RTPCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u1d0f\u0274\u029f\u028f.");
            return true;
        }
        Player player = (Player)sender;
        if (!this.plugin.getConfigManager().isCommandEnabled("RTP")) {
            player.sendMessage(ColorUtils.toComponent("&c\u0280\u1d1b\u1d18 \u1d04\u1d0f\u1d0d\u1d0d\u1d00\u0274\u1d05 \u026a\u0455 \u1d04\u1d1c\u0280\u0280\u1d07\u0274\u1d1b\u029f\u028f \u1d05\u026a\u0455\u1d00\u0299\u029f\u1d07\u1d05."));
            return true;
        }
        if (!this.plugin.getRtpManager().isEnabled()) {
            player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getRtp().getString("MESSAGES.DISABLED", "&c\u0280\u1d1b\u1d18 \u026a\u0455 \u1d05\u026a\u0455\u1d00\u0299\u029f\u1d07\u1d05.")));
            return true;
        }
        if (args.length == 0) {
            new RTPMenu(this.plugin).open(player);
            return true;
        }
        this.plugin.getRtpManager().queueCommandTeleport(player, args[0]);
        return true;
    }
}

