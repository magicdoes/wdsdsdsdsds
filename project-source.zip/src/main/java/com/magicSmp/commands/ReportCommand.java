/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.TabExecutor
 *  org.bukkit.permissions.Permissible
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.PermissionUtils;
import com.bx.magicSmp.utils.PlayerLookup;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.permissions.Permissible;

public class ReportCommand
implements TabExecutor {
    private static final String PERMISSION = "MagicSMP.report";
    private final MagicSmp plugin;

    public ReportCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("REPORT.PLAYER_ONLY", "&c\u1d0f\u0274\u029f\u028f \u1d18\u029f\u1d00\u028f\u1d07\u0280\u0455 \u1d04\u1d00\u0274 \u1d1c\u0455\u1d07 \u0280\u1d07\u1d18\u1d0f\u0280\u1d1b.")));
            return true;
        }
        Player reporter = (Player)sender;
        if (!PermissionUtils.has((Permissible)reporter, PERMISSION)) {
            reporter.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("REPORT.NO_PERMISSION", "&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274 \u1d1b\u1d0f \u0280\u1d07\u1d18\u1d0f\u0280\u1d1b \u1d18\u029f\u1d00\u028f\u1d07\u0280\u0455.")));
            return true;
        }
        if (args.length < 2) {
            reporter.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("REPORT.USAGE", "&c\u1d1c\u0455\u1d00\u0262\u1d07: /report <player> <reason>")));
            return true;
        }
        Player reported = PlayerLookup.findOnlinePlayer(args[0]);
        if (reported == null) {
            reporter.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("REPORT.PLAYER_NOT_FOUND", "&c\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u0274\u1d0f\u1d1b \ua730\u1d0f\u1d1c\u0274\u1d05.")));
            return true;
        }
        this.plugin.getStaffAlertManager().sendReport(reporter, reported, this.joinArgs(args, 1));
        return true;
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length != 1 || !PermissionUtils.has((Permissible)sender, PERMISSION)) {
            return List.of();
        }
        String input = args[0].toLowerCase();
        ArrayList<String> suggestions = new ArrayList<String>();
        for (String name : PlayerLookup.onlineNames()) {
            Player reporter;
            Player player = PlayerLookup.findOnlinePlayer(name);
            if (player == null || sender instanceof Player && (reporter = (Player)sender).getUniqueId().equals(player.getUniqueId()) || !name.toLowerCase().startsWith(input)) continue;
            suggestions.add(name);
        }
        return suggestions;
    }

    private String joinArgs(String[] args, int startIndex) {
        StringBuilder builder = new StringBuilder();
        for (int i = startIndex; i < args.length; ++i) {
            if (!builder.isEmpty()) {
                builder.append(' ');
            }
            builder.append(args[i]);
        }
        return builder.toString();
    }
}

