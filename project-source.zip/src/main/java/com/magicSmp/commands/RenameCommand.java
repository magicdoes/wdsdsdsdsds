/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.permissions.Permissible
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.PermissionUtils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.permissions.Permissible;

public class RenameCommand
implements CommandExecutor {
    private static final String PERMISSION = "MagicSMP.staff.rename";
    private final MagicSmp plugin;

    public RenameCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ColorUtils.toComponent("&c\u1d0f\u0274\u029f\u028f \u1d18\u029f\u1d00\u028f\u1d07\u0280\u0455 \u1d04\u1d00\u0274 \u1d1c\u0455\u1d07 \u1d1b\u029c\u026a\u0455 \u1d04\u1d0f\u1d0d\u1d0d\u1d00\u0274\u1d05."));
            return true;
        }
        Player player = (Player)sender;
        if (!PermissionUtils.has((Permissible)player, PERMISSION)) {
            player.sendMessage(ColorUtils.toComponent("&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274."));
            return true;
        }
        if (args.length == 0) {
            player.sendMessage(ColorUtils.toComponent("&c\u1d1c\u0455\u1d00\u0262\u1d07: /" + label + " <name...|reset>"));
            return true;
        }
        ItemStack item = player.getInventory().getItemInMainHand();
        if (item == null || item.getType().isAir()) {
            player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("RENAME.NO_ITEM", "&c\u028f\u1d0f\u1d1c \u1d0d\u1d1c\u0455\u1d1b \u029c\u1d0f\u029f\u1d05 \u1d00\u0274 \u026a\u1d1b\u1d07\u1d0d \u1d1b\u1d0f \u0280\u1d07\u0274\u1d00\u1d0d\u1d07 \u026a\u1d1b")));
            return true;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("RENAME.META_ERROR", "&c\u1d1b\u029c\u026a\u0455 \u026a\u1d1b\u1d07\u1d0d \u1d04\u1d00\u0274\u0274\u1d0f\u1d1b \u0299\u1d07 \u0280\u1d07\u0274\u1d00\u1d0d\u1d07\u1d05")));
            return true;
        }
        String newName = String.join((CharSequence)" ", args);
        if (this.isResetRequest(args)) {
            meta.setDisplayName(null);
            item.setItemMeta(meta);
            player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("RENAME.RESET_SUCCESS", "&7\u026a\u1d1b\u1d07\u1d0d \u0274\u1d00\u1d0d\u1d07 \u029c\u1d00\u0455 \u0299\u1d07\u1d07\u0274 \u0280\u1d07\u0455\u1d07\u1d1b."), player));
            return true;
        }
        meta.setDisplayName(ColorUtils.toComponent(newName, player));
        item.setItemMeta(meta);
        player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("RENAME.SUCCESS", "&7\u0274\u1d07\u1d21 \u0274\u1d00\u1d0d\u1d07: &f%name%", "%name%", newName), player));
        return true;
    }

    private boolean isResetRequest(String[] args) {
        if (args.length != 1) {
            return false;
        }
        String value = args[0];
        return value.equalsIgnoreCase("reset") || value.equalsIgnoreCase("clear") || value.equalsIgnoreCase("remove");
    }
}

