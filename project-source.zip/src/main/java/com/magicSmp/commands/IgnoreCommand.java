/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.permissions.Permissible
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.managers.IgnoreManager;
import com.bx.magicSmp.models.IgnoreEntry;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.PermissionUtils;
import com.bx.magicSmp.utils.PlayerLookup;
import java.util.List;
import java.util.UUID;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.permissions.Permissible;

public class IgnoreCommand
implements CommandExecutor {
    private static final String PERMISSION = "MagicSMP.ignore";
    private final MagicSmp plugin;

    public IgnoreCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!this.plugin.getConfigManager().isCommandEnabled("IGNORE")) {
            this.send(sender, this.message("DISABLED", "&c\u026a\u0262\u0274\u1d0f\u0280\u1d07 \u1d04\u1d0f\u1d0d\u1d0d\u1d00\u0274\u1d05 \u026a\u0455 \u1d04\u1d1c\u0280\u0280\u1d07\u0274\u1d1b\u029f\u028f \u1d05\u026a\u0455\u1d00\u0299\u029f\u1d07\u1d05."));
            return true;
        }
        if (!(sender instanceof Player)) {
            this.send(sender, this.message("PLAYER-ONLY", "&c\u1d0f\u0274\u029f\u028f \u1d18\u029f\u1d00\u028f\u1d07\u0280\u0455 \u1d04\u1d00\u0274 \u1d1c\u0455\u1d07 \u1d1b\u029c\u026a\u0455 \u1d04\u1d0f\u1d0d\u1d0d\u1d00\u0274\u1d05."));
            return true;
        }
        Player player = (Player)sender;
        if (!PermissionUtils.has((Permissible)player, PERMISSION)) {
            this.send(player, this.message("NO-PERMISSION", "&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274."));
            return true;
        }
        boolean removeOnly = label.equalsIgnoreCase("unignore");
        if (args.length == 0) {
            this.send(player, removeOnly ? this.message("UNIGNORE-USAGE", "&c\u1d1c\u0455\u1d00\u0262\u1d07: /unignore <player>") : this.message("USAGE", "&c\u1d1c\u0455\u1d00\u0262\u1d07: /ignore <player|list>"));
            return true;
        }
        if (!removeOnly && args[0].equalsIgnoreCase("list")) {
            this.sendIgnoreList(player);
            return true;
        }
        ResolvedTarget target = this.resolveTarget(player, args[0]);
        if (target == null) {
            this.send(player, this.message("PLAYER-NOT-FOUND", "&c\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u0274\u1d0f\u1d1b \ua730\u1d0f\u1d1c\u0274\u1d05."));
            return true;
        }
        if (player.getUniqueId().equals(target.uuid())) {
            this.send(player, this.message("CANNOT-IGNORE-SELF", "&c\u028f\u1d0f\u1d1c \u1d04\u1d00\u0274\u0274\u1d0f\u1d1b \u026a\u0262\u0274\u1d0f\u0280\u1d07 \u028f\u1d0f\u1d1c\u0280\u0455\u1d07\u029f\ua730."));
            return true;
        }
        if (removeOnly) {
            this.handleRemove(player, target);
            return true;
        }
        IgnoreManager.ToggleResult result = this.plugin.getIgnoreManager().toggleIgnore(player, target.uuid(), target.name());
        if (result.action() == IgnoreManager.ToggleAction.ADDED) {
            this.send(player, this.message("ADDED", "&7%player% &c\u029c\u1d00\u0455 \u0299\u1d07\u1d07\u0274 \u1d00\u1d05\u1d05\u1d07\u1d05 \u1d1b\u1d0f \u028f\u1d0f\u1d1c\u0280 \u026a\u0262\u0274\u1d0f\u0280\u1d07 \u029f\u026a\u0455\u1d1b.").replace("%player%", target.name()));
            return true;
        }
        if (result.action() == IgnoreManager.ToggleAction.REMOVED) {
            String displayName = result.entry() == null ? target.name() : result.entry().ignoredNameSnapshot();
            this.send(player, this.message("REMOVED", "&7%player% &c\u029c\u1d00\u0455 \u0299\u1d07\u1d07\u0274 \u0280\u1d07\u1d0d\u1d0f\u1d20\u1d07\u1d05 \ua730\u0280\u1d0f\u1d0d \u028f\u1d0f\u1d1c\u0280 \u026a\u0262\u0274\u1d0f\u0280\u1d07 \u029f\u026a\u0455\u1d1b.").replace("%player%", displayName));
            return true;
        }
        this.send(player, this.message("ERROR", "&c\u1d04\u1d0f\u1d1c\u029f\u1d05 \u0274\u1d0f\u1d1b \u1d1c\u1d18\u1d05\u1d00\u1d1b\u1d07 \u028f\u1d0f\u1d1c\u0280 \u026a\u0262\u0274\u1d0f\u0280\u1d07 \u029f\u026a\u0455\u1d1b."));
        return true;
    }

    private void handleRemove(Player player, ResolvedTarget target) {
        if (!this.plugin.getIgnoreManager().isIgnoring(player.getUniqueId(), target.uuid())) {
            this.send(player, this.message("NOT-IGNORED", "&7%player% &c\u026a\u0455 \u0274\u1d0f\u1d1b \u026a\u0274 \u028f\u1d0f\u1d1c\u0280 \u026a\u0262\u0274\u1d0f\u0280\u1d07 \u029f\u026a\u0455\u1d1b.").replace("%player%", target.name()));
            return;
        }
        if (!this.plugin.getIgnoreManager().removeIgnore(player.getUniqueId(), target.uuid())) {
            this.send(player, this.message("ERROR", "&c\u1d04\u1d0f\u1d1c\u029f\u1d05 \u0274\u1d0f\u1d1b \u1d1c\u1d18\u1d05\u1d00\u1d1b\u1d07 \u028f\u1d0f\u1d1c\u0280 \u026a\u0262\u0274\u1d0f\u0280\u1d07 \u029f\u026a\u0455\u1d1b."));
            return;
        }
        this.send(player, this.message("REMOVED", "&7%player% &c\u029c\u1d00\u0455 \u0299\u1d07\u1d07\u0274 \u0280\u1d07\u1d0d\u1d0f\u1d20\u1d07\u1d05 \ua730\u0280\u1d0f\u1d0d \u028f\u1d0f\u1d1c\u0280 \u026a\u0262\u0274\u1d0f\u0280\u1d07 \u029f\u026a\u0455\u1d1b.").replace("%player%", target.name()));
    }

    private void sendIgnoreList(Player player) {
        List<IgnoreEntry> entries = this.plugin.getIgnoreManager().getIgnoredPlayers(player.getUniqueId());
        if (entries.isEmpty()) {
            this.send(player, this.message("LIST-EMPTY", "&7\u028f\u1d0f\u1d1c \u1d00\u0280\u1d07 \u0274\u1d0f\u1d1b \u026a\u0262\u0274\u1d0f\u0280\u026a\u0274\u0262 \u1d00\u0274\u028f\u1d0f\u0274\u1d07."));
            return;
        }
        this.send(player, this.message("LIST-HEADER", "&8&m-------- &c\u026a\u0262\u0274\u1d0f\u0280\u1d07\u1d05 \u1d18\u029f\u1d00\u028f\u1d07\u0280\u0455 &7(%count%) &8&m--------").replace("%count%", String.valueOf(entries.size())).replace("{count}", String.valueOf(entries.size())));
        for (IgnoreEntry entry : entries) {
            this.send(player, this.message("LIST-ENTRY", "&8- &7%player%").replace("%player%", entry.ignoredNameSnapshot()).replace("{player}", entry.ignoredNameSnapshot()));
        }
    }

    private ResolvedTarget resolveTarget(Player owner, String input) {
        if (input == null || input.isBlank()) {
            return null;
        }
        Player online = PlayerLookup.findOnlinePlayer(input);
        if (online != null) {
            return new ResolvedTarget(online.getUniqueId(), online.getName());
        }
        for (IgnoreEntry entry : this.plugin.getIgnoreManager().getIgnoredPlayers(owner.getUniqueId())) {
            if (!entry.ignoredNameSnapshot().equalsIgnoreCase(input) && !entry.ignoredUuid().toString().equalsIgnoreCase(input)) continue;
            return new ResolvedTarget(entry.ignoredUuid(), entry.ignoredNameSnapshot());
        }
        UUID uuid = PlayerLookup.findKnownPlayerUuid(this.plugin, input);
        if (uuid == null) {
            return null;
        }
        String name = this.plugin.getDatabaseManager().getLastKnownUsername(uuid);
        String fallback = name == null || name.isBlank() ? input : name;
        return new ResolvedTarget(uuid, fallback);
    }

    private void send(CommandSender sender, String message) {
        if (sender instanceof Player) {
            Player player = (Player)sender;
            player.sendMessage(ColorUtils.toComponent(message, player));
            return;
        }
        sender.sendMessage(ColorUtils.colorize(message));
    }

    private String message(String key, String fallback) {
        return this.plugin.getConfigManager().getMessages().getString("IGNORE." + key, fallback);
    }

    private record ResolvedTarget(UUID uuid, String name) {
    }
}

