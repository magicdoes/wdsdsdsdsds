/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.permissions.Permissible
 *  org.bukkit.util.StringUtil
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.amethyst.AmethystToolType;
import com.bx.magicSmp.amethyst.AmethystToolsManager;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.PermissionUtils;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.permissions.Permissible;
import org.bukkit.util.StringUtil;

public class AmethystToolCommand
implements CommandExecutor,
TabCompleter {
    private static final String PERMISSION = "MagicSmp.admin.amethysttool";
    private static final List<String> SUBCOMMAND_COMPLETIONS = List.of("give", "reload");
    private static final List<String> TYPE_COMPLETIONS = AmethystToolCommand.createTypeCompletions();
    private static final List<String> DURATION_COMPLETIONS = List.of("600", "1200", "3600", "7200");
    private final MagicSmp plugin;

    public AmethystToolCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        AmethystToolsManager mgr = this.plugin.getAmethystToolsManager();
        if (args.length < 1) {
            sender.sendMessage(ColorUtils.toComponent(mgr.getMessage("GIVE-USAGE")));
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        if (sub.equals("reload")) {
            if (!PermissionUtils.has((Permissible)sender, PERMISSION)) {
                sender.sendMessage(ColorUtils.toComponent("&c\u0274\u1d0f \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274."));
                return true;
            }
            this.plugin.getConfigManager().reloadAmethystTools();
            sender.sendMessage(ColorUtils.toComponent(mgr.getMessage("RELOAD-SUCCESS")));
            return true;
        }
        if (sub.equals("give")) {
            if (!PermissionUtils.has((Permissible)sender, PERMISSION)) {
                sender.sendMessage(ColorUtils.toComponent("&c\u0274\u1d0f \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274."));
                return true;
            }
            if (args.length < 3) {
                sender.sendMessage(ColorUtils.toComponent(mgr.getMessage("GIVE-USAGE")));
                return true;
            }
            String targetName = args[1];
            String typeName = args[2];
            long duration = args.length >= 4 ? this.parseLong(args[3]) : -1L;
            Player target = Bukkit.getPlayer((String)targetName);
            if (target == null) {
                sender.sendMessage(ColorUtils.toComponent("&c\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u0274\u1d0f\u1d1b \ua730\u1d0f\u1d1c\u0274\u1d05: " + targetName));
                return true;
            }
            AmethystToolType type = AmethystToolType.fromString(typeName);
            if (type == null) {
                sender.sendMessage(ColorUtils.toComponent(mgr.getMessage("GIVE-INVALID-TYPE")));
                return true;
            }
            ItemStack item = mgr.createTool(type, target.getUniqueId(), duration);
            if (item == null) {
                sender.sendMessage(ColorUtils.toComponent("&c\ua730\u1d00\u026a\u029f\u1d07\u1d05 \u1d1b\u1d0f \u1d04\u0280\u1d07\u1d00\u1d1b\u1d07 \u026a\u1d1b\u1d07\u1d0d (\u1d04\u029c\u1d07\u1d04\u1d0b \u1d04\u1d0f\u0274\ua730\u026a\u0262)."));
                return true;
            }
            target.getInventory().addItem(new ItemStack[]{item});
            sender.sendMessage(ColorUtils.toComponent(mgr.getMessage("GIVE-SUCCESS", "{type}", type.getDisplayName(), "{player}", target.getName())));
            return true;
        }
        sender.sendMessage(ColorUtils.toComponent(mgr.getMessage("GIVE-USAGE")));
        return true;
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!PermissionUtils.has((Permissible)sender, PERMISSION)) {
            return Collections.emptyList();
        }
        if (args.length == 1) {
            return this.partialMatches(args[0], SUBCOMMAND_COMPLETIONS);
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("give")) {
            return this.partialMatches(args[1], this.onlinePlayerNames());
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("give")) {
            return this.partialMatches(args[2], TYPE_COMPLETIONS);
        }
        if (args.length == 4 && args[0].equalsIgnoreCase("give")) {
            return this.partialMatches(args[3], DURATION_COMPLETIONS);
        }
        return Collections.emptyList();
    }

    private static List<String> createTypeCompletions() {
        ArrayList<String> completions = new ArrayList<String>();
        for (AmethystToolType type : AmethystToolType.values()) {
            completions.add(type.name().toLowerCase(Locale.ROOT).replace('_', '-'));
        }
        return List.copyOf(completions);
    }

    private List<String> onlinePlayerNames() {
        ArrayList<String> names = new ArrayList<String>();
        for (Player player : Bukkit.getOnlinePlayers()) {
            names.add(player.getName());
        }
        names.sort(String.CASE_INSENSITIVE_ORDER);
        return names;
    }

    private List<String> partialMatches(String token, List<String> completions) {
        ArrayList<String> matches = new ArrayList<String>();
        StringUtil.copyPartialMatches((String)token, completions, matches);
        matches.sort(String.CASE_INSENSITIVE_ORDER);
        return matches;
    }

    private long parseLong(String s) {
        try {
            return Long.parseLong(s);
        }
        catch (NumberFormatException e) {
            return -1L;
        }
    }
}

