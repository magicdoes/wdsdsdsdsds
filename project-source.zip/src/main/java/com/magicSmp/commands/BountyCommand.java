/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.menus.BountyConfirmMenu;
import com.bx.magicSmp.menus.BountyMenu;
import com.bx.magicSmp.models.Bounty;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.NumberUtils;
import java.util.UUID;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class BountyCommand
implements CommandExecutor {
    private final MagicSmp plugin;

    public BountyCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u1d0f\u0274\u029f\u028f.");
            return true;
        }
        Player player = (Player)sender;
        if (args.length == 0 || args[0].equalsIgnoreCase("list")) {
            new BountyMenu(this.plugin).open(player);
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "add": 
            case "set": {
                this.handleAdd(player, args);
                break;
            }
            case "info": {
                this.handleInfo(player, args);
                break;
            }
            default: {
                player.sendMessage(ColorUtils.toComponent("&c\u1d1c\u0455\u1d00\u0262\u1d07: /bounty <add|info|list> [\u1d18\u029f\u1d00\u028f\u1d07\u0280] [\u1d00\u1d0d\u1d0f\u1d1c\u0274\u1d1b]"));
            }
        }
        return true;
    }

    private void handleAdd(Player player, String[] args) {
        double amount;
        if (args.length < 3) {
            player.sendMessage(ColorUtils.toComponent("&c\u1d1c\u0455\u1d00\u0262\u1d07: /bounty \u1d00\u1d05\u1d05 <player> <amount>"));
            return;
        }
        UUID targetUuid = this.plugin.getBountyManager().resolvePlayerUuid(player, args[1]);
        if (targetUuid == null) {
            player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessage("BOUNTY.PLAYER-NOT-EXIST")));
            return;
        }
        if (targetUuid.equals(player.getUniqueId())) {
            player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessage("BOUNTY.CANT-SELF-BOUNTY")));
            return;
        }
        try {
            amount = NumberUtils.parse(args[2]);
        }
        catch (NumberFormatException e) {
            player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessage("BALANCE.PAY.INVALID-AMOUNT")));
            return;
        }
        if (amount < 1.0) {
            player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessage("BOUNTY.MINIMUM-PRICE", "{amount}", NumberUtils.format(1.0), "{amount_formatted}", this.plugin.getCurrencyManager().formatMoney(1.0))));
            return;
        }
        new BountyConfirmMenu(this.plugin, targetUuid, this.plugin.getBountyManager().getDisplayName(targetUuid), amount).open(player);
    }

    private void handleInfo(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(ColorUtils.toComponent("&c\u1d1c\u0455\u1d00\u0262\u1d07: /bounty \u026a\u0274\ua730\u1d0f <player>"));
            return;
        }
        UUID targetUuid = this.plugin.getBountyManager().resolvePlayerUuid(player, args[1]);
        if (targetUuid == null) {
            player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessage("BOUNTY.PLAYER-NOT-EXIST")));
            return;
        }
        Bounty bounty = this.plugin.getBountyManager().getBounty(targetUuid);
        if (bounty == null) {
            player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessage("BOUNTY.NO-BOUNTY")));
            return;
        }
        String msg = this.plugin.getConfigManager().getMessage("BOUNTY.PLAYER-HAS-BOUNTY", "{player}", this.plugin.getBountyManager().getDisplayName(targetUuid), "{amount}", NumberUtils.format(bounty.getAmount()), "{amount_formatted}", this.plugin.getCurrencyManager().formatMoney(bounty.getAmount()));
        player.sendMessage(ColorUtils.toComponent(msg));
    }
}

