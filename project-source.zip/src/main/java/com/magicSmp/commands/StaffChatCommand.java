/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.permissions.Permissible
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.PermissionUtils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.permissions.Permissible;

public class StaffChatCommand
implements CommandExecutor {
    private static final String PERMISSION = "MagicSMP.staff.chat.use";
    private final MagicSmp plugin;

    public StaffChatCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Player player;
        if (sender instanceof Player && !PermissionUtils.has((Permissible)(player = (Player)sender), PERMISSION)) {
            player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("STAFFCHAT.NO_PERMISSION", "&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274 \u1d1b\u1d0f \u1d1c\u0455\u1d07 \u0455\u1d1b\u1d00\ua730\ua730 \u1d04\u029c\u1d00\u1d1b.")));
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("STAFFCHAT.USAGE", "&c\u1d1c\u0455\u1d00\u0262\u1d07: /staffchat <message>")));
            return true;
        }
        this.plugin.getStaffChatManager().sendStaffChat(sender, String.join((CharSequence)" ", args));
        return true;
    }
}

