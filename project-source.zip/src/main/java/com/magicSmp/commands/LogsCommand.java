/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.menus.PlayerLogsMenu;
import com.bx.magicSmp.utils.ColorUtils;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class LogsCommand
implements CommandExecutor {
    private final MagicSmp plugin;

    public LogsCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String targetName;
        UUID targetUuid;
        if (!(sender instanceof Player)) {
            sender.sendMessage("\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u1d0f\u0274\u029f\u028f.");
            return true;
        }
        Player viewer = (Player)sender;
        if (!viewer.hasPermission("MagicSMP.admin.logs")) {
            viewer.sendMessage(ColorUtils.toComponent("&cYou do not have permission to use this command."));
            return true;
        }
        if (args.length != 1) {
            viewer.sendMessage(ColorUtils.toComponent("&cUsage: /logs <player>"));
            return true;
        }
        String input = args[0].trim();
        Player onlineTarget = this.findOnlineTarget(input);
        UUID uUID = targetUuid = onlineTarget == null ? this.plugin.getDatabaseManager().findPlayerUuidByUsername(input) : onlineTarget.getUniqueId();
        if (targetUuid == null) {
            viewer.sendMessage(ColorUtils.toComponent("&cPlayer not found."));
            return true;
        }
        String string = targetName = onlineTarget == null ? this.plugin.getDatabaseManager().getLastKnownUsername(targetUuid) : onlineTarget.getName();
        if (targetName == null || targetName.isBlank()) {
            targetName = input;
        }
        new PlayerLogsMenu(this.plugin, targetUuid, targetName).open(viewer);
        return true;
    }

    private Player findOnlineTarget(String username) {
        Player exact = Bukkit.getPlayerExact((String)username);
        if (exact != null) {
            return exact;
        }
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (!player.getName().equalsIgnoreCase(username)) continue;
            return player;
        }
        return null;
    }
}

