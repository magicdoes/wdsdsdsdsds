/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.inventory.meta.BookMeta
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.permissions.Permissible
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.PermissionUtils;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BookMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.permissions.Permissible;

public class SafetyCommand
implements CommandExecutor {
    private final MagicSmp plugin;

    public SafetyCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            if (!PermissionUtils.has((Permissible)sender, "safety.reload")) {
                sender.sendMessage(ColorUtils.toComponent(this.plugin.getLanguageManager().text("MESSAGES.SAFETY.NO-PERMISSION", "&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274.")));
                return true;
            }
            try {
                this.plugin.reloadAllPluginConfigurations();
                sender.sendMessage(ColorUtils.toComponent(this.plugin.getLanguageManager().text("MESSAGES.SAFETY.RELOAD-SUCCESS", "&a\u0455\u1d00\ua730\u1d07\u1d1b\u028f \u1d04\u1d0f\u0274\ua730\u026a\u0262 \u0280\u1d07\u029f\u1d0f\u1d00\u1d05\u1d07\u1d05.")));
            }
            catch (Exception e) {
                this.plugin.getLogger().log(Level.SEVERE, "Failed to reload safety configurations.", e);
                sender.sendMessage(ColorUtils.toComponent("&c\ua730\u1d00\u026a\u029f\u1d07\u1d05 \u1d1b\u1d0f \u0280\u1d07\u029f\u1d0f\u1d00\u1d05 \u1d04\u1d0f\u0274\ua730\u026a\u0262\u1d1c\u0280\u1d00\u1d1b\u026a\u1d0f\u0274. \u1d04\u029c\u1d07\u1d04\u1d0b \u1d04\u1d0f\u0274\u0455\u1d0f\u029f\u1d07 \ua730\u1d0f\u0280 \u1d05\u1d07\u1d1b\u1d00\u026a\u029f\u0455."));
            }
            return true;
        }
        if (args.length > 0 && (args[0].equalsIgnoreCase("add") || args[0].equalsIgnoreCase("give"))) {
            Player target;
            if (!PermissionUtils.has((Permissible)sender, "safety.add")) {
                sender.sendMessage(ColorUtils.toComponent(this.plugin.getLanguageManager().text("MESSAGES.SAFETY.NO-PERMISSION", "&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274.")));
                return true;
            }
            if (args.length > 1) {
                target = Bukkit.getPlayer((String)args[1]);
                if (target == null) {
                    sender.sendMessage(ColorUtils.toComponent(this.plugin.getLanguageManager().text("MESSAGES.SAFETY.PLAYER-NOT-FOUND", "&c\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u0274\u1d0f\u1d1b \ua730\u1d0f\u1d1c\u0274\u1d05.")));
                    return true;
                }
            } else if (sender instanceof Player) {
                Player player;
                target = player = (Player)sender;
            } else {
                sender.sendMessage(ColorUtils.toComponent(this.plugin.getLanguageManager().text("MESSAGES.SAFETY.USAGE", "&c\u1d1c\u0455\u1d00\u0262\u1d07: /safety [\u0280\u1d07\u029f\u1d0f\u1d00\u1d05|\u1d00\u1d05\u1d05 <player>|\u0262\u026a\u1d20\u1d07 <player>]")));
                return true;
            }
            this.givePhysicalSafetyBook(sender, target);
            return true;
        }
        if (!(sender instanceof Player)) {
            sender.sendMessage("\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u1d0f\u0274\u029f\u028f.");
            return true;
        }
        Player player = (Player)sender;
        if (!PermissionUtils.has((Permissible)player, "safety.use")) {
            player.sendMessage(ColorUtils.toComponent(this.plugin.getLanguageManager().text("MESSAGES.SAFETY.NO-PERMISSION", "&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274.")));
            return true;
        }
        this.openSafetyBook(player);
        return true;
    }

    private ItemStack createSafetyBook(Player viewer) {
        ItemStack book = new ItemStack(Material.WRITTEN_BOOK);
        BookMeta meta = (BookMeta)book.getItemMeta();
        if (meta == null) {
            return null;
        }
        String title = this.plugin.getLanguageManager().text("MESSAGES.SAFETY.BOOK-TITLE", "Safety Guide");
        String author = this.plugin.getLanguageManager().text("MESSAGES.SAFETY.BOOK-AUTHOR", "Server");
        meta.setTitle(ColorUtils.colorize(title, viewer));
        meta.setAuthor(ColorUtils.colorize(author, viewer));
        List<String> defaultPages = List.of("&0\u26a0 \u1d21\u1d00\u1d1b\u1d04\u029c \u1d0f\u1d1c\u1d1b!\n\nFake discords or\nmods can steal your\naccount.\n\nThe only official\ndiscord can be found\nusing &1/discord&0.\n\nNever download files\nor mods from random\npeople.");
        List<String> rawPages = this.plugin.getLanguageManager().list("MESSAGES.SAFETY.BOOK-PAGES", defaultPages, new String[0]);
        ArrayList<String> coloredPages = new ArrayList<String>();
        for (String rawPage : rawPages) {
            coloredPages.add(ColorUtils.colorize(rawPage, viewer));
        }
        meta.setPages(coloredPages);
        book.setItemMeta((ItemMeta)meta);
        return book;
    }

    private void openSafetyBook(Player player) {
        try {
            ItemStack book = this.createSafetyBook(player);
            if (book == null) {
                player.sendMessage(ColorUtils.toComponent("&c\u1d00\u0274 \u1d07\u0280\u0280\u1d0f\u0280 \u1d0f\u1d04\u1d04\u1d1c\u0280\u0280\u1d07\u1d05: \u0299\u1d0f\u1d0f\u1d0b\u1d0d\u1d07\u1d1b\u1d00 \u026a\u0455 \u0274\u1d1c\u029f\u029f."));
                return;
            }
            player.openBook(book);
        }
        catch (Exception e) {
            this.plugin.getLogger().log(Level.SEVERE, "Failed to open safety book for " + player.getName(), e);
            player.sendMessage(ColorUtils.toComponent("&c\u1d00\u0274 \u1d07\u0280\u0280\u1d0f\u0280 \u1d0f\u1d04\u1d04\u1d1c\u0280\u0280\u1d07\u1d05 \u1d21\u029c\u026a\u029f\u1d07 \u1d0f\u1d18\u1d07\u0274\u026a\u0274\u0262 \u1d1b\u029c\u1d07 \u0455\u1d00\ua730\u1d07\u1d1b\u028f \u0299\u1d0f\u1d0f\u1d0b."));
        }
    }

    private void givePhysicalSafetyBook(CommandSender sender, Player target) {
        try {
            Player senderPlayer;
            ItemStack book = this.createSafetyBook(target);
            if (book == null) {
                sender.sendMessage(ColorUtils.toComponent("&c\u1d00\u0274 \u1d07\u0280\u0280\u1d0f\u0280 \u1d0f\u1d04\u1d04\u1d1c\u0280\u0280\u1d07\u1d05: \u0299\u1d0f\u1d0f\u1d0b\u1d0d\u1d07\u1d1b\u1d00 \u026a\u0455 \u0274\u1d1c\u029f\u029f."));
                return;
            }
            HashMap leftovers = target.getInventory().addItem(new ItemStack[]{book});
            if (!leftovers.isEmpty()) {
                leftovers.values().forEach(leftover -> target.getWorld().dropItemNaturally(target.getLocation(), (ItemStack)leftover));
            }
            target.sendMessage(ColorUtils.toComponent(this.plugin.getLanguageManager().text("MESSAGES.SAFETY.GIVE-SUCCESS-RECEIVER", "&a\u028f\u1d0f\u1d1c \u0280\u1d07\u1d04\u1d07\u026a\u1d20\u1d07\u1d05 \u1d1b\u029c\u1d07 \u0455\u1d00\ua730\u1d07\u1d1b\u028f \u0299\u1d0f\u1d0f\u1d0b.")));
            if (!(sender instanceof Player) || !(senderPlayer = (Player)sender).getUniqueId().equals(target.getUniqueId())) {
                sender.sendMessage(ColorUtils.toComponent(this.plugin.getLanguageManager().text("MESSAGES.SAFETY.GIVE-SUCCESS-SENDER", "&a\u0455\u1d1c\u1d04\u1d04\u1d07\u0455\u0455\ua730\u1d1c\u029f\u029f\u028f \u0262\u1d00\u1d20\u1d07 \u0455\u1d00\ua730\u1d07\u1d1b\u028f \u0299\u1d0f\u1d0f\u1d0b \u1d1b\u1d0f {player}.", "{player}", target.getName())));
            }
        }
        catch (Exception e) {
            this.plugin.getLogger().log(Level.SEVERE, "Failed to give safety book to " + target.getName(), e);
            sender.sendMessage(ColorUtils.toComponent("&c\u1d00\u0274 \u1d07\u0280\u0280\u1d0f\u0280 \u1d0f\u1d04\u1d04\u1d1c\u0280\u0280\u1d07\u1d05 \u1d21\u029c\u026a\u029f\u1d07 \u0262\u026a\u1d20\u026a\u0274\u0262 \u1d1b\u029c\u1d07 \u0455\u1d00\ua730\u1d07\u1d1b\u028f \u0299\u1d0f\u1d0f\u1d0b."));
        }
    }
}

