/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.TabCompleter
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.managers.ShopAddonManager;
import com.bx.magicSmp.menus.ShopAddonMenu;
import com.bx.magicSmp.menus.ShopMenu;
import com.bx.magicSmp.models.EconomyReason;
import com.bx.magicSmp.utils.ColorUtils;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

public class ShopCommand
implements CommandExecutor,
TabCompleter {
    private final MagicSmp plugin;

    public ShopCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ColorUtils.colorize(this.text("SHOP-GUI.MESSAGES.PLAYER-ONLY", "&c\u1d0f\u0274\u029f\u028f \u1d18\u029f\u1d00\u028f\u1d07\u0280\u0455 \u1d04\u1d00\u0274 \u1d1c\u0455\u1d07 \u1d1b\u029c\u026a\u0455 \u1d04\u1d0f\u1d0d\u1d0d\u1d00\u0274\u1d05.")));
            return true;
        }
        Player player = (Player)sender;
        if (args.length == 0) {
            if (this.plugin.getShopManager().isUsingAddon(player)) {
                String addonName = this.plugin.getShopManager().getCurrentAddon(player);
                new ShopAddonMenu(this.plugin, addonName, null, 0).open(player);
            } else {
                new ShopMenu(this.plugin).open(player);
            }
            return true;
        }
        if (args[0].equalsIgnoreCase("change")) {
            return this.handleChangeCommand(player, args);
        }
        if (args[0].equalsIgnoreCase("reload")) {
            return this.handleReloadCommand(player);
        }
        if (this.plugin.getShopManager().isUsingAddon(player)) {
            return this.handleAddonPurchase(player, args);
        }
        player.sendMessage(ColorUtils.toComponent(this.text("SHOP-GUI.MESSAGES.USAGE", "&c\u1d1c\u0455\u1d00\u0262\u1d07: /shop [change <name>|reload]")));
        return true;
    }

    private boolean handleChangeCommand(Player player, String[] args) {
        if (!player.hasPermission("magicsmp.command.shop.change")) {
            player.sendMessage(ColorUtils.colorize("&c\u028f\u1d0f\u1d1c \u1d05\u1d0f\u0274'\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274 \u1d1b\u1d0f \u1d04\u029c\u1d00\u0274\u0262\u1d07 \u1d1b\u029c\u1d07 \u0455\u029c\u1d0f\u1d18."));
            return true;
        }
        this.plugin.getLogger().info("Change command recognized");
        if (args.length < 2) {
            player.sendMessage(ColorUtils.colorize("&c\u1d1c\u0455\u1d00\u0262\u1d07: /shop change <name>"));
            player.sendMessage(ColorUtils.colorize("&7\u1d00\u1d20\u1d00\u026a\u029f\u1d00\u0299\u029f\u1d07 \u1d00\u1d05\u1d05\u1d0f\u0274\u0455: " + String.join((CharSequence)", ", this.plugin.getShopManager().getAddonManager().getAddonNames())));
            player.sendMessage(ColorUtils.colorize("&7\u1d1c\u0455\u1d07 'default' \ua730\u1d0f\u0280 \u1d0f\u0280\u026a\u0262\u026a\u0274\u1d00\u029f \u0455\u029c\u1d0f\u1d18"));
            return true;
        }
        String targetName = args[1].toLowerCase(Locale.ROOT);
        this.plugin.getLogger().info("Target name: " + targetName);
        if (targetName.equals("default")) {
            if (this.plugin.getShopManager().switchToDefault()) {
                player.sendMessage(ColorUtils.colorize("&a\u0455\u1d21\u026a\u1d1b\u1d04\u029c\u1d07\u1d05 \u1d1b\u1d0f \u1d05\u1d07\ua730\u1d00\u1d1c\u029f\u1d1b \u0455\u029c\u1d0f\u1d18 \ua730\u1d0f\u0280 \u1d07\u1d20\u1d07\u0280\u028f\u1d0f\u0274\u1d07!"));
                for (Player p : this.plugin.getServer().getOnlinePlayers()) {
                    if (!(p.getOpenInventory().getTopInventory().getHolder() instanceof InventoryHolder)) continue;
                    new ShopMenu(this.plugin).open(p);
                }
            } else {
                player.sendMessage(ColorUtils.colorize("&c\ua730\u1d00\u026a\u029f\u1d07\u1d05 \u1d1b\u1d0f \u0455\u1d21\u026a\u1d1b\u1d04\u029c \u0455\u029c\u1d0f\u1d18."));
            }
            return true;
        }
        if (this.plugin.getShopManager().switchToAddon(targetName)) {
            player.sendMessage(ColorUtils.colorize("&a\u0455\u1d21\u026a\u1d1b\u1d04\u029c\u1d07\u1d05 \u1d1b\u1d0f \u1d00\u1d05\u1d05\u1d0f\u0274 \ua730\u1d0f\u0280 \u1d07\u1d20\u1d07\u0280\u028f\u1d0f\u0274\u1d07: " + targetName));
            for (Player p : this.plugin.getServer().getOnlinePlayers()) {
                if (!(p.getOpenInventory().getTopInventory().getHolder() instanceof InventoryHolder)) continue;
                new ShopAddonMenu(this.plugin, targetName, null, 0).open(p);
            }
        } else {
            player.sendMessage(ColorUtils.colorize("&c\u1d1c\u0274\u1d0b\u0274\u1d0f\u1d21\u0274 \u1d00\u1d05\u1d05\u1d0f\u0274: " + targetName));
            player.sendMessage(ColorUtils.colorize("&7\u1d00\u1d20\u1d00\u026a\u029f\u1d00\u0299\u029f\u1d07 \u1d00\u1d05\u1d05\u1d0f\u0274\u0455: " + String.join((CharSequence)", ", this.plugin.getShopManager().getAddonManager().getAddonNames())));
        }
        return true;
    }

    private boolean handleReloadCommand(Player player) {
        if (player.hasPermission("magicsmp.command.shop.reload")) {
            this.plugin.getShopManager().reload();
            this.plugin.getShopManager().getAddonManager().reload();
            player.sendMessage(ColorUtils.colorize("&a\u0455\u029c\u1d0f\u1d18 \u1d00\u0274\u1d05 \u1d00\u1d05\u1d05\u1d0f\u0274\u0455 \u0280\u1d07\u029f\u1d0f\u1d00\u1d05\u1d07\u1d05!"));
        } else {
            player.sendMessage(ColorUtils.colorize("&c\u028f\u1d0f\u1d1c \u1d05\u1d0f\u0274'\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274 \u1d1b\u1d0f \u0280\u1d07\u029f\u1d0f\u1d00\u1d05 \u1d1b\u029c\u1d07 \u0455\u029c\u1d0f\u1d18."));
        }
        return true;
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<String>();
        if (args.length == 1) {
            completions.add("change");
            completions.add("reload");
        } else if (args.length == 2 && args[0].equalsIgnoreCase("change")) {
            completions.add("default");
            completions.addAll(this.plugin.getShopManager().getAddonManager().getAddonNames());
        }
        return completions;
    }

    private String text(String key, String def) {
        return this.plugin.getConfigManager().getShop().getString(key, def);
    }

    private boolean handleAddonPurchase(Player player, String[] args) {
        String addonName = this.plugin.getShopManager().getCurrentAddon(player);
        ShopAddonManager.ShopAddon addon = this.plugin.getShopManager().getAddonManager().getAddon(addonName);
        if (addon == null) {
            player.sendMessage(ColorUtils.colorize("&c\u1d04\u1d1c\u0280\u0280\u1d07\u0274\u1d1b \u1d00\u1d05\u1d05\u1d0f\u0274 \u0274\u1d0f\u1d1b \ua730\u1d0f\u1d1c\u0274\u1d05"));
            return true;
        }
        if (args.length < 1) {
            player.sendMessage(ColorUtils.colorize("&c\u1d1c\u0455\u1d00\u0262\u1d07: /shop <item> [amount]"));
            return true;
        }
        String itemName = args[0].toUpperCase(Locale.ROOT);
        int amount = 1;
        if (args.length >= 2) {
            try {
                amount = Integer.parseInt(args[1]);
                if (amount <= 0) {
                    player.sendMessage(ColorUtils.colorize("&c\u1d00\u1d0d\u1d0f\u1d1c\u0274\u1d1b \u1d0d\u1d1c\u0455\u1d1b \u0299\u1d07 \u1d18\u1d0f\u0455\u026a\u1d1b\u026a\u1d20\u1d07"));
                    return true;
                }
            }
            catch (NumberFormatException e) {
                player.sendMessage(ColorUtils.colorize("&c\u026a\u0274\u1d20\u1d00\u029f\u026a\u1d05 \u1d00\u1d0d\u1d0f\u1d1c\u0274\u1d1b"));
                return true;
            }
        }
        ShopAddonManager.ShopAddonItem foundItem = null;
        for (List<ShopAddonManager.ShopAddonItem> categoryItems : addon.items().values()) {
            for (ShopAddonManager.ShopAddonItem item : categoryItems) {
                if (!item.key().equalsIgnoreCase(itemName)) continue;
                foundItem = item;
                break;
            }
            if (foundItem == null) continue;
            break;
        }
        if (foundItem == null) {
            player.sendMessage(ColorUtils.colorize("&c\u026a\u1d1b\u1d07\u1d0d \u0274\u1d0f\u1d1b \ua730\u1d0f\u1d1c\u0274\u1d05 \u026a\u0274 \u1d00\u1d05\u1d05\u1d0f\u0274 \u0455\u029c\u1d0f\u1d18"));
            return true;
        }
        double totalPrice = foundItem.price() * (double)amount;
        double balance = this.plugin.getEconomyManager().getBalance(player.getUniqueId());
        if (balance < totalPrice) {
            player.sendMessage(ColorUtils.colorize("&c\u028f\u1d0f\u1d1c \u1d05\u1d0f\u0274'\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d07\u0274\u1d0f\u1d1c\u0262\u029c \u1d0d\u1d0f\u0274\u1d07\u028f!"));
            player.sendMessage(ColorUtils.colorize("&7\u0274\u1d07\u1d07\u1d05\u1d07\u1d05: " + this.plugin.getCurrencyManager().formatMoney(totalPrice) + " &7\u029c\u1d00\u1d20\u1d07: " + this.plugin.getCurrencyManager().formatMoney(balance)));
            return true;
        }
        this.plugin.getEconomyManager().withdraw(player, totalPrice, EconomyReason.SHOP_PURCHASE);
        ItemStack itemStack = new ItemStack(foundItem.material(), amount);
        player.getInventory().addItem(new ItemStack[]{itemStack});
        player.sendMessage(ColorUtils.colorize("&a\u0455\u1d1c\u1d04\u1d04\u1d07\u0455\u0455\ua730\u1d1c\u029f\u029f\u028f \u1d18\u1d1c\u0280\u1d04\u029c\u1d00\u0455\u1d07\u1d05 " + amount + "x " + (foundItem.displayName() != null ? foundItem.displayName() : foundItem.key()) + " \ua730\u1d0f\u0280 " + this.plugin.getCurrencyManager().formatMoney(totalPrice)));
        return true;
    }
}

