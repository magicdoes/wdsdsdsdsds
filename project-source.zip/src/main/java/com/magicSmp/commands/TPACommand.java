/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.md_5.bungee.api.chat.BaseComponent
 *  net.md_5.bungee.api.chat.ClickEvent
 *  net.md_5.bungee.api.chat.ClickEvent$Action
 *  net.md_5.bungee.api.chat.TextComponent
 *  org.bukkit.entity.Entity
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.managers.TPAManager;
import com.bx.magicSmp.menus.TpaQueueMenu;
import com.bx.magicSmp.models.PlayerData;
import com.bx.magicSmp.models.ThreeChoice;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.PlayerLookup;
import com.bx.magicSmp.utils.PlayerSettingUtils;
import com.bx.magicSmp.utils.SoundUtils;
import java.util.UUID;
import net.md_5.bungee.api.chat.BaseComponent;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;

public class TPACommand
implements CommandExecutor {
    private final MagicSmp plugin;

    public TPACommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String sub;
        if (!(sender instanceof Player)) {
            sender.sendMessage("\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u1d0f\u0274\u029f\u028f.");
            return true;
        }
        Player player = (Player)sender;
        switch (sub = label.toLowerCase()) {
            case "tpa": {
                this.handleTpa(player, args);
                break;
            }
            case "tpahere": {
                this.handleTpaHere(player, args);
                break;
            }
            case "tpaccept": {
                this.handleAccept(player, args);
                break;
            }
            case "tpadeny": {
                this.handleDeny(player);
                break;
            }
            case "tpacancel": {
                this.plugin.getTPAManager().cancelRequestsByRequester(player.getUniqueId());
                this.send(player, this.plugin.getConfigManager().getMessage("TPA.CANCELLED-REQUESTS"));
                break;
            }
        }
        return true;
    }

    private void handleTpa(Player player, String[] args) {
        if (args.length == 0) {
            new TpaQueueMenu(this.plugin, false).open(player);
            return;
        }
        Player target = PlayerLookup.findOnlinePlayer(args[0]);
        if (target == null || target.equals(player)) {
            this.send(player, target == null ? "&c\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u0274\u1d0f\u1d1b \u1d0f\u0274\u029f\u026a\u0274\u1d07." : this.plugin.getConfigManager().getMessage("TPA.CANNOT-INVITE-YOURSELF"));
            return;
        }
        if (this.plugin.getFriendsManager() != null && this.plugin.getFriendsManager().isTeleportRequestBlocked(player.getUniqueId(), target.getUniqueId())) {
            this.send(player, "&c" + target.getName() + " has disabled teleport requests from you.");
            return;
        }
        if (this.plugin.getFriendsManager() != null && this.plugin.getFriendsManager().isTpaAutoAcceptEnabled(player.getUniqueId(), target.getUniqueId())) {
            this.plugin.getSpigotScheduler().runEntity((Entity)player, () -> {
                this.plugin.getTeleportManager().queue(player, target.getLocation(), "TPA", null);
                this.send(player, this.plugin.getConfigManager().getMessage("TPA.YOUR-REQUEST-ACCEPTED", "{player}", target.getName()));
                target.sendMessage(ColorUtils.toComponent("&7\u1d00\u1d1c\u1d1b\u1d0f-\u1d00\u1d04\u1d04\u1d07\u1d18\u1d1b\u1d07\u1d05 \u1d1b\u1d07\u029f\u1d07\u1d18\u1d0f\u0280\u1d1b \u0280\u1d07\u01eb\u1d1c\u1d07\u0455\u1d1b \ua730\u0280\u1d0f\u1d0d &b" + player.getName() + "&7."));
            });
            return;
        }
        PlayerData targetData = this.plugin.getPlayerDataManager().get(target);
        if (targetData != null) {
            ThreeChoice choice = targetData.getTpaRequestsChoice();
            if (choice == ThreeChoice.OFF) {
                int queuePosition = this.plugin.getTPAManager().queueManualTPA(player, target);
                if (queuePosition == 0) {
                    this.sendAlreadySent(player, target);
                    return;
                }
                this.send(player, this.plugin.getConfigManager().getMessage("TPA.INVITE-SENT", "{player}", this.publicName(target)));
                this.send(player, "&7\u028f\u1d0f\u1d1c\u0280 /tpa \u0280\u1d07\u01eb\u1d1c\u1d07\u0455\u1d1b \u1d21\u1d00\u0455 \u0455\u1d1b\u1d0f\u0280\u1d07\u1d05 \u026a\u0274 &b" + this.publicName(target) + "&7'\u0455 \u01eb\u1d1c\u1d07\u1d1c\u1d07 &8(#" + queuePosition + "&8).");
                this.playNotification(player, "TPA.REQUEST-SENT");
                return;
            }
            if (choice == ThreeChoice.FRIENDS_FOLLOWED) {
                boolean isFriendOrFollowed;
                boolean bl = isFriendOrFollowed = this.plugin.getFriendsManager() != null && this.plugin.getFriendsManager().isFollowing(target.getUniqueId(), player.getUniqueId());
                if (!isFriendOrFollowed) {
                    this.send(player, "&c" + target.getName() + " only accepts teleport requests from friends/followed.");
                    return;
                }
            }
        }
        if (targetData != null && targetData.isTpauto()) {
            int queuePosition = this.plugin.getTPAManager().queueAutoTPA(player, target, false);
            if (queuePosition == 0) {
                this.sendAlreadySent(player, target);
                return;
            }
            this.send(player, this.plugin.getConfigManager().getMessage("TPA.INVITE-SENT", "{player}", this.publicName(target)));
            if (queuePosition > 1) {
                this.send(player, "&7\u028f\u1d0f\u1d1c\u0280 /tpa \u0280\u1d07\u01eb\u1d1c\u1d07\u0455\u1d1b \u1d21\u1d00\u0455 \u0455\u1d1b\u1d0f\u0280\u1d07\u1d05 \u026a\u0274 &b" + this.publicName(target) + "&7'\u0455 \u1d00\u1d1c\u1d1b\u1d0f-\u1d00\u1d04\u1d04\u1d07\u1d18\u1d1b \u01eb\u1d1c\u1d07\u1d1c\u1d07 &8(#" + queuePosition + "&8).");
            }
            this.playNotification(player, "TPA.REQUEST-SENT");
            this.plugin.getTPAManager().processQueuedAutoRequests(target.getUniqueId());
            return;
        }
        if (!this.plugin.getTPAManager().sendTPA(player, target)) {
            this.sendAlreadySent(player, target);
            return;
        }
        this.send(player, this.plugin.getConfigManager().getMessage("TPA.INVITE-SENT", "{player}", this.publicName(target)));
        this.playNotification(player, "TPA.REQUEST-SENT");
        this.sendIncomingRequest(player, target, false);
    }

    private void handleTpaHere(Player player, String[] args) {
        if (args.length == 0) {
            new TpaQueueMenu(this.plugin, true).open(player);
            return;
        }
        Player target = PlayerLookup.findOnlinePlayer(args[0]);
        if (target == null || target.equals(player)) {
            this.send(player, target == null ? "&c\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u0274\u1d0f\u1d1b \u1d0f\u0274\u029f\u026a\u0274\u1d07." : this.plugin.getConfigManager().getMessage("TPA.CANNOT-INVITE-YOURSELF"));
            return;
        }
        if (this.plugin.getFriendsManager() != null && this.plugin.getFriendsManager().isTeleportRequestBlocked(player.getUniqueId(), target.getUniqueId())) {
            this.send(player, "&c" + target.getName() + " has disabled teleport requests from you.");
            return;
        }
        if (this.plugin.getFriendsManager() != null && this.plugin.getFriendsManager().isTpaAutoAcceptEnabled(player.getUniqueId(), target.getUniqueId())) {
            this.plugin.getSpigotScheduler().runEntity((Entity)target, () -> {
                this.plugin.getTeleportManager().queue(target, player.getLocation(), "TPA", null);
                this.send(player, this.plugin.getConfigManager().getMessage("TPA.YOUR-REQUEST-HERE-ACCEPTED", "{player}", target.getName()));
                target.sendMessage(ColorUtils.toComponent("&7\u1d00\u1d1c\u1d1b\u1d0f-\u1d00\u1d04\u1d04\u1d07\u1d18\u1d1b\u1d07\u1d05 \u1d1b\u1d07\u029f\u1d07\u1d18\u1d0f\u0280\u1d1b \u0280\u1d07\u01eb\u1d1c\u1d07\u0455\u1d1b \ua730\u0280\u1d0f\u1d0d &b" + player.getName() + "&7."));
            });
            return;
        }
        PlayerData targetData = this.plugin.getPlayerDataManager().get(target);
        if (targetData != null) {
            ThreeChoice choice = targetData.getTpaHereRequestsChoice();
            if (choice == ThreeChoice.OFF) {
                int queuePosition = this.plugin.getTPAManager().queueManualTPAHere(player, target);
                if (queuePosition == 0) {
                    this.sendAlreadySent(player, target);
                    return;
                }
                this.send(player, this.plugin.getConfigManager().getMessage("TPA.INVITE-HERE-SENT", "{player}", this.publicName(target)));
                this.send(player, "&7\u028f\u1d0f\u1d1c\u0280 /tpahere \u0280\u1d07\u01eb\u1d1c\u1d07\u0455\u1d1b \u1d21\u1d00\u0455 \u1d00\u1d05\u1d05\u1d07\u1d05 \u1d1b\u1d0f &b" + this.publicName(target) + "&7'\u0455 \u01eb\u1d1c\u1d07\u1d1c\u1d07 &8(#" + queuePosition + "&8).");
                this.playNotification(player, "TPA.REQUEST-SENT");
                return;
            }
            if (choice == ThreeChoice.FRIENDS_FOLLOWED) {
                boolean isFriendOrFollowed;
                boolean bl = isFriendOrFollowed = this.plugin.getFriendsManager() != null && this.plugin.getFriendsManager().isFollowing(target.getUniqueId(), player.getUniqueId());
                if (!isFriendOrFollowed) {
                    this.send(player, "&c" + target.getName() + " only accepts teleport-here requests from friends/followed.");
                    return;
                }
            }
        }
        if (targetData != null && targetData.isAutoTpaHereEnabled()) {
            int queuePosition = this.plugin.getTPAManager().queueAutoTPAHere(player, target, false);
            if (queuePosition == 0) {
                this.sendAlreadySent(player, target);
                return;
            }
            this.send(player, this.plugin.getConfigManager().getMessage("TPA.INVITE-HERE-SENT", "{player}", this.publicName(target)));
            if (queuePosition > 1) {
                this.send(player, "&7\u028f\u1d0f\u1d1c\u0280 /tpahere \u0280\u1d07\u01eb\u1d1c\u1d07\u0455\u1d1b \u1d21\u1d00\u0455 \u1d00\u1d05\u1d05\u1d07\u1d05 \u1d1b\u1d0f &b" + this.publicName(target) + "&7'\u0455 \u1d00\u1d1c\u1d1b\u1d0f-\u1d00\u1d04\u1d04\u1d07\u1d18\u1d1b \u01eb\u1d1c\u1d07\u1d1c\u1d07 &8(#" + queuePosition + "&8).");
            }
            this.playNotification(player, "TPA.REQUEST-SENT");
            this.plugin.getTPAManager().processQueuedAutoRequests(target.getUniqueId());
            return;
        }
        if (!this.plugin.getTPAManager().sendTPAHere(player, target)) {
            this.sendAlreadySent(player, target);
            return;
        }
        this.send(player, this.plugin.getConfigManager().getMessage("TPA.INVITE-HERE-SENT", "{player}", this.publicName(target)));
        this.playNotification(player, "TPA.REQUEST-SENT");
        this.sendIncomingRequest(player, target, true);
    }

    private void handleAccept(Player player, String[] args) {
        TPAManager.TpaRequest request = this.plugin.getTPAManager().getRequest(player.getUniqueId());
        if (request == null) {
            this.send(player, this.plugin.getConfigManager().getMessage("TPA.NO-REQUEST", "{player}", args.length > 0 ? args[0] : ""));
            return;
        }
        this.plugin.getTPAManager().acceptPendingRequest(player);
    }

    private void handleDeny(Player player) {
        if (!this.plugin.getTPAManager().hasRequest(player.getUniqueId())) {
            this.send(player, this.plugin.getConfigManager().getMessage("TPA.NO-REQUEST", "{player}", ""));
            return;
        }
        TPAManager.TpaRequest request = this.plugin.getTPAManager().getRequest(player.getUniqueId());
        this.plugin.getTPAManager().removeRequest(player.getUniqueId());
        this.send(player, "&7\u1d1b\u1d18\u1d00 \u0280\u1d07\u01eb\u1d1c\u1d07\u0455\u1d1b \u1d05\u1d07\u0274\u026a\u1d07\u1d05.");
        if (request == null) {
            return;
        }
        Player requester = Bukkit.getPlayer(request.requester());
        if (requester != null) {
            requester.sendMessage(ColorUtils.toComponent("&7\u028f\u1d0f\u1d1c\u0280 \u1d1b\u1d07\u029f\u1d07\u1d18\u1d0f\u0280\u1d1b \u0280\u1d07\u01eb\u1d1c\u1d07\u0455\u1d1b \u1d21\u1d00\u0455 \u1d05\u1d07\u0274\u026a\u1d07\u1d05."));
        }
    }

    private void sendAlreadySent(Player player, Player target) {
        this.send(player, this.plugin.getConfigManager().getMessage("TPA.ALREADY-SENT", "{player}", this.publicName(target)));
    }

    private void send(Player player, String message) {
        player.sendMessage(ColorUtils.toComponent(message));
    }

    private void sendIncomingRequest(Player requester, Player target, boolean tpaHere) {
        String requesterName = requester.getName();
        String requesterDisplayName = this.publicName(requester);
        UUID requesterUuid = requester.getUniqueId();
        PlayerData targetData = this.plugin.getPlayerDataManager().get(target);
        boolean alertsEnabled = targetData == null || targetData.isTeleportAlertsEnabled();
        this.plugin.getSpigotScheduler().runEntity((Entity)target, () -> {
            if (!target.isOnline()) {
                return;
            }
            if (alertsEnabled) {
                this.playNotification(target, "TPA.REQUEST-RECEIVED");
                String messagePath = tpaHere ? "TPA.REQUEST-HERE-RECEIVED" : "TPA.REQUEST-RECEIVED";
                TextComponent requestMsg = ColorUtils.toBaseComponent(this.plugin.getConfigManager().getMessage(messagePath, "{player}", requesterDisplayName));
                requestMsg.setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/tpaccept " + requesterName));
                target.spigot().sendMessage((BaseComponent)requestMsg);
            }
        });
    }

    private void playNotification(Player player, String path) {
        SoundUtils.play(this.plugin, player, this.plugin.getConfigManager().getSound(path), PlayerSettingUtils.SoundChannel.NOTIFICATION);
    }

    private boolean shouldOpenTpaConfirmMenu(Player target) {
        return false;
    }

    private String publicName(Player player) {
        return player.getName();
    }
}

