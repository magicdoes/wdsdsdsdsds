/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.PluginCommand
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.configuration.file.FileConfiguration
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.commands.WorthCommand;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

public class WorthSetCommand
implements CommandExecutor,
TabCompleter {
    public static double parseAmount(String string) {
        string = string.toLowerCase(Locale.ROOT);
        double d = Double.parseDouble(string.replaceAll("[kmb]$", ""));
        if (string.endsWith("k")) {
            return d * (double)1000;
        }
        if (string.endsWith("m")) {
            return d * (double)1000 * (double)1000;
        }
        if (string.endsWith("b")) {
            return d * (double)1000 * (double)1000 * (double)1000;
        }
        return d;
    }

    public static void init(JavaPlugin javaPlugin) {
        if (!javaPlugin.isEnabled()) {
            return;
        }
        WorthSetCommand worthSetCommand = new WorthSetCommand();
        PluginCommand pluginCommand = javaPlugin.getCommand("worth");
        pluginCommand.setExecutor((CommandExecutor)worthSetCommand);
        pluginCommand.setTabCompleter((TabCompleter)worthSetCommand);
    }

    public boolean onCommand(CommandSender commandSender, Command command, String string, String[] stringArray) {
        if (stringArray.length != 0 && "set".equalsIgnoreCase(stringArray[0])) {
            if (!commandSender.hasPermission("MagicSMP.admin.worth")) { commandSender.sendMessage("§cYou do not have permission to change worth prices."); return true; }
            if (stringArray.length != 3) { commandSender.sendMessage("§cUsage: /worth set <item> <price per item>"); return true; }
            Material material = Material.matchMaterial(stringArray[1]);
            if (material == null || !material.isItem() || material.isAir()) { commandSender.sendMessage("§cChoose a valid item or block."); return true; }
            if (!stringArray[2].matches("[0-9]{1,15}(\\.[0-9]{1,8})?[kKmMbB]?")) { commandSender.sendMessage("§cEnter a positive price, for example 1000, 2k or 1.5m."); return true; }
            double d = WorthSetCommand.parseAmount(stringArray[2]);
            if (!(d > 0.0)) { commandSender.sendMessage("§cThe price must be greater than zero."); return true; }
            FileConfiguration cfg = MagicSmp.getInstance().getConfigManager().getWorth();
            cfg.set("ITEMS." + material.name(), d);
            try { cfg.save(new File(MagicSmp.getInstance().getDataFolder(), "worth.yml")); } catch (Exception e) { commandSender.sendMessage("§cCould not save worth.yml."); return true; }
            MagicSmp.getInstance().getWorthManager().reload();
            commandSender.sendMessage("§aWorth price saved. Selling and /worth now use the new price.");
            return true;
        }
        if (stringArray.length != 0 && "remove".equalsIgnoreCase(stringArray[0])) {
            if (!commandSender.hasPermission("MagicSMP.admin.worth")) { commandSender.sendMessage("§cYou do not have permission to change worth prices."); return true; }
            if (stringArray.length != 2) { commandSender.sendMessage("§cUsage: /worth remove <item>"); return true; }
            Material material = Material.matchMaterial(stringArray[1]);
            if (material == null || material.isAir()) { commandSender.sendMessage("§cChoose a valid item or block."); return true; }
            FileConfiguration cfg = MagicSmp.getInstance().getConfigManager().getWorth();
            String path = "ITEMS." + material.name();
            if (!cfg.contains(path)) { commandSender.sendMessage("§cThat item is not in the worth file."); return true; }
            cfg.set(path, null);
            try { cfg.save(new File(MagicSmp.getInstance().getDataFolder(), "worth.yml")); } catch (Exception e) { commandSender.sendMessage("§cCould not save worth.yml."); return true; }
            MagicSmp.getInstance().getWorthManager().reload();
            commandSender.sendMessage("§aRemoved " + material.name() + " from worth.yml. Selling and /worth are updated immediately.");
            return true;
        }
        return new WorthCommand(MagicSmp.getInstance()).onCommand(commandSender, command, string, stringArray);
    }

    public List onTabComplete(CommandSender commandSender, Command command, String string, String[] stringArray) {
        ArrayList<String> out = new ArrayList<String>();
        if (!commandSender.hasPermission("MagicSMP.admin.worth")) return out;
        if (stringArray.length == 1) {
            String q = stringArray[0].toLowerCase(Locale.ROOT);
            for (String sub : new String[]{"set", "remove", "reload"}) if (sub.startsWith(q)) out.add(sub);
        } else if (stringArray.length == 2 && "set".equalsIgnoreCase(stringArray[0])) {
            String q = stringArray[1].toUpperCase(Locale.ROOT);
            for (Material material : Material.values()) if (material.isItem() && !material.isAir() && material.name().startsWith(q)) out.add(material.name());
        } else if (stringArray.length == 2 && "remove".equalsIgnoreCase(stringArray[0])) {
            String q = stringArray[1].toUpperCase(Locale.ROOT);
            FileConfiguration cfg = MagicSmp.getInstance().getConfigManager().getWorth();
            org.bukkit.configuration.ConfigurationSection items = cfg.getConfigurationSection("ITEMS");
            if (items != null) for (String key : items.getKeys(false)) if (key.toUpperCase(Locale.ROOT).startsWith(q)) out.add(key.toUpperCase(Locale.ROOT));
        }
        return out;
    }

}

