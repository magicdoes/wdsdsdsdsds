/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.managers.LeaderboardManager;
import com.bx.magicSmp.menus.LeaderboardMenu;
import com.bx.magicSmp.menus.LeaderboardTypeMenu;
import com.bx.magicSmp.utils.ColorUtils;
import java.util.stream.Collectors;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class LeaderboardCommand
implements CommandExecutor {
    private final MagicSmp plugin;

    public LeaderboardCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u1d0f\u0274\u029f\u028f.");
            return true;
        }
        Player player = (Player)sender;
        if (!this.plugin.getConfigManager().isCommandEnabled("LEADERBOARDS")) {
            player.sendMessage(ColorUtils.toComponent("&c\u029f\u1d07\u1d00\u1d05\u1d07\u0280\u0299\u1d0f\u1d00\u0280\u1d05\u0455 \u1d00\u0280\u1d07 \u1d04\u1d1c\u0280\u0280\u1d07\u0274\u1d1b\u029f\u028f \u1d05\u026a\u0455\u1d00\u0299\u029f\u1d07\u1d05."));
            return true;
        }
        if (args.length == 0 && label.equalsIgnoreCase("baltop")) {
            new LeaderboardTypeMenu(this.plugin, LeaderboardManager.LeaderboardType.MONEY).open(player);
            return true;
        }
        if (args.length == 0) {
            LeaderboardManager.LeaderboardType shortcutType;
            switch (label.toLowerCase()) {
                case "kills": {
                    LeaderboardManager.LeaderboardType leaderboardType2 = LeaderboardManager.LeaderboardType.KILLS;
                    break;
                }
                case "deaths": {
                    LeaderboardManager.LeaderboardType leaderboardType2 = LeaderboardManager.LeaderboardType.DEATHS;
                    break;
                }
                case "topplaytime": {
                    LeaderboardManager.LeaderboardType leaderboardType2 = LeaderboardManager.LeaderboardType.PLAYTIME;
                    break;
                }
                default: {
                    LeaderboardManager.LeaderboardType leaderboardType2 = shortcutType = null;
                }
            }
            if (shortcutType != null) {
                new LeaderboardTypeMenu(this.plugin, shortcutType).open(player);
                return true;
            }
        }
        if (args.length == 0) {
            new LeaderboardMenu(this.plugin).open(player);
            return true;
        }
        LeaderboardManager.LeaderboardType type = this.plugin.getLeaderboardManager().parseType(args[0]).orElse(null);
        if (type == null) {
            String available = this.plugin.getLeaderboardManager().getTypes().stream().map(leaderboardType -> leaderboardType.getConfigKey()).collect(Collectors.joining(", "));
            player.sendMessage(ColorUtils.toComponent("&c\u026a\u0274\u1d20\u1d00\u029f\u026a\u1d05 \u029f\u1d07\u1d00\u1d05\u1d07\u0280\u0299\u1d0f\u1d00\u0280\u1d05 \u1d1b\u028f\u1d18\u1d07. &7\u1d00\u1d20\u1d00\u026a\u029f\u1d00\u0299\u029f\u1d07: &f" + available));
            return true;
        }
        new LeaderboardTypeMenu(this.plugin, type).open(player);
        return true;
    }
}

