/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.permissions.Permissible
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.PermissionUtils;
import com.bx.magicSmp.utils.PlayerLookup;
import java.util.Arrays;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.permissions.Permissible;

public class MessageCommand
implements CommandExecutor {
    private static final String PERMISSION = "MagicSMP.message";
    private final MagicSmp plugin;

    public MessageCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Player player;
        if (!this.plugin.getConfigManager().isCommandEnabled("MESSAGE")) {
            this.send(sender, this.message("DISABLED", "&c\u1d18\u0280\u026a\u1d20\u1d00\u1d1b\u1d07 \u1d0d\u1d07\u0455\u0455\u1d00\u0262\u1d07\u0455 \u1d00\u0280\u1d07 \u1d04\u1d1c\u0280\u0280\u1d07\u0274\u1d1b\u029f\u028f \u1d05\u026a\u0455\u1d00\u0299\u029f\u1d07\u1d05."));
            return true;
        }
        if (sender instanceof Player && !PermissionUtils.has((Permissible)(player = (Player)sender), PERMISSION)) {
            this.send(player, this.message("NO-PERMISSION", "&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274."));
            return true;
        }
        if (label.equalsIgnoreCase("reply") || label.equalsIgnoreCase("r")) {
            return this.handleReply(sender, args, label);
        }
        if (args.length < 2) {
            this.send(sender, this.message("USAGE", "&c\u1d1c\u0455\u1d00\u0262\u1d07: /msg <player> <message>"));
            return true;
        }
        Player target = PlayerLookup.findOnlinePlayer(args[0]);
        if (target == null) {
            this.send(sender, this.message("PLAYER-NOT-ONLINE", "&c\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u0274\u1d0f\u1d1b \u1d0f\u0274\u029f\u026a\u0274\u1d07."));
            return true;
        }
        String privateMessage = String.join((CharSequence)" ", Arrays.copyOfRange(args, 1, args.length));
        this.plugin.getPrivateMessageManager().sendPrivateMessage(sender, target, privateMessage);
        return true;
    }

    private boolean handleReply(CommandSender sender, String[] args, String label) {
        if (!(sender instanceof Player)) {
            this.send(sender, this.message("PLAYER-ONLY-REPLY", "&c\u1d0f\u0274\u029f\u028f \u1d18\u029f\u1d00\u028f\u1d07\u0280\u0455 \u1d04\u1d00\u0274 \u1d1c\u0455\u1d07 /" + label + "."));
            return true;
        }
        Player player = (Player)sender;
        if (args.length == 0) {
            this.send(player, this.message("REPLY-USAGE", "&c\u1d1c\u0455\u1d00\u0262\u1d07: /reply <message>"));
            return true;
        }
        this.plugin.getPrivateMessageManager().reply(player, String.join((CharSequence)" ", args));
        return true;
    }

    private void send(CommandSender sender, String message) {
        if (sender instanceof Player) {
            Player player = (Player)sender;
            player.sendMessage(ColorUtils.toComponent(message, player));
            return;
        }
        sender.sendMessage(ColorUtils.colorize(message));
    }

    private String message(String key, String fallback) {
        String configured = switch (key) {
            case "USAGE" -> this.configuredMessage("MESSAGES.USAGE", "PRIVATE-MESSAGE.USAGE");
            case "REPLY-USAGE" -> this.configuredMessage("MESSAGES.REPLY_USAGE", "PRIVATE-MESSAGE.REPLY-USAGE");
            case "PLAYER-ONLY-REPLY" -> this.configuredMessage("MESSAGES.PLAYER_ONLY_REPLY", "PRIVATE-MESSAGE.PLAYER-ONLY-REPLY");
            case "NO-PERMISSION" -> this.configuredMessage("MESSAGES.NO_PERMISSION", "PRIVATE-MESSAGE.NO-PERMISSION");
            case "DISABLED" -> this.configuredMessage("MESSAGES.DISABLED", "PRIVATE-MESSAGE.DISABLED");
            case "PLAYER-NOT-ONLINE" -> this.configuredMessage("MESSAGES.PLAYER_NOT_ONLINE", "PRIVATE-MESSAGE.PLAYER-NOT-ONLINE");
            default -> this.plugin.getConfigManager().getMessages().getString("PRIVATE-MESSAGE." + key);
        };
        return configured == null ? fallback : configured;
    }

    private String configuredMessage(String path, String fallbackPath) {
        String value = this.plugin.getConfigManager().getMessages().getString(path);
        if (value != null) {
            return value;
        }
        return this.plugin.getConfigManager().getMessages().getString(fallbackPath);
    }
}

