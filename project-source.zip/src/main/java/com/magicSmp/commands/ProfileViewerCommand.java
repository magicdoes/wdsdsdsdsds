/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.menus.ProfileViewerMenu;
import com.bx.magicSmp.models.ProfileSnapshot;
import com.bx.magicSmp.utils.ColorUtils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ProfileViewerCommand
implements CommandExecutor {
    private final MagicSmp plugin;

    public ProfileViewerCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u1d0f\u0274\u029f\u028f.");
            return true;
        }
        Player player = (Player)sender;
        if (!this.plugin.getProfileViewerManager().canView(player)) {
            player.sendMessage(ColorUtils.toComponent("&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274 \u1d1b\u1d0f \u1d20\u026a\u1d07\u1d21 \u1d18\u029f\u1d00\u028f\u1d07\u0280 \u1d18\u0280\u1d0f\ua730\u026a\u029f\u1d07\u0455."));
            return true;
        }
        if (args.length == 0) {
            player.sendMessage(ColorUtils.toComponent("&c\u1d1c\u0455\u1d00\u0262\u1d07: /" + label + " <player>"));
            return true;
        }
        ProfileSnapshot snapshot = this.plugin.getProfileViewerManager().resolveProfile(args[0]).orElse(null);
        if (snapshot == null) {
            player.sendMessage(ColorUtils.toComponent("&c\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u1d18\u0280\u1d0f\ua730\u026a\u029f\u1d07 \u0274\u1d0f\u1d1b \ua730\u1d0f\u1d1c\u0274\u1d05."));
            return true;
        }
        new ProfileViewerMenu(this.plugin, snapshot.getUuid()).open(player);
        return true;
    }
}

