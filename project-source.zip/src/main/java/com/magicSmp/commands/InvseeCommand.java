/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.command.TabCompleter
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.utils.ColorUtils;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public class InvseeCommand
implements CommandExecutor,
TabCompleter {
    private final MagicSmp plugin;

    public InvseeCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        OfflinePlayer offlinePlayer;
        UUID targetUuid;
        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            if (!this.plugin.getInvseeManager().canAdmin(sender)) {
                sender.sendMessage(ColorUtils.toComponent(this.plugin.getInvseeManager().getMessage("NO-PERMISSION", "&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274.")));
                return true;
            }
            this.plugin.getConfigManager().reloadInvsee();
            this.plugin.getInvseeManager().reload();
            sender.sendMessage(ColorUtils.toComponent(this.plugin.getInvseeManager().getMessage("RELOAD-SUCCESS", "&a\u026a\u0274\u1d20\u0455\u1d07\u1d07 \u1d04\u1d0f\u0274\ua730\u026a\u0262 \u0280\u1d07\u029f\u1d0f\u1d00\u1d05\u1d07\u1d05.")));
            return true;
        }
        if (!(sender instanceof Player)) {
            sender.sendMessage("\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u1d0f\u0274\u029f\u028f.");
            return true;
        }
        Player viewer = (Player)sender;
        if (!this.plugin.getInvseeManager().isEnabled()) {
            viewer.sendMessage(ColorUtils.toComponent(this.plugin.getInvseeManager().getMessage("FEATURE-DISABLED", "&c\u1d1b\u029c\u1d07 \u026a\u0274\u1d20\u0455\u1d07\u1d07 \u0455\u028f\u0455\u1d1b\u1d07\u1d0d \u026a\u0455 \u1d05\u026a\u0455\u1d00\u0299\u029f\u1d07\u1d05.")));
            return true;
        }
        if (!this.plugin.getInvseeManager().canView(viewer)) {
            viewer.sendMessage(ColorUtils.toComponent(this.plugin.getInvseeManager().getMessage("NO-PERMISSION", "&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274.")));
            return true;
        }
        if (args.length == 0) {
            viewer.sendMessage(ColorUtils.toComponent("&c\u1d1c\u0455\u1d00\u0262\u1d07: /" + label + " <player>"));
            return true;
        }
        Player target = this.plugin.getInvseeManager().findOnlineTarget(args[0]);
        if (target == null && !this.plugin.getInvseeManager().requiresOnlineTarget() && (targetUuid = this.plugin.getDatabaseManager().findPlayerUuidByUsername(args[0])) != null && (offlinePlayer = Bukkit.getOfflinePlayer((UUID)targetUuid)) != null && offlinePlayer.hasPlayedBefore()) {
            this.plugin.getInvseeManager().openOffline(viewer, offlinePlayer);
            return true;
        }
        if (target == null) {
            boolean knownPlayer = this.plugin.getInvseeManager().hasKnownPlayer(args[0]);
            String path = this.plugin.getInvseeManager().requiresOnlineTarget() || knownPlayer ? "PLAYER-NOT-ONLINE" : "PLAYER-NOT-FOUND";
            String fallback = this.plugin.getInvseeManager().requiresOnlineTarget() || knownPlayer ? "&cthat player must be online." : "&cplayer not found.";
            viewer.sendMessage(ColorUtils.toComponent(this.plugin.getInvseeManager().formatMessage(path, fallback, "{player}", args[0], "{target}", args[0])));
            return true;
        }
        if (!this.plugin.getInvseeManager().allowSelfView() && viewer.getUniqueId().equals(target.getUniqueId())) {
            viewer.sendMessage(ColorUtils.toComponent(this.plugin.getInvseeManager().getMessage("SELF-VIEW-DISABLED", "&c\u028f\u1d0f\u1d1c \u1d04\u1d00\u0274\u0274\u1d0f\u1d1b \u026a\u0274\u1d20\u0455\u1d07\u1d07 \u028f\u1d0f\u1d1c\u0280\u0455\u1d07\u029f\ua730.")));
            return true;
        }
        this.plugin.getInvseeManager().open(viewer, target);
        return true;
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        ArrayList<String> completions = new ArrayList<String>();
        if (args.length == 1) {
            for (Player player : Bukkit.getOnlinePlayers()) {
                completions.add(player.getName());
            }
            if (!this.plugin.getInvseeManager().requiresOnlineTarget()) {
                List<String> knownPlayerNames = this.plugin.getDatabaseManager().loadKnownPlayerNames();
                for (String playerName : knownPlayerNames) {
                    Player onlinePlayer;
                    if (playerName == null || playerName.isBlank() || (onlinePlayer = Bukkit.getPlayer((String)playerName)) != null && onlinePlayer.isOnline()) continue;
                    completions.add(playerName);
                }
            }
            String partial = args[0].toLowerCase();
            completions.removeIf(name -> !name.toLowerCase().startsWith(partial));
        }
        return completions;
    }
}

