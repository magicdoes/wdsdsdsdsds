/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.util.StringUtil
 */
package com.bx.magicSmp.commands;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.util.StringUtil;

public class ChatTabCompleter
implements TabCompleter {
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return this.partialMatches(args[0], List.of("help", "mute", "unmute", "delay", "clear"));
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("delay")) {
            return this.partialMatches(args[1], List.of("0", "3", "5", "10", "off"));
        }
        return Collections.emptyList();
    }

    private List<String> partialMatches(String token, List<String> completions) {
        ArrayList<String> matches = new ArrayList<String>();
        StringUtil.copyPartialMatches((String)token, completions, matches);
        matches.sort(String.CASE_INSENSITIVE_ORDER);
        return matches;
    }
}

