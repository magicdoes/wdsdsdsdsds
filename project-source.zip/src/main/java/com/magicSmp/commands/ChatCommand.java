/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.permissions.Permissible
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.PermissionUtils;
import com.bx.magicSmp.utils.PlayerSettingUtils;
import java.util.List;
import java.util.Locale;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.permissions.Permissible;

public class ChatCommand
implements CommandExecutor {
    private static final String BASE_PERMISSION = "MagicSmp.staff.chat.use";
    private static final String MUTE_PERMISSION = "MagicSmp.staff.chat.mute";
    private static final String UNMUTE_PERMISSION = "MagicSmp.staff.chat.unmute";
    private static final String DELAY_PERMISSION = "MagicSmp.staff.chat.delay";
    private static final String CLEAR_PERMISSION = "MagicSmp.staff.chat.clear";
    private final MagicSmp plugin;

    public ChatCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!this.plugin.getConfigManager().isCommandEnabled("CHAT")) {
            this.send(sender, this.message("DISABLED", "&c\u1d04\u029c\u1d00\u1d1b \u1d04\u1d0f\u1d0d\u1d0d\u1d00\u0274\u1d05 \u026a\u0455 \u1d04\u1d1c\u0280\u0280\u1d07\u0274\u1d1b\u029f\u028f \u1d05\u026a\u0455\u1d00\u0299\u029f\u1d07\u1d05."));
            return true;
        }
        if (!this.hasAccess(sender, BASE_PERMISSION, MUTE_PERMISSION, UNMUTE_PERMISSION, DELAY_PERMISSION, CLEAR_PERMISSION)) {
            this.send(sender, this.message("NO-PERMISSION", "&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274."));
            return true;
        }
        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            this.sendHelp(sender);
            return true;
        }
        return switch (args[0].toLowerCase(Locale.ROOT)) {
            case "mute" -> this.handleMute(sender);
            case "unmute" -> this.handleUnmute(sender);
            case "delay" -> this.handleDelay(sender, args, label);
            case "clear" -> this.handleClear(sender);
            default -> {
                this.sendHelp(sender);
                yield true;
            }
        };
    }

    private boolean handleMute(CommandSender sender) {
        if (!this.hasAccess(sender, MUTE_PERMISSION)) {
            this.send(sender, this.message("NO-PERMISSION", "&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274."));
            return true;
        }
        this.plugin.getChatManager().setGlobalChatMuted(true, true);
        this.broadcast(this.message("MUTED", "&a\u0262\u029f\u1d0f\u0299\u1d00\u029f \u1d04\u029c\u1d00\u1d1b \u026a\u0455 \u0274\u1d0f\u1d21 \u1d0d\u1d1c\u1d1b\u1d07\u1d05."), sender);
        return true;
    }

    private boolean handleUnmute(CommandSender sender) {
        if (!this.hasAccess(sender, UNMUTE_PERMISSION)) {
            this.send(sender, this.message("NO-PERMISSION", "&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274."));
            return true;
        }
        this.plugin.getChatManager().setGlobalChatMuted(false, true);
        this.broadcast(this.message("UNMUTED", "&a\u0262\u029f\u1d0f\u0299\u1d00\u029f \u1d04\u029c\u1d00\u1d1b \u026a\u0455 \u0274\u1d0f\u1d21 \u1d1c\u0274\u1d0d\u1d1c\u1d1b\u1d07\u1d05."), sender);
        return true;
    }

    private boolean handleDelay(CommandSender sender, String[] args, String label) {
        int delaySeconds;
        if (!this.hasAccess(sender, DELAY_PERMISSION)) {
            this.send(sender, this.message("NO-PERMISSION", "&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274."));
            return true;
        }
        if (args.length < 2) {
            this.send(sender, "&c\u1d1c\u0455\u1d00\u0262\u1d07: /" + label + " \u1d05\u1d07\u029f\u1d00\u028f <seconds|off>");
            return true;
        }
        if (args[1].equalsIgnoreCase("off")) {
            delaySeconds = 0;
        } else {
            try {
                delaySeconds = Integer.parseInt(args[1]);
            }
            catch (NumberFormatException exception) {
                this.send(sender, this.message("INVALID-DELAY", "&c\u026a\u0274\u1d20\u1d00\u029f\u026a\u1d05 \u1d05\u1d07\u029f\u1d00\u028f."));
                return true;
            }
        }
        int maxDelay = this.plugin.getChatManager().getMaxDelaySeconds();
        if (delaySeconds < 0 || delaySeconds > maxDelay) {
            this.send(sender, this.message("INVALID-DELAY", "&c\u026a\u0274\u1d20\u1d00\u029f\u026a\u1d05 \u1d05\u1d07\u029f\u1d00\u028f. \u1d1c\u0455\u1d07 \u1d00 \u0274\u1d1c\u1d0d\u0299\u1d07\u0280 \u0299\u1d07\u1d1b\u1d21\u1d07\u1d07\u0274 0 \u1d00\u0274\u1d05 {max}.").replace("{max}", String.valueOf(maxDelay)).replace("%max%", String.valueOf(maxDelay)));
            return true;
        }
        boolean enabled = delaySeconds > 0;
        this.plugin.getChatManager().setGlobalDelay(delaySeconds, enabled, true);
        String status = enabled ? this.message("STATUS-ENABLED", "\u1d07\u0274\u1d00\u0299\u029f\u1d07\u1d05") : this.message("STATUS-DISABLED", "\u1d05\u026a\u0455\u1d00\u0299\u029f\u1d07\u1d05");
        String response = this.message("DELAY", "&7\u1d04\u029c\u1d00\u1d1b \u026a\u0455 \u0274\u1d0f\u1d21 \u1d05\u1d07\u029f\u1d00\u028f\u1d07\u1d05 &a%delay% &7\u0455\u1d07\u1d04\u1d0f\u0274\u1d05\u0455 \u1d00\u0274\u1d05 \u1d05\u1d07\u029f\u1d00\u028f \u026a\u0455 &a%status%").replace("%delay%", String.valueOf(delaySeconds)).replace("%status%", status).replace("{delay}", String.valueOf(delaySeconds)).replace("{status}", status);
        this.broadcast(response, sender);
        return true;
    }

    private boolean handleClear(CommandSender sender) {
        if (!this.hasAccess(sender, CLEAR_PERMISSION)) {
            this.send(sender, this.message("NO-PERMISSION", "&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274."));
            return true;
        }
        this.plugin.getChatManager().clearChatForAllPlayers();
        this.broadcast(this.message("CLEARED", "&a\u0262\u029f\u1d0f\u0299\u1d00\u029f \u1d04\u029c\u1d00\u1d1b \u026a\u0455 \u1d04\u029f\u1d07\u1d00\u0280\u1d07\u1d05."), sender);
        return true;
    }

    private void sendHelp(CommandSender sender) {
        List<String> lines = this.plugin.getConfigManager().getMessages().getStringList("CHAT-MANAGER.HELP");
        if (lines.isEmpty()) {
            lines = List.of("", "&b&l\u1d04\u029c\u1d00\u1d1b \u1d0d\u1d00\u0274\u1d00\u0262\u1d07\u0280 &7(\u1d04\u1d0f\u1d0d\u1d0d\u1d00\u0274\u1d05\u0455)", "", "&f/chat \u1d0d\u1d1c\u1d1b\u1d07 &7- \u1d1b\u1d0f \u1d0d\u1d1c\u1d1b\u1d07 \u0262\u029f\u1d0f\u0299\u1d00\u029f \u1d04\u029c\u1d00\u1d1b.", "&f/chat \u1d1c\u0274\u1d0d\u1d1c\u1d1b\u1d07 &7- \u1d1b\u1d0f \u1d1c\u0274\u1d0d\u1d1c\u1d1b\u1d07 \u0262\u029f\u1d0f\u0299\u1d00\u029f \u1d04\u029c\u1d00\u1d1b.", "&f/chat \u1d05\u1d07\u029f\u1d00\u028f (\u1d1b\u026a\u1d0d\u1d07) &7- \u1d1b\u1d0f \u1d00\u1d05\u1d05 \u1d05\u1d07\u029f\u1d00\u028f \u1d1b\u1d0f \u0262\u029f\u1d0f\u0299\u1d00\u029f \u1d04\u029c\u1d00\u1d1b.", "&f/chat \u1d04\u029f\u1d07\u1d00\u0280 &7- \u1d1b\u1d0f \u1d04\u029f\u1d07\u1d00\u0280 \u0262\u029f\u1d0f\u0299\u1d00\u029f \u1d04\u029c\u1d00\u1d1b.", "");
        }
        for (String line : lines) {
            this.send(sender, line);
        }
    }

    private void broadcast(String message, CommandSender sender) {
        Bukkit.getOnlinePlayers().stream().filter(player -> PlayerSettingUtils.notificationEnabled(this.plugin, player, PlayerSettingUtils.NotificationChannel.SERVER_BROADCAST)).forEach(player -> player.sendMessage(ColorUtils.toComponent(message, player)));
        if (!(sender instanceof Player)) {
            sender.sendMessage(ColorUtils.colorize(message));
        }
    }

    private void send(CommandSender sender, String message) {
        if (sender instanceof Player) {
            Player player = (Player)sender;
            player.sendMessage(ColorUtils.toComponent(message, player));
            return;
        }
        sender.sendMessage(ColorUtils.colorize(message));
    }

    private boolean hasAccess(CommandSender sender, String ... permissions) {
        if (!(sender instanceof Player)) {
            return true;
        }
        Player player = (Player)sender;
        if (PermissionUtils.has((Permissible)player, BASE_PERMISSION)) {
            return true;
        }
        for (String permission : permissions) {
            if (!PermissionUtils.has((Permissible)player, permission)) continue;
            return true;
        }
        return false;
    }

    private String message(String key, String fallback) {
        return this.plugin.getConfigManager().getMessages().getString("CHAT-MANAGER." + key, fallback);
    }
}

