/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.TabCompleter
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.managers.FeatureManager;
import java.util.List;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

public class FeatureAwareTabCompleter
implements TabCompleter {
    private final MagicSmp plugin;
    private final TabCompleter delegate;
    private final FeatureManager.Feature[] requiredFeatures;

    public FeatureAwareTabCompleter(MagicSmp plugin, TabCompleter delegate, FeatureManager.Feature ... requiredFeatures) {
        this.plugin = plugin;
        this.delegate = delegate;
        this.requiredFeatures = requiredFeatures;
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        for (FeatureManager.Feature feature : this.requiredFeatures) {
            if (this.plugin.getFeatureManager().isEnabled(feature)) continue;
            return List.of();
        }
        return this.delegate.onTabComplete(sender, command, alias, args);
    }
}

