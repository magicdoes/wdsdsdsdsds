/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.permissions.Permissible
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.managers.CurrencyManager;
import com.bx.magicSmp.managers.EconomyManager;
import com.bx.magicSmp.models.EconomyReason;
import com.bx.magicSmp.models.EconomyTransactionResult;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.NumberUtils;
import com.bx.magicSmp.utils.PermissionUtils;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.permissions.Permissible;

public class RemoveMoneyCommand
implements CommandExecutor {
    private static final String PERMISSION = "MagicSMP.admin.removemoney";
    private final MagicSmp plugin;

    public RemoveMoneyCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        double amount;
        if (!PermissionUtils.has((Permissible)sender, PERMISSION)) {
            sender.sendMessage(ColorUtils.toComponent("&c\u0274\u1d0f \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274."));
            return true;
        }
        if (args.length < 2) {
            sender.sendMessage(ColorUtils.toComponent("&c\u1d1c\u0455\u1d00\u0262\u1d07: /removemoney <player> <amount>"));
            return true;
        }
        try {
            amount = NumberUtils.parse(args[1]);
        }
        catch (NumberFormatException e) {
            sender.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessage("BALANCE.ADMIN.INVALID-AMOUNT")));
            return true;
        }
        if (amount <= 0.0) {
            sender.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessage("BALANCE.ADMIN.MUST-BE-POSITIVE")));
            return true;
        }
        EconomyManager.AccountReference account = this.plugin.getEconomyManager().resolveAccount(args[0]);
        if (account == null) {
            sender.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessage("BALANCE.ADMIN.PLAYER-NOT-FOUND")));
            return true;
        }
        EconomyTransactionResult result = this.plugin.getEconomyManager().withdraw(account, amount, EconomyReason.ADMIN_REMOVE);
        if (!result.success()) {
            String key = result.insufficientFunds() ? "BALANCE.ADMIN.TARGET-NOT-ENOUGH-MONEY" : "BALANCE.ADMIN.PLAYER-NOT-FOUND";
            sender.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessage(key, "{player}", result.displayName(), "{balance}", this.compactAmount(result.beforeBalance()), "{balance_full}", this.fullAmount(result.beforeBalance()), "{balance_money}", this.plugin.getCurrencyManager().formatMoneyCompact(result.beforeBalance()), "{balance_money_full}", this.fullMoney(result.beforeBalance()))));
            return true;
        }
        sender.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessage("BALANCE.ADMIN.REMOVE-MONEY-SUCCESS", "{player}", result.displayName(), "{amount}", this.compactAmount(result.amount()), "{amount_full}", this.fullAmount(result.amount()), "{money}", this.plugin.getCurrencyManager().formatMoneyCompact(result.amount()), "{money_full}", this.fullMoney(result.amount()), "{balance}", this.compactAmount(result.afterBalance()), "{balance_full}", this.fullAmount(result.afterBalance()), "{balance_money}", this.plugin.getCurrencyManager().formatMoneyCompact(result.afterBalance()), "{balance_money_full}", this.fullMoney(result.afterBalance()))));
        Player targetPlayer = Bukkit.getPlayer(result.targetUuid());
        if (targetPlayer != null && !targetPlayer.equals(sender)) {
            targetPlayer.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessage("BALANCE.ADMIN.REMOVE-MONEY-RECEIVED", "{admin}", sender.getName(), "{amount}", this.compactAmount(result.amount()), "{amount_full}", this.fullAmount(result.amount()), "{money}", this.plugin.getCurrencyManager().formatMoneyCompact(result.amount()), "{money_full}", this.fullMoney(result.amount()), "{balance}", this.compactAmount(result.afterBalance()), "{balance_full}", this.fullAmount(result.afterBalance()), "{balance_money}", this.plugin.getCurrencyManager().formatMoneyCompact(result.afterBalance()), "{balance_money_full}", this.fullMoney(result.afterBalance()))));
        }
        return true;
    }

    private String compactAmount(double amount) {
        return this.plugin.getCurrencyManager().formatCompactAmount(CurrencyManager.CurrencyType.MONEY, amount);
    }

    private String fullAmount(double amount) {
        return this.plugin.getCurrencyManager().formatAmount(CurrencyManager.CurrencyType.MONEY, amount);
    }

    private String fullMoney(double amount) {
        return this.plugin.getCurrencyManager().format(CurrencyManager.CurrencyType.MONEY, amount, false);
    }
}

