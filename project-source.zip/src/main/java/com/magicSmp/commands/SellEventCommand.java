/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.utils.ColorUtils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class SellEventCommand
implements CommandExecutor {
    private final MagicSmp plugin;

    public SellEventCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("magicsmp.command.sellevent")) {
            sender.sendMessage(ColorUtils.toComponent("&cYou do not have permission to use /sellevent."));
            return true;
        }
        if (args.length == 0) {
            this.sendUsage(sender);
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "start": {
                this.plugin.getSellEventManager().forceStartEvent();
                sender.sendMessage(ColorUtils.toComponent("&aSell event started manually!"));
                break;
            }
            case "end": {
                this.plugin.getSellEventManager().forceEndEvent();
                sender.sendMessage(ColorUtils.toComponent("&cSell event ended manually!"));
                break;
            }
            case "status": {
                boolean active = this.plugin.getSellEventManager().isEventActive();
                double multiplier = this.plugin.getSellEventManager().getMultiplier();
                long remaining = this.plugin.getSellEventManager().getRemainingSeconds();
                sender.sendMessage(ColorUtils.toComponent("&6Sell Event Status:"));
                sender.sendMessage(ColorUtils.toComponent("&7Active: " + (active ? "&aYes" : "&cNo")));
                sender.sendMessage(ColorUtils.toComponent("&7Multiplier: &e" + multiplier + "x"));
                if (!active) break;
                sender.sendMessage(ColorUtils.toComponent("&7Time Remaining: &e" + remaining + " seconds"));
                break;
            }
            default: {
                this.sendUsage(sender);
            }
        }
        return true;
    }

    private void sendUsage(CommandSender sender) {
        sender.sendMessage(ColorUtils.toComponent("&cUsage: /sellevent <start|end|status>"));
    }
}

