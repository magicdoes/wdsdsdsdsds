/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.menus.ServerInfoMenu;
import com.bx.magicSmp.utils.ColorUtils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class HelpCommand
implements CommandExecutor {
    private final MagicSmp plugin;

    public HelpCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u1d0f\u0274\u029f\u028f.");
            return true;
        }
        Player player = (Player)sender;
        if (!this.plugin.getConfigManager().isCommandEnabled("HELP")) {
            player.sendMessage(ColorUtils.toComponent("&c\u029c\u1d07\u029f\u1d18 \u1d04\u1d0f\u1d0d\u1d0d\u1d00\u0274\u1d05 \u026a\u0455 \u1d04\u1d1c\u0280\u0280\u1d07\u0274\u1d1b\u029f\u028f \u1d05\u026a\u0455\u1d00\u0299\u029f\u1d07\u1d05."));
            return true;
        }
        ServerInfoMenu menu = new ServerInfoMenu(this.plugin);
        if (menu.hasValidButtons()) {
            menu.open(player);
            return true;
        }
        this.sendLegacyHelp(player);
        return true;
    }

    private void sendLegacyHelp(Player player) {
        player.sendMessage(ColorUtils.toComponent("&7&m-------- &b\u029c\u1d07\u029f\u1d18 &7&m--------"));
        this.sendHelpLine(player, "team", "&b/team &7- manage your team");
        this.sendHelpLine(player, "home", "&b/home &7- teleport to your home");
        this.sendHelpLine(player, "spawn", "&b/spawn &7- teleport to spawn");
        this.sendHelpLine(player, "rtp", "&b/rtp &7- random teleport");
        this.sendHelpLine(player, "tpa", "&b/tpa &7- request teleport to a player");
        this.sendHelpLine(player, "shop", "&b/shop &7- open the shop");
        this.sendHelpLine(player, "sell", "&b/sell &7- sell your items");
        this.sendHelpLine(player, "crate", "&b/crates &7- open the crates menu");
        player.sendMessage(ColorUtils.toComponent("&b/balance &7- \u1d04\u029c\u1d07\u1d04\u1d0b \u028f\u1d0f\u1d1c\u0280 \u0299\u1d00\u029f\u1d00\u0274\u1d04\u1d07"));
        this.sendHelpLine(player, "bounty", "&b/bounty &7- view bounties");
        this.sendHelpLine(player, "stats", "&b/stats &7- view your stats");
        this.sendHelpLine(player, "leaderboards", "&b/leaderboard &7- view top players");
        this.sendHelpLine(player, "social", "&b/discord &7- discord link");
        this.sendHelpLine(player, "rules", "&b/rules &7- view server rules");
        player.sendMessage(ColorUtils.toComponent("&7&m---------------------"));
    }

    private void sendHelpLine(Player player, String commandKey, String line) {
        if (this.plugin.getConfigManager().isCommandEnabled(commandKey)) {
            player.sendMessage(ColorUtils.toComponent(line));
        }
    }
}

