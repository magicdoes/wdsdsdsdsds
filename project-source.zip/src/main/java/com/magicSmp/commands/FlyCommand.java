/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.GameMode
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.permissions.Permissible
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.managers.FeatureManager;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.PermissionUtils;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.permissions.Permissible;

public class FlyCommand
implements CommandExecutor,
TabCompleter {
    private static final String PERMISSION = "MagicSMP.staff.fly";
    private final MagicSmp plugin;

    public FlyCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Player player;
        Player target;
        if (!this.plugin.getFeatureManager().isEnabled(FeatureManager.Feature.FLY)) {
            this.plugin.getFeatureManager().sendDisabledMessage(sender, FeatureManager.Feature.FLY, label);
            return true;
        }
        if (args.length > 1) {
            sender.sendMessage(ColorUtils.toComponent("&c\u1d1c\u0455\u1d00\u0262\u1d07: /" + label + " [\u1d18\u029f\u1d00\u028f\u1d07\u0280]"));
            return true;
        }
        if (args.length == 0) {
            if (!(sender instanceof Player)) {
                sender.sendMessage(ColorUtils.toComponent("&c\u1d1c\u0455\u1d00\u0262\u1d07: /" + label + " <player>"));
                return true;
            }
            player = (Player)sender;
            boolean isStaff = PermissionUtils.has((Permissible)player, PERMISSION);
            String playerFlyPerm = this.plugin.getConfigManager().getConfig().getString("FLY-SYSTEM.PLAYER-FLY-PERMISSION", "MagicSMP.player.fly");
            boolean isPlayerFly = PermissionUtils.has((Permissible)player, playerFlyPerm);
            if (!isStaff && !isPlayerFly) {
                player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("STAFF.NO_PERMISSION_OTHERS", "&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274.")));
                return true;
            }
            if (!isStaff) {
                if (this.plugin.getCombatManager() != null && this.plugin.getCombatManager().isInCombat(player.getUniqueId())) {
                    player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("FLY.PLAYER_IN_COMBAT", "&cYou cannot fly while in combat.")));
                    return true;
                }
                boolean inSpawn = this.plugin.getSpawnManager().isInSpawnCuboid(player);
                if (!inSpawn) {
                    player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("FLY.PLAYER_RESTRICTED", "&cYou can only use flight in spawn.")));
                    return true;
                }
            }
            target = player;
        } else {
            if (sender instanceof Player && !PermissionUtils.has((Permissible)(player = (Player)sender), PERMISSION)) {
                player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("STAFF.NO_PERMISSION_OTHERS", "&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274.")));
                return true;
            }
            target = this.findOnlinePlayer(args[0]);
            if (target == null) {
                sender.sendMessage(ColorUtils.toComponent("&c\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u0274\u1d0f\u1d1b \u1d0f\u0274\u029f\u026a\u0274\u1d07."));
                return true;
            }
        }
        boolean enabled = this.toggleFlight(target);
        String path = enabled ? "FLY.ENABLED" : "FLY.DISABLED";
        String fallback = enabled ? "&aflight mode activated" : "&cflight mode deactivated";
        String targetMessage = this.plugin.getConfigManager().getMessageOrDefault(path, fallback);
        target.sendMessage(ColorUtils.toComponent(targetMessage, target));
        if (!(sender instanceof Player) || !(player = (Player)sender).getUniqueId().equals(target.getUniqueId())) {
            sender.sendMessage(ColorUtils.toComponent("&7\ua730\u029f\u026a\u0262\u029c\u1d1b \ua730\u1d0f\u0280 &e" + target.getName() + " &7\u1d21\u1d00\u0455 " + (enabled ? "&a\u1d07\u0274\u1d00\u0299\u029f\u1d07\u1d05" : "&c\u1d05\u026a\u0455\u1d00\u0299\u029f\u1d07\u1d05") + "&7."));
        }
        return true;
    }

    private boolean toggleFlight(Player target) {
        boolean nativeFlightMode;
        boolean currentlyEnabled = this.isFlightEnabled(target);
        boolean nextEnabled = !currentlyEnabled;
        GameMode gameMode = target.getGameMode();
        boolean bl = nativeFlightMode = gameMode == GameMode.CREATIVE || gameMode == GameMode.SPECTATOR;
        if (nextEnabled) {
            target.setAllowFlight(true);
            target.setFlying(true);
            return true;
        }
        target.setFlying(false);
        if (!nativeFlightMode) {
            target.setAllowFlight(false);
        }
        return false;
    }

    private boolean isFlightEnabled(Player target) {
        if (target == null) {
            return false;
        }
        GameMode gameMode = target.getGameMode();
        if (gameMode == GameMode.CREATIVE || gameMode == GameMode.SPECTATOR) {
            return target.isFlying();
        }
        return target.getAllowFlight() || target.isFlying();
    }

    private Player findOnlinePlayer(String input) {
        if (input == null || input.isBlank()) {
            return null;
        }
        Player exact = Bukkit.getPlayerExact((String)input);
        if (exact != null) {
            return exact;
        }
        String expected = input.toLowerCase(Locale.ROOT);
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (!player.getName().toLowerCase(Locale.ROOT).equals(expected)) continue;
            return player;
        }
        return null;
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<String>();
        if (!this.plugin.getFeatureManager().isEnabled(FeatureManager.Feature.FLY)) {
            return completions;
        }
        if (args.length == 1) {
            for (Player player : Bukkit.getOnlinePlayers()) {
                completions.add(player.getName());
            }
        }
        return completions;
    }
}

