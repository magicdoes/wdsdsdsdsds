/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.util.StringUtil
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.models.FollowEntry;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.util.StringUtil;

public class FriendsTabCompleter
implements TabCompleter {
    private final MagicSmp plugin;

    public FriendsTabCompleter(MagicSmp plugin) {
        this.plugin = plugin;
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!(sender instanceof Player)) {
            return Collections.emptyList();
        }
        Player player = (Player)sender;
        if (args.length == 1) {
            ArrayList<String> subcommands = new ArrayList<String>();
            subcommands.add("list");
            subcommands.add("follow");
            subcommands.add("unfollow");
            subcommands.add("search");
            subcommands.add("following");
            subcommands.add("followers");
            subcommands.add("friends");
            if (player.hasPermission("donutfriends.admin")) {
                subcommands.add("reload");
            }
            return this.partialMatches(args[0], subcommands);
        }
        if (args.length == 2) {
            String sub = args[0].toLowerCase();
            if (sub.equals("follow") || sub.equals("add")) {
                ArrayList<String> players = new ArrayList<String>();
                for (Player online : Bukkit.getOnlinePlayers()) {
                    if (online.getUniqueId().equals(player.getUniqueId())) continue;
                    players.add(online.getName());
                }
                return this.partialMatches(args[1], players);
            }
            if (sub.equals("unfollow") || sub.equals("remove")) {
                ArrayList<String> following = new ArrayList<String>();
                for (FollowEntry entry : this.plugin.getFriendsManager().getFollowing(player.getUniqueId())) {
                    following.add(entry.followedNameSnapshot());
                }
                return this.partialMatches(args[1], following);
            }
        }
        return Collections.emptyList();
    }

    private List<String> partialMatches(String token, List<String> completions) {
        ArrayList<String> matches = new ArrayList<String>();
        StringUtil.copyPartialMatches((String)token, completions, matches);
        matches.sort(String.CASE_INSENSITIVE_ORDER);
        return matches;
    }
}

