/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.permissions.Permissible
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.managers.CurrencyManager;
import com.bx.magicSmp.models.WorthResult;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.NumberUtils;
import com.bx.magicSmp.utils.PermissionUtils;
import com.bx.magicSmp.utils.PlayerSettingUtils;
import java.util.Arrays;
import me.xyr0.astralsmpcore.systems.sell.SellMenus;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.permissions.Permissible;

public class WorthCommand
implements CommandExecutor {
    private final MagicSmp plugin;

    public WorthCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        boolean pricesAlias = label.equalsIgnoreCase("prices");
        if (pricesAlias || args.length == 0) {
            this.openBrowser(sender);
            return true;
        }
        String subcommand = args[0].toLowerCase();
        if (subcommand.equals("browse") || subcommand.equals("prices")) {
            this.openBrowser(sender);
            return true;
        }
        if (subcommand.equals("reload")) {
            if (!PermissionUtils.has((Permissible)sender, "MagicSMP.admin.worth")) {
                this.sendMessage(sender, this.plugin.getConfigManager().getMessages().getString("WORTH.NO-ADMIN-PERMISSION", "&cyou do not have permission to reload worth settings."));
                return true;
            }
            this.plugin.getConfigManager().reloadWorth();
            this.plugin.getWorthManager().reload();
            this.sendMessage(sender, this.plugin.getConfigManager().getMessages().getString("WORTH.RELOADED", "&a\u1d21\u1d0f\u0280\u1d1b\u029c \u1d04\u1d0f\u0274\ua730\u026a\u0262 \u0280\u1d07\u029f\u1d0f\u1d00\u1d05\u1d07\u1d05."));
            return true;
        }
        if (subcommand.equals("hand") || subcommand.equals("held") || subcommand.equals("item") || subcommand.equals("check")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u1d0f\u0274\u029f\u028f.");
                return true;
            }
            Player player = (Player)sender;
            ItemStack item = player.getInventory().getItemInMainHand();
            if (item.getType().isAir()) {
                this.sendMessage(player, "&c\u029c\u1d0f\u029f\u1d05 \u1d00\u0274 \u026a\u1d1b\u1d07\u1d0d \u1d1b\u1d0f \u1d04\u029c\u1d07\u1d04\u1d0b \u026a\u1d1b\u0455 \u1d21\u1d0f\u0280\u1d1b\u029c.");
                return true;
            }
            this.sendWorthMessage(sender, item, item.getAmount());
            return true;
        }
        int amount = 1;
        int itemIndex = 0;
        try {
            int parsedAmount = Integer.parseInt(args[0]);
            if (parsedAmount > 0) {
                amount = parsedAmount;
                itemIndex = 1;
            }
        }
        catch (NumberFormatException parsedAmount) {
            // empty catch block
        }
        if (itemIndex >= args.length) {
            this.sendMessage(sender, this.plugin.getConfigManager().getMessages().getString("WORTH.USAGE", "&c\u1d1c\u0455\u1d00\u0262\u1d07: /\u1d21\u1d0f\u0280\u1d1b\u029c [\u1d00\u1d0d\u1d0f\u1d1c\u0274\u1d1b] <\u026a\u1d1b\u1d07\u1d0d> or /\u1d21\u1d0f\u0280\u1d1b\u029c \u029c\u1d00\u0274\u1d05"));
            return true;
        }
        String itemInput = String.join((CharSequence)" ", Arrays.copyOfRange(args, itemIndex, args.length));
        Material material = this.plugin.getWorthManager().findMaterial(itemInput);
        if (material == null || material.isAir()) {
            String msg = this.plugin.getConfigManager().getMessages().getString("WORTH.UNKNOWN-ITEM", "&c\u1d1c\u0274\u1d0b\u0274\u1d0f\u1d21\u0274 \u026a\u1d1b\u1d07\u1d0d: {item}").replace("{item}", itemInput);
            this.sendMessage(sender, msg);
            return true;
        }
        ItemStack item = new ItemStack(material, amount);
        this.sendWorthMessage(sender, item, amount);
        return true;
    }

    private void sendWorthMessage(CommandSender sender, ItemStack item, int displayAmount) {
        WorthResult worthResult = this.plugin.getWorthManager().resolveWorth(item);
        if (!worthResult.sellable()) {
            this.sendMessage(sender, this.plugin.getConfigManager().getMessage("WORTH.NO-SELLABLE"));
            return;
        }
        String name = this.plugin.getWorthManager().prettifyMaterial(item.getType());
        String msg = displayAmount == 1 ? this.plugin.getConfigManager().getMessage("WORTH.DEFAULT", "{item}", name, "{price}", NumberUtils.format(worthResult.totalWorth()), "{price_formatted}", this.plugin.getCurrencyManager().formatMoney(worthResult.totalWorth())) : this.plugin.getConfigManager().getMessage("WORTH.HAND-ITEM", "{amount}", String.valueOf(displayAmount), "{item}", name, "{total}", NumberUtils.format(worthResult.totalWorth()), "{total_formatted}", this.plugin.getCurrencyManager().formatMoney(worthResult.totalWorth()));
        this.sendMessage(sender, msg);
        if (worthResult.container() && worthResult.hasContainerContentsWorth()) {
            String breakdown = this.plugin.getConfigManager().getMessages().getString("WORTH.CONTAINER-BREAKDOWN", "&7base: &f{base_formatted} &8| &7contents: &f{contents_formatted}");
            breakdown = breakdown.replace("{base}", this.plugin.getCurrencyManager().formatCompactAmount(CurrencyManager.CurrencyType.MONEY, worthResult.baseWorth())).replace("{base_formatted}", this.plugin.getCurrencyManager().formatMoney(worthResult.baseWorth())).replace("{contents}", this.plugin.getCurrencyManager().formatCompactAmount(CurrencyManager.CurrencyType.MONEY, worthResult.containerContentsWorth())).replace("{contents_formatted}", this.plugin.getCurrencyManager().formatMoney(worthResult.containerContentsWorth()));
            this.sendMessage(sender, breakdown);
        }
    }

    private void sendMessage(CommandSender sender, String message) {
        if (sender instanceof Player) {
            Player player = (Player)sender;
            PlayerSettingUtils.sendActionBar(this.plugin, player, message);
        } else {
            sender.sendMessage(ColorUtils.toComponent(message));
        }
    }

    private void openBrowser(CommandSender sender) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u1d0f\u0274\u029f\u028f.");
            return;
        }
        Player player = (Player)sender;
        SellMenus.openWorth(player, 0);
    }
}

