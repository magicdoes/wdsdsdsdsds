/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.permissions.Permissible
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.PermissionUtils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.permissions.Permissible;

public class HelpopCommand
implements CommandExecutor {
    private static final String PERMISSION = "MagicSMP.helpop";
    private final MagicSmp plugin;

    public HelpopCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("HELPOP.PLAYER_ONLY", "&c\u1d0f\u0274\u029f\u028f \u1d18\u029f\u1d00\u028f\u1d07\u0280\u0455 \u1d04\u1d00\u0274 \u1d1c\u0455\u1d07 \u029c\u1d07\u029f\u1d18\u1d0f\u1d18.")));
            return true;
        }
        Player player = (Player)sender;
        if (!PermissionUtils.has((Permissible)player, PERMISSION)) {
            player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("HELPOP.NO_PERMISSION", "&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274 \u1d1b\u1d0f \u0280\u1d07\u01eb\u1d1c\u1d07\u0455\u1d1b \u0455\u1d1b\u1d00\ua730\ua730 \u1d00\u0455\u0455\u026a\u0455\u1d1b\u1d00\u0274\u1d04\u1d07.")));
            return true;
        }
        if (args.length == 0) {
            player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("HELPOP.USAGE", "&c\u1d1c\u0455\u1d00\u0262\u1d07: /helpop <message>")));
            return true;
        }
        this.plugin.getStaffAlertManager().sendHelpop(player, String.join((CharSequence)" ", args));
        return true;
    }
}

