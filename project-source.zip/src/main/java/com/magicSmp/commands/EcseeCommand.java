/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.utils.ColorUtils;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class EcseeCommand
implements CommandExecutor {
    private final MagicSmp plugin;

    public EcseeCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String targetName;
        UUID targetUuid;
        if (!(sender instanceof Player)) {
            sender.sendMessage(this.plugin.getEnderChestManager().getMessage("ECSEE-PLAYER-ONLY", "\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u1d0f\u0274\u029f\u028f."));
            return true;
        }
        Player viewer = (Player)sender;
        if (!this.plugin.getEnderChestManager().isInspectionEnabled()) {
            viewer.sendMessage(ColorUtils.toComponent(this.plugin.getEnderChestManager().getMessage("ECSEE-DISABLED", "&c\u1d1b\u029c\u1d07 /ecsee \u1d04\u1d0f\u1d0d\u1d0d\u1d00\u0274\u1d05 \u026a\u0455 \u1d05\u026a\u0455\u1d00\u0299\u029f\u1d07\u1d05.")));
            return true;
        }
        if (!this.plugin.getEnderChestManager().canInspect(viewer)) {
            viewer.sendMessage(ColorUtils.toComponent(this.plugin.getEnderChestManager().getMessage("ECSEE-NO-PERMISSION", "&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274 \u1d1b\u1d0f \u1d1c\u0455\u1d07 \u1d1b\u029c\u026a\u0455 \u1d04\u1d0f\u1d0d\u1d0d\u1d00\u0274\u1d05.")));
            return true;
        }
        if (args.length != 1) {
            viewer.sendMessage(ColorUtils.toComponent(this.plugin.getEnderChestManager().getMessage("ECSEE-USAGE", "&c\u1d1c\u0455\u1d00\u0262\u1d07: /ecsee <player>")));
            return true;
        }
        String input = args[0].trim();
        Player onlineTarget = this.findOnlineTarget(input);
        UUID uUID = targetUuid = onlineTarget == null ? this.plugin.getDatabaseManager().findPlayerUuidByUsername(input) : onlineTarget.getUniqueId();
        if (targetUuid == null) {
            viewer.sendMessage(ColorUtils.toComponent(this.plugin.getEnderChestManager().formatMessage("ECSEE-PLAYER-NOT-FOUND", "&c\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u0274\u1d0f\u1d1b \ua730\u1d0f\u1d1c\u0274\u1d05.", "{player}", input, "{target}", input)));
            return true;
        }
        String string = targetName = onlineTarget == null ? this.plugin.getDatabaseManager().getLastKnownUsername(targetUuid) : onlineTarget.getName();
        if (targetName == null || targetName.isBlank()) {
            targetName = input;
        }
        this.plugin.getEnderChestManager().openInspection(viewer, targetUuid, targetName);
        return true;
    }

    private Player findOnlineTarget(String username) {
        Player exact = Bukkit.getPlayerExact((String)username);
        if (exact != null) {
            return exact;
        }
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (!player.getName().equalsIgnoreCase(username)) continue;
            return player;
        }
        return null;
    }
}

