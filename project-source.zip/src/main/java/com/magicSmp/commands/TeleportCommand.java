/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Entity
 *  org.bukkit.permissions.Permissible
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.PermissionUtils;
import java.util.Locale;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.permissions.Permissible;

public class TeleportCommand
implements CommandExecutor {
    private static final String PERMISSION = "MagicSMP.staff.teleport";
    private final MagicSmp plugin;

    public TeleportCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ColorUtils.toComponent("&c\u1d0f\u0274\u029f\u028f \u1d18\u029f\u1d00\u028f\u1d07\u0280\u0455 \u1d04\u1d00\u0274 \u1d1c\u0455\u1d07 \u1d1b\u029c\u026a\u0455 \u1d04\u1d0f\u1d0d\u1d0d\u1d00\u0274\u1d05."));
            return true;
        }
        Player player = (Player)sender;
        if (!PermissionUtils.has((Permissible)player, PERMISSION)) {
            player.sendMessage(ColorUtils.toComponent("&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274."));
            return true;
        }
        String normalizedLabel = label.toLowerCase(Locale.ROOT);
        if ("tphere".equals(normalizedLabel)) {
            return this.handleTeleportHereAlias(player, args);
        }
        if ("tpall".equals(normalizedLabel)) {
            return this.handleTeleportAllAlias(player, args);
        }
        if (args.length == 0) {
            this.sendUsage(player, label);
            return true;
        }
        if (args.length == 1) {
            if (args[0].equalsIgnoreCase("all")) {
                this.teleportAll(player);
                return true;
            }
            if (args[0].equalsIgnoreCase("top")) {
                this.teleportTop(player);
                return true;
            }
            this.teleportToPlayer(player, args[0]);
            return true;
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("here")) {
            this.teleportHere(player, args[1]);
            return true;
        }
        if (args.length == 3 || args.length == 4) {
            this.teleportToPosition(player, args);
            return true;
        }
        this.sendUsage(player, label);
        return true;
    }

    private boolean handleTeleportHereAlias(Player player, String[] args) {
        if (args.length != 1) {
            player.sendMessage(ColorUtils.toComponent("&c\u1d1c\u0455\u1d00\u0262\u1d07: /tphere <player>"));
            return true;
        }
        this.teleportHere(player, args[0]);
        return true;
    }

    private boolean handleTeleportAllAlias(Player player, String[] args) {
        if (args.length != 0) {
            player.sendMessage(ColorUtils.toComponent("&c\u1d1c\u0455\u1d00\u0262\u1d07: /tpall"));
            return true;
        }
        this.teleportAll(player);
        return true;
    }

    private void teleportToPlayer(Player player, String input) {
        Player target = this.findOnlinePlayer(input);
        if (target == null) {
            player.sendMessage(ColorUtils.toComponent("&c\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u0274\u1d0f\u1d1b \u1d0f\u0274\u029f\u026a\u0274\u1d07."));
            return;
        }
        String targetName = target.getName();
        this.plugin.getSpigotScheduler().teleport((Entity)player, target.getLocation()).thenAccept(success -> this.plugin.getSpigotScheduler().runEntity((Entity)player, () -> {
            if (Boolean.TRUE.equals(success) && player.isOnline()) {
                player.sendMessage(ColorUtils.toComponent(this.message("TELEPORT.TO_PLAYER", "&d\u1d1b\u1d07\u029f\u1d07\u1d18\u1d0f\u0280\u1d1b\u1d07\u1d05 &7\u1d1b\u1d0f %player%").replace("%player%", targetName), player));
            }
        }));
    }

    private void teleportHere(Player player, String input) {
        Player target = this.findOnlinePlayer(input);
        if (target == null) {
            player.sendMessage(ColorUtils.toComponent("&c\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u0274\u1d0f\u1d1b \u1d0f\u0274\u029f\u026a\u0274\u1d07."));
            return;
        }
        if (player.getUniqueId().equals(target.getUniqueId())) {
            player.sendMessage(ColorUtils.toComponent("&c\u028f\u1d0f\u1d1c \u1d04\u1d00\u0274\u0274\u1d0f\u1d1b \u1d1b\u1d07\u029f\u1d07\u1d18\u1d0f\u0280\u1d1b \u028f\u1d0f\u1d1c\u0280\u0455\u1d07\u029f\ua730 \u1d1b\u1d0f \u028f\u1d0f\u1d1c\u0280\u0455\u1d07\u029f\ua730."));
            return;
        }
        Location destination = player.getLocation();
        String targetName = target.getName();
        String senderName = player.getName();
        this.plugin.getSpigotScheduler().teleport((Entity)target, destination).thenAccept(success -> {
            if (!Boolean.TRUE.equals(success)) {
                return;
            }
            this.plugin.getSpigotScheduler().runEntity((Entity)player, () -> {
                if (player.isOnline()) {
                    player.sendMessage(ColorUtils.toComponent(this.message("TELEPORT.HERE", "&d\u1d1b\u1d07\u029f\u1d07\u1d18\u1d0f\u0280\u1d1b\u1d07\u1d05 &7%player% \u1d1b\u1d0f \u028f\u1d0f\u1d1c\u0280 \u029f\u1d0f\u1d04\u1d00\u1d1b\u026a\u1d0f\u0274").replace("%player%", targetName), player));
                }
            });
            this.plugin.getSpigotScheduler().runEntity((Entity)target, () -> {
                if (target.isOnline()) {
                    target.sendMessage(ColorUtils.toComponent(this.message("TELEPORT.HERE_TARGET", "&d\u028f\u1d0f\u1d1c \u1d21\u1d07\u0280\u1d07 \u1d1b\u1d07\u029f\u1d07\u1d18\u1d0f\u0280\u1d1b\u1d07\u1d05 \u1d1b\u1d0f &7%sender%").replace("%sender%", senderName), target));
                }
            });
        });
    }

    private void teleportAll(Player player) {
        int moved = 0;
        for (Player target : Bukkit.getOnlinePlayers()) {
            if (player.getUniqueId().equals(target.getUniqueId())) continue;
            String senderName = player.getName();
            Location destination = player.getLocation();
            this.plugin.getSpigotScheduler().teleport((Entity)target, destination).thenAccept(success -> this.plugin.getSpigotScheduler().runEntity((Entity)target, () -> {
                if (Boolean.TRUE.equals(success) && target.isOnline()) {
                    target.sendMessage(ColorUtils.toComponent(this.message("TELEPORT.ALL_TARGET", "&d\u028f\u1d0f\u1d1c \u1d21\u1d07\u0280\u1d07 \u1d1b\u1d07\u029f\u1d07\u1d18\u1d0f\u0280\u1d1b\u1d07\u1d05 \u1d1b\u1d0f &7%sender%").replace("%sender%", senderName), target));
                }
            }));
            ++moved;
        }
        if (moved == 0) {
            player.sendMessage(ColorUtils.toComponent("&c\u0274\u1d0f \u1d0f\u1d1b\u029c\u1d07\u0280 \u1d18\u029f\u1d00\u028f\u1d07\u0280\u0455 \u1d0f\u0274\u029f\u026a\u0274\u1d07."));
            return;
        }
        player.sendMessage(ColorUtils.toComponent(this.message("TELEPORT.ALL", "&d\u1d1b\u1d07\u029f\u1d07\u1d18\u1d0f\u0280\u1d1b\u1d07\u1d05 &7\u1d00\u029f\u029f \u1d18\u029f\u1d00\u028f\u1d07\u0280\u0455 \u1d1b\u1d0f \u028f\u1d0f\u1d1c\u0280 \u029f\u1d0f\u1d04\u1d00\u1d1b\u026a\u1d0f\u0274"), player));
    }

    private void teleportTop(Player player) {
        Object current = player.getLocation().clone();
        int highestY = ((Location)current).getWorld().getHighestBlockYAt((Location)current) + 1;
        current.setY((double)highestY);
        this.plugin.getSpigotScheduler().teleport((Entity)player, (Location)current).thenAccept(success -> this.plugin.getSpigotScheduler().runEntity((Entity)player, () -> {
            if (Boolean.TRUE.equals(success) && player.isOnline()) {
                player.sendMessage(ColorUtils.toComponent(this.message("TELEPORT.TOP", "&d\u1d1b\u1d07\u029f\u1d07\u1d18\u1d0f\u0280\u1d1b\u1d07\u1d05 &7\u1d1b\u1d0f \u1d1b\u029c\u1d07 \u029c\u026a\u0262\u029c\u1d07\u0455\u1d1b \u1d18\u1d0f\u0455\u026a\u1d1b\u026a\u1d0f\u0274"), player));
            }
        }));
    }

    private void teleportToPosition(Player player, String[] args) {
        Double x = this.parseCoordinate(args[0]);
        Double y = this.parseCoordinate(args[1]);
        Double z = this.parseCoordinate(args[2]);
        if (x == null || y == null || z == null) {
            player.sendMessage(ColorUtils.toComponent("&c\u1d04\u1d0f\u1d0f\u0280\u1d05\u026a\u0274\u1d00\u1d1b\u1d07\u0455 \u1d0d\u1d1c\u0455\u1d1b \u0299\u1d07 \u1d20\u1d00\u029f\u026a\u1d05 \u0274\u1d1c\u1d0d\u0299\u1d07\u0280\u0455."));
            return;
        }
        World world = player.getWorld();
        if (args.length == 4 && (world = Bukkit.getWorld((String)args[3])) == null) {
            player.sendMessage(ColorUtils.toComponent("&c\u1d21\u1d0f\u0280\u029f\u1d05 \u0274\u1d0f\u1d1b \ua730\u1d0f\u1d1c\u0274\u1d05."));
            return;
        }
        Location destination = new Location(world, x.doubleValue(), y.doubleValue(), z.doubleValue(), player.getLocation().getYaw(), player.getLocation().getPitch());
        World destinationWorld = world;
        this.plugin.getSpigotScheduler().teleport((Entity)player, destination).thenAccept(success -> this.plugin.getSpigotScheduler().runEntity((Entity)player, () -> {
            if (Boolean.TRUE.equals(success) && player.isOnline()) {
                player.sendMessage(ColorUtils.toComponent(this.message("TELEPORT.POSITION", "&7\u1d1b\u1d07\u029f\u1d07\u1d18\u1d0f\u0280\u1d1b\u1d07\u1d05 \u1d1b\u1d0f: &d%x%,%y%,%z% &7(%world%)").replace("%x%", this.formatCoordinate(x)).replace("%y%", this.formatCoordinate(y)).replace("%z%", this.formatCoordinate(z)).replace("%world%", destinationWorld.getName()), player));
            }
        }));
    }

    private void sendUsage(Player player, String label) {
        player.sendMessage(ColorUtils.toComponent("&c\u1d1c\u0455\u1d00\u0262\u1d07: /" + label + " <player|here <player>|\u1d00\u029f\u029f|\u1d1b\u1d0f\u1d18|x \u028f \u1d22 [\u1d21\u1d0f\u0280\u029f\u1d05]>"));
    }

    private String message(String path, String fallback) {
        return this.plugin.getConfigManager().getMessageOrDefault(path, fallback);
    }

    private Player findOnlinePlayer(String input) {
        if (input == null || input.isBlank()) {
            return null;
        }
        Player exact = Bukkit.getPlayerExact((String)input);
        if (exact != null) {
            return exact;
        }
        String expected = input.toLowerCase(Locale.ROOT);
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (!player.getName().toLowerCase(Locale.ROOT).equals(expected)) continue;
            return player;
        }
        return null;
    }

    private Double parseCoordinate(String input) {
        try {
            return Double.parseDouble(input);
        }
        catch (NumberFormatException exception) {
            return null;
        }
    }

    private String formatCoordinate(double value) {
        if (Math.rint(value) == value) {
            return String.valueOf((long)value);
        }
        return String.format(Locale.US, "%.2f", value).replaceAll("0+$", "").replaceAll("\\.$", "");
    }
}

