/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.entity.Entity
 *  org.bukkit.permissions.Permissible
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.managers.AuctionHouseManager;
import com.bx.magicSmp.menus.AuctionHouseBrowseMenu;
import com.bx.magicSmp.menus.PlayerAuctionGui;
import com.bx.magicSmp.menus.SellGui;
import com.bx.magicSmp.models.AuctionCategory;
import com.bx.magicSmp.models.PlayerPreference;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.NumberUtils;
import com.bx.magicSmp.utils.PermissionUtils;
import com.bx.magicSmp.utils.SoundUtils;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.permissions.Permissible;

public final class AuctionHouseCommand
implements CommandExecutor,
TabCompleter {
    private final MagicSmp plugin;

    public AuctionHouseCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String subcommand;
        if (!(sender instanceof Player)) {
            sender.sendMessage(this.plugin.getLanguageManager().message("AUCTION_HOUSE.PLAYERS_ONLY", "\u1d0f\u0274\u029f\u028f \u1d18\u029f\u1d00\u028f\u1d07\u0280\u0455 \u1d04\u1d00\u0274 \u1d1c\u0455\u1d07 \u1d1b\u029c\u026a\u0455 \u1d04\u1d0f\u1d0d\u1d0d\u1d00\u0274\u1d05.", new String[0]));
            return true;
        }
        Player player = (Player)sender;
        AuctionHouseManager manager = this.plugin.getAuctionHouseManager();
        String string = subcommand = args.length == 0 ? "" : args[0].toLowerCase(Locale.ROOT);
        if (!(args.length == 0 || "sell".equals(subcommand) || "my".equals(subcommand) || "claims".equals(subcommand) || "cancel".equals(subcommand) || "limit".equals(subcommand) || "fastbuy".equals(subcommand) || "fastsell".equals(subcommand) || "reload".equals(subcommand))) {
            manager.setSearchQuery(player.getUniqueId(), String.join((CharSequence)" ", args));
            this.openBrowse(player);
            return true;
        }
        if ("reload".equals(subcommand)) {
            this.handleReload(player);
            return true;
        }
        if (!manager.isEnabled()) {
            this.send(player, "AUCTION_HOUSE.DISABLED", "&c\u1d00\u1d1c\u1d04\u1d1b\u026a\u1d0f\u0274 \u029c\u1d0f\u1d1c\u0455\u1d07 \u026a\u0455 \u1d04\u1d1c\u0280\u0280\u1d07\u0274\u1d1b\u029f\u028f \u1d05\u026a\u0455\u1d00\u0299\u029f\u1d07\u1d05.");
            return true;
        }
        switch (subcommand) {
            case "": {
                if (!this.requirePermission(player, "use")) break;
                this.openBrowse(player);
                break;
            }
            case "sell": {
                if (!this.requirePermission(player, "sell")) break;
                this.handleSell(player, args);
                break;
            }
            case "my": {
                if (!this.requirePermission(player, "my")) break;
                this.openPlayerItems(player);
                break;
            }
            case "claims": {
                if (!this.requirePermission(player, "claims")) {
                    return true;
                }
                if (!manager.isClaimsEnabled()) {
                    manager.processAutoClaims(player);
                    this.send(player, "AUCTION_HOUSE.CLAIMS_AUTOMATIC", "&e\u1d04\u029f\u1d00\u026a\u1d0d\u0455 \u1d00\u0280\u1d07 \u1d04\u1d0f\u029f\u029f\u1d07\u1d04\u1d1b\u1d07\u1d05 \u1d00\u1d1c\u1d1b\u1d0f\u1d0d\u1d00\u1d1b\u026a\u1d04\u1d00\u029f\u029f\u028f.");
                    break;
                }
                this.openPlayerItems(player);
                break;
            }
            case "cancel": {
                if (!this.requirePermission(player, "cancel")) break;
                this.handleCancel(player, args);
                break;
            }
            case "limit": {
                if (!this.requirePermission(player, "limit")) break;
                this.handleLimit(player);
                break;
            }
            case "fastbuy": {
                this.togglePreference(player, true);
                break;
            }
            case "fastsell": {
                this.togglePreference(player, false);
                break;
            }
            default: {
                if (!this.requirePermission(player, "use")) break;
                this.openBrowse(player);
            }
        }
        return true;
    }

    private void handleReload(Player player) {
        if (!PermissionUtils.has((Permissible)player, "MagicSmp.admin.auctionhouse")) {
            this.send(player, "AUCTION_HOUSE.NO_ADMIN_PERMISSION", "&c\u028f\u1d0f\u1d1c \u1d04\u1d00\u0274\u0274\u1d0f\u1d1b \u0280\u1d07\u029f\u1d0f\u1d00\u1d05 \u1d00\u1d1c\u1d04\u1d1b\u026a\u1d0f\u0274 \u029c\u1d0f\u1d1c\u0455\u1d07 \u0455\u1d07\u1d1b\u1d1b\u026a\u0274\u0262\u0455.");
            return;
        }
        this.plugin.getConfigManager().reloadAuctionHouse();
        this.plugin.getAuctionHouseManager().reload();
        this.send(player, "AUCTION_HOUSE.RELOADED", "&a\u1d00\u1d1c\u1d04\u1d1b\u026a\u1d0f\u0274 \u029c\u1d0f\u1d1c\u0455\u1d07 \u0455\u1d07\u1d1b\u1d1b\u026a\u0274\u0262\u0455 \u0280\u1d07\u029f\u1d0f\u1d00\u1d05\u1d07\u1d05.");
    }

    private void handleSell(Player player, String[] args) {
        double price;
        if (args.length < 2) {
            this.send(player, "AUCTION_HOUSE.SELL_USAGE", "&c\u1d1c\u0455\u1d00\u0262\u1d07: /ah \u0455\u1d07\u029f\u029f <price>");
            return;
        }
        try {
            price = NumberUtils.parse(args[1]);
        }
        catch (NumberFormatException exception) {
            this.send(player, "AUCTION_HOUSE.INVALID_PRICE", "&c\u026a\u0274\u1d20\u1d00\u029f\u026a\u1d05 \u1d18\u0280\u026a\u1d04\u1d07.");
            return;
        }
        ItemStack hand = player.getInventory().getItemInMainHand();
        if (hand == null || hand.getType().isAir()) {
            this.send(player, "AUCTION_HOUSE.NO_ITEM_IN_HAND", "&c\u029c\u1d0f\u029f\u1d05 \u1d1b\u029c\u1d07 \u026a\u1d1b\u1d07\u1d0d \u028f\u1d0f\u1d1c \u1d21\u1d00\u0274\u1d1b \u1d1b\u1d0f \u029f\u026a\u0455\u1d1b.");
            return;
        }
        AuctionHouseManager manager = this.plugin.getAuctionHouseManager();
        Object escrow = hand.clone();
        player.getInventory().setItemInMainHand(new ItemStack(Material.AIR));
        player.updateInventory();
        manager.getPreferenceAsync(player.getUniqueId()).whenComplete((arg_0, arg_1) -> this.lambda$handleSell$3(player, manager, (ItemStack)escrow, price, arg_0, arg_1));
    }

    private void handleCreateResult(Player player, PlayerPreference preference, double price, AuctionHouseManager.CreateListingResult result) {
        if (!result.success()) {
            player.sendMessage(ColorUtils.toComponent(this.resolveCreateFailure(result)));
            SoundUtils.play(player, this.plugin.getConfigManager().getSound("AUCTION_HOUSE.FAIL"));
            return;
        }
        preference.lastPrice(price);
        this.plugin.getAuctionHouseManager().savePreference(preference);
        player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessage("AUCTION_HOUSE.LISTING_CREATED", "{listing_id}", String.valueOf(result.listing().id()), "{item}", this.plugin.getAuctionHouseManager().describeItem(result.listing().item()), "{price}", NumberUtils.format(result.listing().price()), "{price_formatted}", this.plugin.getCurrencyManager().formatMoney(result.listing().price()), "{fee}", NumberUtils.format(result.listingFee()), "{fee_formatted}", this.plugin.getCurrencyManager().formatMoney(result.listingFee()), "{expires}", this.plugin.getAuctionHouseManager().formatRemaining(result.listing().secondsRemaining(System.currentTimeMillis())))));
        SoundUtils.play(player, this.plugin.getConfigManager().getSound("AUCTION_HOUSE.SUCCESS"));
        this.openPlayerItems(player);
    }

    private void handleCancel(Player player, String[] args) {
        long listingId;
        if (args.length < 2) {
            this.send(player, "AUCTION_HOUSE.CANCEL_USAGE", "&c\u1d1c\u0455\u1d00\u0262\u1d07: /ah \u1d04\u1d00\u0274\u1d04\u1d07\u029f <listingId>");
            return;
        }
        try {
            listingId = Long.parseLong(args[1]);
        }
        catch (NumberFormatException exception) {
            this.send(player, "AUCTION_HOUSE.INVALID_LISTING_ID", "&c\u026a\u0274\u1d20\u1d00\u029f\u026a\u1d05 \u029f\u026a\u0455\u1d1b\u026a\u0274\u0262 \u026a\u1d05.");
            return;
        }
        this.plugin.getAuctionHouseManager().cancelListing(player, listingId).thenAccept(result -> this.plugin.getSpigotScheduler().runEntity((Entity)player, () -> {
            if (!result.success()) {
                String key = switch (result.reason()) {
                    default -> throw new MatchException(null, null);
                    case AuctionHouseManager.CancelFailureReason.DISABLED -> "AUCTION_HOUSE.DISABLED";
                    case AuctionHouseManager.CancelFailureReason.NO_PERMISSION -> "AUCTION_HOUSE.NO_PERMISSION";
                    case AuctionHouseManager.CancelFailureReason.LISTING_NOT_FOUND -> "AUCTION_HOUSE.LISTING_NOT_FOUND";
                    case AuctionHouseManager.CancelFailureReason.NOT_OWNER -> "AUCTION_HOUSE.NOT_YOUR_LISTING";
                    case AuctionHouseManager.CancelFailureReason.NOT_ACTIVE -> "AUCTION_HOUSE.LISTING_NOT_ACTIVE";
                    case AuctionHouseManager.CancelFailureReason.DATABASE_ERROR -> "AUCTION_HOUSE.CANCEL_DATABASE_ERROR";
                };
                this.send(player, key, "&c\u1d1b\u029c\u1d07 \u029f\u026a\u0455\u1d1b\u026a\u0274\u0262 \u1d04\u1d0f\u1d1c\u029f\u1d05 \u0274\u1d0f\u1d1b \u0299\u1d07 \u1d04\u1d00\u0274\u1d04\u1d07\u029f\u029f\u1d07\u1d05.");
                return;
            }
            player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessage("AUCTION_HOUSE.LISTING_CANCELLED", "{listing_id}", String.valueOf(result.listing().id()), "{item}", this.plugin.getAuctionHouseManager().describeItem(result.listing().item()))));
            this.openPlayerItems(player);
        }));
    }

    private void handleLimit(Player player) {
        int active = this.plugin.getAuctionHouseManager().countActiveListings(player.getUniqueId());
        int limit = this.plugin.getAuctionHouseManager().getMaxActiveListings(player);
        String displayLimit = limit == Integer.MAX_VALUE ? this.plugin.getAuctionHouseManager().getText("UNLIMITED", "\u1d1c\u0274\u029f\u026a\u1d0d\u026a\u1d1b\u1d07\u1d05") : String.valueOf(limit);
        player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("AUCTION_HOUSE.LIMIT", "&6\u029f\u026a\u0455\u1d1b\u026a\u0274\u0262 \u029f\u026a\u1d0d\u026a\u1d1b: &e{active}&7/&e{limit}", "{active}", String.valueOf(active), "{limit}", displayLimit)));
    }

    private void togglePreference(Player player, boolean fastBuy) {
        String permission;
        String string = permission = fastBuy ? "fastbuy" : "fastsell";
        if (!this.canUse(player, permission)) {
            this.send(player, "AUCTION_HOUSE.NO_FAST_PERMISSION", "&c\u028f\u1d0f\u1d1c \u1d04\u1d00\u0274\u0274\u1d0f\u1d1b \u1d1c\u0455\u1d07 \u1d1b\u029c\u1d00\u1d1b \ua730\u1d00\u0455\u1d1b-\u1d00\u1d04\u1d1b\u026a\u1d0f\u0274 \u0455\u1d07\u1d1b\u1d1b\u026a\u0274\u0262.");
            return;
        }
        this.plugin.getAuctionHouseManager().getPreferenceAsync(player.getUniqueId()).thenAccept(preference -> {
            boolean enabled;
            if (fastBuy) {
                preference.fastBuyEnabled(!preference.fastBuyEnabled());
                enabled = preference.fastBuyEnabled();
            } else {
                preference.fastSellEnabled(!preference.fastSellEnabled());
                enabled = preference.fastSellEnabled();
            }
            this.plugin.getAuctionHouseManager().savePreference((PlayerPreference)preference);
            boolean finalEnabled = enabled;
            this.plugin.getSpigotScheduler().runEntity((Entity)player, () -> player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault(fastBuy ? "AUCTION_HOUSE.FAST_BUY_TOGGLED" : "AUCTION_HOUSE.FAST_SELL_TOGGLED", "&6&l\u1d00\u1d1c\u1d04\u1d1b\u026a\u1d0f\u0274\u029c\u1d0f\u1d1c\u0455\u1d07 &8\u00bb &e{setting} \u026a\u0455 \u0274\u1d0f\u1d21 {state}&e.", "{setting}", fastBuy ? this.plugin.getAuctionHouseManager().getText("FAST_BUY", "\ua730\u1d00\u0455\u1d1b \u0299\u1d1c\u028f") : this.plugin.getAuctionHouseManager().getText("FAST_SELL", "\ua730\u1d00\u0455\u1d1b \u0455\u1d07\u029f\u029f"), "{state}", finalEnabled ? this.plugin.getAuctionHouseManager().getText("ENABLED", "&a\u1d07\u0274\u1d00\u0299\u029f\u1d07\u1d05") : this.plugin.getAuctionHouseManager().getText("DISABLED", "&c\u1d05\u026a\u0455\u1d00\u0299\u029f\u1d07\u1d05")))));
        });
    }

    private void openBrowse(Player player) {
        ItemStack hand;
        this.plugin.getAuctionHouseManager().processAutoClaims(player);
        String category = "ALL";
        boolean autoFilter = this.plugin.getConfigManager().getAuctionHouse().getBoolean("SETTINGS.AUTO_FILTER_BY_HAND", false);
        if (autoFilter && (hand = player.getInventory().getItemInMainHand()) != null && hand.getType() != Material.AIR) {
            category = AuctionCategory.findCategoryForItem(hand).name();
        }
        new AuctionHouseBrowseMenu(this.plugin, 1, this.plugin.getAuctionHouseManager().getDefaultSort(), category).open(player);
    }

    private void openPlayerItems(Player player) {
        this.plugin.getAuctionHouseManager().processAutoClaims(player);
        new PlayerAuctionGui(this.plugin, 1).open(player);
    }

    private boolean hasEither(Player player, String first, String second) {
        return PermissionUtils.has((Permissible)player, first) || PermissionUtils.has((Permissible)player, second);
    }

    private boolean requirePermission(Player player, String action) {
        if (this.canUse(player, action)) {
            return true;
        }
        this.send(player, "AUCTION_HOUSE.NO_PERMISSION", "&c\u028f\u1d0f\u1d1c \u1d04\u1d00\u0274\u0274\u1d0f\u1d1b \u1d1c\u0455\u1d07 \u1d1b\u029c\u1d00\u1d1b \u1d00\u1d1c\u1d04\u1d1b\u026a\u1d0f\u0274 \u029c\u1d0f\u1d1c\u0455\u1d07 \u1d00\u1d04\u1d1b\u026a\u1d0f\u0274.");
        return false;
    }

    private boolean canUse(Player player, String action) {
        return this.hasEither(player, "MagicSmp.auctionhouse." + action, "donutauction." + action) || PermissionUtils.has((Permissible)player, "MagicSmp.admin.auctionhouse");
    }

    private void send(Player player, String key, String fallback) {
        player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessage(key, fallback)));
    }

    private String resolveCreateFailure(AuctionHouseManager.CreateListingResult result) {
        return switch (result.reason()) {
            default -> throw new MatchException(null, null);
            case AuctionHouseManager.CreateFailureReason.DISABLED -> this.plugin.getConfigManager().getMessage("AUCTION_HOUSE.DISABLED");
            case AuctionHouseManager.CreateFailureReason.NO_PERMISSION -> this.plugin.getConfigManager().getMessage("AUCTION_HOUSE.NO_PERMISSION");
            case AuctionHouseManager.CreateFailureReason.NO_PLAYER_DATA -> this.plugin.getLanguageManager().message("AUCTION_HOUSE.PLAYER_DATA_UNAVAILABLE", "&c\u028f\u1d0f\u1d1c\u0280 \u1d18\u029f\u1d00\u028f\u1d07\u0280 \u1d05\u1d00\u1d1b\u1d00 \u1d04\u1d0f\u1d1c\u029f\u1d05 \u0274\u1d0f\u1d1b \u0299\u1d07 \u029f\u1d0f\u1d00\u1d05\u1d07\u1d05.", new String[0]);
            case AuctionHouseManager.CreateFailureReason.NO_ITEM -> this.plugin.getConfigManager().getMessage("AUCTION_HOUSE.NO_ITEM_IN_HAND");
            case AuctionHouseManager.CreateFailureReason.INVALID_ITEM -> this.plugin.getConfigManager().getMessage("AUCTION_HOUSE.ITEM_BLOCKED");
            case AuctionHouseManager.CreateFailureReason.UNSAFE_ITEM -> this.plugin.getConfigManager().getMessageOrDefault("CRASH_PROTECTION.ITEM_BLOCKED", "&c\u1d1b\u029c\u1d00\u1d1b \u026a\u1d1b\u1d07\u1d0d \u1d04\u1d00\u0274\u0274\u1d0f\u1d1b \u0299\u1d07 \u1d1c\u0455\u1d07\u1d05 \u029c\u1d07\u0280\u1d07. &7\u0280\u1d07\u1d00\u0455\u1d0f\u0274: &f{reason}", "{context}", "\u1d00\u1d1c\u1d04\u1d1b\u026a\u1d0f\u0274 \u029c\u1d0f\u1d1c\u0455\u1d07", "{reason}", result.safetyResult() == null ? "\u1d1c\u0274\u0455\u1d00\ua730\u1d07 \u026a\u1d1b\u1d07\u1d0d \u1d05\u1d00\u1d1b\u1d00" : result.safetyResult().reason());
            case AuctionHouseManager.CreateFailureReason.INVALID_PRICE -> this.plugin.getConfigManager().getMessage("AUCTION_HOUSE.PRICE_OUT_OF_RANGE");
            case AuctionHouseManager.CreateFailureReason.INVALID_DURATION -> this.plugin.getConfigManager().getMessageOrDefault("AUCTION_HOUSE.INVALID_DURATION", "&c\u1d1b\u029c\u1d00\u1d1b \u029f\u026a\u0455\u1d1b\u026a\u0274\u0262 \u1d05\u1d1c\u0280\u1d00\u1d1b\u026a\u1d0f\u0274 \u026a\u0455 \u0274\u1d0f\u1d1b \u1d00\u029f\u029f\u1d0f\u1d21\u1d07\u1d05.");
            case AuctionHouseManager.CreateFailureReason.NO_MONEY -> this.plugin.getConfigManager().getMessage("AUCTION_HOUSE.NO_MONEY_FOR_FEE", "{fee}", NumberUtils.format(result.listingFee()), "{fee_formatted}", this.plugin.getCurrencyManager().formatMoney(result.listingFee()));
            case AuctionHouseManager.CreateFailureReason.MAX_LISTINGS_REACHED -> this.plugin.getConfigManager().getMessage("AUCTION_HOUSE.MAX_LISTINGS_REACHED");
            case AuctionHouseManager.CreateFailureReason.DATABASE_ERROR -> this.plugin.getLanguageManager().message("AUCTION_HOUSE.CREATE_DATABASE_ERROR", "&c\u1d00\u1d1c\u1d04\u1d1b\u026a\u1d0f\u0274 \u029c\u1d0f\u1d1c\u0455\u1d07 \u1d04\u1d0f\u1d1c\u029f\u1d05 \u0274\u1d0f\u1d1b \u0455\u1d00\u1d20\u1d07 \u028f\u1d0f\u1d1c\u0280 \u029f\u026a\u0455\u1d1b\u026a\u0274\u0262.", new String[0]);
        };
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        Player player;
        block12: {
            block11: {
                if (!(sender instanceof Player)) break block11;
                player = (Player)sender;
                if (args.length == 1) break block12;
            }
            return List.of();
        }
        ArrayList<String> values = new ArrayList<String>();
        if (this.canUse(player, "sell")) {
            values.add("sell");
        }
        if (this.canUse(player, "my")) {
            values.add("my");
        }
        if (this.canUse(player, "limit")) {
            values.add("limit");
        }
        if (this.canUse(player, "fastbuy")) {
            values.add("fastbuy");
        }
        if (this.canUse(player, "fastsell")) {
            values.add("fastsell");
        }
        if (this.plugin.getAuctionHouseManager().isClaimsEnabled() && this.canUse(player, "claims")) {
            values.add("claims");
        }
        if (this.canUse(player, "cancel")) {
            values.add("cancel");
        }
        if (PermissionUtils.has((Permissible)player, "MagicSmp.admin.auctionhouse")) {
            values.add("reload");
        }
        String prefix = args[0].toLowerCase(Locale.ROOT);
        return values.stream().filter(value -> value.startsWith(prefix)).toList();
    }

    private /* synthetic */ void lambda$handleSell$3(Player player, AuctionHouseManager manager, ItemStack escrow, double price, PlayerPreference preference, Throwable throwable) {
        if (!player.isOnline()) {
            manager.returnEscrow(player, escrow);
            return;
        }
        this.plugin.getSpigotScheduler().runEntity((Entity)player, () -> {
            boolean fastSell;
            if (throwable != null || preference == null) {
                manager.returnEscrow(player, escrow);
                this.send(player, "AUCTION_HOUSE.CREATE_DATABASE_ERROR", "&c\u1d00\u1d1c\u1d04\u1d1b\u026a\u1d0f\u0274 \u029c\u1d0f\u1d1c\u0455\u1d07 \u1d04\u1d0f\u1d1c\u029f\u1d05 \u0274\u1d0f\u1d1b \u029f\u1d0f\u1d00\u1d05 \u028f\u1d0f\u1d1c\u0280 \u029f\u026a\u0455\u1d1b\u026a\u0274\u0262 \u0455\u1d07\u1d1b\u1d1b\u026a\u0274\u0262\u0455.");
                return;
            }
            boolean bl = fastSell = preference.fastSellEnabled() && this.hasEither(player, "MagicSmp.auctionhouse.fastsell", "donutauction.fastsell");
            if (fastSell) {
                boolean autoDetect = this.plugin.getConfigManager().getAuctionHouse().getBoolean("SETTINGS.AUTO_DETECT_CATEGORY", false);
                AuctionCategory category = autoDetect ? AuctionCategory.findCategoryForItem(escrow) : AuctionCategory.from(preference.lastCategory());
                manager.createListingFromItem(player, escrow, price, preference.lastDurationHours(), category).thenAccept(result -> this.plugin.getSpigotScheduler().runEntity((Entity)player, () -> this.handleCreateResult(player, preference, price, (AuctionHouseManager.CreateListingResult)result)));
                return;
            }
            new SellGui(this.plugin, escrow, price, preference).open(player);
        });
    }
}

