/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.permissions.Permissible
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.menus.FriendsMenu;
import com.bx.magicSmp.models.FollowEntry;
import com.bx.magicSmp.models.PlayerData;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.PermissionUtils;
import com.bx.magicSmp.utils.PlayerLookup;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.permissions.Permissible;

public class FriendsCommand
implements CommandExecutor {
    private static final String PERMISSION = "MagicSMP.friends";
    private static final String COMMAND_PERMISSION = "MagicSMP.command.friends";
    private static final String FRIEND_COMMAND_PERMISSION = "MagicSMP.command.friend";
    private static final String ADMIN_PERMISSION = "donutfriends.admin";
    private final MagicSmp plugin;

    public FriendsCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String sub;
        if (!(sender instanceof Player)) {
            if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
                if (sender.hasPermission(ADMIN_PERMISSION)) {
                    this.plugin.getConfigManager().reload();
                    sender.sendMessage(ColorUtils.colorize(this.plugin.getConfigManager().getMessage("FRIENDS.RELOAD_SUCCESS")));
                } else {
                    sender.sendMessage(ColorUtils.colorize(this.plugin.getConfigManager().getMessage("FRIENDS.NO_PERMISSION")));
                }
                return true;
            }
            sender.sendMessage(ColorUtils.colorize(this.plugin.getConfigManager().getMessage("FRIENDS.PLAYER_ONLY")));
            return true;
        }
        Player player = (Player)sender;
        if (!(PermissionUtils.has((Permissible)player, PERMISSION) || PermissionUtils.has((Permissible)player, COMMAND_PERMISSION) || PermissionUtils.has((Permissible)player, FRIEND_COMMAND_PERMISSION))) {
            player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessage("FRIENDS.NO_PERMISSION"), player));
            return true;
        }
        if (args.length == 0) {
            new FriendsMenu(this.plugin).open(player);
            return true;
        }
        switch (sub = args[0].toLowerCase()) {
            case "reload": {
                if (PermissionUtils.has((Permissible)player, ADMIN_PERMISSION)) {
                    this.plugin.getConfigManager().reload();
                    player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessage("FRIENDS.RELOAD_SUCCESS"), player));
                    break;
                }
                player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessage("FRIENDS.NO_PERMISSION"), player));
                break;
            }
            case "list": {
                new FriendsMenu(this.plugin, 0, null, FriendsMenu.FilterType.ALL).open(player);
                break;
            }
            case "following": {
                new FriendsMenu(this.plugin, 0, null, FriendsMenu.FilterType.FOLLOWING).open(player);
                break;
            }
            case "followers": {
                new FriendsMenu(this.plugin, 0, null, FriendsMenu.FilterType.FOLLOWERS).open(player);
                break;
            }
            case "friends": {
                new FriendsMenu(this.plugin, 0, null, FriendsMenu.FilterType.FRIENDS).open(player);
                break;
            }
            case "add": 
            case "follow": {
                if (args.length < 2) {
                    player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessage("FRIENDS.USAGE_FOLLOW"), player));
                    return true;
                }
                this.handleFollow(player, args[1]);
                break;
            }
            case "remove": 
            case "unfollow": {
                if (args.length < 2) {
                    player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessage("FRIENDS.USAGE_REMOVE"), player));
                    return true;
                }
                this.handleUnfollow(player, args[1]);
                break;
            }
            case "search": {
                if (args.length < 2) {
                    player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessage("FRIENDS.USAGE_SEARCH"), player));
                    return true;
                }
                new FriendsMenu(this.plugin, 0, args[1], FriendsMenu.FilterType.ALL).open(player);
                break;
            }
            default: {
                player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessage("FRIENDS.UNKNOWN_SUBCOMMAND"), player));
            }
        }
        return true;
    }

    private void handleFollow(Player player, String targetName) {
        ResolvedTarget target = this.resolveTarget(player, targetName);
        if (target == null) {
            player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessage("FRIENDS.PLAYER_NOT_FOUND"), player));
            return;
        }
        if (player.getUniqueId().equals(target.uuid())) {
            player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessage("FRIENDS.CANNOT_FOLLOW_SELF"), player));
            return;
        }
        if (this.plugin.getFriendsManager().isFollowing(player.getUniqueId(), target.uuid())) {
            player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessage("FRIENDS.ALREADY_FOLLOWING", "{player}", target.name()), player));
            return;
        }
        boolean success = this.plugin.getFriendsManager().followPlayer(player, target.uuid(), target.name());
        if (success) {
            PlayerData targetData;
            player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessage("FRIENDS.FOLLOW_SUCCESS", "{player}", target.name()), player));
            Player onlineTarget = Bukkit.getPlayer(target.uuid());
            if (onlineTarget != null && onlineTarget.isOnline() && ((targetData = this.plugin.getPlayerDataManager().get(onlineTarget)) == null || targetData.isFollowAlertsEnabled())) {
                String senderName = player.getName();
                onlineTarget.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("FRIENDS.FOLLOW_ALERT_RECEIVED", "&d&lFollow &7\u00bb &b" + senderName + " &7is now following you.")));
            }
        } else {
            player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessage("FRIENDS.FOLLOW_FAILURE"), player));
        }
    }

    private void handleUnfollow(Player player, String targetName) {
        ResolvedTarget target = this.resolveTarget(player, targetName);
        if (target == null) {
            player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessage("FRIENDS.REMOVE_NOT_FOUND"), player));
            return;
        }
        if (!this.plugin.getFriendsManager().isFollowing(player.getUniqueId(), target.uuid())) {
            player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessage("FRIENDS.NOT_FOLLOWING", "{player}", target.name()), player));
            return;
        }
        boolean success = this.plugin.getFriendsManager().unfollowPlayer(player, target.uuid());
        if (success) {
            player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessage("FRIENDS.UNFOLLOW_SUCCESS", "{player}", target.name()), player));
        } else {
            player.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessage("FRIENDS.UNFOLLOW_FAILURE"), player));
        }
    }

    private ResolvedTarget resolveTarget(Player player, String input) {
        if (input == null || input.isBlank()) {
            return null;
        }
        Player online = PlayerLookup.findOnlinePlayer(input);
        if (online != null) {
            return new ResolvedTarget(online.getUniqueId(), online.getName());
        }
        for (FollowEntry entry : this.plugin.getFriendsManager().getFollowing(player.getUniqueId())) {
            if (!entry.followedNameSnapshot().equalsIgnoreCase(input) && !entry.followedUuid().toString().equalsIgnoreCase(input)) continue;
            return new ResolvedTarget(entry.followedUuid(), entry.followedNameSnapshot());
        }
        UUID uuid = PlayerLookup.findKnownPlayerUuid(this.plugin, input);
        if (uuid == null) {
            return null;
        }
        String name = this.plugin.getDatabaseManager().getLastKnownUsername(uuid);
        String fallback = name == null || name.isBlank() ? input : name;
        return new ResolvedTarget(uuid, fallback);
    }

    private record ResolvedTarget(UUID uuid, String name) {
    }
}

