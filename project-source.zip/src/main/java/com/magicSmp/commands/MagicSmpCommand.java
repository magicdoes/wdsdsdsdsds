/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.permissions.Permissible
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.managers.FeatureManager;
import com.bx.magicSmp.managers.MaintenanceManager;
import com.bx.magicSmp.managers.OptimizationManager;
import com.bx.magicSmp.managers.SpawnManager;
import com.bx.magicSmp.managers.StatsWipeManager;
import com.bx.magicSmp.menus.FeatureToggleMenu;
import com.bx.magicSmp.menus.StatsWipeMenu;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.PermissionUtils;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.logging.Level;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.permissions.Permissible;

public class MagicSmpCommand
implements CommandExecutor,
TabCompleter {
    private static final String RELOAD_PERMISSION = "MagicSMP.admin.reload";
    private static final String STATS_WIPE_PERMISSION = "MagicSMP.admin.statswipe";
    private static final String OPTIMIZE_PERMISSION = "MagicSMP.admin.optimize";
    private static final String SETUP_PERMISSION = "MagicSMP.admin.setup";
    private static final String FEATURES_PERMISSION = "MagicSMP.admin.features";
    private static final String DEFAULT_WEBHOOK_PLACEHOLDER = "https://discord.com/api/webhooks/your_webhook_here";
    private static final int COMMANDS_PER_PAGE = 8;
    private static final List<String> ROOT_COMPLETIONS = List.of("reload", "statswipe", "optimize", "setup", "features", "maintenance");
    private static final List<String> SETUP_COMPLETIONS = List.of("status", "apply", "setspawn", "commands");
    private static final List<String> COMMAND_CATEGORIES = List.of("all", "starter", "economy", "market", "staff", "admin", "setup");
    private final MagicSmp plugin;

    public MagicSmpCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            this.sendUsage(sender, label);
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "reload": {
                this.handleReload(sender);
                break;
            }
            case "statswipe": {
                this.handleStatsWipe(sender, label, args);
                break;
            }
            case "optimize": 
            case "optimization": {
                this.handleOptimize(sender, label, args);
                break;
            }
            case "setup": {
                this.handleSetup(sender, label, args);
                break;
            }
            case "features": {
                this.handleFeatures(sender, label, args);
                break;
            }
            case "maintenance": {
                this.handleMaintenance(sender, label, args);
                break;
            }
            default: {
                this.sendUsage(sender, label);
            }
        }
        return true;
    }

    private void handleReload(CommandSender sender) {
        if (!PermissionUtils.has((Permissible)sender, RELOAD_PERMISSION)) {
            sender.sendMessage(ColorUtils.toComponent("&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274 \u1d1b\u1d0f \u0280\u1d07\u029f\u1d0f\u1d00\u1d05 \u1d18\u029f\u1d1c\u0262\u026a\u0274 \u0455\u1d07\u1d1b\u1d1b\u026a\u0274\u0262\u0455."));
            return;
        }
        try {
            this.plugin.reloadAllPluginConfigurations();
            sender.sendMessage(ColorUtils.toComponent("&a\u1d0d\u1d00\u0262\u026a\u1d04\u0455\u1d0d\u1d18 \u1d04\u1d0f\u0274\ua730\u026a\u0262\u1d1c\u0280\u1d00\u1d1b\u026a\u1d0f\u0274 \u0280\u1d07\u029f\u1d0f\u1d00\u1d05\u1d07\u1d05."));
        }
        catch (Exception exception) {
            this.plugin.getLogger().log(Level.SEVERE, "failed to reload MagicSmp configuration.", exception);
            sender.sendMessage(ColorUtils.toComponent("&c\ua730\u1d00\u026a\u029f\u1d07\u1d05 \u1d1b\u1d0f \u0280\u1d07\u029f\u1d0f\u1d00\u1d05 \u1d04\u1d0f\u0274\ua730\u026a\u0262\u1d1c\u0280\u1d00\u1d1b\u026a\u1d0f\u0274. \u1d04\u029c\u1d07\u1d04\u1d0b \u1d04\u1d0f\u0274\u0455\u1d0f\u029f\u1d07 \ua730\u1d0f\u0280 \u1d05\u1d07\u1d1b\u1d00\u026a\u029f\u0455."));
        }
    }

    private void handleStatsWipe(CommandSender sender, String label, String[] args) {
        if (!PermissionUtils.has((Permissible)sender, STATS_WIPE_PERMISSION)) {
            sender.sendMessage(ColorUtils.toComponent(this.message("NO-PERMISSION", "&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274 \u1d1b\u1d0f \u1d1c\u0455\u1d07 \u0455\u1d1b\u1d00\u1d1b\u0455 \u1d21\u026a\u1d18\u1d07.")));
            return;
        }
        if (args.length == 1 || this.isGuiAlias(args[1])) {
            if (!(sender instanceof Player)) {
                sender.sendMessage(ColorUtils.toComponent(this.message("PLAYER-ONLY-GUI", "&c\u1d0f\u1d18\u1d07\u0274 \u1d1b\u029c\u1d07 \u0455\u1d1b\u1d00\u1d1b\u0455 \u1d21\u026a\u1d18\u1d07 \u0262\u1d1c\u026a \u026a\u0274-\u0262\u1d00\u1d0d\u1d07, \u1d0f\u0280 \u1d1c\u0455\u1d07 /" + label + " \u0455\u1d1b\u1d00\u1d1b\u0455\u1d21\u026a\u1d18\u1d07 <target> \u1d04\u1d0f\u0274\ua730\u026a\u0280\u1d0d.")));
                return;
            }
            Player player = (Player)sender;
            new StatsWipeMenu(this.plugin).open(player);
            return;
        }
        StatsWipeManager.WipeTarget target = StatsWipeManager.WipeTarget.fromInput(args[1]).orElse(null);
        if (target == null) {
            sender.sendMessage(ColorUtils.toComponent(this.message("INVALID-TARGET", "&c\u026a\u0274\u1d20\u1d00\u029f\u026a\u1d05 \u0455\u1d1b\u1d00\u1d1b\u0455 \u1d21\u026a\u1d18\u1d07 \u1d1b\u1d00\u0280\u0262\u1d07\u1d1b. \u1d00\u1d20\u1d00\u026a\u029f\u1d00\u0299\u029f\u1d07: {targets}").replace("{targets}", this.availableTargets())));
            return;
        }
        if (args.length < 3 || !args[2].equalsIgnoreCase("confirm")) {
            sender.sendMessage(ColorUtils.toComponent(this.message("DIRECT-USAGE", "&c\u1d1c\u0455\u1d07 /" + label + " \u0455\u1d1b\u1d00\u1d1b\u0455\u1d21\u026a\u1d18\u1d07 <target> \u1d04\u1d0f\u0274\ua730\u026a\u0280\u1d0d \u1d1b\u1d0f \u0280\u1d1c\u0274 \u1d05\u026a\u0280\u1d07\u1d04\u1d1b\u029f\u028f, \u1d0f\u0280 /" + label + " \u0455\u1d1b\u1d00\u1d1b\u0455\u1d21\u026a\u1d18\u1d07 \u1d1b\u1d0f \u1d0f\u1d18\u1d07\u0274 \u1d1b\u029c\u1d07 \u0262\u1d1c\u026a.")));
            return;
        }
        StatsWipeManager.WipeResult result = this.plugin.getStatsWipeManager().wipeTarget(target, sender.getName());
        if (result.busy()) {
            sender.sendMessage(ColorUtils.toComponent(this.message("BUSY", "&c\u1d00 \u1d21\u026a\u1d18\u1d07 \u026a\u0455 \u1d00\u029f\u0280\u1d07\u1d00\u1d05\u028f \u026a\u0274 \u1d18\u0280\u1d0f\u0262\u0280\u1d07\u0455\u0455.")));
            return;
        }
        if (!result.success()) {
            String error = result.errorMessage() == null || result.errorMessage().isBlank() ? "unknown error" : result.errorMessage();
            sender.sendMessage(ColorUtils.toComponent(this.message("FAILED", "&c\u0455\u1d1b\u1d00\u1d1b\u0455 \u1d21\u026a\u1d18\u1d07 \ua730\u1d00\u026a\u029f\u1d07\u1d05: {error}").replace("{error}", error)));
            return;
        }
        sender.sendMessage(ColorUtils.toComponent(this.message("SUCCESS", "&a\u1d21\u026a\u1d18\u1d07 \u1d04\u1d0f\u1d0d\u1d18\u029f\u1d07\u1d1b\u1d07: &f{target}&a. \u1d00\ua730\ua730\u1d07\u1d04\u1d1b\u1d07\u1d05 \u0280\u1d07\u1d04\u1d0f\u0280\u1d05\u0455: &f{count}&a.").replace("{target}", target.getDisplayName()).replace("{count}", String.valueOf(result.affectedCount(target)))));
    }

    private void handleOptimize(CommandSender sender, String label, String[] args) {
        if (!PermissionUtils.has((Permissible)sender, OPTIMIZE_PERMISSION)) {
            sender.sendMessage(ColorUtils.toComponent("&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274 \u1d1b\u1d0f \u1d1c\u0455\u1d07 \u1d0f\u1d18\u1d1b\u026a\u1d0d\u026a\u1d22\u1d00\u1d1b\u026a\u1d0f\u0274 \u1d1b\u1d0f\u1d0f\u029f\u0455."));
            return;
        }
        OptimizationManager optimizationManager = this.plugin.getOptimizationManager();
        if (optimizationManager == null) {
            sender.sendMessage(ColorUtils.toComponent("&c\u1d0f\u1d18\u1d1b\u026a\u1d0d\u026a\u1d22\u1d00\u1d1b\u026a\u1d0f\u0274 \u1d0d\u1d00\u0274\u1d00\u0262\u1d07\u0280 \u026a\u0455 \u0274\u1d0f\u1d1b \u1d00\u1d20\u1d00\u026a\u029f\u1d00\u0299\u029f\u1d07."));
            return;
        }
        if (args.length == 1 || args[1].equalsIgnoreCase("status")) {
            this.sendOptimizationStatus(sender, label, optimizationManager);
            return;
        }
        switch (args[1].toLowerCase(Locale.ROOT)) {
            case "reload": {
                optimizationManager.reload();
                sender.sendMessage(ColorUtils.toComponent("&a\u1d0f\u1d18\u1d1b\u026a\u1d0d\u026a\u1d22\u1d00\u1d1b\u026a\u1d0f\u0274 \u0455\u1d07\u1d1b\u1d1b\u026a\u0274\u0262\u0455 \u0280\u1d07\u029f\u1d0f\u1d00\u1d05\u1d07\u1d05."));
                break;
            }
            case "reset": {
                optimizationManager.resetStats();
                sender.sendMessage(ColorUtils.toComponent("&a\u1d0f\u1d18\u1d1b\u026a\u1d0d\u026a\u1d22\u1d00\u1d1b\u026a\u1d0f\u0274 \u0280\u1d1c\u0274\u1d1b\u026a\u1d0d\u1d07 \u1d04\u1d0f\u1d1c\u0274\u1d1b\u1d07\u0280\u0455 \u0280\u1d07\u0455\u1d07\u1d1b."));
                break;
            }
            default: {
                sender.sendMessage(ColorUtils.toComponent("&c\u1d1c\u0455\u1d00\u0262\u1d07: /" + label + " \u1d0f\u1d18\u1d1b\u026a\u1d0d\u026a\u1d22\u1d07 [\u0455\u1d1b\u1d00\u1d1b\u1d1c\u0455|\u0280\u1d07\u029f\u1d0f\u1d00\u1d05|\u0280\u1d07\u0455\u1d07\u1d1b]"));
            }
        }
    }

    private void handleSetup(CommandSender sender, String label, String[] args) {
        if (!PermissionUtils.has((Permissible)sender, SETUP_PERMISSION)) {
            sender.sendMessage(ColorUtils.toComponent("&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274 \u1d1b\u1d0f \u1d1c\u0455\u1d07 \u0455\u1d07\u1d1b\u1d1c\u1d18 \u1d1b\u1d0f\u1d0f\u029f\u0455."));
            return;
        }
        if (args.length == 1 || args[1].equalsIgnoreCase("status")) {
            this.sendSetupStatus(sender, label);
            return;
        }
        switch (args[1].toLowerCase(Locale.ROOT)) {
            case "apply": {
                this.handleSetupApply(sender, label, args);
                break;
            }
            case "setspawn": {
                this.handleSetupLocation(sender);
                break;
            }
            case "commands": {
                this.handleSetupCommands(sender, label, args);
                break;
            }
            default: {
                this.sendSetupUsage(sender, label);
            }
        }
    }

    private void handleFeatures(CommandSender sender, String label, String[] args) {
        if (!PermissionUtils.has((Permissible)sender, FEATURES_PERMISSION)) {
            sender.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("FEATURES.NO-PERMISSION", "&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274 \u1d1b\u1d0f \u1d0d\u1d00\u0274\u1d00\u0262\u1d07 \ua730\u1d07\u1d00\u1d1b\u1d1c\u0280\u1d07 \u1d1b\u1d0f\u0262\u0262\u029f\u1d07\u0455.")));
            return;
        }
        if (args.length == 1 || args.length >= 2 && this.isGuiAlias(args[1])) {
            if (sender instanceof Player) {
                Player player = (Player)sender;
                new FeatureToggleMenu(this.plugin).open(player);
                return;
            }
            this.sendFeatureList(sender);
            return;
        }
        String action = args[1].toLowerCase(Locale.ROOT);
        if (action.equals("list")) {
            this.sendFeatureList(sender);
            return;
        }
        if (!(action.equals("toggle") || action.equals("enable") || action.equals("disable"))) {
            this.sendFeatureUsage(sender, label);
            return;
        }
        if (args.length < 3) {
            this.sendFeatureUsage(sender, label);
            return;
        }
        FeatureManager.Feature feature = FeatureManager.Feature.fromInput(args[2]).orElse(null);
        if (feature == null) {
            sender.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("FEATURES.UNKNOWN", "&c\u1d1c\u0274\u1d0b\u0274\u1d0f\u1d21\u0274 \ua730\u1d07\u1d00\u1d1b\u1d1c\u0280\u1d07: &f{feature}", "{feature}", args[2])));
            return;
        }
        boolean success = action.equals("toggle") ? this.plugin.getFeatureManager().toggle(feature) : this.plugin.getFeatureManager().setEnabled(feature, action.equals("enable"));
        if (!success) {
            sender.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("FEATURES.TOGGLE-FAILED", "&c\ua730\u1d00\u026a\u029f\u1d07\u1d05 \u1d1b\u1d0f \u1d1c\u1d18\u1d05\u1d00\u1d1b\u1d07 {feature}.", "{feature}", feature.displayName(), "{feature_key}", feature.configKey())));
            return;
        }
        sender.sendMessage(ColorUtils.toComponent(this.plugin.getConfigManager().getMessageOrDefault("FEATURES.TOGGLED", "&a{feature} \u026a\u0455 \u0274\u1d0f\u1d21 {state}.", "{feature}", feature.displayName(), "{feature_key}", feature.configKey(), "{state}", this.plugin.getFeatureManager().statusText(feature))));
    }

    private void handleSetupApply(CommandSender sender, String label, String[] args) {
        if (args.length < 4 || !args[2].equalsIgnoreCase("single-paper") || !args[3].equalsIgnoreCase("confirm")) {
            sender.sendMessage(ColorUtils.toComponent("&c\u1d1c\u0455\u1d00\u0262\u1d07: /" + label + " \u0455\u1d07\u1d1b\u1d1c\u1d18 \u1d00\u1d18\u1d18\u029f\u028f \u0455\u026a\u0274\u0262\u029f\u1d07-\u1d18\u1d00\u1d18\u1d07\u0280 \u1d04\u1d0f\u0274\ua730\u026a\u0280\u1d0d"));
            return;
        }
        try {
            FileConfiguration config = this.plugin.getConfigManager().getConfig();
            FileConfiguration database = this.plugin.getConfigManager().getDatabase();
            FileConfiguration discord = this.plugin.getConfigManager().getDiscord();
            config.set("SETTINGS.SPAWN-MENU", (Object)true);
            database.set("DATABASE.TYPE", (Object)"SQLITE");
            database.set("DATABASE.SQLITE.FILE", (Object)"data/data.db");
            database.set("REDIS.ENABLED", (Object)false);
            discord.set("WEBHOOKS.ENABLED", (Object)false);
            boolean saved = this.plugin.getConfigManager().saveConfig() & this.plugin.getConfigManager().saveDatabase() & this.plugin.getConfigManager().saveDiscord();
            if (!saved) {
                sender.sendMessage(ColorUtils.toComponent("&c\u0455\u026a\u0274\u0262\u029f\u1d07 \u1d18\u1d00\u1d18\u1d07\u0280 \u1d18\u0280\u1d07\u0455\u1d07\u1d1b \u1d21\u1d00\u0455 \u1d00\u1d18\u1d18\u029f\u026a\u1d07\u1d05 \u026a\u0274 \u1d0d\u1d07\u1d0d\u1d0f\u0280\u028f, \u0299\u1d1c\u1d1b \u1d0f\u0274\u1d07 \u1d0f\u0280 \u1d0d\u1d0f\u0280\u1d07 \ua730\u026a\u029f\u1d07\u0455 \ua730\u1d00\u026a\u029f\u1d07\u1d05 \u1d1b\u1d0f \u0455\u1d00\u1d20\u1d07. \u1d04\u029c\u1d07\u1d04\u1d0b \u1d04\u1d0f\u0274\u0455\u1d0f\u029f\u1d07."));
                return;
            }
            this.plugin.reloadAllPluginConfigurations();
            sender.sendMessage(ColorUtils.toComponent("&a\u0455\u026a\u0274\u0262\u029f\u1d07 \u1d18\u1d00\u1d18\u1d07\u0280 \u0455\u1d07\u1d1b\u1d1c\u1d18 \u1d18\u0280\u1d07\u0455\u1d07\u1d1b \u1d00\u1d18\u1d18\u029f\u026a\u1d07\u1d05."));
            sender.sendMessage(ColorUtils.toComponent("&7\u0274\u1d07x\u1d1b: \u1d1c\u0455\u1d07 &f/" + label + " \u0455\u1d07\u1d1b\u1d1c\u1d18 \u0455\u1d07\u1d1b\u0455\u1d18\u1d00\u1d21\u0274 &7\u1d00\u0274\u1d05 &f/" + label + " \u0455\u1d07\u1d1b\u1d1c\u1d18 \u0455\u1d07\u1d1b\u1d00\ua730\u1d0b&7."));
            sender.sendMessage(ColorUtils.toComponent("&e\u0280\u1d07\u0455\u1d1b\u1d00\u0280\u1d1b \u1d1b\u029c\u1d07 \u0455\u1d07\u0280\u1d20\u1d07\u0280 \u0299\u1d07\ua730\u1d0f\u0280\u1d07 \u0262\u1d0f\u026a\u0274\u0262 \u029f\u026a\u1d20\u1d07 \u0455\u1d0f \u0455\u1d1b\u1d0f\u0280\u1d00\u0262\u1d07 \u1d04\u029c\u1d00\u0274\u0262\u1d07\u0455 \u1d00\u0280\u1d07 \ua730\u1d1c\u029f\u029f\u028f \u1d00\u1d18\u1d18\u029f\u026a\u1d07\u1d05."));
        }
        catch (Exception exception) {
            this.plugin.getLogger().log(Level.SEVERE, "failed to apply single paper setup preset.", exception);
            sender.sendMessage(ColorUtils.toComponent("&c\ua730\u1d00\u026a\u029f\u1d07\u1d05 \u1d1b\u1d0f \u1d00\u1d18\u1d18\u029f\u028f \u0455\u1d07\u1d1b\u1d1c\u1d18 \u1d18\u0280\u1d07\u0455\u1d07\u1d1b. \u1d04\u029c\u1d07\u1d04\u1d0b \u1d04\u1d0f\u0274\u0455\u1d0f\u029f\u1d07 \ua730\u1d0f\u0280 \u1d05\u1d07\u1d1b\u1d00\u026a\u029f\u0455."));
        }
    }

    private void handleSetupLocation(CommandSender sender) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ColorUtils.toComponent("&c\u1d0f\u0274\u029f\u028f \u1d18\u029f\u1d00\u028f\u1d07\u0280\u0455 \u1d04\u1d00\u0274 \u0455\u1d00\u1d20\u1d07 \u0455\u1d07\u1d1b\u1d1c\u1d18 \u029f\u1d0f\u1d04\u1d00\u1d1b\u026a\u1d0f\u0274\u0455."));
            return;
        }
        Player player = (Player)sender;
        Location location = player.getLocation();
        SpawnManager.SetupLocationResult result = this.plugin.getSpawnManager().setSpawnLocation(location);
        if (!result.success()) {
            this.plugin.getLogger().warning("failed to save setup spawn location at " + this.describeLocation(location) + ": " + result.message());
            sender.sendMessage(ColorUtils.toComponent("&c\u0455\u1d18\u1d00\u1d21\u0274 \u029f\u1d0f\u1d04\u1d00\u1d1b\u026a\u1d0f\u0274 \u1d04\u1d0f\u1d1c\u029f\u1d05 \u0274\u1d0f\u1d1b \u0299\u1d07 \u0455\u1d00\u1d20\u1d07\u1d05: &f" + result.message()));
            return;
        }
        sender.sendMessage(ColorUtils.toComponent("&a\u0455\u1d18\u1d00\u1d21\u0274 \u029f\u1d0f\u1d04\u1d00\u1d1b\u026a\u1d0f\u0274 \u0455\u1d00\u1d20\u1d07\u1d05 \u1d00\u1d1b &f" + this.describeLocation(location) + "&a. &7\u1d00\u0280\u1d07\u1d00 &f" + result.areaId() + " &7\u0455\u029f\u1d0f\u1d1b &f" + result.slot() + "&7."));
    }

    private void sendSetupStatus(CommandSender sender, String label) {
        FileConfiguration config = this.plugin.getConfigManager().getConfig();
        FileConfiguration database = this.plugin.getConfigManager().getDatabase();
        FileConfiguration discord = this.plugin.getConfigManager().getDiscord();
        sender.sendMessage(ColorUtils.toComponent("&8&m---------- &b\u1d1c\u029f\u1d1b\u026a\u1d0d\u1d00\u1d1b\u1d07\u1d05\u1d0f\u0274\u1d1c\u1d1b\u0455\u1d0d\u1d18 \u0455\u1d07\u1d1b\u1d1c\u1d18 &8&m----------"));
        this.sendCheck(sender, this.isJava21OrNewer(), "java", System.getProperty("java.version", "unknown") + " (java 21+ required)");
        this.sendCheck(sender, this.isPaperLikeServer(), "server", this.plugin.getServer().getName() + " " + this.plugin.getServer().getBukkitVersion());
        this.sendCheck(sender, this.isDatabaseConnected(), "storage", database.getString("DATABASE.TYPE", "SQLITE").toUpperCase(Locale.ROOT) + " configured");
        this.sendCheck(sender, this.isRedisReadyForSingleServer(database), "redis", this.redisDetail(database));
        this.sendCheck(sender, this.isDiscordWebhookReady(discord), "discord webhook", this.discordWebhookDetail(discord));
        this.sendCheck(sender, this.plugin.getSpawnManager().hasSpawn(), "spawn", (String)(this.plugin.getSpawnManager().hasSpawn() ? "ready" : "use /" + label + " setup setspawn"));
        List<String> rtpWorlds = this.availableRtpWorlds();
        this.sendCheck(sender, this.plugin.getRtpManager().isEnabled() && !rtpWorlds.isEmpty(), "rtp worlds", rtpWorlds.isEmpty() ? "no configured rtp worlds are loaded" : String.join((CharSequence)", ", rtpWorlds));
        this.sendCheck(sender, true, "optional integrations", this.optionalIntegrationDetail());
        sender.sendMessage(ColorUtils.toComponent("&7\u1d18\u0280\u1d07\u0455\u1d07\u1d1b: &f/" + label + " \u0455\u1d07\u1d1b\u1d1c\u1d18 \u1d00\u1d18\u1d18\u029f\u028f \u0455\u026a\u0274\u0262\u029f\u1d07-\u1d18\u1d00\u1d18\u1d07\u0280 \u1d04\u1d0f\u0274\ua730\u026a\u0280\u1d0d"));
        sender.sendMessage(ColorUtils.toComponent("&7\u1d04\u1d0f\u1d0d\u1d0d\u1d00\u0274\u1d05\u0455: &f/" + label + " \u0455\u1d07\u1d1b\u1d1c\u1d18 \u1d04\u1d0f\u1d0d\u1d0d\u1d00\u0274\u1d05\u0455 [\u1d04\u1d00\u1d1b\u1d07\u0262\u1d0f\u0280\u028f] [\u1d18\u1d00\u0262\u1d07]"));
    }

    private void handleSetupCommands(CommandSender sender, String label, String[] args) {
        String category;
        String string = category = args.length >= 3 ? args[2].toLowerCase(Locale.ROOT) : "all";
        if (!COMMAND_CATEGORIES.contains(category)) {
            sender.sendMessage(ColorUtils.toComponent("&c\u1d1c\u0274\u1d0b\u0274\u1d0f\u1d21\u0274 \u1d04\u1d0f\u1d0d\u1d0d\u1d00\u0274\u1d05 \u1d04\u1d00\u1d1b\u1d07\u0262\u1d0f\u0280\u028f. \u1d00\u1d20\u1d00\u026a\u029f\u1d00\u0299\u029f\u1d07: &f" + String.join((CharSequence)", ", COMMAND_CATEGORIES)));
            return;
        }
        int page = args.length >= 4 ? this.parsePage(args[3]) : 1;
        List<CommandEntry> entries = this.commandEntries(category, label);
        if (entries.isEmpty()) {
            sender.sendMessage(ColorUtils.toComponent("&c\u0274\u1d0f \u1d04\u1d0f\u1d0d\u1d0d\u1d00\u0274\u1d05\u0455 \ua730\u1d0f\u1d1c\u0274\u1d05 \ua730\u1d0f\u0280 \u1d04\u1d00\u1d1b\u1d07\u0262\u1d0f\u0280\u028f: &f" + category));
            return;
        }
        int totalPages = Math.max(1, (int)Math.ceil((double)entries.size() / 8.0));
        page = Math.max(1, Math.min(page, totalPages));
        int start = (page - 1) * 8;
        int end = Math.min(entries.size(), start + 8);
        sender.sendMessage(ColorUtils.toComponent("&8&m---------- &b\u1d1c\u1d05\u0455 \u1d04\u1d0f\u1d0d\u1d0d\u1d00\u0274\u1d05\u0455 &8(&f" + category + " " + page + "/" + totalPages + "&8) &8&m----------"));
        for (int index = start; index < end; ++index) {
            CommandEntry entry = entries.get(index);
            sender.sendMessage(ColorUtils.toComponent("&f" + entry.usage() + " &8- &7" + entry.description()));
        }
        sender.sendMessage(ColorUtils.toComponent("&7\u1d04\u1d00\u1d1b\u1d07\u0262\u1d0f\u0280\u026a\u1d07\u0455: &f" + String.join((CharSequence)"&7, &f", COMMAND_CATEGORIES)));
    }

    private List<CommandEntry> commandEntries(String category, String label) {
        if (category.equals("setup")) {
            return List.of(new CommandEntry("/" + label + " setup [status]", "show setup checklist"), new CommandEntry("/" + label + " setup apply single-paper confirm", "apply the single paper preset"), new CommandEntry("/" + label + " setup setspawn", "save your current location as spawn"), new CommandEntry("/" + label + " setup commands [category] [page]", "browse command usage"));
        }
        Map commandMap = this.plugin.getDescription().getCommands();
        List<String> commandNames = this.commandNamesForCategory(category, commandMap.keySet());
        ArrayList<CommandEntry> entries = new ArrayList<CommandEntry>();
        for (String commandName : commandNames) {
            Map details = (Map)commandMap.get(commandName);
            if (details == null) continue;
            String usage = String.valueOf(details.getOrDefault("usage", "/" + commandName));
            Object description = String.valueOf(details.getOrDefault("description", "no description"));
            String aliases = this.formatAliases(details.get("aliases"));
            if (!aliases.isBlank()) {
                description = (String)description + " (aliases: " + aliases + ")";
            }
            if (!this.plugin.getFeatureManager().isCommandFeatureEnabled(commandName)) continue;
            entries.add(new CommandEntry(usage, (String)description));
        }
        return entries;
    }

    private void sendFeatureList(CommandSender sender) {
        sender.sendMessage(ColorUtils.toComponent("&8&m---------- &b\ua730\u1d07\u1d00\u1d1b\u1d1c\u0280\u1d07 \u1d1b\u1d0f\u0262\u0262\u029f\u1d07\u0455 &8&m----------"));
        for (FeatureManager.Feature feature : this.plugin.getFeatureManager().getFeatures()) {
            sender.sendMessage(ColorUtils.toComponent("&f" + feature.configKey() + " &8- " + this.plugin.getFeatureManager().statusText(feature) + " &8- &7" + feature.displayName()));
        }
    }

    private List<String> commandNamesForCategory(String category, Collection<String> allCommandNames) {
        if (category.equals("all")) {
            return new ArrayList<String>(allCommandNames);
        }
        return switch (category) {
            case "starter" -> List.of("spawn", "home", "homes", "sethome", "delhome", "renamehome", "rtp", "tpa", "tpahere", "tpaccept", "tpadeny", "tpacancel", "stats", "ping", "playtime", "social", "discord", "supportus", "rules", "help");
            case "economy" -> List.of("balance", "pay", "addmoney", "removemoney", "setmoney", "shop", "sell", "sellhand", "sellall", "sellhistory", "worth");
            case "market" -> List.of("auctionhouse", "bounty");
            case "staff" -> List.of("staffmode", "stafflist", "staffchat", "helpop", "report", "freeze", "fly", "heal", "feed", "gamemode", "randomteleport", "teleport", "alts", "vanish", "invsee", "profileviewer", "punishments", "ban", "tempban", "mute", "tempmute", "warn", "kick", "blacklist", "unban", "unmute", "unblacklist", "findplayer", "rename");
            case "admin" -> List.of("MagicSMP", "clearlag", "amethysttool", "arena", "shop", "orders", "auctionhouse", "enderchest", "freeze", "staffmode", "invsee", "worth");
            default -> List.of();
        };
    }

    private String formatAliases(Object rawAliases) {
        String alias;
        if (rawAliases instanceof Collection) {
            Collection aliases = (Collection)rawAliases;
            return aliases.stream().map(String::valueOf).reduce((left, right) -> left + ", " + right).orElse("");
        }
        if (rawAliases instanceof String && !(alias = (String)rawAliases).isBlank()) {
            return alias;
        }
        return "";
    }

    private void sendCheck(CommandSender sender, boolean ok, String label, String detail) {
        String state = ok ? "&aok" : "&echeck";
        sender.sendMessage(ColorUtils.toComponent("&8- " + state + " &f" + label + " &8- &7" + detail));
    }

    private boolean isJava21OrNewer() {
        String version = System.getProperty("java.version", "");
        String normalized = version.startsWith("1.") ? version.substring(2) : version;
        int dotIndex = normalized.indexOf(46);
        String major = dotIndex >= 0 ? normalized.substring(0, dotIndex) : normalized;
        try {
            return Integer.parseInt(major) >= 21;
        }
        catch (NumberFormatException ignored) {
            return false;
        }
    }

    private boolean isPaperLikeServer() {
        String serverName = this.plugin.getServer().getName().toLowerCase(Locale.ROOT);
        return serverName.contains("paper") || serverName.contains("purpur") || serverName.contains("pufferfish");
    }

    private boolean isDatabaseConnected() {
        Connection connection;
        Connection connection2 = connection = this.plugin.getDatabaseManager() == null ? null : this.plugin.getDatabaseManager().getConnection();
        if (connection == null) {
            return false;
        }
        try {
            return !connection.isClosed();
        }
        catch (SQLException ignored) {
            return false;
        }
    }

    private boolean isRedisReadyForSingleServer(FileConfiguration database) {
        return !database.getBoolean("REDIS.ENABLED", false) || this.plugin.getRedisManager() != null && this.plugin.getRedisManager().isConnected();
    }

    private String redisDetail(FileConfiguration database) {
        if (!database.getBoolean("REDIS.ENABLED", false)) {
            return "disabled for single-server setup";
        }
        return this.plugin.getRedisManager() != null && this.plugin.getRedisManager().isConnected() ? "enabled and connected" : "enabled but not connected";
    }

    private boolean isDiscordWebhookReady(FileConfiguration discord) {
        ConfigurationSection root = discord.getConfigurationSection("WEBHOOKS");
        if (root == null || !root.getBoolean("ENABLED", true)) {
            return true;
        }
        String url = root.getString("URL", "");
        return !url.isBlank() && !DEFAULT_WEBHOOK_PLACEHOLDER.equalsIgnoreCase(url);
    }

    private String discordWebhookDetail(FileConfiguration discord) {
        ConfigurationSection root = discord.getConfigurationSection("WEBHOOKS");
        if (root == null || !root.getBoolean("ENABLED", true)) {
            return "disabled";
        }
        String url = root.getString("URL", "");
        if (url.isBlank() || DEFAULT_WEBHOOK_PLACEHOLDER.equalsIgnoreCase(url)) {
            return "enabled with placeholder URL";
        }
        return "enabled";
    }

    private List<String> availableRtpWorlds() {
        ConfigurationSection worlds = this.plugin.getConfigManager().getRtp().getConfigurationSection("WORLD-SETTINGS");
        if (worlds == null) {
            return List.of();
        }
        ArrayList<String> loaded = new ArrayList<String>();
        for (String worldName : worlds.getKeys(false)) {
            World world = Bukkit.getWorld((String)worldName);
            if (world == null) continue;
            loaded.add(world.getName());
        }
        loaded.sort(String.CASE_INSENSITIVE_ORDER);
        return loaded;
    }

    private String optionalIntegrationDetail() {
        String installedText;
        ArrayList<String> installed = new ArrayList<String>();
        ArrayList<String> missing = new ArrayList<String>();
        for (String pluginName : List.of("PlaceholderAPI", "LuckPerms", "Vault", "ProtocolLib")) {
            if (this.plugin.getServer().getPluginManager().getPlugin(pluginName) == null) {
                missing.add(pluginName);
                continue;
            }
            installed.add(pluginName);
        }
        String string = installedText = installed.isEmpty() ? "none installed" : "installed: " + String.join((CharSequence)", ", installed);
        if (missing.isEmpty()) {
            return installedText;
        }
        return installedText + "; optional missing: " + String.join((CharSequence)", ", missing);
    }

    private String describeLocation(Location location) {
        if (location == null || location.getWorld() == null) {
            return "unknown";
        }
        return location.getWorld().getName() + " " + location.getBlockX() + ", " + location.getBlockY() + ", " + location.getBlockZ();
    }

    private int parsePage(String raw) {
        try {
            return Math.max(1, Integer.parseInt(raw));
        }
        catch (NumberFormatException ignored) {
            return 1;
        }
    }

    private void sendOptimizationStatus(CommandSender sender, String label, OptimizationManager optimizationManager) {
        sender.sendMessage(ColorUtils.toComponent("&8&m---------- &b\u1d0f\u1d18\u1d1b\u026a\u1d0d\u026a\u1d22\u1d00\u1d1b\u026a\u1d0f\u0274 &8&m----------"));
        sender.sendMessage(ColorUtils.toComponent("&7\u1d07\u0274\u1d00\u0299\u029f\u1d07\u1d05: &f" + optimizationManager.isEnabled() + " &8| &7\u0455\u1d1b\u1d00\u1d1b\u1d07: " + optimizationManager.getLoadState().display()));
        sender.sendMessage(ColorUtils.toComponent("&7\u1d1b\u1d18\u0455: &f" + optimizationManager.formatMetric(optimizationManager.getLastTps()) + " &8| &7\u1d0d\u0455\u1d18\u1d1b: &f" + optimizationManager.formatMetric(optimizationManager.getLastMspt())));
        sender.sendMessage(ColorUtils.toComponent("&7\u1d0d\u1d07\u1d0d\u1d0f\u0280\u028f: &f" + optimizationManager.getUsedMemoryMb() + "mb&8/&f" + optimizationManager.getMaxMemoryMb() + "\u1d0d\u0299"));
        sender.sendMessage(ColorUtils.toComponent("&7\u0455\u1d0b\u026a\u1d18\u1d18\u1d07\u1d05 \u1d1b\u1d00\u0455\u1d0b \u0280\u1d1c\u0274\u0455: &f" + optimizationManager.getTotalSkippedRuns() + " &8(&7\u0455\u1d04\u1d0f\u0280\u1d07\u0299\u1d0f\u1d00\u0280\u1d05=&f" + optimizationManager.getSkippedRuns(OptimizationManager.OptimizedTask.SCOREBOARD) + "&8, &7\u1d1b\u1d00\u0299\u029f\u026a\u0455\u1d1b=&f" + optimizationManager.getSkippedRuns(OptimizationManager.OptimizedTask.TABLIST) + "&8)"));
        sender.sendMessage(ColorUtils.toComponent("&7\u1d1c\u0455\u1d00\u0262\u1d07: &f/" + label + " \u1d0f\u1d18\u1d1b\u026a\u1d0d\u026a\u1d22\u1d07 [\u0455\u1d1b\u1d00\u1d1b\u1d1c\u0455|\u0280\u1d07\u029f\u1d0f\u1d00\u1d05|\u0280\u1d07\u0455\u1d07\u1d1b]"));
    }

    private void sendUsage(CommandSender sender, String label) {
        sender.sendMessage(ColorUtils.toComponent("&c\u1d1c\u0455\u1d00\u0262\u1d07: /" + label + " <reload|statswipe|optimize|setup|features>"));
    }

    private void sendSetupUsage(CommandSender sender, String label) {
        sender.sendMessage(ColorUtils.toComponent("&c\u1d1c\u0455\u1d00\u0262\u1d07: /" + label + " \u0455\u1d07\u1d1b\u1d1c\u1d18 <status|apply|setspawn|commands>"));
    }

    private void sendFeatureUsage(CommandSender sender, String label) {
        sender.sendMessage(ColorUtils.toComponent("&c\u1d1c\u0455\u1d00\u0262\u1d07: /" + label + " \ua730\u1d07\u1d00\u1d1b\u1d1c\u0280\u1d07\u0455 [\u029f\u026a\u0455\u1d1b|\u1d1b\u1d0f\u0262\u0262\u029f\u1d07|\u1d07\u0274\u1d00\u0299\u029f\u1d07|\u1d05\u026a\u0455\u1d00\u0299\u029f\u1d07] [\ua730\u1d07\u1d00\u1d1b\u1d1c\u0280\u1d07]"));
    }

    private String message(String key, String fallback) {
        return this.plugin.getConfigManager().getMessages().getString("STATS-WIPE." + key, fallback);
    }

    private boolean isGuiAlias(String input) {
        return input.equalsIgnoreCase("menu") || input.equalsIgnoreCase("gui");
    }

    private String availableTargets() {
        return Arrays.stream(StatsWipeManager.WipeTarget.values()).map(StatsWipeManager.WipeTarget::getDisplayName).reduce((left, right) -> left + ", " + right).orElse("player stats");
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return this.partialMatches(args[0], ROOT_COMPLETIONS);
        }
        String root = args[0].toLowerCase(Locale.ROOT);
        if (root.equals("optimize") || root.equals("optimization")) {
            return args.length == 2 ? this.partialMatches(args[1], List.of("status", "reload", "reset")) : List.of();
        }
        if (root.equals("features")) {
            return this.completeFeatures(args);
        }
        if (root.equals("maintenance")) {
            if (args.length == 2) {
                return this.partialMatches(args[1], List.of("on", "off", "status", "setlobby"));
            }
            if (args.length == 3 && args[1].equalsIgnoreCase("setlobby")) {
                return List.of();
            }
            return List.of();
        }
        if (root.equals("statswipe")) {
            if (args.length == 2) {
                List<String> targets = Arrays.stream(StatsWipeManager.WipeTarget.values()).map(target -> target.getDisplayName().toLowerCase(Locale.ROOT).replace(" ", "-")).toList();
                return this.partialMatches(args[1], targets);
            }
            return args.length == 3 ? this.partialMatches(args[2], List.of("confirm")) : List.of();
        }
        if (!root.equals("setup")) {
            return List.of();
        }
        if (args.length == 2) {
            return this.partialMatches(args[1], SETUP_COMPLETIONS);
        }
        String setupSub = args[1].toLowerCase(Locale.ROOT);
        if (setupSub.equals("apply")) {
            if (args.length == 3) {
                return this.partialMatches(args[2], List.of("single-paper"));
            }
            if (args.length == 4 && args[2].equalsIgnoreCase("single-paper")) {
                return this.partialMatches(args[3], List.of("confirm"));
            }
        }
        if (setupSub.equals("commands")) {
            if (args.length == 3) {
                return this.partialMatches(args[2], COMMAND_CATEGORIES);
            }
            if (args.length == 4) {
                return this.partialMatches(args[3], List.of("1", "2", "3", "4", "5"));
            }
        }
        return List.of();
    }

    private List<String> completeFeatures(String[] args) {
        if (args.length == 2) {
            return this.partialMatches(args[1], List.of("list", "toggle", "enable", "disable"));
        }
        if (args.length == 3 && List.of("toggle", "enable", "disable").contains(args[1].toLowerCase(Locale.ROOT))) {
            List<String> featureKeys = this.plugin.getFeatureManager().getFeatures().stream().map(feature -> feature.configKey().toLowerCase(Locale.ROOT).replace('_', '-')).toList();
            return this.partialMatches(args[2], featureKeys);
        }
        return List.of();
    }

    private List<String> partialMatches(String input, Collection<String> options) {
        String normalized = input == null ? "" : input.toLowerCase(Locale.ROOT);
        return options.stream().filter(option -> option.toLowerCase(Locale.ROOT).startsWith(normalized)).toList();
    }

    private void handleMaintenance(CommandSender sender, String label, String[] args) {
        if (!sender.hasPermission("MagicSMP.admin.maintenance")) {
            sender.sendMessage(ColorUtils.toComponent("&c\u028f\u1d0f\u1d1c \u1d05\u1d0f \u0274\u1d0f\u1d1b \u029c\u1d00\u1d20\u1d07 \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274 \u1d1b\u1d0f \u1d0d\u1d00\u0274\u1d00\u0262\u1d07 \u1d0d\u1d00\u026a\u0274\u1d1b\u1d07\u0274\u1d00\u0274\u1d04\u1d07 \u1d0d\u1d0f\u1d05\u1d07."));
            return;
        }
        if (args.length < 2) {
            sender.sendMessage(ColorUtils.toComponent("&c\u1d1c\u0455\u1d00\u0262\u1d07: /" + label + " \u1d0d\u1d00\u026a\u0274\u1d1b\u1d07\u0274\u1d00\u0274\u1d04\u1d07 <on|off|status|setlobby [server]>"));
            return;
        }
        MaintenanceManager mm = this.plugin.getMaintenanceManager();
        if (mm == null) {
            sender.sendMessage(ColorUtils.toComponent("&c\u1d0d\u1d00\u026a\u0274\u1d1b\u1d07\u0274\u1d00\u0274\u1d04\u1d07 \u1d0d\u1d00\u0274\u1d00\u0262\u1d07\u0280 \u026a\u0455 \u0274\u1d0f\u1d1b \u1d00\u1d20\u1d00\u026a\u029f\u1d00\u0299\u029f\u1d07."));
            return;
        }
        switch (args[1].toLowerCase(Locale.ROOT)) {
            case "on": 
            case "start": 
            case "enable": {
                if (mm.isMaintenanceActive()) {
                    sender.sendMessage(ColorUtils.toComponent("&e\u1d0d\u1d00\u026a\u0274\u1d1b\u1d07\u0274\u1d00\u0274\u1d04\u1d07 \u1d0d\u1d0f\u1d05\u1d07 \u026a\u0455 \u1d00\u029f\u0280\u1d07\u1d00\u1d05\u028f \u1d00\u1d04\u1d1b\u026a\u1d20\u1d07."));
                    return;
                }
                mm.startMaintenance();
                sender.sendMessage(ColorUtils.toComponent("&a\u1d0d\u1d00\u026a\u0274\u1d1b\u1d07\u0274\u1d00\u0274\u1d04\u1d07 \u1d0d\u1d0f\u1d05\u1d07 \u029c\u1d00\u0455 \u0299\u1d07\u1d07\u0274 \u1d07\u0274\u1d00\u0299\u029f\u1d07\u1d05. \u1d18\u029f\u1d00\u028f\u1d07\u0280\u0455 \u1d00\u0280\u1d07 \u0299\u1d07\u026a\u0274\u0262 \u0280\u1d07\u1d05\u026a\u0280\u1d07\u1d04\u1d1b\u1d07\u1d05."));
                break;
            }
            case "off": 
            case "stop": 
            case "disable": {
                if (!mm.isMaintenanceActive()) {
                    sender.sendMessage(ColorUtils.toComponent("&e\u1d0d\u1d00\u026a\u0274\u1d1b\u1d07\u0274\u1d00\u0274\u1d04\u1d07 \u1d0d\u1d0f\u1d05\u1d07 \u026a\u0455 \u0274\u1d0f\u1d1b \u1d00\u1d04\u1d1b\u026a\u1d20\u1d07."));
                    return;
                }
                mm.stopMaintenance();
                sender.sendMessage(ColorUtils.toComponent("&a\u1d0d\u1d00\u026a\u0274\u1d1b\u1d07\u0274\u1d00\u0274\u1d04\u1d07 \u1d0d\u1d0f\u1d05\u1d07 \u029c\u1d00\u0455 \u0299\u1d07\u1d07\u0274 \u1d05\u026a\u0455\u1d00\u0299\u029f\u1d07\u1d05. \u0280\u1d07\u1d04\u1d0f\u0274\u0274\u1d07\u1d04\u1d1b \u0455\u026a\u0262\u0274\u1d00\u029f \u0455\u1d07\u0274\u1d1b."));
                break;
            }
            case "status": {
                boolean active = mm.isMaintenanceActive();
                String lobby = mm.getLobbyServer();
                sender.sendMessage(ColorUtils.toComponent("&d&l\u1d0d\u1d00\u026a\u0274\u1d1b\u1d07\u0274\u1d00\u0274\u1d04\u1d07 \u0455\u1d1b\u1d00\u1d1b\u1d1c\u0455:"));
                sender.sendMessage(ColorUtils.toComponent("  &f\u1d00\u1d04\u1d1b\u026a\u1d20\u1d07: " + (active ? "&a\u028f\u1d07\u0455" : "&c\u0274\u1d0f")));
                sender.sendMessage(ColorUtils.toComponent("  &f\u029f\u1d0f\u0299\u0299\u028f \u0455\u1d07\u0280\u1d20\u1d07\u0280: &b" + lobby));
                break;
            }
            case "setlobby": {
                if (args.length < 3) {
                    sender.sendMessage(ColorUtils.toComponent("&c\u1d1c\u0455\u1d00\u0262\u1d07: /" + label + " \u1d0d\u1d00\u026a\u0274\u1d1b\u1d07\u0274\u1d00\u0274\u1d04\u1d07 \u0455\u1d07\u1d1b\u029f\u1d0f\u0299\u0299\u028f <server>"));
                    return;
                }
                String lobby = args[2];
                mm.setLobbyServer(lobby);
                sender.sendMessage(ColorUtils.toComponent("&a\u029f\u1d0f\u0299\u0299\u028f \u0455\u1d07\u0280\u1d20\u1d07\u0280 \u0455\u1d07\u1d1b \u1d1b\u1d0f &b" + lobby + "&a."));
                break;
            }
            default: {
                sender.sendMessage(ColorUtils.toComponent("&c\u1d1c\u0455\u1d00\u0262\u1d07: /" + label + " \u1d0d\u1d00\u026a\u0274\u1d1b\u1d07\u0274\u1d00\u0274\u1d04\u1d07 <on|off|status|setlobby [server]>"));
            }
        }
    }

    private record CommandEntry(String usage, String description) {
    }
}

