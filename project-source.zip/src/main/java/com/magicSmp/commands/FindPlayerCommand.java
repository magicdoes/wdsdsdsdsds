/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.World$Environment
 *  org.bukkit.block.Biome
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.utils.ColorUtils;
import com.bx.magicSmp.utils.PlayerLookup;
import java.util.Locale;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Biome;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class FindPlayerCommand
implements CommandExecutor {
    private static final String DEFAULT_SPAWN = "&7{player}'s in the &bspawn";
    private static final String DEFAULT_OVERWORLD = "&7{player}'s in the &boverworld &7(&b{biome}&7)";
    private static final String DEFAULT_NETHER = "&7{player}'s in the &bnether &7(&b{biome}&7)";
    private static final String DEFAULT_THE_END = "&7{player}'s in the &bthe end &7(&b{biome}&7)";
    private static final String DEFAULT_UNKNOWN = "&7{player}'s in the &b{world}";
    private final MagicSmp plugin;

    public FindPlayerCommand(MagicSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u1d0f\u0274\u029f\u028f.");
            return true;
        }
        Player player = (Player)sender;
        if (args.length == 0) {
            player.sendMessage(ColorUtils.toComponent("&c\u1d1c\u0455\u1d00\u0262\u1d07: /findplayer <player>"));
            return true;
        }
        Player target = PlayerLookup.findOnlinePlayer(args[0]);
        if (target == null) {
            player.sendMessage(ColorUtils.toComponent("&c\u1d18\u029f\u1d00\u028f\u1d07\u0280 \u0274\u1d0f\u1d1b \u1d0f\u0274\u029f\u026a\u0274\u1d07."));
            return true;
        }
        LocationMessage locationMessage = this.resolveLocationMessage(target);
        String msg = this.plugin.getConfigManager().getMessageOrDefault(locationMessage.key(), locationMessage.fallback(), "{player}", target.getName(), "{world}", this.friendlyWorldName(target.getWorld()), "{biome}", this.formatBiome(target.getLocation()));
        player.sendMessage(ColorUtils.toComponent(msg));
        return true;
    }

    private LocationMessage resolveLocationMessage(Player target) {
        if (this.plugin.getSpawnManager().isInSpawnCuboid(target)) {
            return new LocationMessage("FINDPLAYER.SPAWN", DEFAULT_SPAWN);
        }
        World world = target.getWorld();
        if (world == null) {
            return new LocationMessage("FINDPLAYER.UNKNOWN", DEFAULT_UNKNOWN);
        }
        return switch (world.getEnvironment()) {
            default -> throw new MatchException(null, null);
            case World.Environment.NORMAL -> new LocationMessage("FINDPLAYER.OVERWORLD", DEFAULT_OVERWORLD);
            case World.Environment.NETHER -> new LocationMessage("FINDPLAYER.NETHER", DEFAULT_NETHER);
            case World.Environment.THE_END -> new LocationMessage("FINDPLAYER.THE_END", DEFAULT_THE_END);
            case World.Environment.CUSTOM -> new LocationMessage("FINDPLAYER.UNKNOWN", DEFAULT_UNKNOWN);
        };
    }

    private String friendlyWorldName(World world) {
        if (world == null) {
            return "unknown";
        }
        return switch (world.getEnvironment()) {
            default -> throw new MatchException(null, null);
            case World.Environment.NORMAL -> "overworld";
            case World.Environment.NETHER -> "nether";
            case World.Environment.THE_END -> "the end";
            case World.Environment.CUSTOM -> this.formatIdentifier(world.getName());
        };
    }

    private String formatBiome(Location location) {
        if (location == null || location.getWorld() == null) {
            return "unknown";
        }
        Biome biome = location.getBlock().getBiome();
        if (biome == null) {
            return "unknown";
        }
        return this.formatIdentifier(biome.getKey().getKey());
    }

    private String formatIdentifier(String value) {
        if (value == null || value.isBlank()) {
            return "unknown";
        }
        String normalized = value;
        int namespaceSeparator = normalized.indexOf(58);
        if (namespaceSeparator >= 0 && namespaceSeparator + 1 < normalized.length()) {
            normalized = normalized.substring(namespaceSeparator + 1);
        }
        normalized = normalized.replace('-', '_').replace(' ', '_').toLowerCase(Locale.ROOT);
        String[] parts = normalized.split("_+");
        StringBuilder builder = new StringBuilder();
        for (String part : parts) {
            if (part.isBlank()) continue;
            if (!builder.isEmpty()) {
                builder.append(' ');
            }
            builder.append(Character.toUpperCase(part.charAt(0)));
            if (part.length() <= 1) continue;
            builder.append(part.substring(1));
        }
        return builder.isEmpty() ? "unknown" : builder.toString();
    }

    private record LocationMessage(String key, String fallback) {
    }
}

