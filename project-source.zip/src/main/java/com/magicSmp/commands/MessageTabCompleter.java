/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.util.StringUtil
 */
package com.bx.magicSmp.commands;

import com.bx.magicSmp.MagicSmp;
import com.bx.magicSmp.utils.PlayerLookup;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.util.StringUtil;

public class MessageTabCompleter
implements TabCompleter {
    private final MagicSmp plugin;

    public MessageTabCompleter(MagicSmp plugin) {
        this.plugin = plugin;
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (alias.equalsIgnoreCase("reply") || alias.equalsIgnoreCase("r") || args.length != 1) {
            return Collections.emptyList();
        }
        ArrayList<String> completions = new ArrayList<String>();
        for (String name : PlayerLookup.onlineNames()) {
            Player player = PlayerLookup.findOnlinePlayer(name);
            if (player != null && sender instanceof Player) {
                Player senderPlayer = (Player)sender;
                if (player.getUniqueId().equals(senderPlayer.getUniqueId())) continue;
            }
            completions.add(name);
        }
        ArrayList<String> matches = new ArrayList<String>();
        StringUtil.copyPartialMatches((String)args[0], completions, matches);
        matches.sort(String.CASE_INSENSITIVE_ORDER);
        return matches;
    }
}

