/*
 * Decompiled with CFR 0.152.
 */
package com.bx.magicSmp.freeze;

import java.util.UUID;
import org.bukkit.Location;

public final class FreezeSession {
    private final UUID targetUuid;
    private Location anchorLocation;
    private long lastAlertSentAt;
    private long lastReminderSentAt;

    public FreezeSession(UUID targetUuid, Location anchorLocation) {
        this.targetUuid = targetUuid;
        this.anchorLocation = anchorLocation == null ? null : anchorLocation.clone();
        this.lastAlertSentAt = 0L;
        this.lastReminderSentAt = 0L;
    }

    public UUID getTargetUuid() {
        return this.targetUuid;
    }

    public Location getAnchorLocation() {
        return this.anchorLocation == null ? null : this.anchorLocation.clone();
    }

    public void setAnchorLocation(Location anchorLocation) {
        this.anchorLocation = anchorLocation == null ? null : anchorLocation.clone();
    }

    public boolean shouldSendAlert(long now, long cooldownMillis) {
        return cooldownMillis <= 0L || now - this.lastAlertSentAt >= cooldownMillis;
    }

    public void markAlertSent(long now) {
        this.lastAlertSentAt = now;
    }

    public boolean shouldSendReminder(long now, long cooldownMillis) {
        return cooldownMillis <= 0L || now - this.lastReminderSentAt >= cooldownMillis;
    }

    public void markReminderSent(long now) {
        this.lastReminderSentAt = now;
    }
}

